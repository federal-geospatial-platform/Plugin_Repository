"""
File Import Handler

Handles Excel, CSV, PostgreSQL, and QGIS layer imports.
"""

import csv
import os
import requests
from datetime import date
import uuid
from qgis.PyQt import QtWidgets
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtCore import QVariant
from qgis.core import (
    Qgis, QgsProject, QgsVectorLayer, QgsWkbTypes, QgsField, QgsFields,
    QgsFeature, QgsGeometry, QgsVectorFileWriter, QgsCoordinateTransformContext
)

from ..data_loaders import DataLoader, DataLoadError
from ..table_dialog import DataTableDialog
from ..utils import (
    select_file, select_folder, create_timestamped_copy, show_error_message,
    show_info_message, show_warning_message, log_message, ProgressTracker, coordinate_errors
)


class FileImportHandler:
    """
    Handles importing data from various sources (Excel, CSV, PostgreSQL, QGIS layers).
    """
    
    def __init__(self, parent_widget):
        """
        Initialize file import handler.
        
        :param parent_widget: Parent widget (usually the dockwidget)
        """
        self.parent = parent_widget

    @staticmethod
    def _is_empty_value(value):
        return value is None or str(value).strip().lower() in ('', 'null', '<null>')

    @classmethod
    def _join_key(cls, value):
        if cls._is_empty_value(value):
            return ''
        return str(value).strip().casefold()

    def _warn_import_coordinates(self, data_dict):
        headers = data_dict.get('headers', [])
        columns = {str(header).strip().lower(): index
                   for index, header in enumerate(headers) if header}
        if not {'latitude', 'longitude'} & columns.keys():
            return
        problems = []
        missing = [name for name in ('latitude', 'longitude') if name not in columns]
        if missing:
            problems.append(f"Missing coordinate column(s): {', '.join(missing)}")
        else:
            source_rows = data_dict.get('source_row_numbers', [])
            for index, row in enumerate(data_dict.get('data', [])[1:], start=1):
                def value(name):
                    column = columns.get(name)
                    return row[column] if column is not None and column < len(row) else None

                errors = coordinate_errors(value('latitude'), value('longitude'))
                if not errors:
                    continue
                number = source_rows[index] if index < len(source_rows) else index + 1
                label = f"Row {number}"
                if value('source_layer'):
                    label += f" ({value('source_layer')}"
                    for field in ('xlsx_row_id', 'objectid_points', 'source_record_id'):
                        if not self._is_empty_value(value(field)):
                            label += f", {field}={value(field)}"
                            break
                    label += ")"
                problems.append(f"{label}: {'; '.join(errors)}.")
        if problems:
            message = (
                "The file was imported, but some coordinates cannot be used to create "
                "points within Canada:\n\n" + '\n'.join(problems) + "\n\n"
                "Please update the latitude and/or longitude values in the source file and "
                "re-import it. These fields cannot be edited directly in the Toponyms Manager plugin."
            )
            show_warning_message(self.parent, "Batch Load Coordinate Problems", message)
            log_message(message, Qgis.Warning)
    
    def import_batch_load_file(self):
        """
        Entry point for the 'Import Batch Load file' button.
        Asks the user what type of file to import (Excel, CSV, File Geodatabase,
        or an already-processed GeoPackage), then dispatches to the appropriate importer.
        """
        self._add_cbmt_basemap_if_needed()

        file_type, ok = QtWidgets.QInputDialog.getItem(
            self.parent,
            "Select File Type",
            "What type of file do you want to import?",
            [
                "Excel Template (.xlsx)", "CSV Batch Load File (.csv)",
                "File Geodatabase (.gdb)", "Processed GeoPackage (.gpkg)"
            ],
            0,
            False
        )
        
        if not ok:
            return False  # User cancelled
        
        if file_type.startswith("File Geodatabase"):
            return bool(self.import_gdb_file())
        elif file_type.startswith("Processed GeoPackage"):
            return bool(self.import_processed_gpkg_file())
        else:
            return bool(self.import_batch_table_file())

    def import_batch_load_path(self, file_path):
        """Import a known batch-load path without file-type or file-selection dialogs."""
        extension = os.path.splitext(file_path)[1].lower()
        if extension not in ('.xlsx', '.csv', '.gdb', '.fgdb', '.gpkg'):
            show_error_message(self.parent, "Import Error", f"Unsupported batch load file: {file_path}")
            log_message(f"Unsupported batch load file: {file_path}", Qgis.Critical)
            return

        self._add_cbmt_basemap_if_needed()
        if extension in ('.gdb', '.fgdb'):
            imported = self.import_gdb_file(file_path)
        elif extension == '.gpkg':
            imported = self.import_processed_gpkg_file(file_path)
        else:
            imported = self.import_batch_table_file(file_path)
        coordinate_handler = getattr(self.parent, 'coordinate_layer_handler', None)
        if imported and extension == '.csv' and coordinate_handler is not None:
            coordinate_handler.add_coordinate_as_layer(silent=True)

    @staticmethod
    def _add_cbmt_basemap_if_needed():
        """Add the Canada Basemap - Transportation (CBMT, EPSG:3857) if not already in the project."""
        style_url = (
            "https://arcgis.com/sharing/rest/content/items/"
            "800d755712e8415aab301b9d55bc2800/resources/styles/root.json"
        )
        layer_name = "CBMT Basemap"
        project = QgsProject.instance()

        for layer in project.mapLayers().values():
            if layer.name() == layer_name:
                if layer.isValid():
                    layer_tree_layer = project.layerTreeRoot().findLayer(layer.id())
                    if layer_tree_layer:
                        layer_tree_layer.setItemVisibilityChecked(True)
                    return
                project.removeMapLayer(layer.id())

        try:
            response = requests.get(style_url, timeout=10)
            response.raise_for_status()
            style = response.json()
        except Exception as e:
            log_message(f"Could not fetch CBMT basemap style: {str(e)}", Qgis.Warning)
            return

        sources = style.get('sources', {})
        source_info = next(iter(sources.values()), None)
        if not source_info:
            log_message("CBMT basemap style has no tile source defined", Qgis.Warning)
            return

        tile_urls = source_info.get('tiles') or []
        tile_url = tile_urls[0] if tile_urls else None
        if not tile_url:
            service_url = source_info.get('url', '').rstrip('/')
            tile_url = f"{service_url}/tile/{{z}}/{{y}}/{{x}}.pbf" if service_url else None
        if not tile_url:
            log_message("CBMT basemap style source has no tile URL", Qgis.Warning)
            return

        zmin = source_info.get('minzoom', 0)
        zmax = source_info.get('maxzoom', 22)

        from qgis.core import QgsVectorTileLayer
        source = f"type=xyz&url={tile_url}&zmin={zmin}&zmax={zmax}"
        basemap_layer = QgsVectorTileLayer(source, layer_name)
        if not basemap_layer.isValid():
            log_message("Failed to create CBMT vector-tile basemap layer", Qgis.Warning)
            return

        FileImportHandler._apply_cbmt_basemap_style(basemap_layer, style)
        project.addMapLayer(basemap_layer, True)
        log_message("CBMT vector-tile basemap added successfully", Qgis.Success)

    @staticmethod
    def _apply_cbmt_basemap_style(layer, style):
        """Convert the CBMT Mapbox GL style JSON into a QGIS renderer and labeling."""
        try:
            from qgis.core import QgsMapBoxGlStyleConverter

            converter = QgsMapBoxGlStyleConverter()
            converter.convert(style)
            if converter.errorMessage():
                log_message(f"CBMT basemap style conversion error: {converter.errorMessage()}", Qgis.Warning)

            renderer = converter.renderer()
            if renderer:
                layer.setRenderer(renderer)
            labeling = converter.labeling()
            if labeling:
                layer.setLabeling(labeling)
                layer.setLabelsEnabled(True)
        except Exception as e:
            log_message(f"Could not apply CBMT basemap style: {str(e)}", Qgis.Warning)

    def import_gdb_file(self, gdb_path=None):
        """
        Transform a File Geodatabase into the processed batch-load GDB.
        """
        try:
            if gdb_path is None:
                gdb_path = select_folder(
                    parent=self.parent,
                    title="Select File Geodatabase (.gdb) Folder"
                )
            
            if not gdb_path:
                return  # User cancelled
            
            if not gdb_path.lower().endswith(('.gdb', '.fgdb')):
                show_warning_message(
                    self.parent,
                    "Unexpected Folder",
                    "The selected folder doesn't end in '.gdb'. Attempting to load it anyway."
                )
            
            # Probe the geodatabase to list its feature classes (sublayers)
            probe_layer = QgsVectorLayer(gdb_path, "probe", "ogr")
            sub_layers = probe_layer.dataProvider().subLayers() if probe_layer.isValid() else []
            
            if not sub_layers:
                show_error_message(
                    self.parent,
                    "Import Error",
                    "No feature classes were found in the selected geodatabase."
                )
                return
            
            # Sublayer strings are separated with QGIS's SUBLAYER_SEPARATOR (or ':' on older versions),
            # e.g. "0!!::!!layerName!!::!!123!!::!!Point"
            from qgis.core import QgsDataProvider
            separator = getattr(QgsDataProvider, 'SUBLAYER_SEPARATOR', '!!::!!')
            layer_names = []
            for entry in sub_layers:
                parts = entry.split(separator) if separator in entry else entry.split(':')
                layer_names.append(parts[1] if len(parts) > 1 else entry)
            
            source_layers = {}
            for name in ('names_6', 'points_0', 'lines_1', 'polygons_2'):
                layer = QgsVectorLayer(f"{gdb_path}|layername={name}", name, "ogr")
                if layer.isValid():
                    source_layers[name] = layer
            missing = sorted(set(('names_6', 'points_0', 'lines_1', 'polygons_2')) - set(source_layers))
            if missing:
                raise DataLoadError(f"The GDB is missing required layer(s): {', '.join(missing)}")

            output_path = self._processed_output_path(gdb_path)
            output_layers, error_count, excluded_matches = self._process_gdb(source_layers, output_path)
            self.parent.excluded_geometry_edits = excluded_matches
            if not output_layers:
                raise DataLoadError("No processed output layers were created.")

            self.parent.batch_load_file_path = output_path
            self.parent.batch_load_sheet_name = 'names_6'
            self.parent.batch_load_source_path = gdb_path
            for layer in output_layers:
                QgsProject.instance().addMapLayer(layer)
                if layer.name() == 'points_0':
                    self.parent.processed_points_layer = layer
                    self.parent.coordinate_layer_handler._apply_point_layer_style(
                        layer, [field.name() for field in layer.fields()], purple=True
                    )
                elif layer.name() in ('lines_1', 'polygons_2'):
                    self.parent.coordinate_layer_handler._apply_processed_geometry_style(layer)

            self.parent.coordinate_layer_handler._offer_zoom_to_layers(output_layers)

            names_layer = next((layer for layer in output_layers if layer.name() == 'names_6'), None)
            points_layer = next((layer for layer in output_layers if layer.name() == 'points_0'), None)
            if names_layer and points_layer:
                data_dict = self._combined_names_points_table(names_layer, points_layer)
                self._show_data_table(data_dict)
                self._warn_import_coordinates(data_dict)
            elif names_layer:
                data_dict = DataLoader.load_qgis_layer(names_layer.source())
                self._show_data_table(data_dict, layer=names_layer)
                self._warn_import_coordinates(data_dict)

            show_info_message(
                self.parent,
                "GDB Processed",
                f"Created processed GDB:\n{output_path}\n\n"
                f"Output layers: {', '.join(layer.name() for layer in output_layers)}\n"
                f"Records routed to error: {error_count}"
            )
            log_message(f"Created processed GDB: {output_path}", Qgis.Success)
            return True
            
        except Exception as e:
            show_error_message(self.parent, "Import Error", f"Failed to import geodatabase:\n{str(e)}")
            log_message(f"GDB import error: {str(e)}", Qgis.Critical)
            return False

    def import_processed_gpkg_file(self, gpkg_path=None):
        """
        Re-open a previously processed batch-load GeoPackage (e.g. one saved before sending
        it for processing) with the same layers, styling, and table view as a fresh GDB import.
        """
        try:
            if gpkg_path is None:
                gpkg_path = select_file(
                    parent=self.parent,
                    title="Select Processed GeoPackage",
                    file_filter="GeoPackage (*.gpkg);;All Files (*.*)"
                )

            if not gpkg_path:
                return  # User cancelled

            source_layers = {}
            for name in ('names_6', 'points_0', 'lines_1', 'polygons_2'):
                layer = QgsVectorLayer(f"{gpkg_path}|layername={name}", name, "ogr")
                if layer.isValid():
                    source_layers[name] = layer
            if 'names_6' not in source_layers:
                raise DataLoadError("The GeoPackage is missing required layer(s): names_6")

            output_layers = list(source_layers.values())

            self.parent.batch_load_file_path = gpkg_path
            self.parent.batch_load_sheet_name = 'names_6'
            self.parent.batch_load_source_path = gpkg_path
            for layer in output_layers:
                QgsProject.instance().addMapLayer(layer)
                if layer.name() == 'points_0':
                    self.parent.processed_points_layer = layer
                    self.parent.coordinate_layer_handler._apply_point_layer_style(
                        layer, [field.name() for field in layer.fields()], purple=True
                    )
                elif layer.name() in ('lines_1', 'polygons_2'):
                    self.parent.coordinate_layer_handler._apply_processed_geometry_style(layer)

            names_layer = source_layers['names_6']
            points_layer = source_layers.get('points_0')
            if points_layer:
                data_dict = self._combined_names_points_table(names_layer, points_layer)
                self._show_data_table(data_dict)
            else:
                data_dict = DataLoader.load_qgis_layer(names_layer.source())
                self._show_data_table(data_dict, layer=names_layer)
            self._warn_import_coordinates(data_dict)

            show_info_message(
                self.parent,
                "Processed GeoPackage Loaded",
                f"Reopened processed GeoPackage:\n{gpkg_path}\n\n"
                f"Output layers: {', '.join(layer.name() for layer in output_layers)}"
            )
            log_message(f"Reopened processed GeoPackage: {gpkg_path}", Qgis.Success)
            coordinate_handler = getattr(self.parent, 'coordinate_layer_handler', None)
            if coordinate_handler is not None:
                coordinate_handler.add_coordinate_as_layer(silent=True)
                coordinate_layer = getattr(self.parent, 'coordinate_layer', None)
                try:
                    error_data = DataLoader.load_qgis_layer(f"{gpkg_path}|layername=error")
                except DataLoadError:
                    error_data = None
                if error_data is not None:
                    self._build_error_source_layers(error_data)
                error_layers = list((getattr(self.parent, 'error_source_layers', None) or {}).values())
                coordinate_handler._offer_zoom_to_layers(output_layers + [coordinate_layer] + error_layers)
            return True

        except Exception as e:
            show_error_message(self.parent, "Import Error", f"Failed to import processed GeoPackage:\n{str(e)}")
            log_message(f"Processed GeoPackage import error: {str(e)}", Qgis.Critical)
            return False

    def import_workspace_error_gpkg(self, gpkg_path):
        """Keep local processing errors alongside records returned by the batch workspace."""
        current_path = self.parent.batch_load_file_path
        previous_source = getattr(self.parent, 'batch_load_source_path', None) or ''
        previous_output = (
            self._processed_output_path(previous_source)
            if previous_source.lower().endswith(('.gdb', '.fgdb')) else None
        )
        for dialog_attr in ('current_table_dialog', 'error_table_dialog'):
            dialog = getattr(self.parent, dialog_attr, None)
            if dialog is not None and not dialog.prepare_for_replacement():
                return False
        returned_names = DataLoader.load_qgis_layer(f"{gpkg_path}|layername=names_6")
        datasets = []
        if current_path and current_path.lower().endswith(('.gdb', '.fgdb')):
            current_path = self._processed_output_path(current_path)
        for path, origin in ((current_path, 'local'), (gpkg_path, 'batch_load')):
            if not path:
                continue
            error_layer = QgsVectorLayer(f"{path}|layername=error", 'error', 'ogr')
            if error_layer.isValid():
                datasets.append((DataLoader.load_qgis_layer(error_layer.source()), origin, False))
        datasets.append((returned_names, 'batch_load', True))

        headers = ['source_layer', 'source_record_id', 'error', 'error_origin']
        records = []
        for data, origin, is_names in datasets:
            columns = [str(header).casefold() for header in data['headers']]
            for column in columns:
                if column != 'fid' and column not in headers:
                    headers.append(column)
            for values in data['data'][1:]:
                record = dict(zip(columns, values))
                record.pop('fid', None)
                record.setdefault('error_origin', origin)
                if is_names:
                    record['source_layer'] = 'names_6'
                    record.setdefault('source_record_id', record.get('xlsx_row_id', ''))
                records.append(record)

        fields = QgsFields()
        for header in headers:
            fields.append(QgsField(header, QVariant.String))
        merged_rows = [[record.get(header) for header in headers] for record in records]
        error_layer = None
        self._write_table(gpkg_path, 'error', fields, merged_rows)
        self._build_error_source_layers({'headers': headers, 'data': [headers] + merged_rows})
        error_sources = getattr(self.parent, 'error_source_layers', None) or {}
        for name, layer in error_sources.items():
            self._write_vector(
                gpkg_path, f'{name}_error', layer.fields(), list(layer.getFeatures()),
                layer.wkbType(), layer.crs()
            )
        self.parent.coordinate_layer_handler.remove_layers(remove_basemap=False)
        if previous_output:
            project = QgsProject.instance()
            for layer in list(project.mapLayers().values()):
                path = layer.source().split('|', 1)[0]
                if os.path.normcase(os.path.normpath(path)) == os.path.normcase(os.path.normpath(previous_output)):
                    project.removeMapLayer(layer.id())
        self.parent.excluded_geometry_edits = {}
        for dialog_attr in ('current_table_dialog', 'error_table_dialog'):
            dialog = getattr(self.parent, dialog_attr, None)
            if dialog is not None:
                dialog.close()
                setattr(self.parent, dialog_attr, None)
        if not self.import_processed_gpkg_file(gpkg_path):
            return False
        self.parent.batch_load_source_path = gpkg_path
        self.open_error_table()
        return True

    def reprocess_gdb_file(self):
        """
        Re-run GDB processing from the original source (e.g. after correcting a
        toponymic_feature_id in the error table so it now matches names_6). Attribute edits
        (on already-processed and still-erroring records) and the points_0 geosys (1347)
        columns are preserved by OBJECTID, since source_record_id/toponymic_feature_id are
        often empty on exactly the records that needed a manual fix. Only geosys values still
        missing after that are (re)loaded.
        """
        source_path = getattr(self.parent, 'batch_load_source_path', None)
        if not source_path or not source_path.lower().endswith(('.gdb', '.fgdb')):
            show_warning_message(
                self.parent,
                "Reprocess Unavailable",
                "Reprocessing requires an active original File Geodatabase. "
                "A returned error GeoPackage is a partial batch and cannot rebuild that GDB. "
                "Correct the errors and run the batch workspace again."
            )
            return

        reply = QtWidgets.QMessageBox.question(
            self.parent,
            "Reprocess File",
            "This regenerates names_6, points_0, lines_1, polygons_2, and the error table "
            "from the original geodatabase. Continue?",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
            QtWidgets.QMessageBox.No
        )
        if reply != QtWidgets.QMessageBox.Yes:
            return

        # Close the related-features dock first (prompting to save/discard unsaved edits)
        # so any last-minute correction is captured before the source is reprocessed.
        for dialog_attr in ('current_table_dialog', 'error_table_dialog'):
            dialog = getattr(self.parent, dialog_attr, None)
            if dialog is not None and not dialog.prepare_for_replacement():
                return

        try:
            output_path = self._processed_output_path(source_path)
            self.synchronize_original_names(output_path)
            preserved_geosys = self._capture_points_0_geosys(output_path)
            preserved_names_geosys = self._capture_names_6_geosys(output_path)
            preserved_names_edits = self._capture_names_6_edits(output_path, 'original_names_6')
            for row_id, values in self._capture_names_6_edits(output_path).items():
                preserved_names_edits.setdefault(row_id, {}).update(values)
            snapshot_fields = list(QgsVectorLayer(
                f'{output_path}|layername=original_names_6', 'snapshot', 'ogr'
            ).fields())
            preserved_edits = {
                name: self._capture_layer_attribute_edits(output_path, name)
                for name in ('points_0', 'lines_1', 'polygons_2')
            }
            log_message(
                f"Reprocess: captured from processed GPKG - "
                + ', '.join(f"{name}={sorted(captured.keys())}" for name, captured in preserved_edits.items()),
                Qgis.Info
            )
            log_message(f"Reprocess: captured points_0 geosys objectids={sorted(preserved_geosys.keys())}", Qgis.Info)
            log_message(f"Reprocess: captured names_6 geosys xlsx_row_ids={sorted(preserved_names_geosys.keys())}", Qgis.Info)

            # Fold in edits on records that matched a names_6 record but were legitimately
            # excluded from their layer's own output (e.g. a points_0 feature whose names_6
            # record has a new_name, so it belongs to lines_1/polygons_2 instead). Such records
            # never appear in the processed GPKG, so without this persistent cache a manual fix
            # would have nowhere to be read back from on the *next* reprocess and would revert.
            excluded_geometry_edits = getattr(self.parent, 'excluded_geometry_edits', None) or {}
            for name in ('points_0', 'lines_1', 'polygons_2'):
                if excluded_geometry_edits.get(name):
                    merged = dict(excluded_geometry_edits[name])
                    merged.update(preserved_edits.get(name, {}))
                    preserved_edits[name] = merged
            log_message(
                f"Reprocess: merged persisted excluded-match edits - "
                + ', '.join(f"{name}={sorted(excluded_geometry_edits.get(name, {}).keys())}" for name in ('points_0', 'lines_1', 'polygons_2')),
                Qgis.Info
            )

            # Fold in edits made via the error table's related-features dock (memory-only
            # copies of records that errored out and so aren't in the processed GPKG yet).
            # Both dicts are keyed by OBJECTID, so they merge without overlap (a record can't
            # be both currently processed and currently erroring at the same time).
            error_source_layers = getattr(self.parent, 'error_source_layers', None) or {}
            for name, layer in error_source_layers.items():
                error_edits = self._capture_memory_layer_edits(layer)
                log_message(
                    f"Reprocess: captured from {name}_error layer - objectids={sorted(error_edits.keys())}",
                    Qgis.Info
                )
                if name in preserved_edits:
                    preserved_edits[name].update(error_edits)
            log_message(
                f"Reprocess: merged edits to reapply - "
                + ', '.join(f"{name}={sorted(captured.keys())}" for name, captured in preserved_edits.items()),
                Qgis.Info
            )

            source_layers = {}
            for name in ('names_6', 'points_0', 'lines_1', 'polygons_2'):
                layer = QgsVectorLayer(f"{source_path}|layername={name}", name, "ogr")
                if layer.isValid():
                    source_layers[name] = layer
            missing = sorted(set(('names_6', 'points_0', 'lines_1', 'polygons_2')) - set(source_layers))
            if missing:
                raise DataLoadError(f"The GDB is missing required layer(s): {', '.join(missing)}")

            for name, captured in preserved_edits.items():
                if name in source_layers:
                    applied = self._apply_captured_edits_by_id(source_layers[name], captured)
                    log_message(f"Reprocess: applied {applied}/{len(captured)} edits onto raw {name}", Qgis.Info)
            applied = self._apply_names_6_edits(source_layers['names_6'], preserved_names_edits, snapshot_fields)
            log_message(f"Reprocess: applied {applied}/{len(preserved_names_edits)} edits onto raw names_6", Qgis.Info)

            if self.parent.current_table_dialog is not None:
                self.parent.current_table_dialog.close()
                self.parent.current_table_dialog = None
            if self.parent.error_table_dialog is not None:
                self.parent.error_table_dialog.close()
                self.parent.error_table_dialog = None
            # Remember which "Add coordinates as layer"/"Load GeoSys points" layers existed so
            # they can be recreated afterward (remove_layers() strips them, and the underlying
            # data may have changed).
            had_coordinate_layer = getattr(self.parent, 'coordinate_layer', None) is not None
            had_geosys_layers = (
                getattr(self.parent, 'geosys_layer', None) is not None or
                getattr(self.parent, 'geosys_layer_points_0', None) is not None
            )
            self.parent.coordinate_layer_handler.remove_layers()
            self._add_cbmt_basemap_if_needed()  # remove_layers() also strips the basemap

            output_layers, error_count, excluded_matches = self._process_gdb(source_layers, output_path)
            if not output_layers:
                raise DataLoadError("No processed output layers were created.")

            merged_excluded = getattr(self.parent, 'excluded_geometry_edits', None) or {}
            for name in ('points_0', 'lines_1', 'polygons_2'):
                merged_excluded.setdefault(name, {}).update(excluded_matches.get(name, {}))
            self.parent.excluded_geometry_edits = merged_excluded

            for layer in source_layers.values():
                if layer.isEditable():
                    layer.rollBack()  # discard the in-memory edits; the raw .gdb is never modified

            self.parent.batch_load_file_path = output_path
            self.parent.batch_load_sheet_name = 'names_6'
            self.parent.batch_load_source_path = source_path
            for layer in output_layers:
                QgsProject.instance().addMapLayer(layer)
                if layer.name() == 'points_0':
                    self.parent.processed_points_layer = layer
                    self.parent.coordinate_layer_handler._apply_point_layer_style(
                        layer, [field.name() for field in layer.fields()], purple=True
                    )
                elif layer.name() in ('lines_1', 'polygons_2'):
                    self.parent.coordinate_layer_handler._apply_processed_geometry_style(layer)

            if preserved_geosys:
                points_dict = self.parent.coordinate_layer_handler._load_points_0_as_data()
                points_headers = points_dict.get('headers', [])
                points_rows = points_dict.get('data', [])
                log_message(
                    f"Reprocess: reapplying geosys, points_0 has {max(len(points_rows) - 1, 0)} row(s), "
                    f"headers include objectid_points={('objectid_points' in [str(h).lower() for h in points_headers])}",
                    Qgis.Info
                )
                if points_rows and len(points_rows) > 1:
                    self.parent.coordinate_layer_handler._populate_geosys_columns(
                        points_headers, points_rows, allow_add_point=True, preserved_by_key=preserved_geosys
                    )
                    self.parent.coordinate_layer_handler._update_points_0_geosys_attributes(points_headers, points_rows)
            else:
                log_message("Reprocess: no preserved geosys values captured (preserved_geosys was empty)", Qgis.Info)

            if preserved_names_geosys:
                names_dict = self.parent.coordinate_layer_handler._load_batch_data()
                names_headers = names_dict.get('headers', [])
                names_rows = names_dict.get('data', [])
                if names_rows and len(names_rows) > 1:
                    self.parent.coordinate_layer_handler._populate_geosys_columns(
                        names_headers, names_rows, preserved_by_key=preserved_names_geosys, key_header='xlsx_row_id'
                    )
                    # Without this write-back, names_6's geosys fields stay unset in the new
                    # GPKG, so the *next* reprocess would find nothing to capture and the
                    # dragged point would revert to its API-derived position.
                    self.parent.coordinate_layer_handler._update_names_6_geosys_attributes(names_headers, names_rows)

            # Recreate any "Add coordinates as layer"/"Load GeoSys points" layers that existed
            # before, since remove_layers() stripped them and the underlying data may have
            # changed (e.g. records that used to error are now processed).
            if had_coordinate_layer:
                self.parent.coordinate_layer_handler.add_coordinate_as_layer(silent=True)
            if had_geosys_layers:
                self.parent.coordinate_layer_handler.load_geosys_point(
                    silent=True,
                    preserved_names_geosys=preserved_names_geosys,
                    preserved_points_geosys=preserved_geosys
                )

            self.synchronize_original_names(output_path)
            self.parent.coordinate_layer_handler._offer_zoom_to_layers(output_layers)

            names_layer = next((layer for layer in output_layers if layer.name() == 'names_6'), None)
            points_layer = next((layer for layer in output_layers if layer.name() == 'points_0'), None)
            if names_layer and points_layer:
                self._show_data_table(self._combined_names_points_table(names_layer, points_layer))
            elif names_layer:
                self._show_data_table(DataLoader.load_qgis_layer(names_layer.source()), layer=names_layer)

            show_info_message(
                self.parent,
                "File Reprocessed",
                f"Reprocessed geodatabase:\n{output_path}\n\n"
                f"Output layers: {', '.join(layer.name() for layer in output_layers)}\n"
                f"Records routed to error: {error_count}"
            )
            log_message(f"Reprocessed GDB: {output_path}", Qgis.Success)

        except Exception as e:
            show_error_message(self.parent, "Reprocess Error", f"Failed to reprocess the geodatabase:\n{str(e)}")
            log_message(f"Reprocess error: {str(e)}", Qgis.Critical)

    def synchronize_original_names(self, file_path):
        for layer in QgsProject.instance().mapLayers().values():
            source = layer.source().split('|', 1)[0]
            if os.path.normcase(os.path.normpath(source)) == os.path.normcase(os.path.normpath(file_path)):
                if layer.isEditable() and not layer.commitChanges():
                    raise DataLoadError(f"Could not save edits for '{layer.name()}': {'; '.join(layer.commitErrors())}")
        archive = QgsVectorLayer(f'{file_path}|layername=original_names_6', 'original_names_6', 'ogr')
        names = QgsVectorLayer(f'{file_path}|layername=names_6', 'names_6', 'ogr')
        if not archive.isValid() or not names.isValid():
            return
        key_index = self._field_index(names.fields(), 'xlsx_row_id')
        if key_index < 0:
            raise DataLoadError('Cannot synchronize original_names_6: names_6 has no xlsx_row_id.')
        archive.startEditing()
        if self._field_index(archive.fields(), 'xlsx_row_id') < 0:
            archive.addAttribute(QgsField('xlsx_row_id', QVariant.Int))
            archive.updateFields()
            archive_key = self._field_index(archive.fields(), 'xlsx_row_id')
            for row_id, feature in enumerate(archive.getFeatures(), start=1):
                archive.changeAttributeValue(feature.id(), archive_key, row_id)
        for field in names.fields():
            if field.name().lower() == 'fid':
                continue
            if self._field_index(archive.fields(), field.name()) < 0:
                archive.addAttribute(QgsField(field))
        archive.updateFields()
        archive_key = self._field_index(archive.fields(), 'xlsx_row_id')
        rows_by_key = {}
        for feature in names.getFeatures():
            try:
                rows_by_key[int(feature[key_index])] = feature
            except (TypeError, ValueError):
                continue
        for feature in archive.getFeatures():
            try:
                current = rows_by_key.get(int(feature[archive_key]))
            except (TypeError, ValueError):
                continue
            if current is None:
                continue
            for index, field in enumerate(names.fields()):
                if field.name().lower() in ('fid', 'xlsx_row_id', '_count'):
                    continue
                target = self._field_index(archive.fields(), field.name())
                archive.changeAttributeValue(feature.id(), target, current[index])
                raw_name = self._NAMES_6_RAW_FIELD.get(field.name().lower())
                raw_index = self._field_index(archive.fields(), raw_name) if raw_name else -1
                if raw_index >= 0:
                    archive.changeAttributeValue(feature.id(), raw_index, current[index])
        if not archive.commitChanges():
            errors = '; '.join(archive.commitErrors())
            archive.rollBack()
            raise DataLoadError(f'Could not synchronize original_names_6: {errors}')
        for layer in QgsProject.instance().mapLayers().values():
            if layer.source() == archive.source():
                layer.reload()
        log_message('Synchronized original_names_6 with current names_6 edits', Qgis.Success)

    @staticmethod
    def _objectid_base_name(layer_name):
        """Map a geometry layer name to the base used in its synthetic 'objectid_<base>' field."""
        return {'points_0': 'points', 'lines_1': 'lines', 'polygons_2': 'polygons'}.get(layer_name)

    @staticmethod
    def _capture_layer_attribute_edits(output_path, layer_name):
        """
        Read all current attribute values from a processed layer, keyed by its objectid_<base>
        field (the original raw OBJECTID value preserved during processing). This is more
        reliable than source_record_id/toponymic_feature_id, which are often empty on records
        that needed a manual fix, so user edits (e.g. a corrected toponymic_feature_id) survive
        reprocessing.
        """
        if not output_path or not os.path.exists(output_path):
            return {}

        layer = QgsVectorLayer(f"{output_path}|layername={layer_name}", layer_name, "ogr")
        if not layer.isValid():
            return {}

        base_name = FileImportHandler._objectid_base_name(layer_name)
        fields = layer.fields()
        objectid_idx = fields.indexOf(f'objectid_{base_name}') if base_name else -1
        if objectid_idx < 0:
            return {}

        captured = {}
        total_features = 0
        for feature in layer.getFeatures():
            total_features += 1
            try:
                objectid = int(feature[objectid_idx])
            except (TypeError, ValueError):
                continue
            captured[objectid] = {
                field.name(): feature[index] for index, field in enumerate(fields)
            }
        log_message(
            f"_capture_layer_attribute_edits({layer_name}): total_features={total_features}, "
            f"captured_objectids={sorted(captured.keys())}",
            Qgis.Info
        )
        return captured

    @staticmethod
    def _capture_memory_layer_edits(layer):
        """
        Read current attribute values from an in-memory error-source layer, keyed by the raw
        feature id it was cloned from (preserved via setId when the layer was built). Records
        that errored out often have an empty/wrong source_record_id or toponymic_feature_id -
        that's typically *why* they errored - so the feature id is the only reliable join key.
        """
        if layer is None or not layer.isValid():
            return {}

        fields = layer.fields()
        captured = {}
        for feature in layer.getFeatures():
            captured[feature.id()] = {
                field.name(): feature[index] for index, field in enumerate(fields)
            }
        return captured

    @staticmethod
    def _apply_captured_edits_by_id(source_layer, captured_edits):
        """
        Reapply previously edited attribute values onto matching raw features by their OBJECTID
        attribute value (not QGIS's internal feature id, which may not equal OBJECTID for some
        OGR/FileGDB providers - e.g. a 0-based FID vs a 1-based OBJECTID).
        """
        if not captured_edits:
            return 0

        fields = source_layer.fields()
        objectid_indexes = FileImportHandler._objectid_indexes(fields)
        objectid_index = min(objectid_indexes) if objectid_indexes else -1
        if objectid_index < 0:
            return 0

        if not source_layer.isEditable():
            source_layer.startEditing()
        applied = 0
        for feature in source_layer.getFeatures():
            try:
                objectid = int(feature[objectid_index])
            except (TypeError, ValueError):
                continue
            values = captured_edits.get(objectid)
            if not values:
                continue
            applied += 1
            for field_name, value in values.items():
                field_idx = fields.indexOf(field_name)
                if field_idx < 0:
                    continue
                if feature[field_idx] != value:
                    source_layer.changeAttributeValue(feature.id(), field_idx, value)
        return applied

    # Processed names_6 fields that don't map 1:1 onto a raw names_6 field.
    _NAMES_6_SKIP_FIELDS = {
        'fid', '_count', 'xlsx_row_id', 'latitude_geosys', 'longitude_geosys', 'source_pt_geosys', 'add_pt_geosys'
    }
    _NAMES_6_RAW_FIELD = {'decision_pdf': 'decision_pdf_filename'}

    @staticmethod
    def _capture_names_6_edits(output_path, layer_name='names_6'):
        """Read processed names_6 attributes keyed by xlsx_row_id (raw names_6 feature order)."""
        if not output_path or not os.path.exists(output_path):
            return {}
        layer = QgsVectorLayer(f"{output_path}|layername={layer_name}", layer_name, "ogr")
        if not layer.isValid():
            return {}
        fields = layer.fields()
        key_idx = fields.indexOf('xlsx_row_id')
        if key_idx < 0:
            return {}
        captured = {}
        for feature in layer.getFeatures():
            try:
                row_id = int(feature[key_idx])
            except (TypeError, ValueError):
                continue
            captured[row_id] = {
                field.name(): feature[index] for index, field in enumerate(fields)
                if field.name().lower() not in (
                    {'fid', '_count', 'xlsx_row_id'} if layer_name == 'original_names_6'
                    else FileImportHandler._NAMES_6_SKIP_FIELDS
                )
            }
        return captured

    @staticmethod
    def _apply_names_6_edits(source_layer, captured_edits, snapshot_fields=None):
        """Write captured names_6 values onto the raw layer's edit buffer, matched by feature order."""
        if not captured_edits:
            return 0
        raw_index = {field.name().lower(): index for index, field in enumerate(source_layer.fields())}
        if not source_layer.isEditable():
            source_layer.startEditing()
        for field in snapshot_fields or []:
            field_name = field.name().lower()
            raw_name = FileImportHandler._NAMES_6_RAW_FIELD.get(field_name, field_name)
            if field_name in {'fid', '_count', 'xlsx_row_id'} or raw_name in raw_index:
                continue
            copied_field = QgsField(field)
            copied_field.setName(raw_name)
            if not source_layer.addAttribute(copied_field):
                raise DataLoadError(f"Could not preserve names_6 column '{field.name()}' during reprocessing.")
            source_layer.updateFields()
            raw_index = {field.name().lower(): index for index, field in enumerate(source_layer.fields())}
        applied = 0
        for row_id, feature in enumerate(source_layer.getFeatures(), start=1):
            values = captured_edits.get(row_id)
            if not values:
                continue
            applied += 1
            for field_name, value in values.items():
                raw_name = FileImportHandler._NAMES_6_RAW_FIELD.get(field_name.lower(), field_name.lower())
                index = raw_index.get(raw_name)
                if index is None:
                    continue
                current = feature[index]
                if FileImportHandler._is_empty_value(current) and FileImportHandler._is_empty_value(value):
                    continue
                if current != value:
                    source_layer.changeAttributeValue(feature.id(), index, value)
        return applied

    @staticmethod
    def _capture_points_0_geosys(output_path):
        """Read current points_0 geosys (1347) values by objectid_points before reprocessing overwrites the file."""
        return FileImportHandler._capture_layer_geosys(output_path, 'points_0', 'objectid_points')

    @staticmethod
    def _capture_names_6_geosys(output_path):
        """Read current names_6 geosys values (only set once a geosys point is manually dragged) by xlsx_row_id."""
        return FileImportHandler._capture_layer_geosys(output_path, 'names_6', 'xlsx_row_id')

    @staticmethod
    def _capture_layer_geosys(output_path, layer_name, key_field):
        if not output_path or not os.path.exists(output_path):
            return {}

        layer = QgsVectorLayer(f"{output_path}|layername={layer_name}", layer_name, "ogr")
        if not layer.isValid():
            return {}

        fields = layer.fields()
        key_idx = fields.indexOf(key_field)
        geosys_columns = ('latitude_geosys', 'longitude_geosys', 'source_pt_geosys', 'add_pt_geosys')
        geosys_idx = {name: fields.indexOf(name) for name in geosys_columns}
        if key_idx < 0 or all(index < 0 for index in geosys_idx.values()):
            return {}

        preserved = {}
        for feature in layer.getFeatures():
            try:
                key_value = int(feature[key_idx])
            except (TypeError, ValueError):
                continue
            values = {name: (feature[index] if index >= 0 else None) for name, index in geosys_idx.items()}
            if any(not FileImportHandler._is_empty_value(value) for value in values.values()):
                preserved[key_value] = values
        return preserved

    @staticmethod
    def _processed_output_path(input_path):
        base = input_path.rstrip('\\/')
        if base.lower().endswith(('.gdb', '.fgdb', '.gpkg')):
            base = os.path.splitext(base)[0]
        return f"{base}_processed.gpkg"

    def _combined_names_points_table(self, names_layer, points_layer):
        """Build a display-only table containing all columns from names_6 and points_0."""
        names_headers = [field.name() for field in names_layer.fields()]
        points_headers = [field.name() for field in points_layer.fields()]
        headers = ['source_layer'] + names_headers[:]
        seen = {header.lower() for header in headers}
        for header in points_headers:
            if header.lower() not in seen:
                headers.append(header)
                seen.add(header.lower())
        data = [headers]

        for layer_name, layer in (('names_6', names_layer), ('points_0', points_layer)):
            layer_header_map = {field.name().lower(): field.name() for field in layer.fields()}
            for feature in layer.getFeatures():
                row = [layer_name]
                for header in headers[1:]:
                    source_header = layer_header_map.get(header.lower())
                    row.append(feature[source_header] if source_header else '')
                data.append(row)

        return {
            'type': 'combined_gdb_view',
            'source': f"{names_layer.source()} + {points_layer.source()}",
            'layer_name': 'names_6 + points_0',
            'sheet_name': 'names_6 + points_0',
            'headers': headers,
            'data': data,
            'row_count': len(data),
            'column_count': len(headers),
            'read_only': True
        }

    def _combined_names_points_data(self, names_dict, points_dict):
        """Build a display-only table containing all columns from names_6 and points_0 data dictionaries."""
        names_headers = names_dict.get('headers', [])
        points_headers = points_dict.get('headers', [])
        headers = ['source_layer'] + names_headers[:]
        seen = {str(header).lower() for header in headers}
        for header in points_headers:
            if str(header).lower() not in seen:
                headers.append(header)
                seen.add(str(header).lower())

        data = [headers]
        for layer_name, data_dict in (('names_6', names_dict), ('points_0', points_dict)):
            source_headers = data_dict.get('headers', [])
            source_map = {str(header).lower(): index for index, header in enumerate(source_headers)}
            for source_row in data_dict.get('data', [])[1:]:
                row = [layer_name]
                for header in headers[1:]:
                    source_index = source_map.get(str(header).lower())
                    row.append(source_row[source_index] if source_index is not None and source_index < len(source_row) else '')
                data.append(row)

        return {
            'type': 'combined_gdb_view',
            'source': f"{names_dict.get('source', 'names_6')} + {points_dict.get('source', 'points_0')}",
            'layer_name': 'names_6 + points_0',
            'sheet_name': 'names_6 + points_0',
            'headers': headers,
            'data': data,
            'row_count': len(data),
            'column_count': len(headers),
            'read_only': True
        }

    def show_batch_data_table(self, names_dict, layer=None, points_dict=None):
        """Show the batch table, preserving points_0 rows for processed GDB/GPKG sources."""
        if points_dict:
            self._show_data_table(self._combined_names_points_data(names_dict, points_dict))
        else:
            self._show_data_table(names_dict, layer=layer)

    @staticmethod
    def _field_index(fields, name):
        wanted = name.lower()
        for index, field in enumerate(fields):
            if field.name().lower() == wanted:
                return index
        return -1

    @staticmethod
    def _objectid_indexes(fields):
        return {
            index for index, field in enumerate(fields)
            if field.name().strip().lower().startswith('objectid')
        }

    @staticmethod
    def _delineation_source_code(value):
        source_codes = {
            'NU-Department of Culture and Heritage': '1267',
            'Prince Edward Island-Department of Finance': '1269',
            'Yukon-Department of Tourism and Culture': '1272',
            'Parks Canada': '1258',
            'New Brunswick-Tourism, Culture and Heritage': '1263',
            'Nova Scotia-Department of Internal Services': '1266',
            'Quebec-Commission de Toponymie': '1270',
            'Atlas Large Scale Data': '1299',
            'Atlas Small Scale Data': '1301',
            'Canada Lands Administrative Boundaries': '1302',
            'National Defence': '1242',
            'Geobase Aboriginal Lands': '1303',
            'Geobase Geopolitical Boundaries': '1304',
            'Geobase Municipal Boundaries': '1305',
            'GNBC Digital Compilation': '1306',
            'National Hydro Network Non Validated Data': '1307',
            'National Hydro Network Validated Data': '1308',
            'Atlas Medium Scale Data': '1300',
            'CARTS Data': '1346',
            'Geographical Names Board of Canada': '1259',
            'AB-Ministry of Culture and Status of Women': '1260',
            'British Columbia-Tourism, Arts, Culture and Sport': '1261',
            'Indigenous Services Canada': '1241',
            'MB-Natural Resources and Northern Development': '1262',
            'Fisheries and Oceans Canada': '1243',
            'Ontario-Ministry of Natural Resources and Forestry': '1268',
            'NL-Forestry, Agriculture and Lands': '1264',
            'NT - Education Culture Employment': '1265',
            'Saskatchewan-Ministry of Parks, Culture and Sport': '1271',
            'Unsynchronized geosys geometries': '1369',
            'Synchronized geosys geometries': '1347',
            'Canadian Hydro Network value-added data': '1370',
            'Act of Parliament': '1368',
            'Environment and Climate Change Canada': '1385'
        }
        return source_codes.get(str(value or '').strip())

    def _process_gdb(self, source_layers, output_path):
        """Build the processed GDB, showing a progress dialog while it runs."""
        total = sum(
            max(source_layers[name].featureCount(), 0) * (2 if name == 'names_6' else 1)
            for name in ('names_6', 'points_0', 'lines_1', 'polygons_2')
        )
        progress = ProgressTracker(self.parent, "Processing batch load file", "Processing records...", total)
        try:
            return self._process_gdb_impl(source_layers, output_path, progress)
        finally:
            progress.close()

    def _process_gdb_impl(self, source_layers, output_path, progress):
        """Build the processed GDB using the workspace's normalization and routing rules."""
        if os.path.isdir(output_path):
            import shutil
            shutil.rmtree(output_path)
        elif os.path.isfile(output_path) and not output_path.lower().endswith('.gpkg'):
            os.remove(output_path)

        names_layer = source_layers['names_6']
        names_fields = self._names_output_fields()
        output_index = {field.name(): index for index, field in enumerate(names_fields)}
        name_records = {}
        records_by_feature_id = {}
        errors = []

        input_index = {field.name().lower(): index for index, field in enumerate(names_layer.fields())}
        names_objectid_indexes = self._objectid_indexes(names_layer.fields())
        names_objectid_index = min(names_objectid_indexes) if names_objectid_indexes else -1
        generated_feature_ids = {}
        decision_ids_by_pdf = {}
        for row_id, feature in enumerate(names_layer.getFeatures(), start=1):
            progress.step()
            values = self._normalize_name_values(feature.attributes(), input_index, output_index, row_id)
            decision_pdf = values[output_index['decision_pdf']]
            decision_pdf = '' if self._is_empty_value(decision_pdf) else str(decision_pdf).strip()
            decision_id = values[output_index['decision_id']]
            if decision_pdf not in decision_ids_by_pdf:
                decision_ids_by_pdf[decision_pdf] = (
                    str(uuid.uuid4()) if self._is_empty_value(decision_id) else str(decision_id).strip()
                )
            values[output_index['decision_id']] = decision_ids_by_pdf[decision_pdf]
            cgndb_id = values[output_index['existing_cgndb_id']]
            if not values[output_index['toponymic_feature_id']] and cgndb_id:
                values[output_index['toponymic_feature_id']] = (
                    self.parent.auth_handler.get_toponymic_feature_id(cgndb_id) or ''
                )
            source_id = self._join_key(values[output_index['source_record_id']])
            tfid = self._join_key(values[output_index['toponymic_feature_id']])
            if not tfid and source_id:
                tfid = generated_feature_ids.get(source_id)
                if not tfid:
                    tfid = uuid.uuid4().hex
                    generated_feature_ids[source_id] = tfid
                values[output_index['toponymic_feature_id']] = tfid
            record = {
                'values': values,
                'source_id': source_id,
                'tfid': tfid,
                'feature_id': feature.id(),
                'geometries': [],
                'has_new_name': not self._is_empty_value(values[output_index['new_name']])
            }
            records_by_feature_id[feature.id()] = record
            if source_id:
                name_records[source_id] = record
            values[output_index['source_record_id']] = source_id
            values[output_index['toponymic_feature_id']] = record['tfid']
            if record['tfid']:
                name_records.setdefault(record['tfid'], record)
            if not source_id and not record['tfid']:
                errors.append(self._error_row(
                    'names_6', record, '', '',
                    'names_6 record has neither toponymic_feature_id nor source_record_id', feature
                ))

        original_objectid_indexes = self._objectid_indexes(names_layer.fields())
        original_objectid_index = min(original_objectid_indexes) if original_objectid_indexes else -1
        original_fields = QgsFields(names_layer.fields())
        for field in names_fields:
            if self._field_index(original_fields, field.name()) < 0:
                original_fields.append(field)
        for field_name, field_type in (
            ('latitude_geosys', QVariant.Double), ('longitude_geosys', QVariant.Double),
            ('source_pt_geosys', QVariant.String), ('add_pt_geosys', QVariant.String)
        ):
            if self._field_index(original_fields, field_name) < 0:
                original_fields.append(QgsField(field_name, field_type))
        if self._field_index(original_fields, '_count') < 0:
            original_fields.append(QgsField('_count', QVariant.Int))

        geometry_outputs = {}
        geometry_records = {}
        for source_name in ('points_0', 'lines_1', 'polygons_2'):
            source_layer = source_layers[source_name]
            output_name = source_name
            objectid_name = {
                'points_0': 'objectid_points',
                'lines_1': 'objectid_lines',
                'polygons_2': 'objectid_polygons'
            }[source_name]
            objectid_indexes = self._objectid_indexes(source_layer.fields())
            objectid_index = min(objectid_indexes) if objectid_indexes else -1
            output_fields = QgsFields()
            output_field_names = set()
            source_field_map = []
            for index, field in enumerate(source_layer.fields()):
                field_key = field.name().lower()
                if index in objectid_indexes or field_key in output_field_names:
                    continue
                output_fields.append(field)
                output_field_names.add(field_key)
                source_field_map.append((index, field.name()))
            for field_name, field_type in ((objectid_name, QVariant.String), ('MD_DELINEATION_CODE', QVariant.String)):
                if field_name.lower() not in output_field_names:
                    output_fields.append(QgsField(field_name, field_type))
                    output_field_names.add(field_name.lower())
            joined_field_names = [
                'existing_cgndb_id', 'new_cgndb_id',
                'existing_name', 'new_name'
            ]
            for joined_name in joined_field_names:
                if joined_name.lower() not in output_field_names:
                    output_fields.append(QgsField(joined_name, QVariant.String))
                    output_field_names.add(joined_name.lower())
            if generated_feature_ids:
                for field_name in ('FGDB_toponymic_feature_id', 'TOPONYMIC_FEATURE_ID'):
                    if field_name.lower() not in output_field_names:
                        output_fields.append(QgsField(field_name, QVariant.String))
                        output_field_names.add(field_name.lower())
            output_features = []
            geometry_records[output_name] = (output_fields, source_layer, [])
            tfid_index = self._field_index(source_layer.fields(), 'toponymic_feature_id')
            source_index = self._field_index(source_layer.fields(), 'source_record_id')
            for feature in source_layer.getFeatures():
                progress.step()
                source_attrs = list(feature.attributes())
                objectid_value = source_attrs[objectid_index] if objectid_index >= 0 else feature.id()
                tfid = self._join_key(source_attrs[tfid_index]) if tfid_index >= 0 else ''
                source_id = self._join_key(source_attrs[source_index]) if source_index >= 0 else ''
                source_desc_index = self._field_index(source_layer.fields(), 'md_delineation_source_desc_cl')
                source_desc = source_attrs[source_desc_index] if source_desc_index >= 0 else ''
                validity_index = self._field_index(source_layer.fields(), 'md_validity_date')
                if validity_index >= 0 and not source_attrs[validity_index]:
                    source_attrs[validity_index] = date.today().isoformat()
                record = name_records.get(tfid) if tfid else None
                record = record or name_records.get(source_id)
                if not record:
                    log_message(
                        f"_process_gdb: {source_name} objectid={objectid_value} tfid='{tfid}' source_id='{source_id}' "
                        f"- no matching names_6 record, routed to error table",
                        Qgis.Warning
                    )
                    errors.append(self._error_row(
                        source_name, None, source_id, tfid,
                        'Geometry feature has no corresponding names_6 record', feature
                    ))
                    continue
                log_message(
                    f"_process_gdb: {source_name} objectid={objectid_value} tfid='{tfid}' source_id='{source_id}' "
                    f"- matched names_6 record(id={id(record)}) has_new_name={record['has_new_name']}",
                    Qgis.Info
                )
                attrs = self._aligned_geometry_attrs(
                    output_fields, source_field_map, source_attrs,
                    objectid_name, objectid_value, source_code=None,
                    joined_field_names=joined_field_names, output_index=output_index,
                    record=record
                )
                output_tfid_index = self._field_index(output_fields, 'toponymic_feature_id')
                if output_tfid_index >= 0 and record.get('tfid'):
                    attrs[output_tfid_index] = record['tfid']
                if generated_feature_ids and record.get('tfid'):
                    self._set_aligned_value(
                        output_fields, attrs, 'FGDB_toponymic_feature_id', record['tfid']
                    )
                    self._set_aligned_value(
                        output_fields, attrs, 'TOPONYMIC_FEATURE_ID', record['tfid']
                    )
                source_code = self._delineation_source_code(source_desc)
                if not source_desc:
                    log_message(
                        f"_process_gdb: {source_name} objectid={objectid_value} matched a names_6 record but has no "
                        f"md_delineation_source_desc_cl - routed to error table ('Feature not loaded in CGNDB...')",
                        Qgis.Warning
                    )
                    errors.append(self._error_row(
                        source_name, record, source_id, tfid,
                        'Feature not loaded in CGNDB since no source was provided', feature
                    ))
                    continue
                if not source_code:
                    log_message(
                        f"_process_gdb: {source_name} objectid={objectid_value} matched a names_6 record but its "
                        f"md_delineation_source_desc_cl='{source_desc}' is unmapped - routed to error table",
                        Qgis.Warning
                    )
                    errors.append(self._error_row(
                        source_name, record, source_id, tfid,
                        f'Unmapped source: {source_desc}', feature
                    ))
                    continue
                if source_name == 'points_0':
                    record['values'][output_index['latitude']] = self._point_coordinate(feature, 1)
                    record['values'][output_index['longitude']] = self._point_coordinate(feature, 0)
                if not record['has_new_name']:
                    if source_name == 'points_0':
                        record['point_output'] = True
                        self._set_aligned_value(output_fields, attrs, 'MD_DELINEATION_CODE', source_code)
                        geometry_records[output_name][2].append(
                            (feature, record, attrs)
                        )
                    continue
                record['geometries'].append((source_name, feature))
                self._set_aligned_value(output_fields, attrs, 'MD_DELINEATION_CODE', source_code)
                geometry_records[output_name][2].append(
                    (feature, record, attrs)
                )

        names_rows = []
        seen_rows = set()
        valid_record_ids = set()
        for record in {id(value): value for value in name_records.values()}.values():
            values = record['values']
            geometries = record['geometries']
            has_point = any(kind == 'points_0' for kind, _ in geometries)
            point = next((feature for kind, feature in geometries if kind == 'points_0'), None)
            if point:
                values[output_index['latitude']] = self._point_coordinate(point, 1)
                values[output_index['longitude']] = self._point_coordinate(point, 0)
            if not record['has_new_name']:
                continue
            missing_point_kind = next(
                (kind for kind, _ in geometries if kind in ('lines_1', 'polygons_2') and not has_point),
                None
            )
            if missing_point_kind:
                label = 'Line' if missing_point_kind == 'lines_1' else 'Polygon'
                errors.append(self._error_row(
                    missing_point_kind, record, record['source_id'], record['tfid'],
                    f'{label} feature has no corresponding point feature for source_record_id={record["source_id"]}',
                    next((feature for kind, feature in geometries if kind == missing_point_kind), None)
                ))
                continue
            valid_record_ids.add(id(record))
            dedupe_key = (
                values[output_index['xlsx_row_id']], values[output_index['latitude']],
                values[output_index['longitude']], values[output_index['toponymic_feature_id']]
            )
            if dedupe_key not in seen_rows:
                seen_rows.add(dedupe_key)
                names_rows.append(values)

        log_message(
            f"Prepared {len(names_rows)} validated names_6 record(s) from the source layer",
            Qgis.Info
        )

        progress.set_label("Writing output layers...")
        original_rows = []
        for feature in names_layer.getFeatures():
            progress.step()
            original_values = list(feature.attributes())
            original_objectid = (
                original_values[original_objectid_index]
                if original_objectid_index >= 0 else feature.id()
            )
            values = original_values + [None] * (len(original_fields) - len(original_values))
            record = records_by_feature_id[feature.id()]
            for field_name, index in output_index.items():
                if field_name in ('latitude', 'longitude', 'xlsx_row_id', 'decision_id') or field_name.lower() not in input_index:
                    self._set_aligned_value(original_fields, values, field_name, record['values'][index])
            self._set_aligned_value(original_fields, values, '_count', original_objectid)
            original_rows.append(self._normalize_output_attributes(original_fields, values))
        output_layers = [
            self._write_table(output_path, 'original_names_6', original_fields, original_rows),
            self._write_table(output_path, 'names_6', names_fields, names_rows)
        ]
        # Records that match a names_6 record but are legitimately excluded from their layer's
        # output (e.g. a points_0 feature whose names_6 record has a new_name, so it belongs to
        # lines_1/polygons_2 instead) never appear as an output row again. Without capturing them
        # here, a manual fix (e.g. a corrected toponymic_feature_id) would have nowhere to be
        # read back from on the *next* reprocess and would silently revert.
        excluded_matches = {name: {} for name in ('points_0', 'lines_1', 'polygons_2')}
        for output_name, (output_fields, source_layer, records) in geometry_records.items():
            output_features = []
            objectid_field = {'points_0': 'objectid_points', 'lines_1': 'objectid_lines', 'polygons_2': 'objectid_polygons'}[output_name]
            objectid_out_idx = self._field_index(output_fields, objectid_field)
            for feature, record, attrs in records:
                excluded = False
                if output_name == 'points_0':
                    excluded = not record.get('point_output', False)
                elif id(record) not in valid_record_ids:
                    excluded = True
                if excluded:
                    if objectid_out_idx >= 0:
                        try:
                            excluded_matches[output_name][int(attrs[objectid_out_idx])] = {
                                field.name(): value for field, value in zip(output_fields, attrs)
                            }
                        except (TypeError, ValueError):
                            pass
                    continue
                output_feature = QgsFeature(output_fields)
                output_feature.setGeometry(feature.geometry())
                output_feature.setAttributes(self._normalize_output_attributes(output_fields, attrs))
                output_features.append(output_feature)
            geometry_outputs[output_name] = self._write_vector(
                output_path, output_name, output_fields, output_features,
                source_layer.wkbType(), source_layer.sourceCrs()
            )
        output_layers.extend(geometry_outputs.values())
        error_fields = QgsFields()
        base_error_fields = (
            ('source_layer', QVariant.String),
            ('source_record_id', QVariant.String), ('toponymic_feature_id', QVariant.String),
            ('error', QVariant.String)
        )
        error_field_names = [name for name, _ in base_error_fields]
        for error_row in errors:
            for name in error_row:
                if name not in error_field_names:
                    error_field_names.append(name)
        for name, field_type in base_error_fields:
            error_fields.append(QgsField(name, field_type))
        for name in error_field_names[len(base_error_fields):]:
            error_fields.append(QgsField(name, QVariant.String))
        error_values = [
            [error_row.get(name, '') for name in error_field_names]
            for error_row in errors
        ]
        output_layers.append(self._write_table(output_path, 'error', error_fields, error_values))
        return [layer for layer in output_layers if layer], len(errors), excluded_matches

    @staticmethod
    def _names_output_fields():
        fields = QgsFields()
        for name, field_type in (
            ('existing_cgndb_id', QVariant.String), ('source_record_id', QVariant.String),
            ('existing_name', QVariant.String), ('status_for_existing_name', QVariant.String),
            ('new_cgndb_id', QVariant.String), ('new_name', QVariant.String),
            ('name_language_cl', QVariant.String), ('origin_language_cl', QVariant.String),
            ('status_code_cl', QVariant.String), ('generic_code', QVariant.String),
            ('latitude', QVariant.Double), ('longitude', QVariant.Double),
            ('gazetteer_map_id', QVariant.String), ('map_index_list', QVariant.String),
            ('region_cl', QVariant.String), ('source_name_origin', QVariant.String),
            ('administrative_location_1', QVariant.String), ('geographic_location_1', QVariant.String),
            ('location_narrative', QVariant.String), ('decision_date', QVariant.String),
            ('decision_pdf', QVariant.String), ('toponymic_feature_id', QVariant.String),
            ('decision_id', QVariant.String),
            ('xlsx_row_id', QVariant.Int)
        ):
            fields.append(QgsField(name, field_type))
        return fields

    @staticmethod
    def _normalize_name_values(attributes, input_index, output_index, row_id):
        source_names = {
            'decision_pdf': 'decision_pdf_filename',
            'toponymic_feature_id': 'toponymic_feature_id'
        }
        ordered = []
        for name in output_index:
            source_name = source_names.get(name, name)
            index = input_index.get(source_name.lower())
            value = attributes[index] if index is not None else None
            ordered.append(value if value is not None else '')
        ordered[output_index['xlsx_row_id']] = row_id
        return ordered

    @staticmethod
    def _point_coordinate(feature, axis):
        point = feature.geometry().asPoint()
        coordinate = point.y() if axis == 1 else point.x()
        return round(coordinate, 7)

    @staticmethod
    def _error_row(source_layer, record, source_id, tfid, message, feature=None):
        row = {
            'source_layer': source_layer,
            'source_record_id': source_id,
            'toponymic_feature_id': tfid,
            'error': message
        }
        if feature is not None:
            for field_index, field in enumerate(feature.fields()):
                field_name = field.name()
                if field_name.casefold() in {
                    'source_layer', 'source_record_id', 'toponymic_feature_id', 'error'
                }:
                    continue
                row[field_name] = feature[field_index]
        return row

    def _aligned_geometry_attrs(
        self, fields, source_field_map, source_attrs, objectid_name, objectid_value,
        source_code, joined_field_names, output_index, record
    ):
        """Create an output attribute row by field name, not by appended position."""
        attrs = [''] * len(fields)
        for source_index, field_name in source_field_map:
            self._set_aligned_value(fields, attrs, field_name, source_attrs[source_index])
        self._set_aligned_value(fields, attrs, objectid_name, str(objectid_value or ''))
        if source_code is not None:
            self._set_aligned_value(fields, attrs, 'MD_DELINEATION_CODE', source_code)
        for field_name in joined_field_names:
            self._set_aligned_value(fields, attrs, field_name, record['values'][output_index[field_name]])
        return attrs

    @staticmethod
    def _set_aligned_value(fields, attrs, field_name, value):
        wanted = field_name.lower()
        for index, field in enumerate(fields):
            if field.name().lower() == wanted:
                attrs[index] = value
                return

    def _write_table(self, gdb_path, name, fields, rows):
        return self._write_vector(gdb_path, name, fields, [self._feature_from_values(fields, row) for row in rows], QgsWkbTypes.NoGeometry, None)

    @staticmethod
    def _normalize_output_attributes(fields, values):
        normalized = list(values)
        for index, field in enumerate(fields):
            if index >= len(normalized):
                normalized.append(None)
            field_type = field.typeName().lower()
            is_text = (
                field.type() == QVariant.String or
                any(text_type in field_type for text_type in ('string', 'text', 'char', 'varchar'))
            )
            if is_text and (
                normalized[index] is None or
                str(normalized[index]).strip().lower() in ('null', '<null>')
            ):
                normalized[index] = ''
            elif not is_text and (
                normalized[index] is None or
                str(normalized[index]).strip().lower() in ('', 'null', '<null>')
            ):
                normalized[index] = None
        return normalized

    @classmethod
    def _feature_from_values(cls, fields, values):
        feature = QgsFeature(fields)
        feature.setAttributes(cls._normalize_output_attributes(fields, values))
        return feature

    def _write_vector(self, gdb_path, name, fields, features, wkb_type, crs):
        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = 'GPKG' if gdb_path.lower().endswith('.gpkg') else 'OpenFileGDB'
        options.layerName = name
        options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer
        if not os.path.exists(gdb_path):
            options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile
        result = QgsVectorFileWriter.writeAsVectorFormatV3(
            self._temporary_memory_layer(name, fields, features, wkb_type, crs),
            gdb_path,
            QgsCoordinateTransformContext(),
            options
        )
        if result[0] != QgsVectorFileWriter.NoError:
            raise DataLoadError(f"Could not write output layer '{name}': {result[1]}")
        return QgsVectorLayer(f"{gdb_path}|layername={name}", name, 'ogr')

    @staticmethod
    def _temporary_memory_layer(name, fields, features, wkb_type, crs):
        uri = QgsWkbTypes.displayString(wkb_type)
        if wkb_type == QgsWkbTypes.NoGeometry:
            uri = 'None'
        if crs and wkb_type != QgsWkbTypes.NoGeometry:
            uri += f"?crs={crs.authid()}"
        layer = QgsVectorLayer(uri, name, 'memory')
        layer.dataProvider().addAttributes(list(fields))
        layer.updateFields()
        layer.dataProvider().addFeatures(features)
        return layer
    
    def resolve_toponymic_feature_ids(self, layer):
        """
        Resolve TOPONYMIC_FEATURE_ID for each feature via its existing_cgndb_id, using the
        geoname-t API. Replaces the FME 'Poly_existingCGNDB_key_DBJoiner' transformer (DB join).
        
        :param layer: QGIS vector layer loaded from the geodatabase (polygon feature class)
        """
        auth_handler = getattr(self.parent, 'auth_handler', None)
        if not auth_handler or not auth_handler.geoname_api_session:
            show_warning_message(
                self.parent,
                "Not Authenticated",
                f"Skipped TOPONYMIC_FEATURE_ID resolution for '{layer.name()}': "
                "please authenticate with geoname-t API first using the login button."
            )
            return
        
        field_names = [f.name() for f in layer.fields()]
        cgndb_field = next(
            (f for f in field_names if f.lower().replace(' ', '_').endswith('existing_cgndb_id')),
            None
        )
        if not cgndb_field:
            return  # Nothing to resolve against
        
        if 'toponymic_feature_id' not in [f.lower() for f in field_names]:
            layer.dataProvider().addAttributes([QgsField('toponymic_feature_id', QVariant.String)])
            layer.updateFields()
        
        tfid_idx = layer.fields().indexOf('toponymic_feature_id')
        cgndb_idx = layer.fields().indexOf(cgndb_field)
        
        resolved = 0
        error_groups = {}
        
        layer.startEditing()
        for feature in layer.getFeatures():
            cgndb_id = feature[cgndb_idx]
            if not cgndb_id or str(cgndb_id).strip() == '':
                continue
            
            cgndb_id = str(cgndb_id).strip()
            tfid = auth_handler.get_toponymic_feature_id(cgndb_id)
            
            if tfid:
                layer.changeAttributeValue(feature.id(), tfid_idx, tfid)
                resolved += 1
            else:
                message = f"existing_cgndb_id '{cgndb_id}' not found in CGNDB \u2014 toponymic_feature_id could not be resolved"
                error_groups.setdefault(message, []).append(feature.id())
        
        layer.commitChanges()
        
        summary = f"Resolved {resolved} feature(s) for '{layer.name()}'."
        if error_groups:
            summary += f"\n\n{sum(len(v) for v in error_groups.values())} feature(s) failed:\n"
            summary += "\n".join(f"- {msg} (feature id(s): {ids})" for msg, ids in error_groups.items())
        
        show_info_message(self.parent, "TOPONYMIC_FEATURE_ID Resolution", summary)
        log_message(
            f"Resolved TOPONYMIC_FEATURE_ID for {resolved} feature(s) in '{layer.name()}', "
            f"{sum(len(v) for v in error_groups.values())} error(s)",
            Qgis.Info
        )
    
    def validate_new_cgndb_id_unique(self, layer):
        """
        Check that each feature's new_cgndb_id does NOT already exist in CGNDB, via the
        geoname-t API. Replaces the FME SQLExecutor uniqueness check
        (select count(cgndb_id) from toponymy_dba.toponym_6 where cgndb_id = ...).
        
        :param layer: QGIS vector layer loaded from the geodatabase
        """
        auth_handler = getattr(self.parent, 'auth_handler', None)
        if not auth_handler or not auth_handler.geoname_api_session:
            return  # Silently skip; resolve_toponymic_feature_ids already warns about auth
        
        field_names = [f.name() for f in layer.fields()]
        new_cgndb_field = next(
            (f for f in field_names if f.lower().replace(' ', '_').endswith('new_cgndb_id')),
            None
        )
        if not new_cgndb_field:
            return  # Nothing to validate
        
        new_cgndb_idx = layer.fields().indexOf(new_cgndb_field)
        error_groups = {}
        checked = 0
        
        for feature in layer.getFeatures():
            new_cgndb_id = feature[new_cgndb_idx]
            if not new_cgndb_id or str(new_cgndb_id).strip() == '':
                continue
            
            new_cgndb_id = str(new_cgndb_id).strip()
            checked += 1
            
            try:
                url = f"{auth_handler.geoname_api_base_url}/toponyms/{new_cgndb_id}"
                response = auth_handler.geoname_api_session.get(url, timeout=5)
                if response.status_code == 200:
                    message = f"new_cgndb_id '{new_cgndb_id}' already exists in CGNDB"
                    error_groups.setdefault(message, []).append(feature.id())
            except requests.exceptions.Timeout:
                error_groups.setdefault("API timeout while checking new_cgndb_id", []).append(feature.id())
            except requests.exceptions.RequestException as e:
                error_groups.setdefault(f"API request error: {str(e)}", []).append(feature.id())
        
        if not checked:
            return
        
        if error_groups:
            summary = f"{sum(len(v) for v in error_groups.values())} of {checked} new_cgndb_id(s) in '{layer.name()}' already exist in CGNDB:\n"
            summary += "\n".join(f"- {msg} (feature id(s): {ids})" for msg, ids in error_groups.items())
            show_warning_message(self.parent, "new_cgndb_id Validation", summary)
        
        log_message(
            f"Checked {checked} new_cgndb_id(s) in '{layer.name()}', "
            f"{sum(len(v) for v in error_groups.values())} conflict(s)",
            Qgis.Info
        )
    
    def _select_feature_classes_dialog(self, layer_names):
        """
        Show a checklist dialog letting the user pick which feature classes to load,
        with an 'All' button to check every item at once.
        
        :param layer_names: List of feature class names available in the geodatabase
        :return: List of selected names, or an empty list if the user cancelled
        """
        dialog = QtWidgets.QDialog(self.parent)
        dialog.setWindowTitle("Select Feature Classes")
        layout = QtWidgets.QVBoxLayout(dialog)
        
        layout.addWidget(QtWidgets.QLabel("Choose the feature class(es) to load:"))
        
        list_widget = QtWidgets.QListWidget()
        for name in layer_names:
            item = QtWidgets.QListWidgetItem(name)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Unchecked)
            list_widget.addItem(item)
        layout.addWidget(list_widget)
        
        all_button = QtWidgets.QPushButton("All")
        all_button.clicked.connect(
            lambda: [list_widget.item(i).setCheckState(Qt.Checked) for i in range(list_widget.count())]
        )
        layout.addWidget(all_button)
        
        button_box = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        button_box.accepted.connect(dialog.accept)
        button_box.rejected.connect(dialog.reject)
        layout.addWidget(button_box)
        
        if dialog.exec_() != QtWidgets.QDialog.Accepted:
            return []
        
        return [
            list_widget.item(i).text()
            for i in range(list_widget.count())
            if list_widget.item(i).checkState() == Qt.Checked
        ]
    
    @staticmethod
    def ensure_xlsx_row_id(data_dict):
        """Prepend a 1-based xlsx_row_id column when missing; return True if it was added."""
        headers = data_dict.get('headers') or []
        if any(str(h).strip().lower() == 'xlsx_row_id' for h in headers if h is not None):
            return False
        data = data_dict.get('data') or []
        new_headers = ['xlsx_row_id'] + list(headers)
        data_dict['headers'] = new_headers
        data_dict['data'] = [new_headers] + [
            [row_number] + list(row) for row_number, row in enumerate(data[1:], start=1)
        ]
        data_dict['column_count'] = len(new_headers)
        return True

    def import_batch_table_file(self, file_path=None):
        """
        Import an Excel or CSV batch table through the reusable table dialog.
        """
        try:
            if file_path is None:
                file_path = select_file(
                    parent=self.parent,
                    title="Select Batch Load Table",
                    file_filter="Batch Load Tables (*.xlsx *.csv);;Excel Files (*.xlsx);;CSV Files (*.csv)"
                )
            
            if not file_path:
                return False  # User cancelled
            
            # Create timestamped working copy
            copy_path = create_timestamped_copy(file_path)
            extension = os.path.splitext(copy_path)[1].lower()
            if extension == '.csv':
                selected_sheet = 'data'
                data_dict = DataLoader.load_csv(copy_path)
            else:
                sheet_names = DataLoader.get_excel_sheets(copy_path)
                default_index = next(
                    (index for index, name in enumerate(sheet_names) if name.lower() == 'data'),
                    0
                )
                selected_sheet = sheet_names[default_index]
                if len(sheet_names) > 1:
                    selected_sheet, ok = QtWidgets.QInputDialog.getItem(
                        self.parent,
                        "Select Sheet",
                        "Choose the sheet to display:",
                        sheet_names,
                        default_index,
                        False
                    )
                    if not ok:
                        return False
                data_dict = DataLoader.load_excel(copy_path, selected_sheet)

            row_id_added = self.ensure_xlsx_row_id(data_dict)
            self.parent.batch_load_file_path = copy_path
            self.parent.batch_load_sheet_name = selected_sheet
            self.parent.batch_load_source_path = file_path

            # Display in reusable table dialog
            self._show_data_table(data_dict)
            if row_id_added:
                self.save_current_batch_as_csv()
            self._warn_import_coordinates(data_dict)
            return True
            
        except DataLoadError as e:
            show_error_message(self.parent, "Import Error", f"Failed to import batch load table:\n{str(e)}")
            log_message(f"Batch table import error: {str(e)}", Qgis.Critical)
            return False
        except Exception as e:
            show_error_message(self.parent, "Unexpected Error", f"An unexpected error occurred:\n{str(e)}")
            log_message(f"Unexpected error importing batch table: {str(e)}", Qgis.Critical)
            return False
    
    def import_csv_file(self):
        """Handle CSV file import"""
        try:
            file_path = select_file(
                parent=self.parent,
                title="Select CSV File",
                file_filter="CSV Files (*.csv);;All Files (*.*)"
            )
            
            if not file_path:
                return
            
            # Optionally prompt for CSV settings (delimiter, encoding)
            # For now, use defaults
            data_dict = DataLoader.load_csv(file_path)
            
            self._show_data_table(data_dict)
            
        except DataLoadError as e:
            show_error_message(self.parent, "Import Error", f"Failed to import CSV file:\n{str(e)}")
            log_message(f"CSV import error: {str(e)}", Qgis.Critical)
    
    def import_postgres_data(self):
        """Handle PostgreSQL table import"""
        try:
            # Prompt user for connection parameters
            host, ok = QtWidgets.QInputDialog.getText(self.parent, "PostgreSQL Connection", "Host:")
            if not ok or not host:
                return
            
            database, ok = QtWidgets.QInputDialog.getText(self.parent, "PostgreSQL Connection", "Database:")
            if not ok or not database:
                return
            
            user, ok = QtWidgets.QInputDialog.getText(self.parent, "PostgreSQL Connection", "User:")
            if not ok or not user:
                return
            
            password, ok = QtWidgets.QInputDialog.getText(
                self.parent, "PostgreSQL Connection", "Password:", QtWidgets.QLineEdit.Password
            )
            if not ok or not password:
                return
            
            table_name, ok = QtWidgets.QInputDialog.getText(self.parent, "PostgreSQL Connection", "Table name:")
            if not ok or not table_name:
                return
            
            # Load data
            data_dict = DataLoader.load_postgres_table(
                host=host,
                database=database,
                user=user,
                password=password,
                table_name=table_name
            )
            
            self._show_data_table(data_dict)
            
        except DataLoadError as e:
            show_error_message(self.parent, "Import Error", f"Failed to import PostgreSQL data:\n{str(e)}")
            log_message(f"PostgreSQL import error: {str(e)}", Qgis.Critical)
    
    def import_qgis_layer(self):
        """Handle QGIS layer import"""
        try:
            # Get list of layers in project
            layers = QgsProject.instance().mapLayers()
            layer_names = [layer.name() for layer in layers.values()]
            
            if not layer_names:
                show_warning_message(self.parent, "No Layers", "No layers found in the current project.")
                return
            
            # Let user select layer
            layer_name, ok = QtWidgets.QInputDialog.getItem(
                self.parent,
                "Select Layer",
                "Choose a layer to import:",
                layer_names,
                0,
                False
            )
            
            if not ok:
                return
            
            # Load data
            data_dict = DataLoader.load_qgis_layer(layer_name)
            
            self._show_data_table(data_dict)
            
        except DataLoadError as e:
            show_error_message(self.parent, "Import Error", f"Failed to import QGIS layer:\n{str(e)}")
            log_message(f"QGIS layer import error: {str(e)}", Qgis.Critical)
    
    def _show_data_table(self, data_dict, layer=None):
        """
        Show data in reusable table dialog (non-modal).
        
        :param data_dict: Data dictionary from DataLoader
        :param layer: Optional QGIS layer to link with table for selection highlighting
        """
        is_error_table = data_dict.get('type') == 'error_table'
        current_dialog = self.parent.error_table_dialog if is_error_table else self.parent.current_table_dialog
        if not is_error_table and self.parent.error_table_dialog is not None:
            self.parent.error_table_dialog.close()
        if current_dialog is not None:
            if not is_error_table and not current_dialog.prepare_for_replacement():
                return

        # Close previous dialog if it exists
        if current_dialog is not None:
            current_dialog.close()

        if layer is None and data_dict.get('type') in ('excel', 'csv'):
            coordinate_layer = getattr(self.parent, 'coordinate_layer', None)
            if coordinate_layer is not None and QgsProject.instance().mapLayer(coordinate_layer.id()):
                layer = coordinate_layer
        
        dialog = DataTableDialog(data_dict, parent=self.parent, layer=layer)
        
        # Connect signal to update batch load file path when saved
        dialog.file_saved.connect(self._on_batch_file_saved)
        
        # Connect signal to handle table minimize
        dialog.minimized.connect(self._on_table_minimized)
        
        # Connect to dialog close/destroy to hide restore container
        dialog.finished.connect(lambda: self.parent.restore_table_container.setVisible(False))
        
        # Store reference to prevent garbage collection
        if is_error_table:
            self.parent.error_table_dialog = dialog
        else:
            self.parent.current_table_dialog = dialog
        
        # Show non-modal so user can interact with other parts of the plugin
        dialog.show()
    
    def _on_batch_file_saved(self, file_path, sheet_name):
        """
        Handler for when batch load file is saved.
        Updates the stored file path so validation can continue using the saved file.
        
        :param file_path: Path to the saved file
        :param sheet_name: Name of the sheet that was saved
        """
        self.parent.batch_load_file_path = file_path
        self.parent.batch_load_sheet_name = sheet_name
        log_message(f"Updated batch load file reference: {file_path} (sheet: {sheet_name})", Qgis.Info)
        show_info_message(
            self.parent,
            "File Reference Updated",
            f"The batch load file reference has been updated to:\n{os.path.basename(file_path)}\n\n"
            "You can now validate the saved file without re-importing it."
        )
    
    def _on_table_minimized(self):
        """
        Handler for when table dialog is minimized.
        Shows the restore button in the dockwidget.
        """
        show_error_table = bool(
            self.parent.batch_load_file_path and
            self.parent.batch_load_file_path.lower().endswith(('.gdb', '.fgdb', '.gpkg'))
        )
        self.parent.restore_table_button.setText(
            "processed table" if show_error_table else "open batch load table"
        )
        self.parent.restore_table_button.setToolTip(
            "<p>Opens the processed table that combines information from the "
            "names_6 and points_0 layers.</p>"
            "<p>When a row is selected, the map zooms to the associated geometry "
            "and displays an editable form containing the related names_6, "
            "points_0, lines_1, and polygons_2 information when available.</p>"
            "<p>Use this form to review and edit records after the File "
            "Geodatabase relationships have been processed.</p>"
            if show_error_table else
            "<p>Opens the imported batch load table and allows records to be "
            "viewed and edited.</p>"
            "<p>When a row is selected, the map automatically zooms to the "
            "corresponding point (if available) and displays an editable form.</p>"
            "<p>The form provides a more user-friendly editing experience "
            "than the table and allows users to select values from geoname-t "
            "code lists using a Code \u2013 Term format.</p>"
        )
        self.parent.open_error_table_button.setVisible(show_error_table)
        self.parent.reprocess_button.setVisible(show_error_table)
        source_path = getattr(self.parent, 'batch_load_source_path', None) or ''
        self.parent.reprocess_button.setEnabled(source_path.lower().endswith(('.gdb', '.fgdb')))
        self.parent.save_gpkg_button.setVisible(show_error_table)
        self.parent.save_csv_button.setVisible(not show_error_table)
        self.parent.restore_table_container.setVisible(True)
        log_message("Table minimized - restore button visible", Qgis.Info)
    
    def on_restore_table(self):
        """
        Handler for restore table button click.
        Shows the table dialog again and hides the restore button and label.
        """
        if self.parent.current_table_dialog is not None:
            self.parent.current_table_dialog.show()
            self.parent.current_table_dialog.raise_()
            self.parent.current_table_dialog.activateWindow()
            self.parent.restore_table_container.setVisible(False)
            if self.parent.error_table_dialog is not None:
                self.parent.error_table_dialog.close()
            log_message("Table restored", Qgis.Info)

    def open_error_table(self):
        """Open the error layer from the current processed batch-load file."""
        file_path = self.parent.batch_load_file_path
        if file_path and file_path.lower().endswith(('.gdb', '.fgdb')):
            file_path = self._processed_output_path(file_path)
        if not file_path or not file_path.lower().endswith('.gpkg'):
            show_warning_message(
                self.parent,
                "Error Table Unavailable",
                "Process a batch load file before opening its error table."
            )
            return

        try:
            data_dict = DataLoader.load_qgis_layer(f"{file_path}|layername=error")
            data_dict['type'] = 'error_table'
            data_dict['read_only'] = True
            if self.parent.current_table_dialog is not None:
                self.parent.current_table_dialog.close()
            self._build_error_source_layers(data_dict)
            self._show_data_table(data_dict)
            self.parent.restore_table_container.setVisible(False)
            log_message("Error table opened", Qgis.Info)
        except DataLoadError as e:
            show_error_message(self.parent, "Error Table", f"Could not open the error table:\n{str(e)}")
            log_message(f"Error table load error: {str(e)}", Qgis.Warning)

    def _build_error_source_layers(self, error_data_dict):
        """
        Build named points_0_error/lines_1_error/polygons_2_error layers containing the raw
        geometry+attributes for records currently routed to the error table, so a selected
        error row can be zoomed to and edited directly. 'Reprocess file' merges any edits made
        here back with the rest of the raw source when regenerating the processed output.
        Existing, still-valid layers are kept as-is (not rebuilt) so in-progress edits made
        directly on the layer (e.g. via its attribute table) survive reopening the error table;
        they're only cleared on Clear/Reprocess (see CoordinateLayerHandler.remove_layers).
        """
        source_path = getattr(self.parent, 'batch_load_source_path', None)
        cache = getattr(self.parent, 'error_source_layers', None)
        if cache is None:
            cache = {}
            self.parent.error_source_layers = cache

        project = QgsProject.instance()
        for layer_name in list(cache.keys()):
            if not project.mapLayer(cache[layer_name].id()):
                cache.pop(layer_name, None)

        if not source_path:
            return

        headers = error_data_dict.get('headers', [])
        header_map = {str(h).strip().lower(): i for i, h in enumerate(headers) if h}
        layer_col = header_map.get('source_layer')
        objectid_col = header_map.get('objectid')
        if layer_col is None or objectid_col is None:
            return

        ids_by_layer = {'points_0': set(), 'lines_1': set(), 'polygons_2': set()}
        for row in error_data_dict.get('data', [])[1:]:
            layer_name = str(row[layer_col]).strip() if layer_col < len(row) and row[layer_col] else ''
            if layer_name not in ids_by_layer:
                continue
            raw_id = row[objectid_col] if objectid_col < len(row) else None
            if raw_id in (None, ''):
                continue
            try:
                ids_by_layer[layer_name].add(int(float(raw_id)))
            except (TypeError, ValueError):
                continue

        for layer_name, feature_ids in ids_by_layer.items():
            if not feature_ids or layer_name in cache:
                continue
            error_layer = QgsVectorLayer(
                f"{source_path}|layername={layer_name}_error", f"{layer_name}_error", "ogr"
            )
            if not error_layer.isValid():
                raw_layer = QgsVectorLayer(f"{source_path}|layername={layer_name}", layer_name, "ogr")
                if not raw_layer.isValid():
                    continue
                error_layer = self._clone_features_to_memory(raw_layer, feature_ids, f"{layer_name}_error")
            if error_layer is None:
                continue
            self._apply_error_layer_style(error_layer)
            error_layer.editingStopped.connect(
                lambda name=layer_name: self._refresh_error_table_from_layer(name)
            )
            project.addMapLayer(error_layer)
            cache[layer_name] = error_layer

    def _refresh_error_table_from_layer(self, layer_name):
        """Refresh the open error table's cells for `layer_name` from its '{layer_name}_error' layer."""
        dialog = self.parent.error_table_dialog
        cache = getattr(self.parent, 'error_source_layers', None)
        layer = cache.get(layer_name) if cache else None
        if dialog is None or layer is None:
            log_message(
                f"_refresh_error_table_from_layer({layer_name}): dialog={dialog is not None}, layer={layer is not None}, aborting",
                Qgis.Warning
            )
            return

        headers = dialog.data_dict.get('headers', [])
        header_map = {str(h).strip().lower(): i for i, h in enumerate(headers) if h}
        layer_col = header_map.get('source_layer')
        objectid_col = header_map.get('objectid')
        if layer_col is None or objectid_col is None:
            log_message(f"_refresh_error_table_from_layer({layer_name}): no source_layer/objectid column, aborting", Qgis.Warning)
            return

        fields = layer.fields()
        col_by_field_index = {
            field_index: header_map.get(field.name().strip().lower())
            for field_index, field in enumerate(fields)
        }
        features_by_id = {feature.id(): feature for feature in layer.getFeatures()}

        data_rows = dialog.data_dict.get('data', [])
        rows_matched = 0
        cells_updated = 0
        for row_idx in range(1, len(data_rows)):
            row = data_rows[row_idx]
            if layer_col >= len(row) or str(row[layer_col]).strip() != layer_name:
                continue
            try:
                row_fid = int(float(row[objectid_col])) if objectid_col < len(row) else None
            except (TypeError, ValueError):
                continue
            feature = features_by_id.get(row_fid)
            if feature is None:
                continue
            rows_matched += 1

            for field_index, col_idx in col_by_field_index.items():
                if col_idx is None or col_idx >= len(row):
                    continue
                value = feature[field_index]
                row[col_idx] = value
                item = dialog.table.item(row_idx - 1, col_idx)
                if item is not None:
                    item.setText('' if value is None else str(value))
                    cells_updated += 1
        log_message(
            f"_refresh_error_table_from_layer({layer_name}): rows_in_error_layer={len(features_by_id)}, "
            f"rows_matched={rows_matched}, cells_updated={cells_updated}",
            Qgis.Info
        )

    @staticmethod
    def _clone_features_to_memory(source_layer, feature_ids, memory_name):
        """
        Copy selected features from a raw layer into a new memory layer, matched and keyed by
        the layer's own OBJECTID attribute value (not QGIS's internal feature id, which may not
        equal OBJECTID for some OGR/FileGDB providers - e.g. a 0-based FID vs 1-based OBJECTID).
        """
        objectid_indexes = FileImportHandler._objectid_indexes(source_layer.fields())
        objectid_index = min(objectid_indexes) if objectid_indexes else -1
        if objectid_index < 0:
            return None

        uri = QgsWkbTypes.displayString(source_layer.wkbType())
        if source_layer.crs().isValid():
            uri += f"?crs={source_layer.crs().authid()}"
        memory_layer = QgsVectorLayer(uri, memory_name, 'memory')
        provider = memory_layer.dataProvider()
        provider.addAttributes(source_layer.fields())
        memory_layer.updateFields()

        features = []
        for feature in source_layer.getFeatures():
            try:
                objectid = int(feature[objectid_index])
            except (TypeError, ValueError):
                continue
            if objectid not in feature_ids:
                continue
            new_feature = QgsFeature(memory_layer.fields())
            new_feature.setId(objectid)
            new_feature.setGeometry(feature.geometry())
            new_feature.setAttributes(feature.attributes())
            features.append(new_feature)
        if not features:
            return None
        provider.addFeatures(features)
        memory_layer.updateExtents()
        return memory_layer

    @staticmethod
    def _apply_error_layer_style(layer):
        """Style an error-source layer distinctly (gray/dashed) from the processed output."""
        try:
            from qgis.core import QgsMarkerSymbol, QgsLineSymbol, QgsFillSymbol, QgsSingleSymbolRenderer

            if layer.geometryType() == QgsWkbTypes.PointGeometry:
                symbol = QgsMarkerSymbol.createSimple({
                    'name': 'circle', 'color': '120,120,120,200',
                    'outline_color': '80,80,80,255', 'outline_width': '0.5', 'size': '2.7'
                })
            elif layer.geometryType() == QgsWkbTypes.LineGeometry:
                symbol = QgsLineSymbol.createSimple({
                    'line_color': '120,120,120,220', 'line_width': '0.4', 'line_style': 'dash'
                })
            elif layer.geometryType() == QgsWkbTypes.PolygonGeometry:
                symbol = QgsFillSymbol.createSimple({
                    'color': '120,120,120,60', 'outline_color': '120,120,120,220',
                    'outline_width': '0.3', 'outline_style': 'dash'
                })
            else:
                return
            layer.setRenderer(QgsSingleSymbolRenderer(symbol))
            layer.triggerRepaint()
        except Exception:
            pass

    def save_processed_gpkg(self):
        """Commit any pending edits on layers backed by the processed GDB/GPKG."""
        file_path = self.parent.batch_load_file_path
        if not file_path or not file_path.lower().endswith(('.gdb', '.fgdb', '.gpkg')):
            show_warning_message(
                self.parent,
                "No Processed GPKG",
                "Process a GDB/GPKG batch load file first."
            )
            return

        committed = []
        failed = []
        for layer in QgsProject.instance().mapLayers().values():
            if layer.source().startswith(file_path) and layer.isEditable():
                if layer.commitChanges():
                    committed.append(layer.name())
                else:
                    failed.append(layer.name())

        if failed:
            show_error_message(
                self.parent,
                "Save Failed",
                f"Failed to save changes for layer(s): {', '.join(failed)}"
            )
        elif committed:
            show_info_message(
                self.parent,
                "GPKG Saved",
                f"Saved changes to: {', '.join(committed)}"
            )
        else:
            show_info_message(
                self.parent,
                "GPKG Saved",
                f"The processed GeoPackage is already saved on disk:\n{file_path}\n\n"
                "No additional in-memory edits were pending."
            )
        log_message(f"Save GPKG: committed={committed}, failed={failed}", Qgis.Info)

    def has_unsaved_table_edits(self):
        """Return True if the batch load table dialog has unsaved edits."""
        dialog = self.parent.current_table_dialog
        return bool(dialog is not None and getattr(dialog, 'is_modified', False))

    def save_current_batch_as_csv(self):
        """Persist the current Excel/CSV batch table to its active CSV path."""
        file_path = self.parent.batch_load_file_path
        if not file_path or not file_path.lower().endswith(('.xlsx', '.csv')):
            return file_path

        csv_path = os.path.splitext(file_path)[0] + '.csv'
        dialog = self.parent.current_table_dialog
        if dialog is not None:
            dialog._save_to_csv(csv_path)
            dialog.mark_table_saved()
        else:
            layer = getattr(self.parent, 'geosys_layer', None)
            rows = getattr(layer, '_sync_data_rows', None) if layer is not None else None
            if rows is None:
                extension = os.path.splitext(file_path)[1].lower()
                if extension == '.csv':
                    rows = DataLoader.load_csv(file_path).get('data', [])
                else:
                    rows = DataLoader.load_excel(
                        file_path, getattr(self.parent, 'batch_load_sheet_name', None)
                    ).get('data', [])
            with open(csv_path, 'w', newline='', encoding='utf-8') as csv_file:
                csv.writer(csv_file).writerows(rows)

        self.parent.batch_load_file_path = csv_path
        self.parent.batch_load_sheet_name = 'data'
        log_message(f"Saved current batch load data to {csv_path}", Qgis.Success)
        return csv_path

    def save_batch_load_csv(self):
        """Save the current xlsx batch load table's data to CSV, even while the table dialog is minimized."""
        file_path = self.parent.batch_load_file_path
        if not file_path or file_path.lower().endswith(('.gdb', '.fgdb', '.gpkg')):
            show_warning_message(
                self.parent,
                "No Batch Load Table",
                "Import an xlsx batch load template file first."
            )
            return

        dialog = self.parent.current_table_dialog
        if dialog is None:
            show_warning_message(
                self.parent,
                "No Batch Load Table",
                "Import a batch load template file first."
            )
            return

        dialog._on_save()
    
    def save_table_edits(self):
        """Trigger the table dialog's save action."""
        dialog = self.parent.current_table_dialog
        if dialog is not None:
            dialog._on_save()
    
    def clear_batch_load(self):
        """Close the table dialog and reset the stored batch load file path/sheet."""
        if self.parent.current_table_dialog is not None:
            self.parent.current_table_dialog.close()
            self.parent.current_table_dialog = None
        if self.parent.error_table_dialog is not None:
            self.parent.error_table_dialog.close()
            self.parent.error_table_dialog = None
        
        self.parent.batch_load_file_path = None
        self.parent.batch_load_sheet_name = None
        self.parent.excluded_geometry_edits = {}
        self.parent.restore_table_container.setVisible(False)
        log_message("Cleared batch load file state", Qgis.Info)
