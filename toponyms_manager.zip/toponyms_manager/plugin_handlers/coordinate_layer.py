"""
Coordinate Layer Handler

Handles creation and management of coordinate layers from batch load files.
"""

import requests
from qgis.core import (
    Qgis, QgsVectorLayer, QgsWkbTypes, QgsField, QgsFeature, QgsGeometry,
    QgsPointXY, QgsProject, QgsCoordinateReferenceSystem, QgsRasterLayer,
    QgsSymbol, QgsMarkerSymbol, QgsLineSymbol, QgsFillSymbol,
    QgsSingleSymbolRenderer,
    QgsPalLayerSettings, QgsTextFormat,
    QgsTextBufferSettings, QgsVectorLayerSimpleLabeling, QgsCoordinateTransform
)
from qgis.PyQt.QtCore import QVariant
from qgis.PyQt import QtWidgets
from qgis.PyQt.QtGui import QColor, QFont

from ..data_loaders import DataLoader, DataLoadError
from ..utils import show_error_message, show_info_message, show_warning_message, log_message, ProgressTracker, coordinate_errors


class CoordinateLayerHandler:
    """
    Handles creating QGIS layers from coordinate data in batch load files.
    """
    
    def __init__(self, parent_widget, auth_handler, file_import_handler):
        """
        Initialize coordinate layer handler.
        
        :param parent_widget: Parent widget (usually the dockwidget)
        :param auth_handler: AuthenticationHandler instance for API access
        :param file_import_handler: FileImportHandler for showing data table
        """
        self.parent = parent_widget
        self.auth_handler = auth_handler
        self.file_import_handler = file_import_handler

    @staticmethod
    def _is_empty_value(value):
        return value is None or str(value).strip().lower() in ('', 'null', '<null>')

    def _load_batch_data(self):
        """Load the active batch data from names_6 in a GDB or from the Excel sheet."""
        file_path = self.parent.batch_load_file_path
        if file_path.lower().endswith(('.gdb', '.fgdb', '.gpkg')):
            return DataLoader.load_qgis_layer(f"{file_path}|layername=names_6")
        if file_path.lower().endswith('.csv'):
            data_dict = DataLoader.load_csv(file_path)
        else:
            sheet_name = self.parent.batch_load_sheet_name or 'data'
            data_dict = None
            if sheet_name.lower() != 'data':
                try:
                    data_dict = DataLoader.load_excel(file_path, 'data')
                except Exception:
                    pass
            if data_dict is None:
                data_dict = DataLoader.load_excel(file_path, sheet_name)
        self.file_import_handler.ensure_xlsx_row_id(data_dict)
        return data_dict
    
    def add_coordinate_as_layer(self, silent=False):
        """
        Add coordinates from the batch load file as a QGIS layer.
        Creates a point layer from latitude/longitude columns.

        :param silent: When True, skip error/zoom prompts and replace any existing
            coordinate layer instead of stacking a new one (used for automatic re-sync).
        """
        try:
            # Check if a file has been loaded
            if not self.parent.batch_load_file_path:
                if not silent:
                    show_error_message(
                        self.parent,
                        "No File Loaded",
                        "Please import a batch load template file first using the 'Import Batch Load file' button."
                    )
                return
            
            log_message("Loading coordinates from batch load file...", Qgis.Info)
            
            # Load the active batch data from Excel or the processed GDB.
            sheet_name = self.parent.batch_load_sheet_name or 'data'
            data_dict = self._load_batch_data()
            if self.parent.batch_load_file_path.lower().endswith(('.gdb', '.fgdb', '.gpkg')):
                sheet_name = 'names_6'
            
            # Get headers and data
            headers = data_dict.get('headers', [])
            data_rows = data_dict.get('data', [])
            
            if not data_rows or len(data_rows) < 2:
                if not silent:
                    show_error_message(
                        self.parent,
                        "No Data",
                        "The file contains no data rows."
                    )
                return
            
            # Create header map for quick lookup
            header_map = {header.lower(): idx for idx, header in enumerate(headers) if header}
            
            # Check if latitude and longitude columns exist
            if 'latitude' not in header_map or 'longitude' not in header_map:
                if silent:
                    message = (
                        "The file was imported, but no coordinate layer was created because "
                        "the batch table is missing the 'latitude' and/or 'longitude' columns."
                    )
                    show_warning_message(self.parent, "Coordinate Layer Not Created", message)
                    log_message(message, Qgis.Warning)
                else:
                    show_error_message(
                        self.parent,
                        "Missing Columns",
                        "The file must contain 'latitude' and 'longitude' columns."
                    )
                return
            
            # Create a new point layer
            layer_name = f"Batch Load Coordinates ({sheet_name})"
            layer = QgsVectorLayer("Point?crs=EPSG:4326", layer_name, "memory")
            provider = layer.dataProvider()
            
            # Add fields from the headers
            fields = []
            for header in headers:
                fields.append(QgsField(header, QVariant.String))
            provider.addAttributes(fields)
            layer.updateFields()
            
            # Get column indices
            lat_idx = header_map['latitude']
            lon_idx = header_map['longitude']
            
            # Add features (skip header row)
            features = []
            data_only = data_rows[1:] if len(data_rows) > 1 else []
            skipped_count = 0
            
            for table_row, row in enumerate(data_only):
                # Ensure row has enough columns
                if len(row) < len(headers):
                    row = list(row) + [None] * (len(headers) - len(row))
                
                # Get latitude and longitude values
                lat_value = row[lat_idx] if lat_idx < len(row) else None
                lon_value = row[lon_idx] if lon_idx < len(row) else None
                
                # Skip rows without valid coordinates
                if lat_value is None or lon_value is None:
                    skipped_count += 1
                    continue
                    
                try:
                    lat = float(lat_value)
                    lon = float(lon_value)
                except (ValueError, TypeError, OverflowError):
                    skipped_count += 1
                    log_message(f"Skipping row {table_row + 2}: Invalid coordinate values", Qgis.Warning)
                    continue
                errors = coordinate_errors(lat_value, lon_value)
                if errors:
                    skipped_count += 1
                    log_message(f"Skipping row {table_row + 2}: {'; '.join(errors)}", Qgis.Warning)
                    continue
                
                # Create point geometry
                point = QgsPointXY(lon, lat)
                feature = QgsFeature()
                feature.setGeometry(QgsGeometry.fromPointXY(point))
                
                # Set attribute values
                attributes = [str(cell) if cell is not None else '' for cell in row]
                feature.setAttributes(attributes)
                
                features.append(feature)
            
            # Add all features to the layer
            provider.addFeatures(features)
            layer.updateExtents()
            
            # Apply styling to the layer
            self._apply_point_layer_style(layer, headers)
            
            # Add basemap if not already present
            self._add_basemap_if_needed()
            
            # Replace any previously loaded coordinate layer instead of stacking duplicates
            old_layer = getattr(self.parent, 'coordinate_layer', None)
            project = QgsProject.instance()
            table_dialog = getattr(self.parent, 'current_table_dialog', None)
            relink_table = bool(table_dialog and (table_dialog.linked_layer is None or table_dialog.linked_layer is old_layer))
            if old_layer is not None and project.mapLayer(old_layer.id()):
                project.removeMapLayer(old_layer.id())

            # Add layer to the project
            project.addMapLayer(layer)
            
            # Store reference to the layer for linking with table (read-only)
            self.parent.coordinate_layer = layer

            if relink_table:
                was_linked = table_dialog.linked_layer is not None
                table_dialog.linked_layer = layer
                table_dialog.table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
                table_dialog.table.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
                if not was_linked and table_dialog.data_type not in ('excel', 'csv'):
                    table_dialog.table.itemSelectionChanged.connect(table_dialog._on_selection_changed)
                if not hasattr(table_dialog, 'clear_selection_button'):
                    button_box = table_dialog.save_button.parentWidget()
                    table_dialog.clear_selection_button = button_box.addButton(
                        "Clear Selection", QtWidgets.QDialogButtonBox.ActionRole
                    )
                    table_dialog.clear_selection_button.clicked.connect(table_dialog._on_clear_selection)
            
            # Note: No editing or sync setup - this is a reference layer only
            
            if not silent:
                self._offer_zoom_to_layers([layer])
            log_message(f"Successfully added coordinate layer: {len(features)} points", Qgis.Success)
            
        except DataLoadError as e:
            show_error_message(self.parent, "Load Error", f"Failed to load data from file:\n{str(e)}")
            log_message(f"Error loading data: {str(e)}", Qgis.Critical)
        except Exception as e:
            show_error_message(self.parent, "Error", f"An unexpected error occurred:\n{str(e)}")
            log_message(f"Unexpected error adding coordinate layer: {str(e)}", Qgis.Critical)
    
    def load_geosys_point(self, silent=False, preserved_names_geosys=None, preserved_points_geosys=None):
        """Load GeoSys points for all rows in the batch load file, with a progress dialog."""
        progress = ProgressTracker(self.parent, "Loading GeoSys points", "Loading GeoSys points (1347)...", 1)
        try:
            self._load_geosys_point_impl(silent, preserved_names_geosys, preserved_points_geosys, progress)
        finally:
            progress.close()

    def _load_geosys_point_impl(self, silent, preserved_names_geosys, preserved_points_geosys, progress):
        """
        Load GeoSys points for all rows in the batch load file.
        Adds geosys coordinate columns and populates them based on existing_cgndb_id.

        :param silent: When True, skip error/zoom prompts (used for automatic re-load, e.g.
            after reprocessing a GDB where geosys layers already existed).
        :param preserved_names_geosys: Optional {int xlsx_row_id: {...}} of manually-dragged
            names_6 geosys values to keep instead of recomputing from the API (e.g. after
            reprocessing a GDB).
        :param preserved_points_geosys: Same, but keyed by int objectid_points for points_0.
        """
        try:
            # Check if a file has been loaded
            if not self.parent.batch_load_file_path:
                if not silent:
                    show_error_message(
                        self.parent,
                        "No File Loaded",
                        "Please import a batch load template file first."
                    )
                return
            
            # Check if geoname-t API is authenticated
            if not self.auth_handler.geoname_api_session:
                if not silent:
                    show_error_message(
                        self.parent,
                        "Not Authenticated",
                        "Please authenticate with geoname-t API first using the login button."
                    )
                return
            
            log_message("Loading GeoSys points...", Qgis.Info)
            
            # Load the active batch data from Excel or the processed GDB.
            is_geospatial_source = self.parent.batch_load_file_path.lower().endswith(
                ('.gdb', '.fgdb', '.gpkg')
            )
            if not is_geospatial_source:
                # Flush table edits to the working CSV, which then becomes the active file.
                self.file_import_handler.save_current_batch_as_csv()
            sheet_name = self.parent.batch_load_sheet_name or 'data'
            if is_geospatial_source:
                sheet_name = 'names_6'

            project_layers = {
                layer.name(): layer
                for layer in QgsProject.instance().mapLayers().values()
            }
            names_layer_name = f"Geosys Points ({'data' if is_geospatial_source else sheet_name})"
            create_names_layer = names_layer_name not in project_layers
            create_points_layer = is_geospatial_source and create_names_layer
            self.parent.geosys_layer = project_layers.get(names_layer_name)
            self.parent.geosys_layer_points_0 = None
            if not create_names_layer and not create_points_layer:
                return

            data_dict = self._load_batch_data()
            
            # Get headers and data
            headers = data_dict.get('headers', [])
            data_rows = data_dict.get('data', [])
            
            if create_names_layer and (not data_rows or len(data_rows) < 2):
                if create_points_layer:
                    create_names_layer = False
                else:
                    if not silent:
                        show_error_message(
                            self.parent,
                            "No Data",
                            "The file contains no data rows."
                        )
                    return

            if not data_rows or len(data_rows) < 2:
                if create_points_layer:
                    data_rows = []
                else:
                    if not silent:
                        show_error_message(
                            self.parent,
                            "No Data",
                            "The file contains no data rows."
                        )
                    return
            
            processed_count = 0
            geosys_layer = self.parent.geosys_layer
            if create_names_layer:
                try:
                    progress.add_total(len(data_rows) - 1)
                    processed_count, api_check_count = self._populate_geosys_columns(
                        headers, data_rows, preserved_by_key=preserved_names_geosys, key_header='xlsx_row_id',
                        progress=progress
                    )
                except ValueError as e:
                    if not silent:
                        show_error_message(
                            self.parent,
                            "Missing Columns",
                            str(e)
                        )
                    return

                if is_geospatial_source:
                    self._update_names_6_geosys_attributes(headers, data_rows)

                data_dict['headers'] = headers
                data_dict['data'] = data_rows
                data_dict['column_count'] = len(headers)
                log_message(
                    f"Updated data structure: {len(headers)} columns, {len(data_rows)} total rows",
                    Qgis.Info
                )

                if not is_geospatial_source:
                    geosys_layer = self._create_geosys_layer(headers, data_rows, sheet_name)
                    self.parent.geosys_layer = geosys_layer
                    if geosys_layer:
                        self._setup_layer_sync(geosys_layer, data_rows, headers)

                if not is_geospatial_source and not silent:
                    self._show_batch_table_with_geosys(data_dict)

            points_0_layer = self.parent.geosys_layer_points_0
            points_0_headers, points_0_rows = [], []
            if create_points_layer:
                points_0_dict = self._load_points_0_as_data(optional=True)
                points_0_headers = points_0_dict.get('headers', [])
                points_0_rows = points_0_dict.get('data', [])
                if points_0_rows and len(points_0_rows) > 1:
                    progress.add_total(len(points_0_rows) - 1)
                    self._populate_geosys_columns(
                        points_0_headers, points_0_rows, allow_add_point=True,
                        preserved_by_key=preserved_points_geosys, key_header='objectid_points',
                        progress=progress
                    )
                    self._update_points_0_geosys_attributes(points_0_headers, points_0_rows)
                    points_0_dict['headers'] = points_0_headers
                    points_0_dict['data'] = points_0_rows
                    points_0_dict['column_count'] = len(points_0_headers)
                geosys_layer = self._create_combined_geosys_layer(
                    headers, data_rows, points_0_headers, points_0_rows
                )
                self.parent.geosys_layer = geosys_layer
            
            progress.close()
            if is_geospatial_source:
                self._refresh_processed_views(refresh_table=not silent)
            if not silent:
                self._offer_zoom_to_layers([geosys_layer, points_0_layer])
            log_message(f"Geosys points loaded: {processed_count} rows processed", Qgis.Success)
            
        except Exception as e:
            show_error_message(
                self.parent,
                "Error",
                f"Failed to load geosys points:\n{str(e)}"
            )
            log_message(f"Error loading geosys points: {str(e)}", Qgis.Critical)

    def _create_combined_geosys_layer(self, names_headers, names_rows, points_headers, points_rows):
        """Combine display rows while retaining the source table and its stable identifiers."""
        headers = ['source_layer']
        for header in names_headers + points_headers:
            if header.lower() not in {name.lower() for name in headers}:
                headers.append(header)
        rows = [headers]
        for source, source_headers, source_rows in (
                ('names_6', names_headers, names_rows),
                ('points_0', points_headers, points_rows)):
            indexes = {header.lower(): idx for idx, header in enumerate(source_headers)}
            for row in source_rows[1:]:
                values = [
                    row[indexes[header.lower()]]
                    if header.lower() in indexes and indexes[header.lower()] < len(row) else None
                    for header in headers[1:]
                ]
                rows.append([source] + values)
        layer = self._create_geosys_layer(headers, rows, 'data')
        if layer is not None:
            layer._geosys_combined = True
            self._setup_layer_sync(layer, rows, headers)
        return layer

    def _refresh_processed_views(self, refresh_table=True):
        """Reload processed layers and the combined table so the new geosys columns appear."""
        file_path = self.parent.batch_load_file_path
        for layer in QgsProject.instance().mapLayers().values():
            if (isinstance(layer, QgsVectorLayer) and layer.source().startswith(file_path)
                    and not layer.isEditable()):
                layer.reload()
                layer.triggerRepaint()

        dialog = getattr(self.parent, 'current_table_dialog', None)
        if not refresh_table or dialog is None or dialog.data_dict.get('type') != 'combined_gdb_view':
            return
        names_layer = QgsVectorLayer(f"{file_path}|layername=names_6", "names_6", "ogr")
        points_layer = QgsVectorLayer(f"{file_path}|layername=points_0", "points_0", "ogr")
        if names_layer.isValid() and points_layer.isValid():
            self.file_import_handler._show_data_table(
                self.file_import_handler._combined_names_points_table(names_layer, points_layer)
            )

    def _offer_zoom_to_layers(self, layers):
        """Offer to zoom to the combined extent of newly created spatial layers."""
        spatial_layers = [
            layer for layer in layers
            if layer and layer.isValid() and layer.isSpatial() and layer.featureCount()
            and any(feature.hasGeometry() and not feature.geometry().isEmpty()
                for feature in layer.getFeatures())
        ]
        if not spatial_layers:
            return
        answer = QtWidgets.QMessageBox.question(
            self.parent,
            "Zoom to layer",
            "Zoom to all loaded layers?",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
            QtWidgets.QMessageBox.Yes
        )
        if answer != QtWidgets.QMessageBox.Yes:
            return

        from qgis.core import QgsCoordinateTransform, QgsRectangle
        from qgis.utils import iface

        if not iface:
            return
        destination_crs = iface.mapCanvas().mapSettings().destinationCrs()
        extent = QgsRectangle()
        extent.setMinimal()
        has_geometry = False
        for layer in spatial_layers:
            layer_extent = layer.extent()
            if layer.crs() != destination_crs:
                transform = QgsCoordinateTransform(layer.crs(), destination_crs, QgsProject.instance())
                layer_extent = transform.transformBoundingBox(layer_extent)
            extent.combineExtentWith(layer_extent)
            has_geometry = True
        if has_geometry:
            extent.grow(max(
                0.05 if destination_crs.isGeographic() else 5000,
                max(extent.width(), extent.height()) * 0.1
            ))
            iface.mapCanvas().setExtent(extent)
            iface.mapCanvas().refresh()

    def _populate_geosys_columns(self, headers, data_rows, allow_add_point=True, preserved_by_key=None, key_header='objectid_points', progress=None):
        """
        Add and populate geosys coordinate columns in a tabular batch dataset.
        Rows sharing a non-empty toponymic_feature_id retain a point only on the
        first row that has Geosys coordinates.

        :param preserved_by_key: Optional {int objectid: {'latitude_geosys', 'longitude_geosys',
            'source_pt_geosys', 'add_pt_geosys'}} used to keep previously loaded/edited
            geosys values instead of recomputing them (e.g. after reprocessing a GDB).
        :param key_header: Header (holding the raw OBJECTID) used to match rows against preserved_by_key.
        """
        new_columns = ['latitude_geosys', 'longitude_geosys', 'source_pt_geosys', 'add_pt_geosys']
        headers_lower = [h.lower() if h else '' for h in headers]
        columns_added = []
        for col in new_columns:
            if col not in headers_lower:
                headers.append(col)
                columns_added.append(col)
        if columns_added:
            for row_idx in range(len(data_rows)):
                while len(data_rows[row_idx]) < len(headers):
                    data_rows[row_idx].append(None)
            data_rows[0] = headers.copy()
            log_message(f"Added {len(columns_added)} new columns: {', '.join(columns_added)}", Qgis.Info)

        header_map = {header.lower(): idx for idx, header in enumerate(headers) if header}
        lat_idx = header_map.get('latitude')
        lon_idx = header_map.get('longitude')
        cgndb_id_idx = header_map.get('existing_cgndb_id')
        tfid_idx = header_map.get('toponymic_feature_id')
        lat_geosys_idx = header_map.get('latitude_geosys')
        lon_geosys_idx = header_map.get('longitude_geosys')
        source_geosys_idx = header_map.get('source_pt_geosys')
        add_geosys_idx = header_map.get('add_pt_geosys')
        key_idx = header_map.get(key_header.lower()) if preserved_by_key else None
        if lat_idx is None or lon_idx is None:
            raise ValueError("The data must contain 'latitude' and 'longitude' columns.")

        processed_count = 0
        api_check_count = 0
        geosys_tfids = set()
        for row_idx in range(1, len(data_rows)):
            if progress:
                progress.step()
            row = data_rows[row_idx]
            tfid_value = row[tfid_idx] if tfid_idx is not None and tfid_idx < len(row) else None
            tfid = str(tfid_value).strip().casefold() if not self._is_empty_value(tfid_value) else ''
            if tfid and tfid in geosys_tfids:
                while len(row) < len(headers):
                    row.append(None)
                row[lat_geosys_idx] = None
                row[lon_geosys_idx] = None
                row[source_geosys_idx] = None
                row[add_geosys_idx] = None
                continue

            if preserved_by_key and key_idx is not None:
                key_value = row[key_idx] if key_idx < len(row) else None
                try:
                    preserved = preserved_by_key.get(int(key_value)) if not self._is_empty_value(key_value) else None
                except (TypeError, ValueError):
                    preserved = None
                if preserved and not self._is_empty_value(preserved.get('latitude_geosys')):
                    row[lat_geosys_idx] = preserved.get('latitude_geosys')
                    row[lon_geosys_idx] = preserved.get('longitude_geosys')
                    row[source_geosys_idx] = preserved.get('source_pt_geosys')
                    row[add_geosys_idx] = preserved.get('add_pt_geosys')
                    if tfid and not self._is_empty_value(row[lat_geosys_idx]):
                        geosys_tfids.add(tfid)
                    processed_count += 1
                    continue
            # Keep geosys values already stored in the data (e.g. points moved by the user).
            if not columns_added and lat_geosys_idx < len(row) and not self._is_empty_value(row[lat_geosys_idx]):
                if tfid:
                    geosys_tfids.add(tfid)
                processed_count += 1
                continue
            cgndb_id = row[cgndb_id_idx] if cgndb_id_idx is not None and cgndb_id_idx < len(row) else None
            if not cgndb_id or str(cgndb_id).strip() == '':
                lat_value = row[lat_idx] if lat_idx < len(row) else None
                lon_value = row[lon_idx] if lon_idx < len(row) else None
                if lat_value and lon_value:
                    row[lat_geosys_idx] = lat_value
                    row[lon_geosys_idx] = lon_value
                    row[source_geosys_idx] = 'batch_load'
                    row[add_geosys_idx] = 'yes' if allow_add_point else None
                    processed_count += 1
                else:
                    row[add_geosys_idx] = None
            else:
                api_check_count += 1
                geosys_point = self._get_geosys_point_from_api(cgndb_id)
                if geosys_point:
                    row[lat_geosys_idx] = geosys_point.get('latitude')
                    row[lon_geosys_idx] = geosys_point.get('longitude')
                    row[source_geosys_idx] = 'cgndb_1347'
                    row[add_geosys_idx] = None
                    processed_count += 1
                else:
                    lat_value = row[lat_idx] if lat_idx < len(row) else None
                    lon_value = row[lon_idx] if lon_idx < len(row) else None
                    if lat_value and lon_value:
                        row[lat_geosys_idx] = lat_value
                        row[lon_geosys_idx] = lon_value
                        row[source_geosys_idx] = 'batch_load'
                        row[add_geosys_idx] = 'yes' if allow_add_point else None
                        processed_count += 1
                    else:
                        row[add_geosys_idx] = None
            if tfid and not self._is_empty_value(row[lat_geosys_idx]):
                geosys_tfids.add(tfid)
        return processed_count, api_check_count

    def _update_points_0_geosys_attributes(self, headers, data_rows):
        """Write geosys columns back to the processed points_0 layer without changing geometry."""
        layer = getattr(self.parent, 'processed_points_layer', None)
        if not layer or not layer.isValid():
            layer = QgsVectorLayer(
                f"{self.parent.batch_load_file_path}|layername=points_0",
                "points_0",
                "ogr"
            )
        if not layer.isValid():
            log_message("Could not update points_0 geosys columns: layer is invalid", Qgis.Warning)
            return

        header_map = {header.lower(): idx for idx, header in enumerate(headers) if header}
        key_idx = header_map.get('objectid_points')
        if key_idx is None:
            log_message("Could not update points_0 geosys columns: no objectid_points column", Qgis.Warning)
            return

        geosys_fields = [
            ('latitude_geosys', QVariant.Double),
            ('longitude_geosys', QVariant.Double),
            ('source_pt_geosys', QVariant.String),
            ('add_pt_geosys', QVariant.String)
        ]

        layer.startEditing()
        for field_name, field_type in geosys_fields:
            if layer.fields().indexOf(field_name) < 0:
                layer.addAttribute(QgsField(field_name, field_type))
        layer.updateFields()

        output_indexes = {field_name: layer.fields().indexOf(field_name) for field_name, _ in geosys_fields}
        layer_key_idx = layer.fields().indexOf('objectid_points')
        rows_by_key = {}
        for row in (data_rows[1:] if len(data_rows) > 1 else []):
            if key_idx < len(row):
                try:
                    rows_by_key[int(row[key_idx])] = row
                except (TypeError, ValueError):
                    continue

        updated = 0
        for feature in layer.getFeatures():
            try:
                feature_key = int(feature[layer_key_idx])
            except (TypeError, ValueError):
                continue
            row = rows_by_key.get(feature_key)
            if not row:
                continue
            for field_name, _ in geosys_fields:
                row_idx = header_map.get(field_name)
                value = row[row_idx] if row_idx is not None and row_idx < len(row) else None
                layer.changeAttributeValue(feature.id(), output_indexes[field_name], value)
            updated += 1

        if layer.commitChanges():
            layer.triggerRepaint()
            log_message(f"Updated geosys columns on points_0 ({updated} row(s))", Qgis.Success)
        else:
            log_message("Failed to commit geosys column updates on points_0", Qgis.Warning)

    def _update_names_6_geosys_attributes(self, headers, data_rows):
        for layer_name in ('names_6', 'original_names_6'):
            self._update_names_geosys_attributes(headers, data_rows, layer_name)

    def _update_names_geosys_attributes(self, headers, data_rows, layer_name):
        """
        Write geosys columns back to the processed names_6 layer without changing geometry.
        Unlike points_0 (matched positionally since it's freshly re-derived every load), names_6
        rows are matched by xlsx_row_id: without this write-back, a dragged names_6 geosys point
        would revert to its API-derived position on the next reprocess (nothing to capture from).
        """
        layer = QgsVectorLayer(
            f"{self.parent.batch_load_file_path}|layername={layer_name}",
            layer_name,
            "ogr"
        )
        if not layer.isValid():
            if layer_name == 'names_6':
                log_message("Could not update names_6 geosys columns: layer is invalid", Qgis.Warning)
            return

        header_map = {header.lower(): idx for idx, header in enumerate(headers) if header}
        key_idx = header_map.get('xlsx_row_id')
        if key_idx is None:
            log_message("Could not update names_6 geosys columns: no xlsx_row_id column", Qgis.Warning)
            return

        geosys_fields = [
            ('latitude_geosys', QVariant.Double),
            ('longitude_geosys', QVariant.Double),
            ('source_pt_geosys', QVariant.String),
            ('add_pt_geosys', QVariant.String)
        ]

        layer.startEditing()
        for field_name, field_type in geosys_fields:
            if layer.fields().indexOf(field_name) < 0:
                layer.addAttribute(QgsField(field_name, field_type))
        layer.updateFields()

        output_indexes = {field_name: layer.fields().indexOf(field_name) for field_name, _ in geosys_fields}
        layer_key_idx = layer.fields().indexOf('xlsx_row_id')
        rows_by_key = {}
        for row in (data_rows[1:] if len(data_rows) > 1 else []):
            if key_idx < len(row):
                try:
                    rows_by_key[int(row[key_idx])] = row
                except (TypeError, ValueError):
                    continue

        updated = 0
        for feature in layer.getFeatures():
            try:
                feature_key = int(feature[layer_key_idx])
            except (TypeError, ValueError):
                continue
            row = rows_by_key.get(feature_key)
            if not row:
                continue
            for field_name, _ in geosys_fields:
                row_idx = header_map.get(field_name)
                value = row[row_idx] if row_idx is not None and row_idx < len(row) else None
                layer.changeAttributeValue(feature.id(), output_indexes[field_name], value)
            updated += 1

        if layer.commitChanges():
            layer.triggerRepaint()
            log_message(f"Updated geosys columns on {layer_name} ({updated} row(s))", Qgis.Success)
        else:
            log_message(f"Failed to commit geosys column updates on {layer_name}", Qgis.Warning)

    def _load_points_0_as_data(self, optional=False):
        """Load points_0 attributes, allowing names-only datasets when optional."""
        layer = QgsVectorLayer(
            f"{self.parent.batch_load_file_path}|layername=points_0",
            "points_0",
            "ogr"
        )
        if not layer.isValid():
            if optional:
                return {}
            raise DataLoadError("Failed to load points_0 from the processed GDB")

        headers = [field.name() for field in layer.fields()]
        lower_headers = [header.lower() for header in headers]
        if 'latitude' not in lower_headers:
            headers.append('latitude')
        if 'longitude' not in lower_headers:
            headers.append('longitude')

        data = [headers]
        for feature in layer.getFeatures():
            row = [feature[field.name()] for field in layer.fields()]
            point = feature.geometry().asPoint()
            if 'latitude' not in lower_headers:
                row.append(point.y())
            if 'longitude' not in lower_headers:
                row.append(point.x())
            data.append(row)

        return {
            'type': 'qgis_layer',
            'source': layer.source(),
            'layer_name': layer.name(),
            'headers': headers,
            'data': data,
            'row_count': len(data),
            'column_count': len(headers)
        }
    
    def toggle_geosys_editing(self, layer_attr='geosys_layer'):
        """
        Toggle edit mode for the geosys point layer: start editing with the Vertex Tool,
        or save changes if already editing.
        
        :return: True if editing is now active, False otherwise
        """
        layer = getattr(self.parent, layer_attr, None)
        if not layer:
            show_error_message(
                self.parent,
                "No Layer",
                "Please load GeoSys points first using 'Load GeoSys points (1347)'."
            )
            return False
        
        if layer.isEditable():
            if layer.commitChanges():
                log_message(f"Saved edits for layer '{layer.name()}'", Qgis.Success)
                file_path = getattr(self.parent, 'batch_load_file_path', '') or ''
                if file_path.lower().endswith(('.xlsx', '.csv')):
                    try:
                        self.file_import_handler.save_current_batch_as_csv()
                    except Exception as error:
                        show_error_message(
                            self.parent,
                            "CSV Save Failed",
                            f"Geosys edits were committed, but the batch table could not be saved as CSV:\n{error}"
                        )
                        log_message(f"Failed to save Geosys edits to batch CSV: {error}", Qgis.Critical)
                        return False
                show_info_message(self.parent, "Edits Saved", f"Changes to '{layer.name()}' have been saved.")
            else:
                show_error_message(self.parent, "Save Failed", "Failed to save changes to the geosys layer.")
            return False
        else:
            self._activate_vertex_tool_for_layer(layer)
            return True
    
    def discard_geosys_edits(self, layer_attr='geosys_layer'):
        """Undo all unsaved edits on the geosys point layer and stop editing."""
        layer = getattr(self.parent, layer_attr, None)
        if not layer:
            return
        if not layer.isEditable():
            show_info_message(self.parent, "Not Editing", "The geosys layer is not currently being edited.")
            return
        if layer.rollBack():
            log_message(f"Discarded edits for layer '{layer.name()}'", Qgis.Info)
            show_info_message(self.parent, "Edits Discarded", f"Changes to '{layer.name()}' have been discarded.")
        else:
            show_error_message(self.parent, "Discard Failed", "Failed to discard changes to the geosys layer.")
    
    def has_unsaved_geosys_edits(self, layer_attr='geosys_layer'):
        """Return True if the geosys layer is currently being edited with uncommitted changes."""
        layer = getattr(self.parent, layer_attr, None)
        return bool(layer and layer.isEditable() and layer.isModified())
    
    def save_geosys_edits(self, layer_attr='geosys_layer'):
        """Commit any pending edits on the geosys layer."""
        layer = getattr(self.parent, layer_attr, None)
        if layer and layer.isEditable():
            layer.commitChanges()
    
    def remove_layers(self, remove_basemap=True):
        """Remove batch layers, optionally including the basemap."""
        project = QgsProject.instance()
        
        for attr in ('coordinate_layer', 'processed_points_layer', 'geosys_layer', 'geosys_layer_points_0'):
            layer = getattr(self.parent, attr, None)
            if layer:
                if layer.isEditable():
                    layer.rollBack()
                if project.mapLayer(layer.id()):
                    project.removeMapLayer(layer.id())
                setattr(self.parent, attr, None)

        error_source_layers = getattr(self.parent, 'error_source_layers', None)
        if error_source_layers:
            for layer in error_source_layers.values():
                if project.mapLayer(layer.id()):
                    project.removeMapLayer(layer.id())
            error_source_layers.clear()

        # Processed GDB output layers (names_6, points_0, lines_1, polygons_2, error, ...)
        # are added straight to the project and never kept on self.parent, so find them by source.
        batch_load_file_path = getattr(self.parent, 'batch_load_file_path', None)
        if batch_load_file_path:
            for layer in list(project.mapLayers().values()):
                if layer.source().startswith(batch_load_file_path):
                    if hasattr(layer, 'isEditable') and layer.isEditable():
                        layer.rollBack()
                    project.removeMapLayer(layer.id())

        if remove_basemap:
            basemap_names = ['OpenStreetMap', 'OSM', 'Basemap', 'Base Map']
            for layer in list(project.mapLayers().values()):
                if any(name.lower() in layer.name().lower() for name in basemap_names):
                    project.removeMapLayer(layer.id())
        
        try:
            from qgis.utils import iface
            if iface:
                iface.mapCanvas().refresh()
        except Exception:
            pass
        
        log_message(
            "Removed coordinate/geosys layers" + (" and basemap" if remove_basemap else ""),
            Qgis.Info
        )
    
    def _get_geosys_point_from_api(self, cgndb_id):
        """Query geoname-t API for geosys point coordinates."""
        try:
            # Build API URL
            url = f"{self.auth_handler.geoname_api_base_url}/toponyms/{cgndb_id}.json"
            log_message(f"Checking geosys point for CGNDB ID: {cgndb_id}", Qgis.Info)
            
            # Make API request
            response = self.auth_handler.geoname_api_session.get(url, timeout=10)
            
            if response.status_code == 404:
                log_message(f"CGNDB ID {cgndb_id} not found in database", Qgis.Info)
                return None
            elif response.status_code != 200:
                log_message(f"API error for {cgndb_id}: status {response.status_code}", Qgis.Warning)
                return None
            
            # Parse response
            data = response.json()
            
            # Navigate to delineations
            toponymic_feature = data.get('toponymicFeature')
            if not toponymic_feature:
                return None
            
            delineations = toponymic_feature.get('delineations', [])
            if not delineations:
                return None
            
            # Look for delineation with source code 1347 (geosys)
            for delineation in delineations:
                delineation_source = delineation.get('delineationSource', {})
                source_code = delineation_source.get('code')
                
                if source_code == 1347:
                    # Found geosys delineation
                    geometry = delineation.get('geometry', {})
                    geom_type = geometry.get('type')
                    
                    # Check if it's a Point
                    if geom_type != 'Point':
                        log_message(f"Geosys delineation for {cgndb_id} is not a Point (type: {geom_type}), skipping", Qgis.Info)
                        continue
                    
                    # Extract coordinates [longitude, latitude]
                    coordinates = geometry.get('coordinates', [])
                    if len(coordinates) < 2:
                        continue
                    
                    lon_source = coordinates[0]
                    lat_source = coordinates[1]
                    
                    # Extract source CRS
                    crs_info = geometry.get('crs', {})
                    crs_properties = crs_info.get('properties', {})
                    crs_name = crs_properties.get('name', 'EPSG:4326')
                    
                    # Reproject to EPSG:4326 if needed
                    if crs_name != 'EPSG:4326':
                        try:
                            source_crs = QgsCoordinateReferenceSystem(crs_name)
                            dest_crs = QgsCoordinateReferenceSystem('EPSG:4326')
                            
                            if not source_crs.isValid():
                                continue
                            
                            transform = QgsCoordinateTransform(source_crs, dest_crs, QgsProject.instance())
                            point = QgsPointXY(lon_source, lat_source)
                            transformed_point = transform.transform(point)
                            
                            lon_4326 = transformed_point.x()
                            lat_4326 = transformed_point.y()
                            
                            log_message(f"Reprojected {cgndb_id} from {crs_name} to EPSG:4326", Qgis.Info)
                        except Exception as transform_error:
                            log_message(f"Error reprojecting {cgndb_id}: {str(transform_error)}", Qgis.Warning)
                            continue
                    else:
                        lon_4326 = lon_source
                        lat_4326 = lat_source
                    
                    log_message(f"Found geosys point for {cgndb_id}: lat={lat_4326}, lon={lon_4326}", Qgis.Success)
                    return {
                        'latitude': lat_4326,
                        'longitude': lon_4326
                    }
            
            log_message(f"No geosys delineation (code 1347) found for {cgndb_id}", Qgis.Info)
            return None
            
        except Exception as e:
            log_message(f"Error checking API for CGNDB ID {cgndb_id}: {str(e)}", Qgis.Warning)
            return None
    
    def _create_geosys_layer(self, headers, data_rows, sheet_name):
        """Create a QGIS layer from geosys coordinates."""
        try:
            header_map = {header.lower(): idx for idx, header in enumerate(headers) if header}
            
            if 'latitude_geosys' not in header_map or 'longitude_geosys' not in header_map:
                log_message("Geosys coordinate columns not found, cannot create layer", Qgis.Warning)
                return None
            
            layer_name = f"Geosys Points ({sheet_name})"
            layer = QgsVectorLayer("Point?crs=EPSG:4326", layer_name, "memory")
            provider = layer.dataProvider()
            
            # Add fields
            fields = []
            for header in headers:
                fields.append(QgsField(header, QVariant.String))
            provider.addAttributes(fields)
            layer.updateFields()
            
            # Get column indices
            lat_geosys_idx = header_map['latitude_geosys']
            lon_geosys_idx = header_map['longitude_geosys']
            
            # Add features (skip header row)
            features = []
            row_map = []
            data_only = data_rows[1:] if len(data_rows) > 1 else []
            skipped_count = 0
            
            for row_idx, row in enumerate(data_only, start=2):
                if len(row) < len(headers):
                    row = list(row) + [None] * (len(headers) - len(row))
                
                lat_value = row[lat_geosys_idx] if lat_geosys_idx < len(row) else None
                lon_value = row[lon_geosys_idx] if lon_geosys_idx < len(row) else None
                
                if lat_value is None or lon_value is None or str(lat_value).strip() == '' or str(lon_value).strip() == '':
                    skipped_count += 1
                    continue
                    
                try:
                    lat = float(lat_value)
                    lon = float(lon_value)
                except (ValueError, TypeError):
                    skipped_count += 1
                    continue
                
                point = QgsPointXY(lon, lat)
                feature = QgsFeature()
                feature.setGeometry(QgsGeometry.fromPointXY(point))
                
                attributes = [str(cell) if cell is not None else '' for cell in row]
                feature.setAttributes(attributes)
                
                features.append(feature)
                row_map.append(row_idx - 1)
            
            provider.addFeatures(features)
            layer._row_map = row_map
            layer.updateExtents()
            
            # Apply styling
            self._apply_geosys_layer_style(layer, headers)
            
            # Add basemap
            self._add_basemap_if_needed()
            
            # Add layer to project
            QgsProject.instance().addMapLayer(layer)
            
            # Restrict editing capabilities - only allow moving points
            self._restrict_layer_editing(layer)
            
            log_message(f"Created geosys layer with {len(features)} points ({skipped_count} skipped)", Qgis.Success)
            return layer
            
        except Exception as e:
            log_message(f"Error creating geosys layer: {str(e)}", Qgis.Critical)
            return None
    
    def _show_batch_table_with_geosys(self, data_dict):
        """Show the batch table with the geosys columns and write them to the CSV."""
        table_dict = {
            'type': 'csv',
            'source': self.parent.batch_load_file_path,
            'sheet_name': 'data',
            'headers': data_dict['headers'],
            'data': data_dict['data'],
            'row_count': len(data_dict['data']) - 1,
            'column_count': len(data_dict['headers']),
        }
        self.file_import_handler._show_data_table(table_dict)
        self.file_import_handler.save_current_batch_as_csv()
        coordinate_layer = getattr(self.parent, 'coordinate_layer', None)
        if coordinate_layer is not None and QgsProject.instance().mapLayer(coordinate_layer.id()):
            # Rebuild so related-feature attributes include the geosys columns.
            self.add_coordinate_as_layer(silent=True)

    def _setup_layer_sync(self, layer, data_rows, headers):
        """
        Set up two-way synchronization between the map layer and table data.
        When geometry is edited in the layer, update the corresponding table data.
        
        :param layer: The QGIS vector layer
        :param data_rows: Reference to the data rows (including header)
        :param headers: List of column headers
        """
        try:
            # Store references in the layer object for access in signal handlers
            layer._sync_data_rows = data_rows
            layer._sync_headers = headers
            layer._sync_handler = self
            
            # Determine which coordinate columns to use
            header_map = {header.lower(): idx for idx, header in enumerate(headers) if header}
            
            # Check for geosys columns first, then fall back to regular columns
            if 'latitude_geosys' in header_map and 'longitude_geosys' in header_map:
                layer._sync_lat_col = 'latitude_geosys'
                layer._sync_lon_col = 'longitude_geosys'
            elif 'latitude' in header_map and 'longitude' in header_map:
                layer._sync_lat_col = 'latitude'
                layer._sync_lon_col = 'longitude'
            else:
                log_message("No coordinate columns found for sync", Qgis.Warning)
                return
            
            # Connect to geometry change signal when editing is committed
            if getattr(layer, '_geosys_combined', False):
                # Persist only committed moves so Discard leaves both source tables unchanged.
                layer.committedGeometriesChanges.connect(
                    lambda _layer_id, geometries: self._sync_committed_geosys_geometries(layer, geometries)
                )
            else:
                layer.geometryChanged.connect(lambda fid, geom: self._on_geometry_changed(layer, fid, geom))
            
            log_message(f"Set up two-way synchronization for layer '{layer.name()}' using {layer._sync_lat_col}/{layer._sync_lon_col}", Qgis.Info)
            
        except Exception as e:
            log_message(f"Error setting up layer sync: {str(e)}", Qgis.Warning)

    def _sync_committed_geosys_geometries(self, layer, geometries):
        for feature_id, geometry in geometries.items():
            self._on_geometry_changed(layer, feature_id, geometry)
        self._refresh_processed_views()

    def _on_geometry_changed(self, layer, feature_id, geometry):
        """
        Handle geometry changes in the layer and update table data.
        
        :param layer: The QGIS vector layer
        :param feature_id: ID of the feature that changed
        :param geometry: New geometry
        """
        try:
            if not hasattr(layer, '_sync_data_rows') or not hasattr(layer, '_sync_headers'):
                return
            
            if not hasattr(layer, '_sync_lat_col') or not hasattr(layer, '_sync_lon_col'):
                return
            
            data_rows = layer._sync_data_rows
            headers = layer._sync_headers
            
            # Create header map
            header_map = {header.lower(): idx for idx, header in enumerate(headers) if header}
            lat_idx = header_map.get(layer._sync_lat_col)
            lon_idx = header_map.get(layer._sync_lon_col)
            
            if lat_idx is None or lon_idx is None:
                return
            
            # Get the feature by ID
            features_list = list(layer.getFeatures())
            feature_index = None
            
            for idx, feature in enumerate(features_list):
                if feature.id() == feature_id:
                    feature_index = idx
                    break
            
            if feature_index is None:
                return
            
            # Rows without a geosys point have no feature, so map through the stored row list.
            row_map = getattr(layer, '_row_map', None)
            row_idx = row_map[feature_index] if row_map and feature_index < len(row_map) else feature_index + 1
            
            if row_idx >= len(data_rows):
                return

            source_idx = header_map.get('source_layer')
            source = (
                str(data_rows[row_idx][source_idx]).lower()
                if getattr(layer, '_geosys_combined', False) is True and source_idx is not None
                else None
            )
            
            # Extract new coordinates from geometry
            point = geometry.asPoint()
            lon = point.x()
            lat = point.y()
            
            # Update the data rows
            data_rows[row_idx][lat_idx] = lat
            data_rows[row_idx][lon_idx] = lon
            add_pt_geosys_idx = header_map.get('add_pt_geosys')
            if add_pt_geosys_idx is not None:
                data_rows[row_idx][add_pt_geosys_idx] = 'yes'
            if source is not None:
                attributes = {lat_idx: str(lat), lon_idx: str(lon)}
                if add_pt_geosys_idx is not None:
                    attributes[add_pt_geosys_idx] = 'yes'
                if not layer.dataProvider().changeAttributeValues({feature_id: attributes}):
                    log_message("Could not synchronize saved Geosys point attributes", Qgis.Warning)
            
            # Update the table dialog if it's still open
            batch_path = getattr(self.parent, 'batch_load_file_path', '') or ''
            batch_dialog = getattr(self.parent, 'current_table_dialog', None)
            row_id_idx = header_map.get('xlsx_row_id')
            if batch_dialog is not None and batch_path.lower().endswith(('.xlsx', '.csv')):
                if row_id_idx is not None:
                    row_id = data_rows[row_idx][row_id_idx]
                    batch_dialog.update_cell(row_id, lat_idx, str(lat))
                    batch_dialog.update_cell(row_id, lon_idx, str(lon))
                    if add_pt_geosys_idx is not None:
                        batch_dialog.update_cell(row_id, add_pt_geosys_idx, 'yes')
            elif source is not None:
                # The combined table is refreshed after saving; row IDs can overlap across sources.
                pass
            elif batch_dialog is not None and row_id_idx is not None and add_pt_geosys_idx is not None:
                dialog_headers = batch_dialog.data_dict.get('headers', [])
                dialog_header_map = {
                    str(header).lower(): idx for idx, header in enumerate(dialog_headers) if header
                }
                row_id = data_rows[row_idx][row_id_idx]
                for field_name, value in (
                        (layer._sync_lat_col, str(lat)), (layer._sync_lon_col, str(lon))):
                    dialog_col = dialog_header_map.get(field_name)
                    if dialog_col is not None:
                        batch_dialog.update_cell(row_id, dialog_col, value)
                dialog_add_idx = dialog_header_map.get('add_pt_geosys')
                if dialog_add_idx is not None:
                    batch_dialog.update_cell(row_id, dialog_add_idx, 'yes')
            elif hasattr(self.parent, 'current_table_dialog') and self.parent.current_table_dialog:
                try:
                    table = self.parent.current_table_dialog.table
                    # Update the table cells (subtract 1 because table doesn't have header row)
                    table_row = feature_index
                    
                    if table_row < table.rowCount():
                        lat_item = table.item(table_row, lat_idx)
                        lon_item = table.item(table_row, lon_idx)
                        
                        if lat_item:
                            lat_item.setText(str(lat))
                        if lon_item:
                            lon_item.setText(str(lon))
                        if add_pt_geosys_idx is not None:
                            add_item = table.item(table_row, add_pt_geosys_idx)
                            if add_item:
                                add_item.setText('yes')
                        
                        log_message(f"Updated table row {table_row + 1}: {layer._sync_lat_col}={lat}, {layer._sync_lon_col}={lon}", Qgis.Info)
                except Exception as table_error:
                    log_message(f"Could not update table display: {str(table_error)}", Qgis.Warning)
            
            log_message(f"Synchronized geometry change: row {row_idx}, {layer._sync_lat_col}={lat}, {layer._sync_lon_col}={lon}", Qgis.Success)

            # The sync above only updates the in-memory table copy and its display; without
            # this, the moved point is lost the next time points_0/names_6 is (re)loaded from
            # disk (e.g. on Reprocess), since it was never written back to the actual layer.
            log_message(f"_on_geometry_changed: layer.name()='{layer.name()}', row_idx={row_idx}, row={data_rows[row_idx]}", Qgis.Info)
            if source == 'points_0':
                self._persist_geosys_row('points_0', 'objectid_points', headers, data_rows[row_idx])
            elif source == 'names_6':
                self._persist_geosys_row('names_6', 'xlsx_row_id', headers, data_rows[row_idx])
            elif layer.name().startswith('Geosys Points (points_0'):
                self._persist_geosys_row('points_0', 'objectid_points', headers, data_rows[row_idx])
            elif layer.name().startswith('Geosys Points (names_6'):
                self._persist_geosys_row('names_6', 'xlsx_row_id', headers, data_rows[row_idx])

        except Exception as e:
            log_message(f"Error handling geometry change: {str(e)}", Qgis.Warning)

    def _persist_geosys_row(self, target_layer_name, key_field, headers, row):
        """
        Write one row's geosys lat/long/source/add_pt columns directly into the actual
        points_0/names_6 layer, matched by a stable raw identifier (not QGIS's internal
        feature id). This makes a dragged geosys point survive until the next reprocess.
        """
        file_path = getattr(self.parent, 'batch_load_file_path', None)
        if not file_path:
            log_message("_persist_geosys_row: no batch_load_file_path, aborting", Qgis.Warning)
            return

        layer = getattr(self.parent, 'processed_points_layer', None) if target_layer_name == 'points_0' else None
        if not layer or not layer.isValid():
            layer = QgsVectorLayer(f"{file_path}|layername={target_layer_name}", target_layer_name, "ogr")
            if not layer.isValid():
                log_message(f"_persist_geosys_row: could not load layer '{target_layer_name}'", Qgis.Warning)
                return

        header_map = {str(h).lower(): idx for idx, h in enumerate(headers) if h}
        key_col = header_map.get(key_field.lower())
        if key_col is None or key_col >= len(row):
            log_message(f"_persist_geosys_row: key column '{key_field}' not found in row headers", Qgis.Warning)
            return
        try:
            key_value = int(row[key_col])
        except (TypeError, ValueError):
            log_message(f"_persist_geosys_row: row's {key_field} value '{row[key_col]}' is not an int", Qgis.Warning)
            return

        fields = layer.fields()
        key_idx = fields.indexOf(key_field)
        if key_idx < 0:
            log_message(f"_persist_geosys_row: layer '{layer.name()}' has no '{key_field}' field", Qgis.Warning)
            return

        # names_6's real layer never gets these fields added elsewhere (only points_0 does,
        # via _update_points_0_geosys_attributes), so add them here if missing.
        geosys_field_types = (
            ('latitude_geosys', QVariant.Double), ('longitude_geosys', QVariant.Double),
            ('source_pt_geosys', QVariant.String), ('add_pt_geosys', QVariant.String)
        )
        was_editable = layer.isEditable()
        if not was_editable:
            layer.startEditing()
        missing_fields = [name for name, _ in geosys_field_types if fields.indexOf(name) < 0]
        if missing_fields:
            for field_name, field_type in geosys_field_types:
                if fields.indexOf(field_name) < 0:
                    layer.addAttribute(QgsField(field_name, field_type))
            layer.updateFields()
            fields = layer.fields()
            key_idx = fields.indexOf(key_field)

        geosys_columns = ('latitude_geosys', 'longitude_geosys', 'source_pt_geosys', 'add_pt_geosys')
        updated = bool(missing_fields)
        matched_feature = False
        for feature in layer.getFeatures():
            try:
                feature_key = int(feature[key_idx])
            except (TypeError, ValueError):
                continue
            if feature_key != key_value:
                continue
            matched_feature = True
            for col_name in geosys_columns:
                col_idx = header_map.get(col_name)
                field_idx = fields.indexOf(col_name)
                if col_idx is None or field_idx < 0 or col_idx >= len(row):
                    continue
                value = row[col_idx]
                if feature[field_idx] != value:
                    layer.changeAttributeValue(feature.id(), field_idx, value)
                    updated = True
            break
        if not matched_feature:
            log_message(f"_persist_geosys_row: no feature in '{layer.name()}' with {key_field}={key_value}", Qgis.Warning)

        if updated:
            commit_ok = layer.commitChanges()
            layer.triggerRepaint()
            log_message(
                f"Persisted geosys change to {target_layer_name} (key {key_field}={key_value}), commit_ok={commit_ok}",
                Qgis.Success if commit_ok else Qgis.Warning
            )
            if commit_ok and target_layer_name == 'names_6':
                self._update_names_geosys_attributes(headers, [headers, row], 'original_names_6')
        elif matched_feature:
            log_message(f"_persist_geosys_row: matched {target_layer_name} {key_field}={key_value} but no field value differed", Qgis.Info)
        elif not was_editable:
            layer.rollBack()
    
    def _restrict_layer_editing(self, layer):
        """
        Restrict layer editing capabilities to only allow moving points.
        Disables add/delete features and copy/paste operations.
        
        :param layer: The QGIS vector layer to restrict
        """
        try:
            from qgis.core import QgsVectorDataProvider
            
            # Get the layer's capabilities
            caps = layer.dataProvider().capabilities()
            
            # We want to keep only ChangeGeometries capability
            # Remove AddFeatures, DeleteFeatures, and other modification capabilities
            allowed_caps = QgsVectorDataProvider.ChangeGeometries | QgsVectorDataProvider.ChangeAttributeValues
            
            # Set custom property to indicate restricted editing
            layer.setCustomProperty("editingRestricted", True)
            layer.setCustomProperty("allowedOperations", "move_only")
            
            # Make the layer read-only by default (user needs to manually enable editing)
            # This helps prevent accidental edits
            if layer.isEditable():
                layer.commitChanges()
            
            # Connect to editingStarted signal to show helpful message
            def on_editing_started():
                try:
                    from qgis.utils import iface
                    if iface:
                        iface.messageBar().pushMessage(
                            "Editing Mode",
                            "You can move points using the 'Vertex Tool' or 'Move Feature' tool. Copy/paste and add/delete are disabled.",
                            level=Qgis.Info,
                            duration=5
                        )
                except:
                    pass
            
            layer.editingStarted.connect(on_editing_started)
            
            log_message(f"Layer '{layer.name()}' editing restricted to geometry changes only", Qgis.Info)
            
        except Exception as e:
            log_message(f"Error restricting layer editing: {str(e)}", Qgis.Warning)
    
    def _activate_vertex_tool_for_layer(self, layer):
        """
        Activate the Vertex Tool for editing the layer.
        Enables editing mode and sets the active tool to Vertex Tool (All Layers).
        
        :param layer: The QGIS vector layer to edit
        """
        try:
            from qgis.utils import iface
            
            if not iface:
                log_message("QGIS interface not available, cannot activate Vertex Tool", Qgis.Warning)
                return
            
            # Set the layer as active
            iface.setActiveLayer(layer)
            
            # Enable editing mode on the layer
            if not layer.isEditable():
                layer.startEditing()
                log_message(f"Enabled editing mode for layer '{layer.name()}'", Qgis.Info)
            
            # Activate the Vertex Tool (All Layers)
            # Try to use the vertex tool action
            try:
                # Use actionVertexToolActiveLayer which is the "Vertex Tool (All Layers)"
                vertex_tool_action = iface.actionVertexToolActiveLayer()
                if vertex_tool_action:
                    vertex_tool_action.trigger()
                    log_message("Activated Vertex Tool (All Layers)", Qgis.Success)
                    
                    # Show helpful message in the message bar
                    iface.messageBar().pushMessage(
                        "Vertex Tool Active",
                        "Click and drag any point to move it. Save your changes when done (Ctrl+S or click the save icon).",
                        level=Qgis.Info,
                        duration=7
                    )
                else:
                    log_message("Vertex Tool action not found", Qgis.Warning)
            except Exception as tool_error:
                log_message(f"Could not activate Vertex Tool: {str(tool_error)}", Qgis.Warning)
            
        except Exception as e:
            log_message(f"Error activating Vertex Tool: {str(e)}", Qgis.Warning)
    
    def _add_basemap_if_needed(self):
        """Add OpenStreetMap basemap if not already present."""
        try:
            project = QgsProject.instance()
            
            # Check if basemap already exists
            basemap_names = ['OpenStreetMap', 'OSM', 'Basemap', 'Base Map']
            existing_layers = project.mapLayers().values()
            
            for layer in existing_layers:
                layer_name = layer.name()
                if any(basemap_name.lower() in layer_name.lower() for basemap_name in basemap_names):
                    if layer.isValid():
                        layer_tree_layer = project.layerTreeRoot().findLayer(layer.id())
                        if layer_tree_layer:
                            layer_tree_layer.setItemVisibilityChecked(True)
                        log_message(f"Basemap already exists: {layer_name}", Qgis.Info)
                        return
                    project.removeMapLayer(layer.id())
            
            # Create OpenStreetMap XYZ tile layer
            osm_url = "type=xyz&url=https://tile.openstreetmap.org/{z}/{x}/{y}.png&zmax=19&zmin=0&crs=EPSG:3857"
            basemap_layer = QgsRasterLayer(osm_url, "OpenStreetMap", "xyz")
            
            if basemap_layer.isValid():
                project.addMapLayer(basemap_layer, True)
                log_message("OpenStreetMap basemap added successfully", Qgis.Success)
            else:
                log_message("Failed to create OpenStreetMap basemap layer", Qgis.Warning)
                
        except Exception as e:
            log_message(f"Error adding basemap: {str(e)}", Qgis.Warning)
    
    @staticmethod
    def _find_header(headers, target):
        """Find the actual header name matching target, ignoring case/whitespace/underscore differences."""
        normalized_target = target.strip().lower().replace(' ', '_')
        for header in headers:
            if not header:
                continue
            normalized = str(header).strip().lower().replace(' ', '_')
            if normalized == normalized_target:
                return header
        return None
    
    def _build_name_label_expression(self, headers):
        """
        Build a label expression preferring existing_name, falling back to new_name.
        
        :param headers: List of column headers
        :return: (is_expression, field_name_or_expression) or (False, None) if no match found
        """
        existing_name_h = self._find_header(headers, 'existing_name')
        new_name_h = self._find_header(headers, 'new_name')
        
        def non_empty(h):
            return f'CASE WHEN "{h}" IS NULL OR "{h}" = \'\' THEN NULL ELSE "{h}" END'
        
        name_parts = [non_empty(h) for h in (existing_name_h, new_name_h) if h]
        if not name_parts:
            # Fall back to legacy single-field lookup
            for field in ['new_name', 'name', 'toponyms', 'label']:
                match = self._find_header(headers, field)
                if match:
                    return False, match
            return False, None
        
        expr = f"coalesce({', '.join(name_parts)}, '')" if len(name_parts) > 1 else name_parts[0]
        return True, expr
    
    def _apply_labels(self, layer, is_expression, label_field, quadrant=QgsPalLayerSettings.PredefinedPointPosition.TopMiddle, min_scale=None, dist=4):
        """
        Configure and enable labeling on the layer using the given field name or expression.
        Pass label_field=None (or 'none') to disable labeling.
        
        :param quadrant: A QgsPalLayerSettings.PredefinedPointPosition value controlling
            where the label sits relative to the point (e.g. TopMiddle, BottomMiddle).
        :param min_scale: If set, the label only shows when zoomed in past this scale
            denominator (e.g. 5000 for 1:5000). None means always visible.
        :param dist: Distance (in mm) between the point and the label.
        """
        if not label_field or str(label_field).strip().lower() == 'none':
            layer.setLabelsEnabled(False)
            layer.triggerRepaint()
            return
        
        label_settings = QgsPalLayerSettings()
        label_settings.fieldName = label_field
        label_settings.isExpression = is_expression
        
        if min_scale:
            label_settings.scaleVisibility = True
            label_settings.maximumScale = 0
            label_settings.minimumScale = min_scale
        
        text_format = QgsTextFormat()
        text_format.setFont(QFont("Arial", 6))
        text_format.setSize(6)
        text_format.setColor(QColor(0, 0, 0))
        
        buffer_settings = QgsTextBufferSettings()
        buffer_settings.setEnabled(True)
        buffer_settings.setSize(1)
        buffer_settings.setColor(QColor(255, 255, 255))
        buffer_settings.setOpacity(0.3)
        text_format.setBuffer(buffer_settings)
        
        label_settings.setFormat(text_format)
        label_settings.placement = QgsPalLayerSettings.Placement.OrderedPositionsAroundPoint
        label_settings.predefinedPositionOrder = [quadrant]
        label_settings.dist = dist
        # Show every label even if they'd otherwise overlap/collide with each other
        label_settings.displayAll = True
        
        labeling = QgsVectorLayerSimpleLabeling(label_settings)
        layer.setLabeling(labeling)
        layer.setLabelsEnabled(True)
        layer.triggerRepaint()
    
    def set_coordinate_label_field(self, field_name):
        """Update labels on the batch coordinate layer and processed points_0 layer."""
        for layer_attr in ('coordinate_layer', 'processed_points_layer'):
            layer = getattr(self.parent, layer_attr, None)
            if not layer:
                continue
            actual_field = self._find_header([f.name() for f in layer.fields()], field_name) if field_name and field_name.lower() != 'none' else None
            self._apply_labels(layer, False, actual_field, quadrant=QgsPalLayerSettings.PredefinedPointPosition.TopMiddle, dist=2)
    
    def set_geosys_label_field(self, field_name):
        """Update the selected label field on both geosys point layers."""
        for layer_attr in ('geosys_layer', 'geosys_layer_points_0'):
            layer = getattr(self.parent, layer_attr, None)
            if not layer:
                continue
            actual_field = (
                self._find_header([f.name() for f in layer.fields()], field_name)
                if field_name and field_name.lower() != 'none' else None
            )
            self._apply_labels(
                layer, False, actual_field,
                quadrant=QgsPalLayerSettings.PredefinedPointPosition.BottomMiddle,
                dist=2
            )
    
    def _apply_point_layer_style(self, layer, headers, purple=False):
        """Apply custom styling to batch load coordinate layer."""
        try:
            color = '83,57,175,225' if purple else '35,95,185,225'
            outline_color = '180,165,225,255' if purple else '165,195,235,255'
            symbol = QgsMarkerSymbol.createSimple({
                'name': 'circle',
                'color': color,
                'outline_color': outline_color,
                'outline_width': '0.5',
                'size': '2.7'
            })
            layer.setRenderer(QgsSingleSymbolRenderer(symbol))
            layer.emitStyleChanged()
            
            # Default label: existing_name, falling back to new_name (user can change via dropdown)
            is_expression, label_field = self._build_name_label_expression(headers)
            self._apply_labels(layer, is_expression, label_field, dist=2)
            
            layer.triggerRepaint()
            log_message("Point layer styling applied successfully", Qgis.Success)
            
        except Exception as e:
            log_message(f"Error applying point layer style: {str(e)}", Qgis.Warning)

    def _apply_processed_geometry_style(self, layer):
        """Apply the processed purple style to line and polygon geometry layers."""
        try:
            if layer.geometryType() == QgsWkbTypes.LineGeometry:
                symbol = QgsLineSymbol.createSimple({
                    'line_color': '83,57,175,225',
                    'line_width': '0.4'
                })
            elif layer.geometryType() == QgsWkbTypes.PolygonGeometry:
                symbol = QgsFillSymbol.createSimple({
                    'color': '83,57,175,65',
                    'outline_color': '83,57,175,225',
                    'outline_width': '0.3'
                })
            else:
                return
            layer.setRenderer(QgsSingleSymbolRenderer(symbol))
            layer.triggerRepaint()
            layer.emitStyleChanged()
        except Exception as e:
            log_message(f"Error applying processed geometry style: {str(e)}", Qgis.Warning)
    
    def _apply_geosys_layer_style(self, layer, headers):
        """Apply custom styling to geosys point layer (distinct from batch load layer)."""
        try:
            is_points_0 = 'points_0' in layer.name().lower()
            color = '220,74,38,225' if is_points_0 else '255,127,0,225'
            outline_color = '255,175,140,255' if is_points_0 else '255,204,128,255'
            symbol = QgsMarkerSymbol.createSimple({
                'name': 'circle',
                'color': color,
                'outline_color': outline_color,
                'outline_width': '0.5',
                'size': '2.7'
            })
            layer.renderer().setSymbol(symbol)
            
            # No label by default (user can pick a field via the dropdown)
            layer.setLabelsEnabled(False)
            
            layer.triggerRepaint()
            log_message("Geosys layer styling applied successfully", Qgis.Success)
            
        except Exception as e:
            log_message(f"Error applying geosys layer style: {str(e)}", Qgis.Warning)
