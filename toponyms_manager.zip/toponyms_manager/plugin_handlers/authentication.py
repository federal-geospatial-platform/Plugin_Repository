"""
Authentication Handler

Handles NRCan (GeoSys/Azure AD) and geoname-t API authentication.
"""

import json
import requests
from requests.auth import HTTPBasicAuth
from urllib.parse import urlsplit
from qgis.PyQt.QtWidgets import QDialog, QVBoxLayout, QLineEdit, QLabel, QDialogButtonBox, QFormLayout
from qgis.core import Qgis
from pygeosys import GeoSysClient

from ..utils import (
    show_error_message, show_info_message, show_warning_message, log_message,
    ProgressTracker,
)


def _redacted_resource_structure(value):
    """Keep JSON keys and nesting without logging any resource values."""
    if isinstance(value, dict):
        return {key: _redacted_resource_structure(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_redacted_resource_structure(item) for item in value]
    return "<redacted>"


class AuthenticationHandler:
    """
    Handles authentication with NRCan GeoSys (via Azure AD) and geoname-t API.
    """
    
    ENVIRONMENTS = {
        "dev": "Development (DEV)",
        "tst": "Testing (TST)",
        "pro": "Production (PROD)",
    }
    UNAVAILABLE_ENVIRONMENTS = frozenset({"tst", "pro"})
    RESOURCE_FILE = "GNBC:data/GNBC/ressources/ressources_toponymy.json"

    def __init__(self, parent_widget):
        """
        Initialize authentication handler.
        
        :param parent_widget: Parent widget (usually the dockwidget)
        """
        self.parent = parent_widget
        self.environment = None
        
        # GeoSys client for NRCan authentication
        self.geosys_client = None
        self.is_authenticated = False
        # Kept in memory only; never written to settings.
        self.fme_token = None
        self.fme_flow_url = None
        self.cgndb_connection = None
        
        # Geoname-t API authentication
        self.geoname_api_session = None
        self.geoname_api_base_url = None
        self.is_geoname_authenticated = False

    def select_environment(self, environment):
        """Switch environments without retaining credentials from the previous one."""
        if environment not in self.ENVIRONMENTS:
            raise ValueError("Unsupported GeoSys environment.")
        if environment in self.UNAVAILABLE_ENVIRONMENTS:
            raise ValueError("This environment is not ready yet.")
        if environment == self.environment:
            return
        was_authenticated = self.is_authenticated
        self.logout_nrcan()
        self.environment = environment
        self.parent.environment_button.setText(
            f"Environment: {'PROD' if environment == 'pro' else environment.upper()}"
        )
        log_message(f"Selected environment: {environment}.", Qgis.Info)
        if was_authenticated:
            self.authenticate_nrcan()

    def _load_environment_resources(self, client):
        """Validate the selected environment's resources before applying any values."""
        response = client.system.search_resources(
            params={"chercher_geosys": False},
            data={
                "fichiers": [self.RESOURCE_FILE],
                "chemin_recherche": [f"/ressources/{self.environment}"],
            },
        )
        if response.status_code != 200:
            raise RuntimeError(
                f"Could not load environment resources (HTTP {response.status_code})."
            )
        resources = response.json_content
        log_message(
            f"Environment resource response structure for {self.environment} "
            f"(all values redacted): {json.dumps(_redacted_resource_structure(resources))}",
            Qgis.Info,
        )
        if not isinstance(resources, dict):
            raise ValueError("Environment resources must be a JSON object.")

        environment_path = f"/ressources/{self.environment}"
        if environment_path in resources:
            resource = resources[environment_path]
            settings = resource.get("value") if isinstance(resource, dict) else None
            if not isinstance(settings, dict):
                raise ValueError("The selected environment resource value must be a JSON object.")
            resources = {name: {"value": value} for name, value in settings.items()}

        values = {}
        required = (
            "fme_flow_token", "fme_flow_url", "url_geoname-t", "env_geosys",
            "cgndb_connection",
        )
        for key, resource in resources.items():
            name = key.rsplit("/", 1)[-1]
            if name not in required:
                continue
            if name in values:
                raise ValueError(f"Duplicate environment resource: {name}.")
            value = resource.get("value") if isinstance(resource, dict) else None
            if not isinstance(value, str) or not value.strip():
                raise ValueError(f"Missing or invalid environment resource: {name}.")
            values[name] = value.strip()
        for name in required:
            if name not in values:
                raise ValueError(f"Missing environment resource: {name}.")
        if values["env_geosys"] != self.environment:
            raise ValueError("The resource env_geosys does not match the selected environment.")
        for name in ("fme_flow_url", "url_geoname-t"):
            url = urlsplit(values[name])
            if url.scheme != "https" or not url.hostname or url.username or url.password:
                raise ValueError(f"Environment resource {name} must be a valid HTTPS URL.")
            if url.query or url.fragment:
                raise ValueError(f"Environment resource {name} must not contain a query or fragment.")

        self.fme_token = values["fme_flow_token"]
        self.fme_flow_url = values["fme_flow_url"]
        self.cgndb_connection = values["cgndb_connection"]
        self.geoname_api_base_url = values["url_geoname-t"].rstrip("/")
        log_message(f"Loaded environment resources for {self.environment}.", Qgis.Success)
    
    def authenticate_nrcan(self):
        """
        Handle NRCan login - Authenticates user with Azure AD using pygeosys.
        """
        if self.environment is None:
            show_warning_message(
                self.parent,
                "Environment Required",
                "Please select an environment before logging in with NRCan."
            )
            return
        self.logout_nrcan()
        try:
            log_message("Starting NRCan authentication with pygeosys...", Qgis.Info)
            
            # Disable login button during authentication
            self.parent.nrcan_login_button.setEnabled(False)
            self.parent.nrcan_login_button.setText("Authenticating...")
            self.parent.environment_button.setEnabled(False)
            
            # Authenticate using pygeosys with Azure AD
            client = GeoSysClient(
                environment=self.environment,
                use_azure_auth=True
            )
            
            if client:
                self._load_environment_resources(client)
                self.geosys_client = client
                self.is_authenticated = True
                
                show_info_message(
                    self.parent,
                    "Login Successful",
                    "You have successfully authenticated with NRCan.\n"
                    "You can now access protected features."
                )
                
                log_message("NRCan authentication successful", Qgis.Success)
                self._update_nrcan_ui()
            else:
                self.is_authenticated = False
                self.geosys_client = None
                
                show_error_message(
                    self.parent,
                    "Login Failed",
                    "Unable to complete authentication.\n\n"
                    "Please check:\n"
                    "- Your internet connection\n"
                    "- Your Azure AD credentials\n"
                    "- QGIS logs for detailed error messages"
                )
                
                log_message("NRCan authentication failed", Qgis.Critical)
                
        except Exception as e:
            self.is_authenticated = False
            self.geosys_client = None
            
            show_error_message(
                self.parent,
                "Login Error",
                f"An unexpected error occurred during login:\n\n{str(e)}\n\n"
                "Please check QGIS logs for more details."
            )
            log_message(f"pygeosys login exception: {str(e)}", Qgis.Critical)
            
        finally:
            # Re-enable login button
            self.parent.nrcan_login_button.setEnabled(True)
            self.parent.environment_button.setEnabled(True)
            self._update_nrcan_ui()

    def authenticate_services(self):
        """Authenticate with NRCan first, then geoname-t, showing the busy bar."""
        if self.is_authenticated and self.is_geoname_authenticated:
            return
        progress = ProgressTracker(self.parent, "Login", "Authenticating...")
        try:
            if not self.is_authenticated:
                progress.set_label("Authenticating with NRCan...")
                self.authenticate_nrcan()
            if self.is_authenticated and not self.is_geoname_authenticated:
                progress.set_label("Authenticating with geoname-t...")
                self.authenticate_geoname()
        finally:
            progress.close()
    
    def authenticate_geoname(self):
        """
        Authenticate with geoname-t API.
        Shows a login dialog to collect username and password.
        """
        if not self.geoname_api_base_url:
            show_warning_message(
                self.parent,
                "Environment Resources Required",
                "Please login with NRCan first to load the selected environment's configuration."
            )
            return
        try:
            # Create login dialog
            dialog = QDialog(self.parent)
            dialog.setWindowTitle("Geoname-t Login")
            dialog.setModal(True)
            
            # Create layout
            layout = QVBoxLayout()
            form_layout = QFormLayout()
            
            # Username field
            username_input = QLineEdit()
            username_input.setPlaceholderText("Enter your username")
            form_layout.addRow(QLabel("Username:"), username_input)
            
            # Password field
            password_input = QLineEdit()
            password_input.setPlaceholderText("Enter your password")
            password_input.setEchoMode(QLineEdit.Password)
            form_layout.addRow(QLabel("Password:"), password_input)
            
            layout.addLayout(form_layout)
            
            # Add buttons
            button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
            button_box.accepted.connect(dialog.accept)
            button_box.rejected.connect(dialog.reject)
            layout.addWidget(button_box)
            
            dialog.setLayout(layout)
            
            # Show dialog and get result
            if dialog.exec_() == QDialog.Accepted:
                username = username_input.text().strip()
                password = password_input.text()
                
                if not username or not password:
                    show_warning_message(
                        self.parent,
                        "Incomplete Credentials",
                        "Username and password are required for geoname-t access."
                    )
                    self.is_geoname_authenticated = False
                    return
                
                # Create session with authentication
                self.geoname_api_session = requests.Session()
                self.geoname_api_session.auth = HTTPBasicAuth(username, password)
                
                # Test the credentials
                try:
                    test_url = f"{self.geoname_api_base_url}/users/{username}"
                    log_message(f"Testing credentials with user endpoint: {test_url}", Qgis.Info)
                    
                    test_response = self.geoname_api_session.get(test_url, timeout=5)
                    log_message(f"Test response status: {test_response.status_code}", Qgis.Info)
                    
                    if test_response.status_code == 401:
                        self.is_geoname_authenticated = False
                        self.geoname_api_session = None
                        show_error_message(
                            self.parent,
                            "Authentication Failed",
                            f"Invalid credentials for geoname-t API.\n\n"
                            f"Username: {username}\n"
                            f"URL: {self.geoname_api_base_url}\n\n"
                            f"Please verify your username and password are correct."
                        )
                        log_message(f"Authentication test failed: {test_response.text[:500]}", Qgis.Warning)
                        return
                    elif test_response.status_code == 200:
                        # Success - credentials are valid
                        self.is_geoname_authenticated = True
                        
                        # Parse user information from response
                        try:
                            user_info = test_response.json()
                            log_message(f"User info received: {user_info}", Qgis.Info)
                            
                            # Extract role information
                            role_list = user_info.get('roleList', [])
                            topo_authority = user_info.get('toponymicAuthority', {})
                            authority_term = topo_authority.get('term', 'N/A') if topo_authority else 'N/A'
                            
                            # Format role list for display
                            roles_display = ', '.join(role_list) if role_list else 'None'
                            
                            log_message(f"User authenticated - Authority: {authority_term}, Roles: {roles_display}", Qgis.Success)
                            
                            show_info_message(
                                self.parent,
                                "Credentials Validated",
                                f"Geoname-t API credentials validated successfully!\n\n"
                                f"Username: {username}\n"
                                f"Toponymic Authority: {authority_term}\n"
                                f"Roles: {roles_display}"
                            )
                        except Exception as parse_error:
                            log_message(f"Could not parse user info: {parse_error}", Qgis.Warning)
                            self.is_geoname_authenticated = True
                            show_info_message(
                                self.parent,
                                "Credentials Validated",
                                f"Geoname-t API credentials validated successfully!\n\n"
                                f"Username: {username}"
                            )
                    else:
                        # Non-401, non-200 response
                        self.is_geoname_authenticated = True  # Assume valid if not 401
                        log_message(f"Unexpected response status {test_response.status_code}, assuming valid credentials", Qgis.Warning)
                        show_info_message(
                            self.parent,
                            "Credentials Stored",
                            f"Geoname-t API credentials have been stored.\n\n"
                            f"Username: {username}\n\n"
                            f"Note: Could not retrieve user information (status: {test_response.status_code})"
                        )
                except requests.exceptions.RequestException as test_err:
                    log_message(f"Error testing credentials: {str(test_err)}", Qgis.Warning)
                    self.is_geoname_authenticated = True  # Assume valid, will verify during actual use
                    show_warning_message(
                        self.parent,
                        "Cannot Verify Credentials",
                        f"Credentials stored but could not be verified:\n{str(test_err)}\n\n"
                        "They will be tested during validation."
                    )
            else:
                # User cancelled
                self.is_geoname_authenticated = False
                log_message("Geoname-t API authentication cancelled by user", Qgis.Info)
                
        except Exception as e:
            self.is_geoname_authenticated = False
            self.geoname_api_session = None
            show_error_message(
                self.parent,
                "Geoname-t Login Error",
                f"An error occurred during geoname-t authentication:\n\n{str(e)}"
            )
            log_message(f"Geoname-t authentication exception: {str(e)}", Qgis.Critical)
        
        finally:
            self._update_geoname_ui()
    
    def get_toponymic_feature_id(self, existing_cgndb_id):
        """
        Look up the toponymic_feature_id for a given existing_cgndb_id via the geoname-t API.
        Replaces the FME 'Poly_existingCGNDB_key_DBJoiner' transformer (DB join on cgndb_id).
        
        :param existing_cgndb_id: The CGNDB ID to look up
        :return: toponymic_feature_id string if found, None otherwise
        """
        if not self.geoname_api_session:
            log_message("Cannot look up toponymic_feature_id: not authenticated with geoname-t", Qgis.Warning)
            return None
        
        try:
            url = f"{self.geoname_api_base_url}/toponyms/{existing_cgndb_id}.json"
            response = self.geoname_api_session.get(url, timeout=10)
            
            if response.status_code == 404:
                return None
            elif response.status_code != 200:
                log_message(
                    f"geoname-t API error for {existing_cgndb_id}: status {response.status_code}",
                    Qgis.Warning
                )
                return None
            
            toponymic_feature = response.json().get('toponymicFeature')
            return toponymic_feature.get('toponymicFeatureId') if toponymic_feature else None
            
        except Exception as e:
            log_message(f"Error looking up toponymic_feature_id for {existing_cgndb_id}: {str(e)}", Qgis.Warning)
            return None
    
    def logout_nrcan(self):
        """Handle NRCan logout action. Clears authentication state."""
        self.geosys_client = None
        self.is_authenticated = False
        self.fme_token = None
        self.fme_flow_url = None
        self.cgndb_connection = None
        self.geoname_api_base_url = None
        self.logout_geoname()
        self._update_nrcan_ui()
        log_message("User logged out from NRCan", Qgis.Info)
    
    def logout_geoname(self):
        """Handle geoname-t logout action. Clears authentication state."""
        if self.geoname_api_session is not None:
            self.geoname_api_session.close()
        self.geoname_api_session = None
        self.is_geoname_authenticated = False
        self._update_geoname_ui()
        log_message("User logged out from geoname-t", Qgis.Info)
    
    def logout_all(self):
        """Log out of both NRCan and geoname-t."""
        self.logout_nrcan()
        show_info_message(self.parent, "Logged Out", "You have been logged out of NRCan and geoname-t.")
        log_message("User logged out from all services", Qgis.Info)
    
    def _update_nrcan_ui(self):
        """Update the combined login button based on authentication state."""
        self._update_login_ui()
    
    def _update_geoname_ui(self):
        """Update the combined login button based on authentication state."""
        self._update_login_ui()

    def _update_login_ui(self):
        """Show the authentication state of both services on the shared button."""
        authenticated_services = []
        if self.is_authenticated:
            authenticated_services.append("NRCan_id")
        if self.is_geoname_authenticated:
            authenticated_services.append("geoname-t")

        if authenticated_services:
            status = " and ".join(authenticated_services)
            self.parent.nrcan_login_button.setText(f"Logged In {status} ✓")
        else:
            self.parent.nrcan_login_button.setText("Login")
        log_message("Authentication UI updated", Qgis.Info)
