"""
Validation Handler

Handles batch load file validation with multiple checks against geoname-t API.
"""

import requests
from collections import defaultdict
from pathlib import Path
from qgis.PyQt import QtWidgets
from qgis.core import Qgis

from ..data_loaders import DataLoader
from ..validation_dialog import ValidationDialog
from ..utils import show_error_message, show_info_message, log_message, coordinate_errors


class ValidationHandler:
    """
    Handles validation of batch load files with multiple rule checks.
    """

    _VALIDATION_NAMES = (
        'required_fields',
        'existing_name_fields',
        'cgndb_id_in_database',
        'new_cgndb_id_not_in_database',
        'lat_long_required',
        'coordinates_in_canada',
        'toponymic_feature_id_exists',
        'status_code_valid',
        'generic_code_valid',
    )

    @classmethod
    def _load_validation_labels(cls):
        """Read editable labels, retaining the IDs and order used by the checks."""
        import yaml

        path = Path(__file__).resolve().parent.parent / 'validation_labels.yaml'
        with path.open(encoding='utf-8') as stream:
            labels = yaml.safe_load(stream)
        if not isinstance(labels, dict):
            raise ValueError(f"{path.name} must map validation names to displayed text.")

        missing = set(cls._VALIDATION_NAMES) - labels.keys()
        unknown = labels.keys() - set(cls._VALIDATION_NAMES)
        if missing or unknown:
            raise ValueError(
                f"{path.name} has missing names: {sorted(missing)}; "
                f"unknown names: {sorted(str(name) for name in unknown)}."
            )
        for name in cls._VALIDATION_NAMES:
            if not isinstance(labels[name], str) or not labels[name].strip():
                raise ValueError(f"{path.name}: '{name}' must have non-empty displayed text.")
        return {name: labels[name] for name in cls._VALIDATION_NAMES}
    
    def __init__(self, parent_widget, auth_handler):
        """
        Initialize validation handler.
        
        :param parent_widget: Parent widget (usually the dockwidget)
        :param auth_handler: AuthenticationHandler instance for API access
        """
        self.parent = parent_widget
        self.auth_handler = auth_handler
        self._generic_codes = None
        self._toponym_status_codes = None

    @staticmethod
    def _is_empty_value(value):
        """Treat database/GDB null sentinels as empty validation values."""
        return value is None or str(value).strip().lower() in ('', 'null', '<null>')

    def _load_combined_names_points(self, file_path):
        """Build the merged names_6+points_0 table so validation matches what's displayed."""
        from qgis.core import QgsVectorLayer

        names_layer = QgsVectorLayer(f"{file_path}|layername=names_6", "names_6", "ogr")
        points_layer = QgsVectorLayer(f"{file_path}|layername=points_0", "points_0", "ogr")
        if names_layer.isValid() and points_layer.isValid():
            return self.parent.file_import_handler._combined_names_points_table(names_layer, points_layer)
        return DataLoader.load_qgis_layer(f"{file_path}|layername=names_6")

    @staticmethod
    def _row_number_start(data_dict):
        """GDB/GPKG sources have a single header row; the Excel template has an extra row before data."""
        return 2 if data_dict.get('type') in ('qgis_layer', 'combined_gdb_view') else 3

    @staticmethod
    def _names_6_row_indexes(data_dict, data_only):
        """Return the positions of names_6 rows when validating a combined names_6+points_0 table."""
        if data_dict.get('type') != 'combined_gdb_view':
            return None
        headers = data_dict.get('headers', [])
        header_map = {str(h).lower().strip(): i for i, h in enumerate(headers) if h}
        source_col = header_map.get('source_layer')
        if source_col is None:
            return None
        return {
            i for i, row in enumerate(data_only)
            if source_col < len(row) and str(row[source_col]).strip().lower() == 'names_6'
        }
    
    def validate_batch_load_file(self):
        """
        Validate the batch load file with multiple checks.
        Shows a validation dialog with progress and results.
        """
        try:
            # Check if a file has been loaded
            if not self.parent.batch_load_file_path:
                show_error_message(
                    self.parent,
                    "No File Loaded",
                    "Please import a batch load template file first using the 'Import Batch Load file' button."
                )
                return
            
            log_message("Starting batch load file validation...", Qgis.Info)
            validation_labels = self._load_validation_labels()
            
            # Create validation dialog
            validation_dialog = ValidationDialog(self.parent)
            is_geospatial_source = self.parent.batch_load_file_path.lower().endswith(
                ('.gdb', '.fgdb', '.gpkg')
            )
            
            # Add validations to the dialog
            if is_geospatial_source:
                validation_dialog.add_section('names_6')
            for name, displayed_text in validation_labels.items():
                validation_dialog.add_validation(name, displayed_text)
            if is_geospatial_source:
                for layer_name in ('points_0', 'lines_1', 'polygons_2'):
                    validation_dialog.add_section(layer_name)
                    validation_dialog.add_validation(
                        f'{layer_name}_geometry',
                        f"Validate {layer_name}: toponymic feature, delineation fields, and geometry in Canada"
                    )
            
            # Show the dialog (non-modal so we can update it)
            validation_dialog.show()
            QtWidgets.QApplication.processEvents()
            
            # Track validation results
            passed = 0
            failed = 0
            
            # Load data once
            sheet_name = self.parent.batch_load_sheet_name or 'data'
            if self.parent.batch_load_file_path.lower().endswith(('.gdb', '.fgdb', '.gpkg')):
                data_dict = self._load_combined_names_points(self.parent.batch_load_file_path)
                sheet_name = 'names_6 + points_0'
            elif self.parent.batch_load_file_path.lower().endswith('.csv'):
                data_dict = DataLoader.load_csv(self.parent.batch_load_file_path)
                sheet_name = 'data'
            elif sheet_name.lower() != 'data':
                try:
                    data_dict = DataLoader.load_excel(self.parent.batch_load_file_path, 'data')
                    sheet_name = 'data'
                except:
                    data_dict = DataLoader.load_excel(self.parent.batch_load_file_path, self.parent.batch_load_sheet_name)
            else:
                data_dict = DataLoader.load_excel(self.parent.batch_load_file_path, sheet_name)
            
            # Run all validations
            passed, failed = self._run_all_validations(validation_dialog, data_dict, sheet_name)
            if is_geospatial_source:
                for layer_name in ('points_0', 'lines_1', 'polygons_2'):
                    if self._validate_geometry_layer(validation_dialog, layer_name):
                        passed += 1
                    else:
                        failed += 1
            
            # Update dialog summary and enable the Close button
            validation_dialog.set_summary(passed, failed)
            
            # Show summary
            log_message(f"Validation complete: {passed} passed, {failed} failed", Qgis.Info)
            show_info_message(
                self.parent,
                "Validation Complete",
                f"Batch load file validation finished.\n\n"
                f"✓ Passed: {passed}\n"
                f"✗ Failed: {failed}\n\n"
                f"Check the validation dialog for detailed results."
            )
            
        except Exception as e:
            if 'validation_dialog' in locals():
                validation_dialog.close_button.setEnabled(True)
            show_error_message(
                self.parent,
                "Validation Error",
                f"An error occurred during validation:\n\n{str(e)}"
            )
            log_message(f"Validation error: {str(e)}", Qgis.Critical)
    
    def _run_all_validations(self, dialog, data_dict, sheet_name):
        """Run all validation checks and return passed/failed counts."""
        passed = 0
        failed = 0
        
        # Validation 1: Required Fields
        if self._validate_required_fields(dialog, data_dict):
            passed += 1
        else:
            failed += 1
        
        # Validation 2: Existing Name Fields Consistency
        if self._validate_existing_name_fields(dialog, data_dict):
            passed += 1
        else:
            failed += 1
        
        # Validation 3: CGNDB ID Exists in Database
        if self._validate_cgndb_id_in_database(dialog, data_dict):
            passed += 1
        else:
            failed += 1
        
        # Validation 4: New CGNDB ID Not in Database
        if self._validate_new_cgndb_id_not_in_database(dialog, data_dict):
            passed += 1
        else:
            failed += 1
        
        # Validation 5: Lat/Long Required
        if self._validate_lat_long_required(dialog, data_dict):
            passed += 1
        else:
            failed += 1
        
        # Validation 6: Coordinates in Canada
        if self._validate_coordinates_in_canada(dialog, data_dict):
            passed += 1
        else:
            failed += 1
        
        # Validation 7: Toponymic Feature ID Exists
        if self._validate_toponymic_feature_id_exists(dialog, data_dict):
            passed += 1
        else:
            failed += 1
        
        # Validation 8: Status Code Valid
        if self._validate_status_code_valid(dialog, data_dict):
            passed += 1
        else:
            failed += 1
        
        # Validation 9: Generic Code Valid
        if self._validate_generic_code_valid(dialog, data_dict):
            passed += 1
        else:
            failed += 1
        
        return passed, failed

    def _validate_geometry_layer(self, dialog, layer_name):
        """Validate processed geometry records for one GDB/GPKG layer."""
        from qgis.core import (
            QgsCoordinateReferenceSystem, QgsCoordinateTransform,
            QgsProject, QgsVectorLayer
        )

        validation_id = f'{layer_name}_geometry'
        file_path = self.parent.batch_load_file_path
        layer = QgsVectorLayer(f"{file_path}|layername={layer_name}", layer_name, 'ogr')
        if not layer.isValid():
            dialog.update_validation(validation_id, 'fail', f"Could not load layer '{layer_name}'.")
            return False

        field_map = {field.name().casefold(): index for index, field in enumerate(layer.fields())}
        required_fields = ('toponymic_feature_id', 'md_delineation_source_desc_cl', 'md_delineation_code')
        missing_columns = [name for name in required_fields if name not in field_map]
        if missing_columns:
            dialog.update_validation(
                validation_id, 'fail', f"Missing columns: {', '.join(missing_columns)}"
            )
            return False

        errors = defaultdict(list)
        new_feature_ids = []
        empty_tfid_features = []
        source_crs = layer.crs()
        target_crs = QgsCoordinateReferenceSystem('EPSG:4326')
        transform = QgsCoordinateTransform(source_crs, target_crs, QgsProject.instance())

        for feature in layer.getFeatures():
            feature_label = f"feature {feature.id()}"
            tfid = feature[field_map['toponymic_feature_id']]
            source_desc = feature[field_map['md_delineation_source_desc_cl']]
            source_code = feature[field_map['md_delineation_code']]
            if self._is_empty_value(tfid):
                empty_tfid_features.append(feature_label)
            elif self.auth_handler.is_geoname_authenticated and self.auth_handler.geoname_api_session:
                try:
                    api_url = f"{self.auth_handler.geoname_api_base_url}/toponyms/{str(tfid).strip()}"
                    response = self.auth_handler.geoname_api_session.get(api_url, timeout=5)
                    if response.status_code == 404:
                        new_feature_ids.append(str(tfid).strip())
                    elif response.status_code != 200:
                        errors[f"API error while checking toponymic_feature_id (status {response.status_code})"].append(feature_label)
                except requests.exceptions.RequestException:
                    errors['API request error while checking toponymic_feature_id'].append(feature_label)
            if self._is_empty_value(source_desc):
                errors['md_delineation_source_desc_cl is empty'].append(feature_label)
            if self._is_empty_value(source_code):
                errors['md_delineation_code is empty'].append(feature_label)
            if not feature.hasGeometry():
                errors['geometry is empty'].append(feature_label)
                continue
            try:
                point = transform.transform(feature.geometry().centroid().asPoint())
                if not (41.7 <= point.y() <= 83.1 and -141.0 <= point.x() <= -52.6):
                    errors['geometry centroid is outside Canada'].append(feature_label)
            except Exception:
                errors['geometry could not be transformed to EPSG:4326'].append(feature_label)

        if errors:
            message = '\n'.join(self._format_grouped_errors(errors))
            if new_feature_ids:
                message += '\nNew toponymic_feature_id values not yet in the API: ' + ', '.join(new_feature_ids[:10])
            dialog.update_validation(validation_id, 'fail', message)
            return False
        if new_feature_ids or empty_tfid_features:
            message = 'Delineation fields and geometry (valid, in Canada) checks passed for all features.'
            if empty_tfid_features:
                message += (
                    '\ntoponymic_feature_id is empty (will be created by the batch load FME script): '
                    + ', '.join(empty_tfid_features[:10])
                )
            if new_feature_ids:
                message += '\nNew toponymic_feature_id values not yet in the API: ' + ', '.join(new_feature_ids[:10])
            dialog.update_validation(validation_id, 'warning', message)
            return True

        dialog.update_validation(validation_id, 'pass')
        return True
    
    def _validate_required_fields(self, dialog, data_dict):
        """Validation 1: Check all required fields have values."""
        try:
            required_fields = ['new_name', 'status_code_cl', 'generic_code', 'region_cl', 'decision_date']
            headers = data_dict.get('headers', [])
            data_rows = data_dict.get('data', [])
            
            if not headers:
                dialog.update_validation('required_fields', 'fail', 'No headers found in the file.')
                return False
            
            header_map = {h.lower().strip(): i for i, h in enumerate(headers) if h}
            missing_columns = [field for field in required_fields if field.lower() not in header_map]
            
            if missing_columns:
                dialog.update_validation('required_fields', 'fail', f"Missing required columns: {', '.join(missing_columns)}")
                return False
            
            data_only = data_rows[1:] if len(data_rows) > 1 else []
            if not data_only:
                dialog.update_validation('required_fields', 'fail', 'No data rows found.')
                return False
            
            error_groups = defaultdict(list)
            names_6_rows = self._names_6_row_indexes(data_dict, data_only)
            for position, (row_idx, row) in enumerate(enumerate(data_only, start=self._row_number_start(data_dict))):
                if names_6_rows is not None and position not in names_6_rows:
                    continue
                if len(row) < len(headers):
                    row = list(row) + [None] * (len(headers) - len(row))
                
                for field in required_fields:
                    col_idx = header_map[field.lower()]
                    value = row[col_idx] if col_idx < len(row) else None
                    if self._is_empty_value(value):
                        error_groups[f"'{field}' is empty"].append(row_idx)
            
            if error_groups:
                errors = self._format_grouped_errors(error_groups)
                dialog.update_validation('required_fields', 'fail', '\n'.join(errors))
                return False
            
            dialog.update_validation('required_fields', 'pass')
            return True
            
        except Exception as e:
            dialog.update_validation('required_fields', 'fail', f"Error: {str(e)}")
            return False
    
    def _validate_existing_name_fields(self, dialog, data_dict):
        """Validation 2: If existing_name has value, check other existing fields."""
        try:
            existing_fields = ['existing_name', 'existing_cgndb_id', 'status_for_existing_name']
            headers = data_dict.get('headers', [])
            data_rows = data_dict.get('data', [])
            
            header_map = {h.lower().strip(): i for i, h in enumerate(headers) if h}
            missing_columns = [field for field in existing_fields if field.lower() not in header_map]
            
            if missing_columns:
                dialog.update_validation('existing_name_fields', 'fail', f"Missing columns: {', '.join(missing_columns)}")
                return False
            
            data_only = data_rows[1:] if len(data_rows) > 1 else []
            error_groups = defaultdict(list)
            names_6_rows = self._names_6_row_indexes(data_dict, data_only)
            
            for position, (row_idx, row) in enumerate(enumerate(data_only, start=self._row_number_start(data_dict))):
                if names_6_rows is not None and position not in names_6_rows:
                    continue
                if len(row) < len(headers):
                    row = list(row) + [None] * (len(headers) - len(row))
                
                existing_name_idx = header_map['existing_name']
                existing_name_value = row[existing_name_idx] if existing_name_idx < len(row) else None
                
                if not self._is_empty_value(existing_name_value):
                    missing_fields = []
                    for field in existing_fields:
                        col_idx = header_map[field.lower()]
                        value = row[col_idx] if col_idx < len(row) else None
                        if self._is_empty_value(value):
                            missing_fields.append(field)
                    
                    if missing_fields:
                        error_msg = f"existing_name is set but missing: {', '.join(missing_fields)}"
                        error_groups[error_msg].append(row_idx)
            
            if error_groups:
                errors = self._format_grouped_errors(error_groups)
                dialog.update_validation('existing_name_fields', 'fail', '\n'.join(errors))
                return False
            
            dialog.update_validation('existing_name_fields', 'pass')
            return True
            
        except Exception as e:
            dialog.update_validation('existing_name_fields', 'fail', f"Error: {str(e)}")
            return False
    
    def _validate_cgndb_id_in_database(self, dialog, data_dict):
        """Validation 3: Check existing CGNDB IDs exist in database via API."""
        try:
            if not self.auth_handler.is_geoname_authenticated or not self.auth_handler.geoname_api_session:
                dialog.update_validation('cgndb_id_in_database', 'fail', 'Not authenticated with geoname-t API.')
                return False
            
            headers = data_dict.get('headers', [])
            data_rows = data_dict.get('data', [])
            header_map = {h.lower().strip(): i for i, h in enumerate(headers) if h}
            
            required_cols = ['existing_name', 'existing_cgndb_id']
            missing_columns = [col for col in required_cols if col.lower() not in header_map]
            
            if missing_columns:
                dialog.update_validation('cgndb_id_in_database', 'fail', f"Missing columns: {', '.join(missing_columns)}")
                return False
            
            data_only = data_rows[1:] if len(data_rows) > 1 else []
            error_groups = defaultdict(list)
            names_6_rows = self._names_6_row_indexes(data_dict, data_only)
            
            for position, (row_idx, row) in enumerate(enumerate(data_only, start=self._row_number_start(data_dict))):
                if names_6_rows is not None and position not in names_6_rows:
                    continue
                if len(row) < len(headers):
                    row = list(row) + [None] * (len(headers) - len(row))
                
                existing_name_idx = header_map['existing_name']
                existing_cgndb_id_idx = header_map['existing_cgndb_id']
                
                existing_name_value = row[existing_name_idx] if existing_name_idx < len(row) else None
                cgndb_id_value = row[existing_cgndb_id_idx] if existing_cgndb_id_idx < len(row) else None
                
                if not self._is_empty_value(existing_name_value):
                    if self._is_empty_value(cgndb_id_value):
                        error_groups["existing_name is set but existing_cgndb_id is empty"].append(row_idx)
                    else:
                        try:
                            api_url = f"{self.auth_handler.geoname_api_base_url}/toponyms/{str(cgndb_id_value).strip()}"
                            response = self.auth_handler.geoname_api_session.get(api_url, timeout=5)
                            
                            if response.status_code == 404:
                                error_groups[f"CGNDB ID '{cgndb_id_value}' not found in database"].append(row_idx)
                            elif response.status_code != 200:
                                error_groups[f"API error (status {response.status_code})"].append(row_idx)
                        except requests.exceptions.Timeout:
                            error_groups["API timeout"].append(row_idx)
                        except requests.exceptions.RequestException:
                            error_groups["API request error"].append(row_idx)
            
            if error_groups:
                errors = self._format_grouped_errors(error_groups)
                dialog.update_validation('cgndb_id_in_database', 'fail', '\n'.join(errors))
                return False
            
            dialog.update_validation('cgndb_id_in_database', 'pass')
            return True
            
        except Exception as e:
            dialog.update_validation('cgndb_id_in_database', 'fail', f"Error: {str(e)}")
            return False
    
    def _validate_new_cgndb_id_not_in_database(self, dialog, data_dict):
        """Validation 4: Check new CGNDB IDs do NOT exist in database."""
        try:
            if not self.auth_handler.is_geoname_authenticated or not self.auth_handler.geoname_api_session:
                dialog.update_validation('new_cgndb_id_not_in_database', 'fail', 'Not authenticated with geoname-t API.')
                return False
            
            headers = data_dict.get('headers', [])
            data_rows = data_dict.get('data', [])
            header_map = {h.lower().strip(): i for i, h in enumerate(headers) if h}
            
            if 'new_cgndb_id' not in header_map:
                dialog.update_validation('new_cgndb_id_not_in_database', 'fail', 'Missing column: new_cgndb_id')
                return False
            
            data_only = data_rows[1:] if len(data_rows) > 1 else []
            error_groups = defaultdict(list)
            names_6_rows = self._names_6_row_indexes(data_dict, data_only)
            
            for position, (row_idx, row) in enumerate(enumerate(data_only, start=self._row_number_start(data_dict))):
                if names_6_rows is not None and position not in names_6_rows:
                    continue
                if len(row) < len(headers):
                    row = list(row) + [None] * (len(headers) - len(row))
                
                new_cgndb_id_idx = header_map['new_cgndb_id']
                new_cgndb_id_value = row[new_cgndb_id_idx] if new_cgndb_id_idx < len(row) else None
                
                if new_cgndb_id_value is not None and str(new_cgndb_id_value).strip() != '':
                    try:
                        api_url = f"{self.auth_handler.geoname_api_base_url}/toponyms/{str(new_cgndb_id_value).strip()}"
                        response = self.auth_handler.geoname_api_session.get(api_url, timeout=5)
                        
                        if response.status_code == 200:
                            error_groups[f"new_cgndb_id '{new_cgndb_id_value}' already exists in database"].append(row_idx)
                    except requests.exceptions.Timeout:
                        error_groups["API timeout"].append(row_idx)
                    except requests.exceptions.RequestException:
                        error_groups["API request error"].append(row_idx)
            
            if error_groups:
                errors = self._format_grouped_errors(error_groups)
                dialog.update_validation('new_cgndb_id_not_in_database', 'fail', '\n'.join(errors))
                return False
            
            dialog.update_validation('new_cgndb_id_not_in_database', 'pass')
            return True
            
        except Exception as e:
            dialog.update_validation('new_cgndb_id_not_in_database', 'fail', f"Error: {str(e)}")
            return False
    
    def _validate_lat_long_required(self, dialog, data_dict):
        """Validation 5: If no existing record, lat/long must be provided."""
        try:
            required_fields = ['existing_cgndb_id', 'existing_name', 'latitude', 'longitude']
            headers = data_dict.get('headers', [])
            data_rows = data_dict.get('data', [])
            
            header_map = {h.lower().strip(): i for i, h in enumerate(headers) if h}
            missing_columns = [field for field in required_fields if field.lower() not in header_map]
            
            if missing_columns:
                dialog.update_validation('lat_long_required', 'fail', f"Missing columns: {', '.join(missing_columns)}")
                return False
            
            data_only = data_rows[1:] if len(data_rows) > 1 else []
            error_groups = defaultdict(list)
            names_6_rows = self._names_6_row_indexes(data_dict, data_only)
            
            for position, (row_idx, row) in enumerate(enumerate(data_only, start=self._row_number_start(data_dict))):
                if names_6_rows is not None and position not in names_6_rows:
                    continue
                if len(row) < len(headers):
                    row = list(row) + [None] * (len(headers) - len(row))
                
                existing_cgndb_id_idx = header_map['existing_cgndb_id']
                existing_name_idx = header_map['existing_name']
                latitude_idx = header_map['latitude']
                longitude_idx = header_map['longitude']
                
                existing_cgndb_id_value = row[existing_cgndb_id_idx] if existing_cgndb_id_idx < len(row) else None
                existing_name_value = row[existing_name_idx] if existing_name_idx < len(row) else None
                latitude_value = row[latitude_idx] if latitude_idx < len(row) else None
                longitude_value = row[longitude_idx] if longitude_idx < len(row) else None
                
                existing_cgndb_id_empty = existing_cgndb_id_value is None or str(existing_cgndb_id_value).strip() == ''
                existing_name_empty = existing_name_value is None or str(existing_name_value).strip() == ''
                
                if existing_cgndb_id_empty and existing_name_empty:
                    missing_fields = []
                    if latitude_value is None or str(latitude_value).strip() == '':
                        missing_fields.append('latitude')
                    if longitude_value is None or str(longitude_value).strip() == '':
                        missing_fields.append('longitude')
                    
                    if missing_fields:
                        error_msg = f"No existing record but missing: {', '.join(missing_fields)}"
                        error_groups[error_msg].append(row_idx)
            
            if error_groups:
                errors = self._format_grouped_errors(error_groups, by_row=True)
                dialog.update_validation('lat_long_required', 'fail', '\n'.join(errors))
                return False
            
            dialog.update_validation('lat_long_required', 'pass')
            return True
            
        except Exception as e:
            dialog.update_validation('lat_long_required', 'fail', f"Error: {str(e)}")
            return False
    
    def _validate_coordinates_in_canada(self, dialog, data_dict):
        """Validation 6: Check coordinates are within Canada bounds."""
        try:
            headers = data_dict.get('headers', [])
            data_rows = data_dict.get('data', [])
            
            header_map = {h.lower().strip(): i for i, h in enumerate(headers) if h}
            
            if 'latitude' not in header_map or 'longitude' not in header_map:
                dialog.update_validation('coordinates_in_canada', 'fail', 'Missing latitude or longitude column')
                return False
            
            data_only = data_rows[1:] if len(data_rows) > 1 else []
            error_groups = defaultdict(list)
            names_6_rows = self._names_6_row_indexes(data_dict, data_only)
            
            for position, (row_idx, row) in enumerate(enumerate(data_only, start=self._row_number_start(data_dict))):
                if names_6_rows is not None and position not in names_6_rows:
                    continue
                if len(row) < len(headers):
                    row = list(row) + [None] * (len(headers) - len(row))
                
                latitude_idx = header_map['latitude']
                longitude_idx = header_map['longitude']
                
                latitude_value = row[latitude_idx] if latitude_idx < len(row) else None
                longitude_value = row[longitude_idx] if longitude_idx < len(row) else None
                
                for error in coordinate_errors(latitude_value, longitude_value):
                    error_groups[error].append(row_idx)
            
            if error_groups:
                errors = self._format_grouped_errors(error_groups, by_row=True)
                dialog.update_validation('coordinates_in_canada', 'fail', '\n'.join(errors))
                return False
            
            dialog.update_validation('coordinates_in_canada', 'pass')
            return True
            
        except Exception as e:
            dialog.update_validation('coordinates_in_canada', 'fail', f"Error: {str(e)}")
            return False
    
    def _validate_toponymic_feature_id_exists(self, dialog, data_dict):
        """Validation 7: Validate names_6 toponymic_feature_id values through the API."""
        headers = data_dict.get('headers', [])
        data_rows = data_dict.get('data', [])
        header_map = {str(header).lower().strip(): index for index, header in enumerate(headers) if header}
        if 'toponymic_feature_id' not in header_map:
            dialog.update_validation('toponymic_feature_id_exists', 'fail', 'Missing column: toponymic_feature_id')
            return False
        if not self.auth_handler.is_geoname_authenticated or not self.auth_handler.geoname_api_session:
            dialog.update_validation('toponymic_feature_id_exists', 'fail', 'Not authenticated with geoname-t API.')
            return False

        data_only = data_rows[1:] if len(data_rows) > 1 else []
        names_6_rows = self._names_6_row_indexes(data_dict, data_only)
        errors = defaultdict(list)
        new_feature_ids = []
        empty_rows = []
        tfid_column = header_map['toponymic_feature_id']
        for position, (row_number, row) in enumerate(
                enumerate(data_only, start=self._row_number_start(data_dict))):
            if names_6_rows is not None and position not in names_6_rows:
                continue
            tfid = row[tfid_column] if tfid_column < len(row) else None
            if self._is_empty_value(tfid):
                empty_rows.append(row_number)
                continue
            try:
                api_url = f"{self.auth_handler.geoname_api_base_url}/toponyms/{str(tfid).strip()}"
                response = self.auth_handler.geoname_api_session.get(api_url, timeout=5)
                if response.status_code == 404:
                    new_feature_ids.append(str(tfid).strip())
                elif response.status_code != 200:
                    errors[f"API error while checking toponymic_feature_id (status {response.status_code})"].append(row_number)
            except requests.exceptions.RequestException:
                errors['API request error while checking toponymic_feature_id'].append(row_number)

        if errors:
            message = '\n'.join(self._format_grouped_errors(errors))
            if new_feature_ids:
                message += '\nNew toponymic_feature_id values not yet in the API: ' + ', '.join(new_feature_ids[:10])
            dialog.update_validation('toponymic_feature_id_exists', 'fail', message)
            return False
        if new_feature_ids or empty_rows:
            warnings = []
            if empty_rows:
                warnings.append(
                    f"toponymic_feature_id is empty (will be created by the batch load FME script): "
                    f"{', '.join(str(r) for r in empty_rows[:10])}"
                )
            if new_feature_ids:
                warnings.append('New toponymic_feature_id values not yet in the API: ' + ', '.join(new_feature_ids[:10]))
            dialog.update_validation('toponymic_feature_id_exists', 'warning', '\n'.join(warnings))
            return True

        dialog.update_validation('toponymic_feature_id_exists', 'pass')
        return True
    
    def _validate_status_code_valid(self, dialog, data_dict):
        """Validation 8: Check names_6 status_code_cl values against the API code list."""
        headers = data_dict.get('headers', [])
        data_rows = data_dict.get('data', [])
        header_map = {str(header).lower().strip(): index for index, header in enumerate(headers) if header}
        if 'status_code_cl' not in header_map:
            dialog.update_validation('status_code_valid', 'fail', 'Missing column: status_code_cl')
            return False
        if not self.auth_handler.is_geoname_authenticated or not self.auth_handler.geoname_api_session:
            dialog.update_validation('status_code_valid', 'fail', 'Not authenticated with geoname-t API.')
            return False

        try:
            if self._toponym_status_codes is None:
                response = self.auth_handler.geoname_api_session.get(
                    f"{self.auth_handler.geoname_api_base_url}/codes/toponym-status.json",
                    params={'sort-field': 'code', 'sort-order': 'asc'},
                    timeout=10
                )
                response.raise_for_status()
                self._toponym_status_codes = {
                    value
                    for definition in response.json().get('definitions', [])
                    for value in (
                        str(definition.get('code')).strip(),
                        str(definition.get('term')).strip().casefold()
                    )
                    if value and value != 'None'
                }
        except requests.exceptions.RequestException as e:
            dialog.update_validation('status_code_valid', 'fail', f"Could not load toponym status codes: {str(e)}")
            return False

        data_only = data_rows[1:] if len(data_rows) > 1 else []
        names_6_rows = self._names_6_row_indexes(data_dict, data_only)
        errors = defaultdict(list)
        status_column = header_map['status_code_cl']
        for position, (row_number, row) in enumerate(
                enumerate(data_only, start=self._row_number_start(data_dict))):
            if names_6_rows is not None and position not in names_6_rows:
                continue
            status_code = row[status_column] if status_column < len(row) else None
            status_value = str(status_code).strip()
            if (not self._is_empty_value(status_code) and
                    status_value not in self._toponym_status_codes and
                    status_value.casefold() not in self._toponym_status_codes):
                errors[f"status_code_cl '{status_code}' is not in the geoname-t code list"].append(row_number)

        if errors:
            dialog.update_validation(
                'status_code_valid', 'fail', '\n'.join(self._format_grouped_errors(errors))
            )
            return False

        dialog.update_validation('status_code_valid', 'pass')
        return True
    
    def _validate_generic_code_valid(self, dialog, data_dict):
        """Validation 9: Check names_6 generic_code values against the API code list."""
        headers = data_dict.get('headers', [])
        data_rows = data_dict.get('data', [])
        header_map = {str(header).lower().strip(): index for index, header in enumerate(headers) if header}
        if 'generic_code' not in header_map:
            dialog.update_validation('generic_code_valid', 'fail', 'Missing column: generic_code')
            return False
        if not self.auth_handler.is_geoname_authenticated or not self.auth_handler.geoname_api_session:
            dialog.update_validation('generic_code_valid', 'fail', 'Not authenticated with geoname-t API.')
            return False

        try:
            if self._generic_codes is None:
                response = self.auth_handler.geoname_api_session.get(
                    f"{self.auth_handler.geoname_api_base_url}/codes/generic.json",
                    params={'sort-field': 'code', 'sort-order': 'asc'},
                    timeout=10
                )
                response.raise_for_status()
                self._generic_codes = {
                    str(definition.get('code')).strip()
                    for definition in response.json().get('definitions', [])
                    if definition.get('code') is not None
                }
        except requests.exceptions.RequestException as e:
            dialog.update_validation('generic_code_valid', 'fail', f"Could not load generic codes: {str(e)}")
            return False

        data_only = data_rows[1:] if len(data_rows) > 1 else []
        names_6_rows = self._names_6_row_indexes(data_dict, data_only)
        errors = defaultdict(list)
        generic_column = header_map['generic_code']
        for position, (row_number, row) in enumerate(
                enumerate(data_only, start=self._row_number_start(data_dict))):
            if names_6_rows is not None and position not in names_6_rows:
                continue
            generic_code = row[generic_column] if generic_column < len(row) else None
            if not self._is_empty_value(generic_code) and str(generic_code).strip() not in self._generic_codes:
                errors[f"generic_code '{generic_code}' is not in the geoname-t code list"].append(row_number)

        if errors:
            dialog.update_validation(
                'generic_code_valid', 'fail', '\n'.join(self._format_grouped_errors(errors))
            )
            return False

        dialog.update_validation('generic_code_valid', 'pass')
        return True
    
    def _format_grouped_errors(self, error_groups, by_row=False):
        """Format grouped error messages for display."""
        if by_row:
            row_errors = defaultdict(list)
            for error_msg, rows in error_groups.items():
                for row in rows:
                    row_errors[row].append(error_msg)
            ordered_rows = sorted(row_errors)
            errors = [
                f"Row {row}: {'; '.join(row_errors[row])}"
                for row in ordered_rows[:10]
            ]
            if len(ordered_rows) > 10:
                errors.append(f"... ({len(ordered_rows) - 10} more rows not shown)")
            return errors
        errors = []
        for error_msg, rows in sorted(error_groups.items()):
            if len(rows) == 1:
                errors.append(f"Row {rows[0]}: {error_msg}")
            else:
                rows_str = ', '.join(map(str, rows[:50]))
                if len(rows) > 50:
                    rows_str += f" ... (+{len(rows) - 50} more)"
                errors.append(f"Rows {rows_str}: {error_msg}")
            
            if len(errors) >= 10:
                remaining = len(error_groups) - len(errors)
                if remaining > 0:
                    errors.append(f"... ({remaining} more error types not shown)")
                break
        
        return errors
