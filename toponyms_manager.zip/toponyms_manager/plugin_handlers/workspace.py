"""
Workspace Handler

Handles FME workspace execution via GeoSys task runner.
"""

import csv
import json
import os
import time
import uuid
import requests
import traceback
from datetime import datetime
from qgis.PyQt import QtWidgets
from qgis.PyQt.QtCore import Qt, QVariant
from qgis.core import Qgis, QgsField, QgsProject, QgsVectorLayer

from ..utils import show_error_message, show_info_message, show_warning_message, log_message, ProgressTracker


class WorkspaceHandler:
    """
    Handles FME workspace execution through GeoSys API.
    """

    BATCH_LOAD_S3_PREFIX = "GNBC:data/GNBC"
    FME_SHARED_DATA_ROOT = "/opt/fme-shared-data/resources/data/"
    LAYER_FILE_EXTENSIONS = ('.gdb', '.fgdb', '.gpkg')
    MAIN_LAYER_NAME = 'names_6'
    DECISION_PDF_FIELDS = ('decision_pdf', 'decision_pdf_filename')
    DECISION_DATE_FIELD = 'decision_date'
    DECISION_ID_FIELD = 'decision_id'
    DECISION_WORKSPACE = "gnbc_batch_load_decision.fmw"
    # Batch Load Parameters dialog values also sent to gnbc_batch_load_decision.fmw.
    DECISION_SHARED_PARAMETERS = (
        'cgndb_connection', 'operator', 'decision_desription', 'authority', 'sql_on_conflict'
    )
    
    def __init__(self, parent_widget, auth_handler):
        """
        Initialize workspace handler.
        
        :param parent_widget: Parent widget (usually the dockwidget)
        :param auth_handler: AuthenticationHandler instance for API access
        """
        self.parent = parent_widget
        self.auth_handler = auth_handler
        self._progress = None
        self._batch_load_s3_objects = None

    def _close_progress(self):
        if self._progress:
            self._progress.close()
            self._progress = None

    def _wait(self, seconds):
        if self._progress:
            self._progress.sleep(seconds)
        else:
            time.sleep(seconds)

    def _save_batch_load_file(self):
        """Save current table/map edits and return the CSV or GeoPackage to upload."""
        file_path = getattr(self.parent, 'batch_load_file_path', None)
        if not file_path or not os.path.isfile(file_path):
            raise FileNotFoundError(f"Batch load file not found: {file_path or '(no file selected)'}")

        extension = os.path.splitext(file_path)[1].lower()
        if extension in ('.xlsx', '.csv'):
            return self.parent.file_import_handler.save_current_batch_as_csv()

        if extension not in ('.gdb', '.fgdb', '.gpkg'):
            raise ValueError(f"Unsupported batch load file type: {extension or '(no extension)'}")

        layers_to_commit = {}
        for layer in QgsProject.instance().mapLayers().values():
            source = layer.source().split('|', 1)[0]
            if os.path.normcase(os.path.normpath(source)) == os.path.normcase(os.path.normpath(file_path)):
                layers_to_commit[layer.id()] = layer
        for attr in ('coordinate_layer', 'geosys_layer', 'geosys_layer_points_0', 'processed_points_layer'):
            layer = getattr(self.parent, attr, None)
            if layer is not None:
                layers_to_commit[layer.id()] = layer

        for layer in layers_to_commit.values():
            if layer.isEditable() and not layer.commitChanges():
                errors = '; '.join(layer.commitErrors())
                raise RuntimeError(f"Could not save edits for layer '{layer.name()}': {errors}")

        dialog = getattr(self.parent, 'current_table_dialog', None)
        if dialog is not None and getattr(dialog, 'is_modified', False):
            if dialog.data_dict.get('read_only'):
                raise RuntimeError("The combined GPKG table is read-only; save edits on its source layer.")
            layer_name = dialog._gdb_layer_name()
            fields = dialog.linked_layer.fields() if dialog.linked_layer else dialog._string_fields_from_headers()
            rows = dialog._get_table_data()[1:]
            self.parent.file_import_handler._write_table(file_path, layer_name, fields, rows)
            dialog.is_modified = False

        log_message(f"Saved current batch load data to {file_path}", Qgis.Success)
        return file_path

    def _upload_batch_load_file(self, file_path):
        """Upload a batch load input (CSV, GeoPackage or decision PDF) to the GNBC S3 location."""
        if not file_path or not os.path.isfile(file_path):
            raise FileNotFoundError(f"Batch load file not found: {file_path or '(no file selected)'}")

        file_name = os.path.splitext(os.path.basename(file_path))[0]
        destination = f"{self.BATCH_LOAD_S3_PREFIX}/{file_name}"
        s3_object = f"{destination}/{os.path.basename(file_path)}"
        if self._batch_load_s3_objects is not None:
            # An upload can create the object even if its response fails.
            self._batch_load_s3_objects.append(s3_object)
        log_message(f"Uploading {os.path.basename(file_path)} to S3 folder {destination}...", Qgis.Info)
        response = self.auth_handler.geosys_client.amazon.upload_file(
            params={"contenant_url": destination},
            data={"fichier": file_path}
        )
        status_code = getattr(response, 'status_code', None)
        if status_code is not None and status_code >= 400:
            raise RuntimeError(f"S3 upload failed with status {status_code}.")
        log_message(f"Uploaded {os.path.basename(file_path)} to S3 object {s3_object}.", Qgis.Success)
        return s3_object

    def _cleanup_batch_load_s3_files(self, s3_objects):
        """Delete temporary files, then their upload containers, never the shared root."""
        s3_objects = list(dict.fromkeys(s3_objects))
        containers = []
        for s3_object in s3_objects:
            container = s3_object.rsplit('/', 1)[0]
            prefix = f"{self.BATCH_LOAD_S3_PREFIX}/"
            if container.startswith(prefix) and '/' not in container[len(prefix):]:
                containers.append(container)
        targets = [(path, False) for path in s3_objects]
        targets.extend((path, True) for path in dict.fromkeys(containers))
        failures = []
        failed_containers = set()
        for s3_object, is_container in targets:
            if is_container and s3_object in failed_containers:
                log_message(
                    f"Keeping S3 container {s3_object} because file deletion failed.", Qgis.Warning
                )
                continue
            try:
                amazon = self.auth_handler.geosys_client.amazon
                if is_container:
                    response = amazon.delete_container(params={"contenant_url": s3_object})
                else:
                    response = amazon.delete_file(params={"fichier_url": s3_object})
                status_code = getattr(response, 'status_code', None)
                if status_code == 404:
                    log_message(f"S3 cleanup: {s3_object} is already absent.", Qgis.Info)
                    continue
                if status_code is None or not 200 <= status_code < 300:
                    raise RuntimeError(f"S3 deletion returned status {status_code}.")
                log_message(f"Deleted temporary S3 object {s3_object}.", Qgis.Success)
            except Exception as error:
                if self._is_missing_s3_file(error):
                    log_message(f"S3 cleanup: {s3_object} is already absent.", Qgis.Info)
                    continue
                failures.append(s3_object)
                if not is_container:
                    failed_containers.add(s3_object.rsplit('/', 1)[0])
                log_message(f"Failed to delete temporary S3 object {s3_object}: {error}", Qgis.Warning)
        if failures:
            show_warning_message(
                self.parent,
                "S3 Cleanup Incomplete",
                "Could not delete these temporary S3 files or folders:\n\n" +
                "\n".join(failures) +
                "\n\nCheck the ToponymsManager log messages for details."
            )

    @classmethod
    def _fme_upload_paths(cls, folder_name, file_name):
        """Return (FME folder, FME-relative path, FME absolute path, task-runner path) for an upload."""
        fme_folder = f"Toponymie/Batch Load/{folder_name}/"
        fme_input_file = f"{fme_folder}{file_name}"
        return fme_folder, fme_input_file, f"{cls.FME_SHARED_DATA_ROOT}{fme_input_file}", f"./{file_name}"

    @staticmethod
    def _upload_actions(s3_object, task_runner_input_file, fme_folder):
        """Task-runner actions that copy an S3 object into the FME shared-resource folder."""
        return {
            "input_files": [[s3_object, task_runner_input_file]],
            "on_start": {
                "upload_fme": [{
                    "source": task_runner_input_file,
                    "connection": "FME_SHAREDRESOURCE_DATA",
                    "path": fme_folder,
                    "overwrite": True
                }]
            },
        }

    @staticmethod
    def _folder_task_steps(folder_input_file, workspace, actions, published_parameters):
        """Wrap a workspace between the add-folder and delete-folder workspaces."""
        return [
            ("gnbc_batch_load_addfolder.fmw", None, {"input_file": folder_input_file}),
            (workspace, actions, published_parameters),
            ("gnbc_batch_load_deletefolder.fmw", None, {"input_file": folder_input_file}),
        ]

    @classmethod
    def _is_layer_file(cls, file_path):
        return os.path.splitext((file_path or '').rstrip('\\/'))[1].lower() in cls.LAYER_FILE_EXTENSIONS

    @staticmethod
    def _header_index(headers, *names):
        lowered = [str(header).strip().casefold() if header is not None else '' for header in headers]
        for name in names:
            if name in lowered:
                return lowered.index(name)
        return None

    @staticmethod
    def _cell_text(value):
        if value is None or (hasattr(value, 'isNull') and value.isNull()):
            return ''
        if hasattr(value, 'toString') and not isinstance(value, str):
            value = value.toString(Qt.ISODate)
        text = str(value).strip()
        return '' if text.casefold() in ('null', '<null>') else text

    def _main_layer(self, file_path):
        """Return the names_6 layer of a GDB/GPKG main file, preferring the project's loaded layer."""
        wanted = os.path.normcase(os.path.normpath(file_path))
        for layer in QgsProject.instance().mapLayers().values():
            parts = layer.source().split('|')
            if (os.path.normcase(os.path.normpath(parts[0])) == wanted and
                    f"layername={self.MAIN_LAYER_NAME}" in (part.lower() for part in parts[1:])):
                return layer
        layer = QgsVectorLayer(f"{file_path}|layername={self.MAIN_LAYER_NAME}", self.MAIN_LAYER_NAME, "ogr")
        if not layer.isValid():
            raise RuntimeError(f"Could not open layer '{self.MAIN_LAYER_NAME}' in {file_path}.")
        return layer

    def _read_main_table(self, file_path):
        """Return (headers, rows) of the main batch table: the CSV itself or the names_6 layer."""
        if not file_path or not os.path.exists(file_path):
            return [], []
        if self._is_layer_file(file_path):
            layer = self._main_layer(file_path)
            return [field.name() for field in layer.fields()], [feature.attributes() for feature in layer.getFeatures()]
        with open(file_path, newline='', encoding='utf-8-sig') as csv_file:
            rows = list(csv.reader(csv_file))
        return (rows[0], rows[1:]) if rows else ([], [])

    def _decision_pdf_path(self, decision_pdf):
        """Resolve a decision_pdf filename against the folder containing the main input file."""
        main_input = getattr(self.parent, 'batch_load_source_path', None) or self.parent.batch_load_file_path
        return os.path.join(os.path.dirname(os.path.normpath(main_input)), decision_pdf)

    def _collect_decisions(self, file_path):
        """
        Group the main table rows by decision_pdf, including one PDF-free decision.

        Returns a list of decision dicts, or None (after showing an error) when a PDF is missing.
        """
        headers, rows = self._read_main_table(file_path)
        pdf_column = self._header_index(headers, *self.DECISION_PDF_FIELDS)
        if pdf_column is None:
            return []
        date_column = self._header_index(headers, self.DECISION_DATE_FIELD)
        id_column = self._header_index(headers, self.DECISION_ID_FIELD)

        decisions = {}
        for row in rows:
            decision_pdf = self._cell_text(row[pdf_column]) if pdf_column < len(row) else ''
            decision = decisions.setdefault(decision_pdf, {
                'decision_pdf': decision_pdf,
                'input_pdf_file': self._decision_pdf_path(decision_pdf) if decision_pdf else None,
                'dates': []
            })
            if id_column is not None and id_column < len(row) and not decision.get('decision_id'):
                decision_id = self._cell_text(row[id_column])
                if decision_id:
                    decision['decision_id'] = decision_id
            if date_column is not None and date_column < len(row):
                decision_date = self._cell_text(row[date_column])
                if decision_date and decision_date not in decision['dates']:
                    decision['dates'].append(decision_date)

        missing = [d['input_pdf_file'] for d in decisions.values()
               if d['input_pdf_file'] and not os.path.isfile(d['input_pdf_file'])]
        if missing:
            log_message(f"Missing decision PDF file(s): {missing}", Qgis.Critical)
            show_error_message(
                self.parent,
                "Decision PDF Not Found",
                "The following decision PDF file(s) referenced in decision_pdf were not found next to "
                "the batch load file:\n\n" + "\n".join(missing) +
                "\n\nNothing was submitted."
            )
            return None
        return list(decisions.values())

    def _resolve_decision_dates(self, decisions, default_date=None):
        """Choose one decision_date per PDF, asking the user when rows disagree. Returns False if cancelled."""
        for decision in decisions:
            if 'decision_date' in decision:
                continue
            dates = decision['dates']
            if len(dates) > 1:
                selected, accepted = QtWidgets.QInputDialog.getItem(
                    self.parent,
                    "Select Decision Date",
                    f"Rows referencing {decision['decision_pdf']} have different decision_date values.\n"
                    "Choose the decision_date to use for this decision:",
                    dates,
                    0,
                    False
                )
                if not accepted:
                    return False
                decision['decision_date'] = selected
            else:
                decision['decision_date'] = dates[0] if dates else default_date
        return True

    def _assign_decision_ids(self, file_path, decisions):
        """Write the accepted decision IDs to every matching row of the main file."""
        for decision in decisions:
            if not decision.get('decision_id'):
                decision['decision_id'] = str(uuid.uuid4())
        decision_ids = {decision['decision_pdf']: decision['decision_id'] for decision in decisions}

        if self._is_layer_file(file_path):
            self._write_layer_decision_ids(file_path, decision_ids)
        else:
            self._write_csv_decision_ids(file_path, decision_ids)
        self._show_decision_ids_in_table(decision_ids)
        log_message(f"Assigned decision_id values in {file_path}: {decision_ids}", Qgis.Info)

    def _write_layer_decision_ids(self, file_path, decision_ids):
        layer = self._main_layer(file_path)
        provider = layer.dataProvider()
        if provider.fields().lookupField(self.DECISION_ID_FIELD) < 0:
            if not provider.addAttributes([QgsField(self.DECISION_ID_FIELD, QVariant.String)]):
                raise RuntimeError(f"Could not add the {self.DECISION_ID_FIELD} field to {self.MAIN_LAYER_NAME}.")
            layer.updateFields()
        provider_fields = provider.fields()
        id_index = provider_fields.lookupField(self.DECISION_ID_FIELD)
        pdf_index = next(
            (provider_fields.lookupField(name) for name in self.DECISION_PDF_FIELDS
             if provider_fields.lookupField(name) >= 0),
            -1
        )
        changes = {
            feature.id(): {id_index: decision_ids.get(self._cell_text(feature.attributes()[pdf_index]), '')}
            for feature in provider.getFeatures()
        }
        if changes and not provider.changeAttributeValues(changes):
            raise RuntimeError(f"Could not write {self.DECISION_ID_FIELD} values to {self.MAIN_LAYER_NAME}.")
        layer.reload()
        layer.triggerRepaint()

    def _write_csv_decision_ids(self, file_path, decision_ids):
        with open(file_path, newline='', encoding='utf-8-sig') as csv_file:
            rows = list(csv.reader(csv_file))
        headers = rows[0]
        pdf_column = self._header_index(headers, *self.DECISION_PDF_FIELDS)
        id_column = self._header_index(headers, self.DECISION_ID_FIELD)
        if id_column is None:
            headers.append(self.DECISION_ID_FIELD)
            id_column = len(headers) - 1
        for row in rows[1:]:
            row.extend([''] * (len(headers) - len(row)))
            row[id_column] = decision_ids.get(self._cell_text(row[pdf_column]), '')
        with open(file_path, 'w', newline='', encoding='utf-8') as csv_file:
            csv.writer(csv_file).writerows(rows)

    def _show_decision_ids_in_table(self, decision_ids):
        """Mirror the written decision_id values in the open batch table without marking it modified."""
        dialog = getattr(self.parent, 'current_table_dialog', None)
        table = getattr(dialog, 'table', None)
        if table is None:
            return
        headers = list(dialog.data_dict.get('headers') or [])
        pdf_column = self._header_index(headers, *self.DECISION_PDF_FIELDS)
        if pdf_column is None:
            return
        layer_column = self._header_index(headers, 'source_layer')
        id_column = self._header_index(headers, self.DECISION_ID_FIELD)

        was_modified = dialog.is_modified
        sorting_enabled = table.isSortingEnabled()
        table.setSortingEnabled(False)
        table.blockSignals(True)
        try:
            if id_column is None:
                headers.append(self.DECISION_ID_FIELD)
                id_column = len(headers) - 1
                data = dialog.data_dict.get('data') or []
                dialog.data_dict['headers'] = headers
                dialog.data_dict['data'] = [headers] + [list(row) + [''] for row in data[1:]]
                dialog.data_dict['column_count'] = len(headers)
                table.setColumnCount(len(headers))
                table.setHorizontalHeaderItem(id_column, QtWidgets.QTableWidgetItem(self.DECISION_ID_FIELD))
            for row in range(table.rowCount()):
                if layer_column is not None:
                    layer_item = table.item(row, layer_column)
                    if layer_item is not None and layer_item.text() not in ('', self.MAIN_LAYER_NAME):
                        continue
                pdf_item = table.item(row, pdf_column)
                item = table.item(row, id_column)
                if item is None:
                    item = QtWidgets.QTableWidgetItem()
                    table.setItem(row, id_column, item)
                item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                item.setText(decision_ids.get(self._cell_text(pdf_item.text() if pdf_item else ''), ''))
        finally:
            table.blockSignals(False)
            table.setSortingEnabled(sorting_enabled)
        dialog.is_modified = was_modified

    def _decision_task_steps(self, decisions, published_parameters):
        """Build decision steps, uploading and wrapping only decisions that have PDFs."""
        shared_parameters = {
            name: published_parameters[name]
            for name in self.DECISION_SHARED_PARAMETERS if name in published_parameters
        }
        task_steps = []
        for decision in decisions:
            input_pdf_file = decision['input_pdf_file']
            decision_parameters = {
                **shared_parameters,
                "decision_id": decision['decision_id'],
            }
            for name in ('decision_desription', 'sql_on_conflict'):
                if name in decision:
                    decision_parameters[name] = decision[name]
            if decision.get('decision_date'):
                decision_parameters["decision_date"] = decision['decision_date']
            if not input_pdf_file:
                task_steps.append((self.DECISION_WORKSPACE, None, decision_parameters))
                continue
            pdf_file_name = os.path.basename(input_pdf_file)
            fme_folder, fme_pdf_file, fme_absolute_pdf_file, task_runner_pdf_file = self._fme_upload_paths(
                os.path.splitext(pdf_file_name)[0], pdf_file_name
            )
            s3_object = self._upload_batch_load_file(input_pdf_file)
            decision_parameters["input_pdf_file"] = fme_absolute_pdf_file
            task_steps.extend(self._folder_task_steps(
                fme_pdf_file,
                self.DECISION_WORKSPACE,
                self._upload_actions(s3_object, task_runner_pdf_file, fme_folder),
                decision_parameters
            ))
        return task_steps

    def _run_task_steps(self, task_steps, run_id, fme_headers):
        """Run workspace steps in order, stopping at the first failure."""
        for sequence_no, (workspace, actions, parameters) in enumerate(task_steps, start=1):
            if self._progress:
                pdf_file = (parameters or {}).get('input_pdf_file')
                detail = f" ({os.path.basename(pdf_file)})" if pdf_file else ""
                self._progress.set_label(f"Running {workspace}{detail}...")
            if not self._run_workspace_task(workspace, sequence_no, run_id, fme_headers, actions, parameters):
                return False
        return True

    def _error_file_name(self):
        """Build the dated output filename for the processed error file."""
        file_path = getattr(self.parent, 'batch_load_file_path', None)
        extension = os.path.splitext(file_path or '')[1].lower()
        if extension in ('.xlsx', '.csv'):
            output_extension = 'csv'
        elif extension in ('.gdb', '.fgdb', '.gpkg'):
            output_extension = 'gpkg'
        else:
            raise ValueError(f"Unsupported batch load file type: {extension or '(no extension)'}")

        date_stamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        return f"batchload_error_{date_stamp}.{output_extension}"

    def _load_authority_options(self):
        """Load selectable geoname-t authority code/term pairs."""
        session = self.auth_handler.geoname_api_session
        if not session:
            raise RuntimeError("Authenticate with geoname-t before processing the batch load file.")

        response = session.get(
            f"{self.auth_handler.geoname_api_base_url}/codes/toponymic-authority.json",
            params={'sort-field': 'term', 'sort-order': 'asc'},
            timeout=10
        )
        response.raise_for_status()
        definitions = response.json().get('definitions', [])
        options = []
        for definition in definitions:
            code = definition.get('code')
            term = definition.get('term')
            if code is None or term is None:
                continue
            code = str(code).strip()
            term = str(term).strip()
            if code and term:
                options.append((f"{code}: {term}", code))
        if not options:
            raise ValueError("The geoname-t toponymic-authority code list returned no usable authorities.")
        return options

    def _prompt_batch_parameters(self, default_input_file, decisions=None):
        """Collect common, per-decision, and main batch workspace parameters."""
        decisions = decisions if decisions is not None else []
        cgndb_connection = self.auth_handler.cgndb_connection
        if not cgndb_connection:
            show_error_message(
                self.parent,
                "CGNDB Configuration Required",
                "Please login with NRCan again to load the selected environment's cgndb_connection."
            )
            return None
        try:
            authority_options = self._load_authority_options()
        except Exception as error:
            log_message(f"Could not load geoname-t authorities: {error}", Qgis.Critical)
            show_error_message(
                self.parent,
                "Authority List Unavailable",
                f"Could not load the authority choices from geoname-t:\n{error}"
            )
            return None

        dialog = QtWidgets.QDialog(self.parent)
        dialog.setWindowTitle("Batch Load Parameters")
        layout = QtWidgets.QVBoxLayout(dialog)
        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        content = QtWidgets.QWidget()
        sections = QtWidgets.QVBoxLayout(content)
        scroll.setWidget(content)
        layout.addWidget(scroll)
        dialog.resize(720, 680)

        def add_section(title, object_name):
            group = QtWidgets.QGroupBox(title)
            group.setObjectName(object_name)
            form = QtWidgets.QFormLayout(group)
            form.setRowWrapPolicy(QtWidgets.QFormLayout.WrapLongRows)
            sections.addWidget(group)
            return form

        def add_conflict_choice(form):
            combo = QtWidgets.QComboBox()
            combo.addItems(('do_nothing', 'do_update', 'fails'))
            combo.setCurrentText('fails')
            form.addRow("Select an action SQL INSERT on conflict on constraint", combo)
            tooltip = (
                "<p><b>Action when a database constraint conflict occurs during insertion:</b></p>"
                "<ul>"
                "<li><b>fails</b> (default): Cancel the transaction and return the database error "
                "in the error file. No changes are applied for this row.</li>"
                "<li><b>do_nothing</b>: Skip the conflicting insert and continue processing "
                "other operations.</li>"
                "<li><b>do_update</b>: Update the conflicting record and continue processing "
                "other operations.</li>"
                "</ul>"
            )
            combo.setToolTip(tooltip)
            form.labelForField(combo).setToolTip(tooltip)
            return combo

        common_form = add_section("Common Parameters", 'common_parameters')
        session_auth = getattr(self.auth_handler.geoname_api_session, 'auth', None)
        operator_username = (getattr(session_auth, 'username', None) or '').strip()
        operator = QtWidgets.QLineEdit(operator_username)
        common_form.addRow("Operator", operator)

        authority = QtWidgets.QComboBox()
        authority.addItem("Select authority...", None)
        for label, code in authority_options:
            authority.addItem(label, code)
        common_form.addRow("Enter Jurisdictional Authority of the decision", authority)

        decision_fields = []
        for index, decision in enumerate(decisions):
            pdf_label = decision['decision_pdf'] or 'Without PDF'
            form = add_section(f"gnbc_batch_load_decision.fmw - {pdf_label}",
                               f'decision_parameters_{index}')
            if not decision.get('decision_id'):
                decision['decision_id'] = str(uuid.uuid4())
            decision_id = QtWidgets.QLineEdit(decision['decision_id'])
            description = QtWidgets.QPlainTextEdit(decision.get('decision_desription', ''))
            description.setMaximumHeight(72)
            form.addRow("Decision ID", decision_id)
            decision_date = QtWidgets.QComboBox()
            decision_date.setEditable(True)
            decision_date.addItem('')
            dates = decision.get('dates', [])
            decision_date.addItems(dates)
            decision_date.setCurrentText(decision.get('decision_date') or (dates[0] if dates else ''))
            decision_date.lineEdit().setPlaceholderText('YYYY-MM-DD')
            form.addRow("Decision Date", decision_date)
            form.addRow("Enter decision description", description)
            conflict = add_conflict_choice(form)
            decision_fields.append((decision, decision_id, description, conflict, decision_date))

        batch_form = add_section("gnbc_batch_load.fmw", 'batch_parameters')
        input_file = QtWidgets.QLineEdit(default_input_file)
        activity_description = QtWidgets.QPlainTextEdit()
        activity_description.setMaximumHeight(72)
        batch_form.addRow("Enter filepath/filename", input_file)
        batch_form.addRow("Enter activity table description", activity_description)
        batch_conflict = add_conflict_choice(batch_form)

        source_extension = os.path.splitext(
            getattr(self.parent, 'batch_load_source_path', None) or self.parent.batch_load_file_path
        )[1].lower()

        buttons = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel
        )

        def accept_if_complete():
            required_values = {
                'input_file': input_file.text().strip(),
                'operator': operator.text().strip(),
                'ACTIVITY_DESCRIPTION': activity_description.toPlainText().strip(),
                'authority': authority.currentData()
            }
            for decision, decision_id, description, conflict, decision_date in decision_fields:
                label = decision['decision_pdf'] or 'Without PDF'
                required_values[f'{label}: decision_id'] = decision_id.text().strip()
                required_values[f'{label}: decision_desription'] = description.toPlainText().strip()
            missing = [name for name, value in required_values.items() if not value]
            if missing:
                QtWidgets.QMessageBox.warning(
                    dialog,
                    "Missing Parameters",
                    f"Please fill in: {', '.join(missing)}"
                )
                return
            dialog.accept()

        buttons.accepted.connect(accept_if_complete)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)

        if dialog.exec_() != QtWidgets.QDialog.Accepted:
            return None

        for decision, decision_id, description, conflict, decision_date in decision_fields:
            decision.update({
                'decision_id': decision_id.text().strip(),
            'decision_date': decision_date.currentText().strip(),
                'decision_desription': description.toPlainText().strip(),
                'sql_on_conflict': conflict.currentText(),
            })
        parameters = {
            'cgndb_connection': cgndb_connection,
            'input_file': input_file.text().strip(),
            'operator': operator.text().strip(),
            'ACTIVITY_DESCRIPTION': activity_description.toPlainText().strip(),
            'authority': authority.currentData(),
            'local_plugin': 'plugin',
            'NAME6_TABLE_SOURCE': 'gdb' if source_extension in ('.gdb', '.fgdb', '.gpkg') else 'xlsx',
            'sql_on_conflict': batch_conflict.currentText(),
        }
        return parameters

    def run_workspace(self):
        """Run the FME workspace with a progress dialog shown until the task finishes."""
        if not self.auth_handler.is_authenticated or not self.auth_handler.geosys_client:
            return self._run_workspace()
        self._progress = ProgressTracker(
            self.parent, "Processing batch load file", "Submitting FME workspace task...", 0, cancellable=True
        )
        try:
            self._run_workspace()
        finally:
            self._close_progress()

    def _run_workspace(self):
        """
        Save the active batch load, run the decision workspaces once per unique
        decision_pdf, execute the main batch load workspaces in order, then
        download the error output when one was produced. Clean up temporary
        S3 objects on every exit after an upload attempt.
        """
        if not self.auth_handler.is_authenticated or not self.auth_handler.geosys_client:
            show_error_message(
                self.parent,
                "Authentication Required",
                "Please login with NRCan credentials first using the Login button."
            )
            return
        
        self._batch_load_s3_objects = []
        try:
            fme_token = self.auth_handler.fme_token
            if not fme_token or not self.auth_handler.fme_flow_url:
                show_error_message(
                    self.parent,
                    "FME Configuration Required",
                    "Please login with NRCan again to load the selected environment's FME configuration."
                )
                return
            upload_file_path = self._save_batch_load_file()
            decisions = self._collect_decisions(upload_file_path)
            if decisions is None:
                return
            batch_file_name = os.path.splitext(
                os.path.basename(self.parent.batch_load_file_path)
            )[0]
            fme_folder, fme_input_file, fme_main_input_file, task_runner_input_file = self._fme_upload_paths(
                batch_file_name, os.path.basename(upload_file_path)
            )
            published_parameters = self._prompt_batch_parameters(fme_input_file, decisions)
            if published_parameters is None:
                return
            if not self._resolve_decision_dates(decisions, published_parameters.get('decision_date')):
                return
            if decisions:
                self._assign_decision_ids(upload_file_path, decisions)

            if os.path.splitext(upload_file_path)[1].lower() in self.LAYER_FILE_EXTENSIONS:
                self.parent.file_import_handler.synchronize_original_names(upload_file_path)
            s3_object = self._upload_batch_load_file(upload_file_path)
            decision_steps = self._decision_task_steps(decisions, published_parameters)
            error_file_name = self._error_file_name()
            error_s3_destination = f"{self.BATCH_LOAD_S3_PREFIX}/{error_file_name}"
            fme_error_file_path = f"{fme_folder}{error_file_name}"
            task_runner_error_file = f"./{error_file_name}"

            run_id = f"toponymy_plugin_{datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}"
            fme_headers = {
                "Authorization": f"fmetoken token={fme_token}",
                "Accept": "application/json",
                "Content-Type": "application/json"
            }
            main_steps = self._folder_task_steps(
                published_parameters['input_file'],
                "gnbc_batch_load.fmw",
                {
                    **self._upload_actions(s3_object, task_runner_input_file, fme_folder),
                    "on_success": {
                        "download_fme": [{
                            "path": fme_error_file_path,
                            "connection": "FME_SHAREDRESOURCE_DATA",
                            "destination": task_runner_error_file
                        }]
                    },
                    "output_files": [[task_runner_error_file, f"{self.BATCH_LOAD_S3_PREFIX}/"]]
                },
                {
                    **published_parameters,
                    "input_file": fme_main_input_file,
                    # The FME writer appends the extension itself.
                    "error_output": os.path.splitext(error_file_name)[0]
                }
            )
            self._batch_load_s3_objects.append(error_s3_destination)

            # Decision records are created before gnbc_batch_load.fmw references their decision_id.
            if not self._run_task_steps(decision_steps + main_steps, run_id, fme_headers):
                return

            original_path = (
                getattr(self.parent, 'batch_load_source_path', None) or
                self.parent.batch_load_file_path
            )
            local_error_path = os.path.join(os.path.dirname(original_path), error_file_name)
            active_path = self.parent.batch_load_file_path
            if (active_path and os.path.normcase(os.path.abspath(active_path)) ==
                    os.path.normcase(os.path.abspath(local_error_path))):
                stem, extension = os.path.splitext(local_error_path)
                local_error_path = f"{stem}_{uuid.uuid4().hex[:8]}{extension}"
            if os.path.exists(local_error_path):
                os.remove(local_error_path)
            try:
                downloaded = self._download_error_file(error_s3_destination, local_error_path)
            except Exception as download_error:
                log_message(f"Failed to download the batch-load error file: {download_error}", Qgis.Critical)
                show_error_message(
                    self.parent,
                    "Error File Download Failed",
                    "The workspaces completed, but the error file could not be downloaded. "
                    "Check the ToponymsManager log messages."
                )
                return

            if downloaded:
                log_message(f"Downloaded batch-load error file: {local_error_path}", Qgis.Warning)
                self._close_progress()
                merge_errors = local_error_path.lower().endswith('.gpkg')
                reply = QtWidgets.QMessageBox.question(
                    self.parent,
                    "Batch Load Processed with Errors",
                    f"The batch load process completed with errors. The error file was saved to:\n"
                    f"{local_error_path}\n\n" +
                    ("Do you want to merge these records with the current error table?"
                     if merge_errors else
                     "Do you want to clear the current batch load and import this error file?"),
                    QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                    QtWidgets.QMessageBox.No
                )
                if reply == QtWidgets.QMessageBox.Yes:
                    if merge_errors:
                        self.parent.file_import_handler.import_workspace_error_gpkg(local_error_path)
                    elif self.parent._clear_batch_load_and_layers():
                        self.parent.file_import_handler.import_batch_load_path(local_error_path)
            else:
                log_message("Batch load processed without errors; no error file was found in S3.", Qgis.Success)
                show_info_message(
                    self.parent,
                    "Batch Load Processed",
                    "The batch load file was processed without errors."
                )
            
        except ImportError:
            show_error_message(
                self.parent,
                "Missing Library",
                "The 'pygeosys' library is not installed.\n\n"
                "Please install it using:\n"
                "pip install pygeosys"
            )
            log_message("pygeosys library not found", Qgis.Critical)
            
        except Exception as e:
            error_details = traceback.format_exc()
            log_message(f"Workspace error type: {type(e).__name__}", Qgis.Critical)
            log_message(f"Workspace error message: {str(e)}", Qgis.Critical)
            log_message(f"Full traceback:\n{error_details}", Qgis.Critical)
            
            if hasattr(e, 'response'):
                log_message(f"Response status: {getattr(e.response, 'status_code', 'N/A')}", Qgis.Critical)
                log_message(f"Response text: {getattr(e.response, 'text', 'N/A')}", Qgis.Critical)
            
            if hasattr(e, 'args') and e.args:
                log_message(f"Error args: {e.args}", Qgis.Critical)
            
            show_error_message(
                self.parent,
                "Workspace Error",
                f"Failed to initialize GeoSys workspace:\n\n"
                f"Error Type: {type(e).__name__}\n"
                f"Error: {str(e)}\n\n"
                f"Check QGIS logs for detailed traceback."
            )
        finally:
            s3_objects = self._batch_load_s3_objects
            self._batch_load_s3_objects = None
            self._cleanup_batch_load_s3_files(s3_objects)

    def _run_workspace_task(
            self, workspace, sequence_no, run_id, fme_headers, actions=None, published_parameters=None):
        """Submit one REST_FME task and return whether it completed successfully."""
        command = {
            "uri": self.auth_handler.fme_flow_url,
            "method": "POST",
            "body": {
                "repository": "GNBC",
                "workspace": workspace,
                "publishedParameters": published_parameters or {}
            },
            "headers": fme_headers
        }
        if actions:
            command.update(actions)

        data = {
            "projet": "GNBC",
            "categorie": "REST_FME",
            "id_groupe": run_id,
            "no_seq": sequence_no,
            "statut": "LANCER",
            "notify": False,
            "commande": json.dumps(command)
        }
        log_message(f"Submitting workspace task: {workspace}", Qgis.Info)

        try:
            task = self.auth_handler.geosys_client.system.insert_task(data=data)
        except Exception as error:
            self._report_workspace_failure(workspace, f"Task submission failed: {error}")
            return False

        status_code = getattr(task, 'status_code', None)
        response_data = getattr(task, 'json_content', None) or {}
        log_message(f"Task response: status_code={status_code}", Qgis.Info)
        if status_code is not None and status_code >= 400:
            self._report_workspace_failure(
                workspace,
                f"Task submission returned HTTP {status_code}: {response_data}"
            )
            return False

        log_message(f"Task response JSON: {json.dumps(response_data, indent=2)}", Qgis.Info)
        task_id = response_data.get('id')
        if not task_id:
            self._report_workspace_failure(workspace, "Task submission returned no task ID.")
            return False

        return self._poll_task_status(task_id, workspace)

    def _report_workspace_failure(self, workspace, details, task_info=None):
        """Log workspace failure details and direct the user to the QGIS log panel."""
        log_message(f"Workspace '{workspace}' failed: {details}", Qgis.Critical)
        if task_info:
            log_message(
                f"Workspace '{workspace}' final task details:\n{json.dumps(task_info, indent=2)}",
                Qgis.Critical
            )
            info_suppl = task_info.get('info_suppl', {})
            if isinstance(info_suppl, dict):
                task_runner_output = info_suppl.get('task_runner_output', {})
                if isinstance(task_runner_output, dict):
                    self._process_task_logs(task_runner_output)

        show_error_message(
            self.parent,
            "Workspace Failed",
            f"The workspace {workspace} failed. Please read the error messages in the "
            "ToponymsManager log messages. Remaining processing steps were stopped."
        )

    def _download_error_file(self, s3_path, local_path):
        """Download the processed error file, returning False when it is absent from S3."""
        try:
            response = self.auth_handler.geosys_client.amazon.download_file(
                params={"fichier_url": s3_path},
                save_path=local_path
            )
        except Exception as error:
            if self._is_missing_s3_file(error):
                return False
            raise

        status_code = getattr(response, 'status_code', None)
        if status_code == 404:
            return False
        if status_code is not None and status_code >= 400:
            raise RuntimeError(f"S3 error-file download failed with status {status_code}.")
        return os.path.isfile(local_path)

    @staticmethod
    def _is_missing_s3_file(error):
        response = getattr(error, 'response', None)
        status_code = getattr(response, 'status_code', None) or getattr(error, 'status_code', None)
        if status_code == 404:
            return True
        message = str(error).casefold()
        return any(marker in message for marker in ('not found', 'nosuchkey', 'no such key', '404'))
    
    def _poll_task_status(self, task_id, workspace):
        """Poll until the workspace task reaches a terminal status."""
        poll_interval = 25  # seconds between polls
        max_wait_time = 900  # 15 minutes timeout
        start_time = time.time()
        terminal_states = {"TERMINÉE", "TASK-RUNNER-ERREUR", "ERREUR", "ANNULÉE"}
        poll_count = 0

        try:
            while True:
                elapsed_time = time.time() - start_time
                if self._progress and self._progress.was_canceled():
                    log_message(f"Stopped waiting for task {task_id}; it continues running in GeoSys", Qgis.Warning)
                    show_warning_message(
                        self.parent,
                        "Stopped Waiting",
                        f"No longer monitoring task {task_id}. It continues running in GeoSys."
                    )
                    return False
                if elapsed_time > max_wait_time:
                    self._report_workspace_failure(
                        workspace,
                        f"Task {task_id} did not complete within {max_wait_time} seconds."
                    )
                    return False

                poll_count += 1
                log_message(f"Polling task status (attempt {poll_count})...", Qgis.Info)
                task_details = self.auth_handler.geosys_client.system.get_task(params={"id_tache": task_id})

                if task_details.status_code == 200 and task_details.json_content:
                    task_info = task_details.json_content
                    current_status = task_info.get('statut', 'UNKNOWN')
                    log_message(f"Current status: {current_status}", Qgis.Info)
                    if self._progress:
                        self._progress.set_label(f"FME task {task_id}: {current_status} ({int(elapsed_time)}s)")

                    if current_status in terminal_states:
                        log_message(f"Task reached terminal state: {current_status}", Qgis.Info)
                        log_message("Waiting 30 seconds for logs to be uploaded...", Qgis.Info)
                        if self._progress:
                            self._progress.set_label("Task finished. Waiting for logs to be uploaded...")
                        self._wait(30)

                        log_message("Re-querying task for final logs...", Qgis.Info)
                        task_details_final = self.auth_handler.geosys_client.system.get_task(params={"id_tache": task_id})
                        if task_details_final.status_code == 200 and task_details_final.json_content:
                            task_info = task_details_final.json_content

                        return self._handle_task_completion(task_id, task_info, current_status, workspace)

                    log_message(f"Task still running... waiting {poll_interval} seconds", Qgis.Info)
                    self._wait(poll_interval)
                else:
                    log_message(f"Failed to query task: status_code={task_details.status_code}", Qgis.Warning)
                    self._wait(poll_interval)
        except Exception as poll_error:
            log_message(f"Error during task polling: {poll_error}", Qgis.Critical)
            log_message(f"Polling error traceback:\n{traceback.format_exc()}", Qgis.Critical)
            self._report_workspace_failure(
                workspace,
                f"Error while monitoring task {task_id}: {poll_error}"
            )
            return False

    def _handle_task_completion(self, task_id, task_info, current_status, workspace):
        """Log final task details and report whether this stage succeeded."""
        task_runner_output = {}
        info_suppl = task_info.get('info_suppl', {})
        if isinstance(info_suppl, dict):
            task_runner_output = info_suppl.get('task_runner_output', {}) or {}
        task_errors = task_runner_output.get('erreur', []) if isinstance(task_runner_output, dict) else []
        succeeded = current_status == "TERMINÉE" and not task_errors

        log_level = Qgis.Info if succeeded else Qgis.Critical
        log_message(f"Final task details:\n{json.dumps(task_info, indent=2)}", log_level)
        process_id = task_info.get('process_id')
        if process_id:
            log_message(f"✓ FME Flow Job ID (process_id): {process_id}", Qgis.Success)
        else:
            log_message("⚠ process_id not found in completed task", Qgis.Warning)

        if info_suppl:
            log_message("Task execution details:", Qgis.Info)
            log_message(json.dumps(info_suppl, indent=2), Qgis.Info)

        if succeeded:
            if isinstance(task_runner_output, dict) and task_runner_output:
                self._process_task_logs(task_runner_output)
            log_message(f"Workspace '{workspace}' completed successfully (task {task_id}).", Qgis.Success)
            return True

        details = f"Task {task_id} finished with status '{current_status}'."
        if task_errors:
            details += f" FME task runner reported: {task_errors}"
        self._report_workspace_failure(workspace, details, task_info)
        return False
    
    def _process_task_logs(self, task_runner_output):
        """
        Download and process FME task logs.
        
        :param task_runner_output: Task runner output dictionary
        """
        log_url = task_runner_output.get('log')
        if log_url:
            log_message(f"📄 Task runner log available at: {log_url}", Qgis.Info)
            
            # Download and parse the log for Logger output
            try:
                log_message("Downloading task log...", Qgis.Info)
                log_response = requests.get(log_url, timeout=30)
                
                if log_response.status_code == 200:
                    log_content = log_response.text
                    log_message("Log downloaded successfully", Qgis.Success)
                    
                    # Filter for Logger-related INFORM messages
                    self._extract_logger_output(log_content)
                else:
                    log_message(f"Failed to download log: HTTP {log_response.status_code}", Qgis.Warning)
                    
            except requests.exceptions.RequestException as download_error:
                log_message(f"Error downloading log: {download_error}", Qgis.Warning)
            except Exception as parse_error:
                log_message(f"Error parsing log: {parse_error}", Qgis.Warning)
        
        # Check for errors
        errors = task_runner_output.get('erreur', [])
        if errors:
            log_message("❌ Task errors:", Qgis.Critical)
            for error in errors:
                log_message(f"  - {error.get('message', str(error))}", Qgis.Critical)
    
    def _extract_logger_output(self, log_content):
        """
        Extract Logger output from FME log content.
        
        :param log_content: Raw log content from FME
        """
        log_message("Filtering for Logger output...", Qgis.Info)
        logger_lines = []
        lines = log_content.split('\n')
        
        for i, line in enumerate(lines):
            # Look for INFORM messages with Logger feature types
            if "INFORM" in line and "Feature Type:" in line:
                # Check if it's a Logger feature type
                if "Logger" in line and "_LOGGED" in line:
                    # Look backwards for the separator line
                    start_index = i
                    for k in range(i - 1, max(0, i - 5), -1):
                        if "++++++" in lines[k]:
                            start_index = k
                            break
                    
                    # Add lines from the separator onwards
                    for j in range(start_index, len(lines)):
                        current_line = lines[j]
                        
                        # Stop if we hit a non-INFORM line
                        if current_line.strip() and "INFORM" not in current_line and j > i:
                            break
                        
                        # Add the line
                        logger_lines.append(current_line)
                        
                        # Stop after the ending separator
                        if "===========" in current_line and "INFORM" in current_line:
                            break
        
        if logger_lines:
            log_message("=" * 80, Qgis.Info)
            log_message("📝 LOGGER OUTPUT FROM FME WORKSPACE:", Qgis.Info)
            log_message("=" * 80, Qgis.Info)
            for log_line in logger_lines:
                # Remove |INFORM| and everything before it
                if "|INFORM|" in log_line:
                    cleaned_line = log_line.split("|INFORM|", 1)[1]
                    log_message(cleaned_line, Qgis.Info)
                else:
                    log_message(log_line, Qgis.Info)
            log_message("=" * 80, Qgis.Info)
        else:
            log_message("ℹ No Logger output found in FME workspace log", Qgis.Info)
