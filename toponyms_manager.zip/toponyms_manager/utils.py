# -*- coding: utf-8 -*-
"""
Utility functions for the Toponyms Manager plugin.
Contains helper functions, file operations, and common utilities.
"""

import os
import math
import shutil
import time
from datetime import datetime

from qgis.PyQt import QtWidgets
from qgis.PyQt.QtCore import Qt
from qgis.PyQt import QtGui
from qgis.core import QgsMessageLog, Qgis


def coordinate_errors(latitude, longitude):
    """Return problems with a coordinate pair using the plugin's Canada bounds."""
    values = (('Latitude', latitude, -90, 90, 41.7, 83.1),
              ('Longitude', longitude, -180, 180, -141.0, -52.6))
    empty = [value is None or str(value).strip().lower() in ('', 'null', '<null>')
             for value in (latitude, longitude)]
    if all(empty):
        return []
    errors = []
    for (name, value, minimum, maximum, canada_min, canada_max), missing in zip(values, empty):
        if missing:
            errors.append(f"{name} is empty")
            continue
        try:
            number = float(value)
        except (ValueError, TypeError, OverflowError):
            errors.append(f"{name} {value!r} is not a valid number")
            continue
        if not math.isfinite(number):
            errors.append(f"{name} {value!r} is not a finite number")
        elif not minimum <= number <= maximum:
            errors.append(f"{name} {number} is outside the valid range ({minimum} to {maximum})")
        elif not canada_min <= number <= canada_max:
            errors.append(f"{name} {number} is outside Canada bounds ({canada_min} to {canada_max})")
    return errors


def select_file(parent=None, title="Select File", file_filter="All Files (*.*)"):
    """
    Open file selection dialog and return selected file path.
    
    :param parent: Parent widget
    :param title: Dialog title
    :param file_filter: File filter string
    :return: Selected file path or None if cancelled
    """
    file_path, _ = QtWidgets.QFileDialog.getOpenFileName(
        parent,
        title,
        os.path.expanduser("~"),
        file_filter
    )
    return file_path if file_path else None


def select_folder(parent=None, title="Select Folder", start_dir=None):
    """
    Open folder selection dialog and return selected folder path.
    
    :param parent: Parent widget
    :param title: Dialog title
    :param start_dir: Starting directory
    :return: Selected folder path or None if cancelled
    """
    folder = QtWidgets.QFileDialog.getExistingDirectory(
        parent,
        title,
        start_dir or os.path.expanduser("~")
    )
    return folder if folder else None


def create_timestamped_copy(file_path, date_format="%Y%m%d"):
    """
    Create today's working copy, replacing trailing dates in the filename.
    Reuse the source if it is already today's file; otherwise overwrite today's copy.
    
    :param file_path: Original file path
    :param date_format: Date format for timestamp (default: YYYYMMDD)
    :return: Path to copied file
    :raises IOError: If copy fails
    """
    file_dir = os.path.dirname(file_path)
    copy_path = os.path.join(file_dir, generate_dated_filename(file_path, date_format))

    if os.path.exists(copy_path) and os.path.samefile(file_path, copy_path):
        QgsMessageLog.logMessage(
            f"Reusing timestamped file: {copy_path}",
            "ToponymsManager",
            Qgis.Info
        )
        return copy_path
    
    shutil.copy2(file_path, copy_path)
    
    QgsMessageLog.logMessage(
        f"Created timestamped copy: {copy_path}",
        "ToponymsManager",
        Qgis.Info
    )
    
    return copy_path


def generate_dated_filename(original_path, date_format="%Y-%m-%d", remove_existing_date=True):
    """
    Generate a filename with today's date, replacing trailing dates by default.
    
    :param original_path: Original file path
    :param date_format: Date format string
    :param remove_existing_date: Remove existing date suffix if present
    :return: New filename (not full path)
    """
    import re
    
    file_name = os.path.basename(original_path)
    name_without_ext, ext = os.path.splitext(file_name)
    
    # Remove existing timestamp if requested
    if remove_existing_date:
        name_without_ext = re.sub(r'(?:_(?:\d{8}|\d{4}-\d{2}-\d{2}))+$', '', name_without_ext)
    
    date_str = datetime.now().strftime(date_format)
    return f"{name_without_ext}_{date_str}{ext}"


def show_info_message(parent, title, message):
    """Show information message box"""
    QtWidgets.QMessageBox.information(parent, title, message)


def show_error_message(parent, title, message):
    """Show error message box"""
    QtWidgets.QMessageBox.critical(parent, title, message)


def show_warning_message(parent, title, message):
    """Show warning message box"""
    QtWidgets.QMessageBox.warning(parent, title, message)


def confirm_action(parent, title, message):
    """
    Show confirmation dialog.
    
    :return: True if user confirms, False otherwise
    """
    reply = QtWidgets.QMessageBox.question(
        parent,
        title,
        message,
        QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
        QtWidgets.QMessageBox.No
    )
    return reply == QtWidgets.QMessageBox.Yes


class _BusyBar(QtWidgets.QWidget):
    """Track with a high-contrast block that bounces left/right based on the clock."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(320, 10)

    def paintEvent(self, event):
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        rect = self.rect().adjusted(1, 1, -1, -1)
        painter.setPen(QtGui.QColor('#808080'))
        painter.setBrush(QtGui.QColor('#e0e0e0'))
        painter.drawRoundedRect(rect, 4, 4)
        block_w = max(rect.width() // 4, 20)
        phase = (time.monotonic() % 1.6) / 1.6
        x = rect.left() + int((rect.width() - block_w) * (1 - abs(2 * phase - 1)))
        painter.setPen(Qt.NoPen)
        painter.setBrush(QtGui.QColor('#0078d7'))
        painter.drawRoundedRect(x, rect.top(), block_w, rect.height(), 4, 4)


class ProgressPanel(QtWidgets.QWidget):
    """Label + busy bar + optional stop button, meant to sit at the bottom of the plugin dock."""

    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(6, 2, 6, 4)
        self.label = QtWidgets.QLabel()
        self.bar = _BusyBar()
        self.stop_button = QtWidgets.QPushButton("Abort process")
        layout.addWidget(self.label)
        layout.addWidget(self.bar)
        layout.addWidget(self.stop_button)


class ProgressTracker:
    """Busy bar (no real-time progress) for long-running tasks; call step() in loops and close() when done.

    Uses parent.progress_panel (bottom of the dock) when present, otherwise a popup dialog.
    """

    def __init__(self, parent, title, label, maximum=0, cancellable=False):
        self._last_pump = 0.0
        self._canceled = False
        self._dialog = None
        self._locked = None
        self._panel = getattr(parent, 'progress_panel', None)
        if self._panel is None:
            self._dialog = QtWidgets.QDialog(parent)
            self._dialog.setWindowTitle(title)
            self._dialog.setWindowModality(Qt.WindowModal)
            self._dialog.setWindowFlags(self._dialog.windowFlags() & ~Qt.WindowCloseButtonHint)
            QtWidgets.QVBoxLayout(self._dialog).setContentsMargins(0, 0, 0, 0)
            self._panel = ProgressPanel(self._dialog)
            self._dialog.layout().addWidget(self._panel)
            self._dialog.show()
        else:
            # Block the rest of the dock while the panel is busy.
            self._locked = getattr(parent, 'dockWidgetContents', None)
            if self._locked is not None:
                self._locked.setEnabled(False)
        self._label = self._panel.label
        self._bar = self._panel.bar
        self._label.setText(label)
        self._panel.stop_button.setVisible(cancellable)
        if cancellable:
            self._panel.stop_button.clicked.connect(self._cancel)
        self._panel.show()
        self._pump()

    def _cancel(self):
        self._canceled = True

    def _pump(self):
        self._bar.repaint()
        QtWidgets.QApplication.processEvents()

    def add_total(self, extra):
        pass

    def step(self, label=None, count=1):
        if label:
            self._label.setText(label)
        now = time.monotonic()
        if label or now - self._last_pump >= 0.03:
            self._last_pump = now
            self._pump()

    def set_label(self, label):
        self._label.setText(label)
        self._pump()

    def was_canceled(self):
        return self._canceled

    def sleep(self, seconds):
        """Wait without freezing the UI; returns early if the user cancels."""
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline and not self._canceled:
            self._pump()
            time.sleep(0.03)

    def close(self):
        if self._dialog is not None:
            self._dialog.close()
            return
        try:
            self._panel.stop_button.clicked.disconnect(self._cancel)
        except TypeError:
            pass
        self._panel.hide()
        if self._locked is not None:
            self._locked.setEnabled(True)


def log_message(message, level=Qgis.Info):
    """
    Log message to QGIS message log.
    
    :param message: Message text
    :param level: Log level (Qgis.Info, Qgis.Warning, Qgis.Critical, Qgis.Success)
    """
    QgsMessageLog.logMessage(message, "ToponymsManager", level)


def ensure_dir_exists(directory):
    """
    Ensure directory exists, create if it doesn't.
    
    :param directory: Directory path
    :return: True if directory exists or was created
    """
    try:
        os.makedirs(directory, exist_ok=True)
        return True
    except Exception as e:
        log_message(f"Failed to create directory {directory}: {str(e)}", Qgis.Critical)
        return False


def normalize_path(path):
    """
    Normalize path separators for current OS.
    
    :param path: Path to normalize
    :return: Normalized path
    """
    return os.path.normpath(path)


def get_file_info(file_path):
    """
    Get basic file information.
    
    :param file_path: Path to file
    :return: Dictionary with file information
    """
    if not os.path.exists(file_path):
        return None
    
    stat_info = os.stat(file_path)
    
    return {
        'name': os.path.basename(file_path),
        'directory': os.path.dirname(file_path),
        'size': stat_info.st_size,
        'size_mb': round(stat_info.st_size / (1024 * 1024), 2),
        'modified': datetime.fromtimestamp(stat_info.st_mtime),
        'extension': os.path.splitext(file_path)[1]
    }
