# -*- coding: utf-8 -*-
"""
Plugin settings management for Toponyms Manager.
Stores FME token and other configuration securely.
"""

from qgis.PyQt.QtCore import QSettings


class PluginSettings:
    """Manage plugin settings using QSettings."""
    
    PLUGIN_NAME = "ToponymsManager"
    
    # Setting keys
    FME_TOKEN = "fme_token"
    FME_REPOSITORY = "fme_repository"
    FME_WORKSPACE = "fme_workspace"
    
    @classmethod
    def get_fme_token(cls):
        """Get stored FME token."""
        settings = QSettings()
        return settings.value(f"{cls.PLUGIN_NAME}/{cls.FME_TOKEN}", "")
    
    @classmethod
    def set_fme_token(cls, token):
        """Store FME token."""
        settings = QSettings()
        settings.setValue(f"{cls.PLUGIN_NAME}/{cls.FME_TOKEN}", token)
    
    @classmethod
    def get_fme_repository(cls):
        """Get stored FME repository."""
        settings = QSettings()
        return settings.value(f"{cls.PLUGIN_NAME}/{cls.FME_REPOSITORY}", "Toponymie")
    
    @classmethod
    def set_fme_repository(cls, repository):
        """Store FME repository."""
        settings = QSettings()
        settings.setValue(f"{cls.PLUGIN_NAME}/{cls.FME_REPOSITORY}", repository)
    
    @classmethod
    def get_fme_workspace(cls):
        """Get stored FME workspace."""
        settings = QSettings()
        return settings.value(f"{cls.PLUGIN_NAME}/{cls.FME_WORKSPACE}", "toponymy_plugin_test.fmw")
    
    @classmethod
    def set_fme_workspace(cls, workspace):
        """Store FME workspace."""
        settings = QSettings()
        settings.setValue(f"{cls.PLUGIN_NAME}/{cls.FME_WORKSPACE}", workspace)
    
    @classmethod
    def clear_all(cls):
        """Clear all plugin settings."""
        settings = QSettings()
        settings.remove(cls.PLUGIN_NAME)
