# batch_load_qgis_plugin

## Selecting an environment

Use **Select Environment** above **Login with NRCan id** to choose
**Development (DEV)**. **Testing (TST)** and **Production (PROD)** remain
visible in the menu but are disabled until their APIs are ready; hovering over
either entry displays a tooltip explaining that the environment is not ready yet.
Initially no environment is selected and the button displays **Select Environment**.
After selection it displays **Environment: DEV**. Select it before logging in
with NRCan, then log in with geoname-t.

The **Login** button shows the same busy bar at the bottom of the dock as the
batch-load actions, with a label for the current authentication service. The bar
closes when login finishes, fails, or the geoname-t dialog is cancelled.

When additional environments are enabled, switching clears the previous
configuration and both logins. If NRCan was logged in, the plugin automatically
authenticates against the new environment and reloads its URLs and FME token;
otherwise, log in with NRCan to load them. Log in with geoname-t again after
switching. If reloading fails, the old configuration is not restored.

NRCan login currently creates a GeoSys client for `dev` and calls
`client.system.search_resources` with `chercher_geosys=False`, the file
`GNBC:data/GNBC/ressources/ressources_toponymy.json`, and the search path
`/ressources/<environment>`. Each returned resource must contain a `value`.
When the response contains `/ressources/<environment>`, its `value` is read as
the settings object (for example,
`{"/ressources/dev": {"source": "...", "value": {"env_geosys": "dev", ...}}}`).
Separate settings returned as `{"value": ...}` entries, keyed by setting name
or full resource path, are also supported.
The required resource names are:

* `env_geosys`: must match the selected environment.
* `url_geoname-t`: complete geoname-t API base URL ending in
  `/services/geoname-t/en`, not the `/ui/` URL.
* `fme_flow_url`: complete FME jobs endpoint ending in `/fmeapiv4/jobs`,
  not the `/fmeserver/` URL.
* `fme_flow_token`: FME Flow token; loaded automatically without a token prompt.
* `cgndb_connection`: FME CGNDB connection name, loaded automatically and passed
  as the `cgndb_connection` workspace parameter instead of a dropdown choice.

URLs must use HTTPS. Missing or invalid resources prevent login rather than
falling back to another environment. Resource values and the token are kept in
memory only and are not printed in the plugin's configuration/submission logs.
For troubleshooting, the QGIS log includes **Environment resource response
structure** with JSON property names and nesting preserved but all leaf values
replaced by `<redacted>`, including tokens and source metadata.

## Batch-load coordinate fields

The `latitude` and `longitude` fields are read-only in both **Open Batch Load
Table** and **Related Batch Load Features** for XLSX, CSV, GDB, and GPKG sources,
including when related-feature editing is enabled. The `latitude_geosys` and
`longitude_geosys` fields retain their existing editing behavior. Automatic
coordinate updates from geometry synchronization are unaffected.
When Geosys points are loaded, only the first row with a point for each
non-empty `toponymic_feature_id` retains the four Geosys fields
(`latitude_geosys`, `longitude_geosys`, `source_pt_geosys`, and `add_pt_geosys`);
later rows with that ID have those fields cleared. For GDB/GPKG, this is applied
separately to `names_6` and `points_0`. Rows without a `toponymic_feature_id`
are not grouped.
For GDB/GPKG sources, **Load GeoSys points (1347)** displays both tables' points
in one orange **Geosys Points (data)** layer. **Edit points**, **Save edits**, and
**Discard edits** control this layer together. The underlying tables remain
separate; saved moves are routed back using `source_layer` and each table's
record identifier. Discarding moves leaves the stored coordinates unchanged.
In the batch table and **Related Batch Load Features**, the four
Geosys fields are read-only on rows with no Geosys coordinates when another row
with the same feature ID has a point. Other fields on those rows remain editable.
Hover over the latitude/longitude column headers or cells, or either the field
name or its value in **Related Batch Load Features**, to see "This field is not
editable." This applies to all four source formats.
Selecting XLSX/CSV rows opens **Related Batch Load Features** directly from the
current table values, even before loading a coordinate layer or when coordinates
are blank or invalid. Related-feature edits are reflected in the table; use its
Save button to write the CSV. Map highlighting remains available when a
coordinate layer is loaded.
After a successful **Import Batch Load file**, the plugin also creates the
coordinate layer automatically and offers to zoom to it.
Import continues if coordinates are invalid, but a warning lists each affected
row and explains whether a coordinate is missing, non-numeric, non-finite,
outside its valid range, or outside the plugin's approximate Canada bounding box
(latitude 41.7 to 83.1, longitude -141.0 to -52.6). This is not an exact national
boundary check. Rows with both coordinates blank are allowed. Invalid pairs are
omitted from the automatically created coordinate layer. Correct the original
source file and re-import it; latitude and longitude cannot be edited in the plugin.
For Excel and CSV imports, warning row numbers match the source, including blank
rows. For processed GDB/GPKG tables, warnings include the source layer and record
identifier when available.
In **Validate Batch Load File**, both latitude/longitude checks list problems in
ascending numeric row order, combining problems on the same row. The first ten
affected rows are shown, followed by a count of any remaining rows.

## Related-feature code-list editing

In **Related Batch Load Features**, code-list fields accept a code, a term, or
the displayed `code - term` label. Matching ignores case and surrounding spaces:
for example, `official` matches `Official`. Accepted edits are converted to the
code, so saving writes only the code to the batch file, even when the previous
cell value was a term.
Existing terms are also displayed as their matching `code - term` label rather
than flagged as unknown codes. Opening their editor selects that listed code;
committing the edit stores the code even if no new text is typed.

For `name_language_cl` and `origin_language_cl`, the text before the first `-`
is also accepted, with surrounding spaces removed. For example, `und` or
`und -` matches a term beginning with `und -`. Other code-list fields require
the full term. Unrecognized new values are not applied; an existing unknown
code can still be retained.

## Decision PDFs

When **Process Batch Load File** runs, every unique non-empty `decision_pdf`
value in the main table (`names_6` for geodatabase/GeoPackage input) must name a
PDF in the same folder as the batch-load source; otherwise processing stops
before anything is uploaded. The plugin generates a new `decision_id` UUID per
PDF and writes it to a `decision_id` column on every row referencing that PDF.

Before `gnbc_batch_load.fmw`, each PDF is uploaded and processed once through
`gnbc_batch_load_addfolder.fmw`, `gnbc_batch_load_decision.fmw` and
`gnbc_batch_load_deletefolder.fmw`. The decision workspace receives
`input_pdf_file`, `decision_id`, `decision_date` (from the PDF's rows; you are
asked to choose when they differ) and the dialog's `cgndb_connection`,
`operator`, `decision_desription`, `authority` and `sql_on_conflict` values.
A failed decision workspace stops all remaining processing.

## Importing batch-load errors

After all processing workspaces finish, any error file is downloaded beside the
original batch-load source. A prompt offers to clear the current batch load and
import that error file directly, using the normal template-import workflow
(including its working-copy and geodatabase processing behavior).
Choosing **No** keeps the current batch and leaves the downloaded file available
for later. Choosing **Yes** uses the same unsaved-edit prompts and layer cleanup
as **Clear**; cancelling cleanup leaves the current batch unchanged and does not
import the error file. No import prompt appears when there is no error file or
when processing or downloading fails.

## Temporary S3 files

At the end of **Process Batch Load File**, whether processing succeeds or fails,
the plugin uses GeoSys `amazon.delete_file` to delete the uploaded main CSV/GPKG,
each uploaded decision PDF, and the run's error output. Upload attempts are
tracked so cleanup also runs after a partial upload failure. After deleting the
files, the plugin explicitly removes each main-file/PDF upload folder using
`amazon.delete_container` with its `contenant_url`. Folder paths are deduplicated;
the shared `GNBC:data/GNBC` folder is never deleted. If deletion of any file in an
upload folder fails, that folder is kept rather than attempting container deletion.
Upload folders are dedicated temporary locations; do not store unrelated files
inside them.

Cleanup happens after the error-file download/import handling and does not delete
local source files or downloaded error files. Missing S3 files/folders are harmless;
other deletion failures are logged and shown as a cleanup warning, without
replacing the original processing error or preventing cleanup of the other files.

## Customizing validation labels

Edit [validation_labels.yaml](validation_labels.yaml) to change the nine main
labels in the batch-load validation dialog. Each key is an internal validation
name; the value is its displayed text. Keep the keys unchanged and edit only the
text after `>-`, for example:

```yaml
required_fields: >-
  Required fields must not be empty.
```

Save the file as UTF-8 and run validation again to see your changes; no plugin
reload is needed. This changes labels only, not validation rules, result details,
or the additional geometry checks for geospatial sources. Missing names, unknown
names, empty labels, and invalid YAML are reported as validation errors rather
than silently skipping checks.

The YAML reader requires `PyYAML>=6.0` in the QGIS Python environment (see
[requirements.txt](requirements.txt)).

## Getting started

To make it easy for you to get started with GitLab, here's a list of recommended next steps.

Already a pro? Just edit this README.md and make it your own. Want to make it easy? [Use the template at the bottom](#editing-this-readme)!

## Add your files

* [Create](https://docs.gitlab.com/user/project/repository/web_editor/#create-a-file) or [upload](https://docs.gitlab.com/user/project/repository/web_editor/#upload-a-file) files
* [Add files using the command line](https://docs.gitlab.com/topics/git/add_files/#add-files-to-a-git-repository) or push an existing Git repository with the following command:

```
cd existing_repo
git remote add origin https://git.geoproc.geogc.ca/cgdi/toponymie/infra-migration-prod/batch_load_qgis_plugin.git
git branch -M main
git push -uf origin main
```

## Integrate with your tools

* [Set up project integrations](https://git.geoproc.geogc.ca/cgdi/toponymie/infra-migration-prod/batch_load_qgis_plugin/-/settings/integrations)

## Collaborate with your team

* [Invite team members and collaborators](https://docs.gitlab.com/user/project/members/)
* [Create a new merge request](https://docs.gitlab.com/user/project/merge_requests/creating_merge_requests/)
* [Automatically close issues from merge requests](https://docs.gitlab.com/user/project/issues/managing_issues/#closing-issues-automatically)
* [Enable merge request approvals](https://docs.gitlab.com/user/project/merge_requests/approvals/)
* [Set auto-merge](https://docs.gitlab.com/user/project/merge_requests/auto_merge/)

## Test and Deploy

Use the built-in continuous integration in GitLab.

* [Get started with GitLab CI/CD](https://docs.gitlab.com/ci/quick_start/)
* [Analyze your code for known vulnerabilities with Static Application Security Testing (SAST)](https://docs.gitlab.com/user/application_security/sast/)
* [Deploy to Kubernetes, Amazon EC2, or Amazon ECS using Auto Deploy](https://docs.gitlab.com/topics/autodevops/requirements/)
* [Use pull-based deployments for improved Kubernetes management](https://docs.gitlab.com/user/clusters/agent/)
* [Set up protected environments](https://docs.gitlab.com/ci/environments/protected_environments/)

***

# Editing this README

When you're ready to make this README your own, just edit this file and use the handy template below (or feel free to structure it however you want - this is just a starting point!). Thanks to [makeareadme.com](https://www.makeareadme.com/) for this template.

## Suggestions for a good README

Every project is different, so consider which of these sections apply to yours. The sections used in the template are suggestions for most open source projects. Also keep in mind that while a README can be too long and detailed, too long is better than too short. If you think your README is too long, consider utilizing another form of documentation rather than cutting out information.

## Name
Choose a self-explaining name for your project.

## Description
Let people know what your project can do specifically. Provide context and add a link to any reference visitors might be unfamiliar with. A list of Features or a Background subsection can also be added here. If there are alternatives to your project, this is a good place to list differentiating factors.

## Badges
On some READMEs, you may see small images that convey metadata, such as whether or not all the tests are passing for the project. You can use Shields to add some to your README. Many services also have instructions for adding a badge.

## Visuals
Depending on what you are making, it can be a good idea to include screenshots or even a video (you'll frequently see GIFs rather than actual videos). Tools like ttygif can help, but check out Asciinema for a more sophisticated method.

## Installation
Within a particular ecosystem, there may be a common way of installing things, such as using Yarn, NuGet, or Homebrew. However, consider the possibility that whoever is reading your README is a novice and would like more guidance. Listing specific steps helps remove ambiguity and gets people to using your project as quickly as possible. If it only runs in a specific context like a particular programming language version or operating system or has dependencies that have to be installed manually, also add a Requirements subsection.

## Usage
Use examples liberally, and show the expected output if you can. It's helpful to have inline the smallest example of usage that you can demonstrate, while providing links to more sophisticated examples if they are too long to reasonably include in the README.

## Support
Tell people where they can go to for help. It can be any combination of an issue tracker, a chat room, an email address, etc.

## Roadmap
If you have ideas for releases in the future, it is a good idea to list them in the README.

## Contributing
State if you are open to contributions and what your requirements are for accepting them.

For people who want to make changes to your project, it's helpful to have some documentation on how to get started. Perhaps there is a script that they should run or some environment variables that they need to set. Make these steps explicit. These instructions could also be useful to your future self.

You can also document commands to lint the code or run tests. These steps help to ensure high code quality and reduce the likelihood that the changes inadvertently break something. Having instructions for running tests is especially helpful if it requires external setup, such as starting a Selenium server for testing in a browser.

## Authors and acknowledgment
Show your appreciation to those who have contributed to the project.

## License
For open source projects, say how it is licensed.

## Project status
If you have run out of energy or time for your project, put a note at the top of the README saying that development has slowed down or stopped completely. Someone may choose to fork your project or volunteer to step in as a maintainer or owner, allowing your project to keep going. You can also make an explicit request for maintainers.
