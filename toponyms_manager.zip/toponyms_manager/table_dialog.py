# -*- coding: utf-8 -*-
"""
Reusable table dialog widget for displaying and editing tabular data.
Works with any structured data source (Excel, CSV, PostgreSQL, etc.).
"""

import os
from datetime import datetime

from qgis.PyQt import QtWidgets, QtGui
from qgis.PyQt.QtCore import Qt, pyqtSignal, QEvent
from qgis.core import QgsMessageLog, Qgis

from .data_loaders import DataLoader, DataLoadError
from .utils import generate_dated_filename


class ComboBoxDelegate(QtWidgets.QStyledItemDelegate):
    """
    Item delegate that provides a combobox for editing table cells.
    """
    def __init__(self, items, parent=None):
        """
        Initialize the delegate with a list of items for the combobox.
        
        :param items: List of strings to display in the combobox
        :param parent: Parent widget
        """
        super(ComboBoxDelegate, self).__init__(parent)
        self.items = items
    
    def createEditor(self, parent, option, index):
        """Create a combobox editor"""
        editor = QtWidgets.QComboBox(parent)
        editor.addItems(self.items)
        return editor
    
    def setEditorData(self, editor, index):
        """Set the current combobox value from the model"""
        value = index.model().data(index, Qt.EditRole)
        # Handle None/null values
        if value is None or value == '' or str(value).lower() == 'none':
            value = 'null'
        idx = editor.findText(str(value))
        if idx >= 0:
            editor.setCurrentIndex(idx)
        else:
            editor.setCurrentIndex(0)
    
    def setModelData(self, editor, model, index):
        """Save the combobox value to the model"""
        value = editor.currentText()
        # Convert 'null' text back to None for storage
        if value == 'null':
            value = None
        model.setData(index, value, Qt.EditRole)
    
    def updateEditorGeometry(self, editor, option, index):
        """Update the editor geometry to match the cell"""
        editor.setGeometry(option.rect)


class RelatedValueDelegate(QtWidgets.QStyledItemDelegate):
    """Paint/edit related-feature values with a QGIS-form-like white value box."""

    BORDER_COLOR = QtGui.QColor(184, 184, 184)
    VOCAB_ROLE = Qt.UserRole + 1
    INVALID_LABEL = "Not found in current code list"

    def _vocab_code(self, index, value):
        """Resolve codes, terms and language prefixes to the listed code."""
        text = value.strip().casefold()
        if not text:
            return ''
        field_name = str(index.sibling(index.row(), 0).data() or '').strip().casefold()
        is_language = field_name in ('name_language_cl', 'origin_language_cl')
        prefix = text.split('-', 1)[0].strip()
        vocab = index.data(self.VOCAB_ROLE) or []
        for code, term, _description in vocab:
            if (text == code.strip().casefold() or
                    text == f"{code} - {term}".strip().casefold() or
                    (is_language and prefix == code.strip().casefold())):
                return code
        for code, term, _description in vocab:
            term_text = term.strip().casefold()
            if term_text and (text == term_text or
                              (is_language and prefix and
                               prefix == term_text.split('-', 1)[0].strip())):
                return code
        return None

    def _display_text(self, index):
        text = index.data(Qt.DisplayRole) or ''
        vocab = index.data(self.VOCAB_ROLE)
        if vocab is None or not text:
            return text
        resolved_code = self._vocab_code(index, text)
        for code, term, _description in vocab:
            if code == resolved_code:
                return f"{code} - {term}"
        return f"\u26a0 {text} - {self.INVALID_LABEL}"

    def sizeHint(self, option, index):
        size = super(RelatedValueDelegate, self).sizeHint(option, index)
        size.setHeight(size.height() + 3)
        return size

    def paint(self, painter, option, index):
        if index.column() != 1 or not index.data(Qt.UserRole):
            super(RelatedValueDelegate, self).paint(painter, option, index)
            return

        option = QtWidgets.QStyleOptionViewItem(option)
        self.initStyleOption(option, index)
        selected = bool(option.state & QtWidgets.QStyle.State_Selected)

        painter.save()
        bg_color = QtGui.QColor(201, 216, 240) if selected else QtGui.QColor(255, 255, 255)
        painter.fillRect(option.rect, bg_color)
        painter.setPen(QtGui.QPen(self.BORDER_COLOR))
        painter.drawRect(option.rect.adjusted(0, 0, -1, -1))

        text_color = index.data(Qt.ForegroundRole)
        painter.setPen(text_color.color() if text_color else QtGui.QColor(0, 0, 0))
        text_rect = option.rect.adjusted(4, 0, -4, 0)
        painter.drawText(text_rect, Qt.AlignVCenter | Qt.AlignLeft, self._display_text(index))
        painter.restore()

    def createEditor(self, parent, option, index):
        vocab = index.data(self.VOCAB_ROLE) if index.column() == 1 else None
        if vocab is not None:
            return self._create_vocab_editor(parent, index, vocab)
        editor = super(RelatedValueDelegate, self).createEditor(parent, option, index)
        if index.column() == 1 and editor:
            editor.setAutoFillBackground(True)
            editor.setStyleSheet("background-color: #ffffff; color: #000000; border: 1px solid #b8b8b8;")
            palette = editor.palette()
            palette.setColor(QtGui.QPalette.Base, QtGui.QColor(255, 255, 255))
            editor.setPalette(palette)
        return editor

    def _create_vocab_editor(self, parent, index, vocab):
        """Searchable combobox listing '<code> - <term>'; only codes can be stored."""
        current = (index.data(Qt.EditRole) or '').strip()
        editor = QtWidgets.QComboBox(parent)
        editor.setEditable(True)
        editor.setInsertPolicy(QtWidgets.QComboBox.NoInsert)
        editor.addItem('', None)
        for code, term, description in vocab:
            editor.addItem(f"{code} - {term}", code)
            if description:
                editor.setItemData(editor.count() - 1, description, Qt.ToolTipRole)
        if current and self._vocab_code(index, current) is None:
            editor.addItem(f"\u26a0 {current} - {self.INVALID_LABEL}", current)
        completer = editor.completer()
        completer.setFilterMode(Qt.MatchContains)
        completer.setCaseSensitivity(Qt.CaseInsensitive)
        completer.setCompletionMode(QtWidgets.QCompleter.PopupCompletion)
        return editor

    def setEditorData(self, editor, index):
        if not isinstance(editor, QtWidgets.QComboBox):
            super(RelatedValueDelegate, self).setEditorData(editor, index)
            return
        current = (index.data(Qt.EditRole) or '').strip()
        resolved_code = self._vocab_code(index, current)
        position = editor.findData(current if resolved_code is None else resolved_code) if current else 0
        editor.setCurrentIndex(max(position, 0))

    def setModelData(self, editor, model, index):
        if not isinstance(editor, QtWidgets.QComboBox):
            super(RelatedValueDelegate, self).setModelData(editor, model, index)
            return
        value = editor.currentText()
        resolved_code = self._vocab_code(index, value)
        if resolved_code is not None:
            model.setData(index, resolved_code, Qt.EditRole)
            return
        text = value.strip().casefold()
        field_name = str(index.sibling(index.row(), 0).data() or '').strip().casefold()
        is_language = field_name in ('name_language_cl', 'origin_language_cl')
        language_prefix = text.split('-', 1)[0].strip() if is_language else text
        for position in range(editor.count()):
            code = editor.itemData(position)
            code_text = '' if code is None else str(code).casefold()
            if (text == code_text or
                    text == editor.itemText(position).strip().casefold() or
                    (is_language and code is not None and language_prefix == code_text)):
                model.setData(index, '' if code is None else code, Qt.EditRole)
                return


class DataTableDialog(QtWidgets.QDialog):
    """
    Reusable dialog for displaying and editing tabular data from any source.
    Provides save functionality and data export options.
    """
    
    # Label-only copies of names_6 values on geometry layers; edited through names_6 only.
    LABEL_FIELDS = ('existing_cgndb_id', 'new_cgndb_id', 'existing_name', 'new_name')
    GEOMETRY_LAYERS = ('points_0', 'lines_1', 'polygons_2')
    READ_ONLY_COORDINATE_FIELDS = ('latitude', 'longitude')
    GEOSYS_FIELDS = (
        'latitude_geosys', 'longitude_geosys', 'source_pt_geosys', 'add_pt_geosys'
    )
    DUPLICATE_GEOSYS_ROLE = Qt.UserRole + 2

    # Controlled-vocabulary fields (lowercase) -> code list endpoint.
    CODE_LIST_BASE_URL = "https://geoname-dev.services.geogc.ca/services/geoname-t/en/codes"
    CODE_LIST_ENDPOINTS = {
        'generic_code': 'generic.json',
        'status_for_existing_name': 'toponym-status.json',
        'status_code_cl': 'toponym-status.json',
        'region_cl': 'region.json',
        'name_language_cl': 'name-language.json',
        'origin_language_cl': 'origin-language.json',
        'md_delineation_code': 'delineation-source.json',
    }

    # Signal emitted when file is saved: (file_path, sheet_name)
    file_saved = pyqtSignal(str, str)
    
    # Signal emitted when dialog is minimized
    minimized = pyqtSignal()
    
    def __init__(self, data_dict, parent=None, layer=None):
        """
        Initialize table dialog with data.
        
        :param data_dict: Dictionary with data structure from DataLoader
        :param parent: Parent widget
        :param layer: Optional QGIS layer to link with table rows for selection
        """
        super(DataTableDialog, self).__init__(parent)
        
        self.parent_widget = parent
        self.data_dict = data_dict
        self.original_source = data_dict.get('source', 'Unknown')
        self.data_type = data_dict.get('type', 'unknown')
        self.linked_layer = layer  # Store reference to QGIS layer
        self.is_modified = False
        
        self._setup_ui()
        self.table.setSortingEnabled(False)
        self._populate_table()
        self.table.setSortingEnabled(True)
        self.mark_table_saved()
        
        if self.linked_layer or self.data_type in ('excel', 'csv', 'combined_gdb_view', 'error_table'):
            self.table.itemSelectionChanged.connect(self._on_selection_changed)
        
        # Track edits made after the initial population
        self.table.itemChanged.connect(self._on_item_changed)
    
    def _on_item_changed(self, item):
        """Mark the table as having unsaved edits."""
        self.is_modified = True
        if self.discard_button is not None:
            self.discard_button.setEnabled(True)
        headers = self.data_dict.get('headers', [])
        if item.column() < len(headers):
            field_name = str(headers[item.column()]).strip().casefold()
            if field_name in (
                    'toponymic_feature_id', 'latitude_geosys', 'longitude_geosys'):
                self._update_duplicate_geosys_editability()
                self._refresh_related_duplicate_geosys_fields()

    def _update_duplicate_geosys_editability(self):
        """Keep duplicate Geosys fields read-only as table values are edited."""
        headers = self.data_dict.get('headers', [])
        geosys_tfids_with_points = self._geosys_tfids_with_points(
            headers,
            [
                [
                    self.table.item(row, column).text()
                    if self.table.item(row, column) is not None else ''
                    for column in range(self.table.columnCount())
                ]
                for row in range(self.table.rowCount())
            ],
        )
        geosys_cols = {
            index for index, header in enumerate(headers)
            if str(header).strip().casefold() in self.GEOSYS_FIELDS
        }
        signals_blocked = self.table.blockSignals(True)
        try:
            for row_idx in range(self.table.rowCount()):
                row_values = [
                    self.table.item(row_idx, column).text()
                    if self.table.item(row_idx, column) is not None else ''
                    for column in range(self.table.columnCount())
                ]
                duplicate = self._is_duplicate_geosys_row(
                    headers, row_values, geosys_tfids_with_points
                )
                for column in geosys_cols:
                    item = self.table.item(row_idx, column)
                    if item is None:
                        continue
                    if duplicate:
                        item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                        item.setToolTip("This duplicate Geosys point is not editable.")
                        item.setData(self.DUPLICATE_GEOSYS_ROLE, True)
                    elif item.data(self.DUPLICATE_GEOSYS_ROLE):
                        if self.data_dict.get('read_only'):
                            item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                        else:
                            item.setFlags(item.flags() | Qt.ItemIsEditable)
                        item.setToolTip("")
                        item.setData(self.DUPLICATE_GEOSYS_ROLE, None)
        finally:
            self.table.blockSignals(signals_blocked)

    def mark_table_saved(self):
        """Remember the last successfully saved batch table for discarding edits."""
        if self.discard_button is not None:
            self._saved_table_data = self._get_table_data()
            self.discard_button.setEnabled(False)
        self.is_modified = False

    def _on_discard_changes(self):
        """Restore unsaved Excel/CSV table edits without changing files on disk."""
        if self.discard_button is None or not self.is_modified:
            return

        answer = QtWidgets.QMessageBox.question(
            self,
            "Discard Changes",
            "Discard unsaved table changes and restore the last saved values?\n\n"
            "This does not undo edits to map layers or related features.",
            QtWidgets.QMessageBox.Discard | QtWidgets.QMessageBox.Cancel,
            QtWidgets.QMessageBox.Cancel
        )
        if answer != QtWidgets.QMessageBox.Discard:
            return

        sorting_enabled = self.table.isSortingEnabled()
        signals_blocked = self.table.blockSignals(True)
        try:
            self.table.setSortingEnabled(False)
            self.data_dict['data'] = [row[:] for row in self._saved_table_data]
            self._populate_table()
        finally:
            self.table.setSortingEnabled(sorting_enabled)
            self.table.blockSignals(signals_blocked)

        self.is_modified = False
        self.discard_button.setEnabled(False)
        self._filter_table(self.search_input.text())
        self._update_status("Unsaved table changes discarded")

    def _setup_ui(self):
        """Setup the user interface"""
        # Set window properties
        title = f"Data Viewer - {os.path.basename(self.original_source)}"
        if self.data_dict.get('sheet_name'):
            title += f" [{self.data_dict['sheet_name']}]"
        
        self.setWindowTitle(title)
        self.resize(1200, 700)
        
        # Keep table windows available through minimize/restore controls.
        self.setWindowFlags(
            Qt.Window | 
            Qt.WindowCloseButtonHint |
            Qt.WindowMinimizeButtonHint | 
            Qt.WindowMaximizeButtonHint
        )
        
        # Create main layout
        layout = QtWidgets.QVBoxLayout()
        
        # Info panel
        info_text = self._build_info_text()
        self.info_label = QtWidgets.QLabel(info_text)
        self.info_label.setWordWrap(True)
        layout.addWidget(self.info_label)
        
        # Search/filter bar
        search_layout = QtWidgets.QHBoxLayout()
        search_label = QtWidgets.QLabel("Search:")
        self.search_input = QtWidgets.QLineEdit()
        self.search_input.setPlaceholderText("Type to filter rows...")
        self.search_input.textChanged.connect(self._filter_table)
        search_layout.addWidget(search_label)
        search_layout.addWidget(self.search_input)
        layout.addLayout(search_layout)
        
        # Create table widget
        self.table = QtWidgets.QTableWidget()
        self.table.setAlternatingRowColors(True)
        self.table.setSortingEnabled(True)
        
        # If layer is linked, set selection to entire rows for better visibility
        if self.linked_layer or self.data_type in ('excel', 'csv', 'combined_gdb_view'):
            self.table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
            self.table.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)  # Allow multiple selection
        
        layout.addWidget(self.table)
        
        # Button box
        button_box = QtWidgets.QDialogButtonBox()
        
        self.save_button = button_box.addButton("Save", QtWidgets.QDialogButtonBox.AcceptRole)
        self.discard_button = None
        if self.data_type in ('excel', 'csv') and not self.data_dict.get('read_only'):
            self.discard_button = button_box.addButton(
                "Discard Changes", QtWidgets.QDialogButtonBox.AcceptRole
            )
            self.discard_button.setToolTip(
                "Restore the last saved table values without changing map layers or related features."
            )
            self.discard_button.setEnabled(False)
            self.discard_button.clicked.connect(self._on_discard_changes)
        self.save_as_button = button_box.addButton("Save As...", QtWidgets.QDialogButtonBox.ActionRole)
        if self.data_dict.get('read_only'):
            self.save_button.setEnabled(False)
            self.save_as_button.setEnabled(False)
        
        # Add clear selection button if layer highlighting is available
        if self.linked_layer or self.data_type in ('excel', 'csv', 'combined_gdb_view', 'error_table'):
            self.clear_selection_button = button_box.addButton("Clear Selection", QtWidgets.QDialogButtonBox.ActionRole)
            self.clear_selection_button.clicked.connect(self._on_clear_selection)
        
        self.save_button.clicked.connect(self._on_save)
        self.save_as_button.clicked.connect(self._on_save_as)
        
        layout.addWidget(button_box)
        
        # Status bar
        self.status_label = QtWidgets.QLabel("")
        layout.addWidget(self.status_label)
        
        self.setLayout(layout)
    
    def _build_info_text(self):
        """Build information text for the info panel"""
        # Calculate actual data rows (excluding header)
        total_rows = self.data_dict.get('row_count', 0)
        data_rows = total_rows - 1 if total_rows > 0 else 0
        
        info_parts = [
            f"<b>Source:</b> {os.path.basename(self.original_source)}",
            f"<b>Type:</b> {self.data_type.upper()}",
            f"<b>Data Rows:</b> {data_rows}",
            f"<b>Columns:</b> {self.data_dict.get('column_count', 0)}"
        ]
        
        if self.data_dict.get('sheet_name'):
            info_parts.insert(2, f"<b>Sheet:</b> {self.data_dict['sheet_name']}")
        
        # Add appropriate edit instruction based on whether layer is linked
        if self.linked_layer:
            info_parts.append("<i>Click any cell to edit. <b>Select rows to highlight points (Ctrl+Click for multiple, Shift+Click for range)</b></i>")
        elif self.data_dict.get('type') == 'combined_gdb_view':
            info_parts.append("<i>Select rows to highlight related points, lines, and polygons.</i>")
        else:
            info_parts.append("<i>Click any cell to edit. Use the search box to filter rows.</i>")
        
        return " | ".join(info_parts)
    
    def _populate_table(self):
        """Populate table with data from data_dict"""
        data = self.data_dict.get('data', [])
        if not data:
            return
        
        # Get headers (first row)
        headers = self.data_dict.get('headers', [])
        
        # Get data rows (skip first row since it's the header)
        data_rows = data[1:] if len(data) > 1 else []
        
        # Set dimensions
        self.table.setRowCount(len(data_rows))
        self.table.setColumnCount(self.data_dict.get('column_count', len(headers) if headers else 0))
        
        # Set column headers
        if headers:
            self.table.setHorizontalHeaderLabels([str(h) if h else f"Column {i+1}" 
                                                   for i, h in enumerate(headers)])
        
        # Find the add_pt_geosys column index
        add_pt_geosys_col = None
        if headers:
            headers_lower = [str(h).lower() if h else '' for h in headers]
            if 'add_pt_geosys' in headers_lower:
                add_pt_geosys_col = headers_lower.index('add_pt_geosys')
        
        # Apply ComboBox delegate to add_pt_geosys column
        if add_pt_geosys_col is not None:
            delegate = ComboBoxDelegate(['yes', 'no', 'null'], self.table)
            self.table.setItemDelegateForColumn(add_pt_geosys_col, delegate)
        
        row_id_col = self._row_id_column()
        coordinate_cols = {
            index for index, header in enumerate(headers)
            if str(header).strip().casefold() in self.READ_ONLY_COORDINATE_FIELDS
        }
        geosys_cols = {
            index for index, header in enumerate(headers)
            if str(header).strip().casefold() in self.GEOSYS_FIELDS
        }
        geosys_tfids_with_points = self._geosys_tfids_with_points(headers, data_rows)
        for column in coordinate_cols:
            self.table.horizontalHeaderItem(column).setToolTip("This field is not editable.")

        # Populate cells with data rows only
        for row_idx, row_data in enumerate(data_rows):
            for col_idx, value in enumerate(row_data):
                # Handle None values for display
                display_value = str(value) if value is not None else ""
                # For add_pt_geosys column, show "null" instead of empty for None values
                if col_idx == add_pt_geosys_col and value is None:
                    display_value = ""  # Show empty, delegate will handle 'null' on edit
                item = QtWidgets.QTableWidgetItem(display_value)
                if (self.data_dict.get('read_only') or col_idx == row_id_col or
                        col_idx in coordinate_cols):
                    item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                if col_idx in coordinate_cols:
                    item.setToolTip("This field is not editable.")
                self.table.setItem(row_idx, col_idx, item)
            if self._is_duplicate_geosys_row(headers, row_data, geosys_tfids_with_points):
                for column in geosys_cols:
                    item = self.table.item(row_idx, column)
                    if item is not None:
                        item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                        item.setToolTip("This duplicate Geosys point is not editable.")
                        item.setData(self.DUPLICATE_GEOSYS_ROLE, True)
        
        # Auto-resize columns
        self.table.resizeColumnsToContents()
        
        self._update_status(f"Loaded {len(data_rows)} data rows")
    
    @staticmethod
    def normalize_row_id(value):
        """Compare row ids as text so Excel floats (1.0) match CSV strings ('1')."""
        try:
            return str(int(float(value)))
        except (TypeError, ValueError):
            return str(value).strip() if value is not None else ''

    def _row_id_column(self):
        headers = [str(h).strip().lower() if h is not None else '' for h in self.data_dict.get('headers', [])]
        return headers.index('xlsx_row_id') if 'xlsx_row_id' in headers else None

    def _row_id_at(self, table_row):
        col = self._row_id_column()
        item = self.table.item(table_row, col) if col is not None else None
        return self.normalize_row_id(item.text()) if item else None

    def update_cell(self, row_id, col, text):
        """Set a cell in the row whose xlsx_row_id matches row_id."""
        row_id = self.normalize_row_id(row_id)
        for row in range(self.table.rowCount()):
            if self._row_id_at(row) == row_id:
                item = self.table.item(row, col)
                if item is not None:
                    item.setText(text)
                    return True
        return False

    def _filter_table(self, search_text):
        """Filter table rows based on search text"""
        if not search_text:
            # Show all rows
            for row in range(self.table.rowCount()):
                self.table.setRowHidden(row, False)
            self._update_status(f"Showing all {self.table.rowCount()} rows")
            return
        
        # Hide rows that don't match search
        search_text = search_text.lower()
        visible_count = 0
        
        for row in range(self.table.rowCount()):
            match = False
            for col in range(self.table.columnCount()):
                item = self.table.item(row, col)
                if item and search_text in item.text().lower():
                    match = True
                    break
            
            self.table.setRowHidden(row, not match)
            if match:
                visible_count += 1
        
        self._update_status(f"Showing {visible_count} of {self.table.rowCount()} rows")
    
    def _get_table_data(self):
        """Extract current data from table as list of lists (includes headers as first row)"""
        # Get headers as first row
        headers = self.data_dict.get('headers', [])
        data = [headers] if headers else []
        
        # Find the add_pt_geosys column index
        add_pt_geosys_col = None
        if headers:
            headers_lower = [str(h).lower() if h else '' for h in headers]
            if 'add_pt_geosys' in headers_lower:
                add_pt_geosys_col = headers_lower.index('add_pt_geosys')
        
        # Get data rows from table
        for row_idx in range(self.table.rowCount()):
            row_data = []
            for col_idx in range(self.table.columnCount()):
                item = self.table.item(row_idx, col_idx)
                value = item.text() if item else ""
                
                # For add_pt_geosys column, convert empty string to None
                if col_idx == add_pt_geosys_col and (value == "" or value.lower() == "null"):
                    value = None
                
                row_data.append(value)
            data.append(row_data)
        return data
    
    def _on_minimize(self):
        """Handle minimize button click - hide dialog and emit signal"""
        self.minimized.emit()
        self.hide()
    
    def _on_clear_selection(self):
        """Clear table selection and remove map highlights"""
        try:
            from qgis.utils import iface
            
            # Clear table selection
            self.table.clearSelection()
            
            # Clear layer selection
            if self.linked_layer:
                self.linked_layer.removeSelection()
            elif self.data_dict.get('type') == 'combined_gdb_view':
                for layer in self._related_project_layers(('points_0', 'lines_1', 'polygons_2')).values():
                    layer.removeSelection()
            elif self.data_dict.get('type') == 'error_table':
                for layer in self._related_project_layers(('names_6', 'points_0', 'lines_1', 'polygons_2')).values():
                    layer.removeSelection()
                for layer in (getattr(self.parent_widget, 'error_source_layers', None) or {}).values():
                    layer.removeSelection()
                if getattr(self, '_related_features_dock', None):
                    self._clear_related_features_selection()
            
            # Remove rubber band highlight
            if hasattr(self, '_highlight_rubber_band') and self._highlight_rubber_band:
                self._highlight_rubber_band.reset()
                self._highlight_rubber_band = None
            
            # Refresh map canvas
            if iface:
                iface.mapCanvas().refresh()
            
            # Update status
            self._update_status("Selection cleared")
            
            QgsMessageLog.logMessage(
                "Map selection cleared",
                "ToponymsManager",
                Qgis.Info
            )
        except Exception as e:
            QgsMessageLog.logMessage(
                f"Error clearing selection: {str(e)}",
                "ToponymsManager",
                Qgis.Warning
            )
    
    def changeEvent(self, event):
        """Override changeEvent to intercept window minimize and hide instead"""
        if event.type() == QEvent.WindowStateChange:
            if self.windowState() & Qt.WindowMinimized:
                # Restore window state then hide instead of minimizing
                self.setWindowState(self.windowState() & ~Qt.WindowMinimized)
                self._on_minimize()
                return
        super(DataTableDialog, self).changeEvent(event)

    def close(self):
        """Close the table programmatically, preserving normal cleanup behavior."""
        self._allow_close = True
        try:
            return super(DataTableDialog, self).close()
        finally:
            self._allow_close = False
    
    def _on_save(self):
        """Save next to the imported batch load template file."""
        try:
            if self.data_dict.get('read_only'):
                QtWidgets.QMessageBox.information(
                    self,
                    "Read-Only View",
                    "This table is a read-only combined view and cannot be saved directly.\n"
                    "Edit the underlying points_0, lines_1, or polygons_2 layer instead."
                )
                return

            if self._is_gdb_source():
                self._on_save_gdb()
                return

            source_path = getattr(self.parent_widget, 'batch_load_source_path', None) or self.original_source
            dest_folder = os.path.dirname(source_path)
            
            dated_name = generate_dated_filename(self.original_source, date_format="%Y%m%d")
            new_filename = os.path.splitext(dated_name)[0] + '.csv'
            output_path = os.path.normpath(os.path.join(dest_folder, new_filename))
            
            self._save_to_csv(output_path)
            
            # Emit signal that file was saved
            sheet_name = self.data_dict.get('sheet_name', 'Sheet1')
            self.file_saved.emit(output_path, sheet_name)
            
            QtWidgets.QMessageBox.information(
                self,
                "Saved",
                f"Changes saved successfully to:\n{output_path}"
            )
            
            self._update_status(f"Saved to {os.path.basename(output_path)}")
            self.mark_table_saved()
            
        except Exception as e:
            QtWidgets.QMessageBox.critical(
                self,
                "Save Error",
                f"Failed to save changes:\n{str(e)}"
            )
            QgsMessageLog.logMessage(f"Save error: {str(e)}", "ToponymsManager", Qgis.Critical)

    def _on_save_gdb(self):
        """Save a copy of the whole GDB, updating the current table in that copy."""
        source_gdb = self._gdb_dataset_path()
        dest_folder = QtWidgets.QFileDialog.getExistingDirectory(
            self,
            "Select Destination Folder",
            os.path.dirname(source_gdb) if os.path.exists(source_gdb) else os.path.expanduser("~")
        )
        if not dest_folder:
            return

        output_path = self._dated_gdb_output_path(dest_folder, source_gdb)
        self._save_gdb_copy(output_path)

    def _is_gdb_source(self):
        """Return True when the table source is a GDB/GPKG layer URI."""
        return self._gdb_dataset_path().lower().endswith(('.gdb', '.fgdb', '.gpkg'))

    def _gdb_dataset_path(self):
        """Strip any '|layername=...' suffix from a QGIS GDB layer source URI."""
        return self.original_source.split('|', 1)[0]

    def _gdb_layer_name(self):
        # Combined sources look like 'path|layername=a + path|layername=b'; only consider the first one.
        first_source = self.original_source.split(' + ', 1)[0]
        for part in first_source.split('|')[1:]:
            if part.lower().startswith('layername='):
                return part.split('=', 1)[1]
        return self.data_dict.get('sheet_name') or (self.linked_layer.name() if self.linked_layer else 'names_6')

    @staticmethod
    def _dated_gdb_output_path(dest_folder, source_gdb):
        base_name = os.path.basename(source_gdb.rstrip('\\/'))
        name_without_ext, ext = os.path.splitext(base_name)
        if name_without_ext.endswith('.gdb_processed'):
            name_without_ext = name_without_ext[:-len('.gdb_processed')]
        elif name_without_ext.endswith('_processed'):
            name_without_ext = name_without_ext[:-len('_processed')]
        date_str = datetime.now().strftime("%Y-%m-%d")
        return os.path.normpath(os.path.join(dest_folder, f"{name_without_ext}_{date_str}{ext}"))

    def _save_gdb_copy(self, output_path):
        import shutil

        source_gdb = self._gdb_dataset_path()
        if os.path.exists(output_path):
            reply = QtWidgets.QMessageBox.question(
                self,
                "Overwrite GDB",
                f"The output geodatabase already exists:\n{output_path}\n\nOverwrite it?",
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                QtWidgets.QMessageBox.No
            )
            if reply != QtWidgets.QMessageBox.Yes:
                return
            if os.path.isdir(output_path):
                shutil.rmtree(output_path)
            else:
                os.remove(output_path)

        if os.path.isdir(source_gdb):
            shutil.copytree(source_gdb, output_path)
        else:
            shutil.copy2(source_gdb, output_path)

        layer_name = self._gdb_layer_name()
        fields = self.linked_layer.fields() if self.linked_layer else self._string_fields_from_headers()
        rows = self._get_table_data()[1:]
        self.parent_widget.file_import_handler._write_table(output_path, layer_name, fields, rows)

        self.file_saved.emit(output_path, layer_name)
        QtWidgets.QMessageBox.information(
            self,
            "Saved",
            f"Dataset saved successfully to:\n{output_path}"
        )
        self._update_status(f"Saved to {os.path.basename(output_path)}")
        self.is_modified = False

    def _string_fields_from_headers(self):
        from qgis.core import QgsField, QgsFields
        from qgis.PyQt.QtCore import QVariant

        fields = QgsFields()
        for header in self.data_dict.get('headers', []):
            if str(header).lower() == 'fid':
                continue  # 'fid' is GPKG's reserved integer primary key column, not a data field
            fields.append(QgsField(str(header), QVariant.String))
        return fields
    
    def _on_save_as(self):
        """Handle save as button click - full file dialog"""
        try:
            default_path = os.path.splitext(self.original_source)[0] + '.csv'
            output_path, _ = QtWidgets.QFileDialog.getSaveFileName(
                self, "Save File As CSV", default_path,
                "CSV Files (*.csv);;All Files (*.*)"
            )
            
            if not output_path:
                return  # User cancelled
            if not output_path.lower().endswith('.csv'):
                output_path += '.csv'
            
            self._save_to_csv(output_path)
            
            # Emit signal that file was saved
            sheet_name = self.data_dict.get('sheet_name', 'Sheet1')
            self.file_saved.emit(output_path, sheet_name)
            
            QtWidgets.QMessageBox.information(
                self,
                "Saved",
                f"File saved successfully to:\n{output_path}"
            )
            
            self._update_status(f"Saved to {os.path.basename(output_path)}")
            self.mark_table_saved()
            
        except Exception as e:
            QtWidgets.QMessageBox.critical(
                self,
                "Save Error",
                f"Failed to save file:\n{str(e)}"
            )
            QgsMessageLog.logMessage(f"Save error: {str(e)}", "ToponymsManager", Qgis.Critical)
    
    def _on_export_csv(self):
        """Handle export to CSV button click"""
        try:
            output_path, _ = QtWidgets.QFileDialog.getSaveFileName(
                self,
                "Export to CSV",
                os.path.splitext(self.original_source)[0] + ".csv",
                "CSV Files (*.csv);;All Files (*.*)"
            )
            
            if not output_path:
                return
            
            self._save_to_csv(output_path)
            
            QtWidgets.QMessageBox.information(
                self,
                "Exported",
                f"Data exported successfully to:\n{output_path}"
            )
            
            self._update_status(f"Exported to {os.path.basename(output_path)}")
            
        except Exception as e:
            QtWidgets.QMessageBox.critical(
                self,
                "Export Error",
                f"Failed to export CSV:\n{str(e)}"
            )
    
    def _save_to_csv(self, output_path):
        """Save table data to CSV file"""
        import csv
        
        data = self._get_table_data()
        
        with open(output_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerows(data)
        
        QgsMessageLog.logMessage(
            f"Exported CSV file: {output_path}",
            "ToponymsManager",
            Qgis.Success
        )
    
    def _update_status(self, message):
        """Update status label"""
        self.status_label.setText(f"<i>{message}</i>")
    
    def get_modified_data(self):
        """Get the current table data as a structured dictionary"""
        data = self._get_table_data()
        return {
            'type': self.data_type,
            'source': self.original_source,
            'data': data,
            'row_count': len(data),  # Includes header row
            'column_count': self.table.columnCount()
        }
    
    def _on_selection_changed(self):
        """
        Handle table row selection - highlight corresponding feature on the map.
        When a row is selected in the table, select the corresponding point in the QGIS layer.
        Uses flashing effect to make selection visible even for overlapping points.
        """
        if self.data_dict.get('type') == 'combined_gdb_view':
            self._on_related_selection_changed()
            return

        if self.data_dict.get('type') == 'error_table':
            self._on_error_selection_changed()
            return

        if self.data_type in ('excel', 'csv'):
            try:
                if not self._show_tabular_related_features():
                    return
            except (RuntimeError, ValueError, TypeError, KeyError) as error:
                QgsMessageLog.logMessage(
                    f"Could not open related batch table features: {error}",
                    "ToponymsManager", Qgis.Warning
                )
                QtWidgets.QMessageBox.warning(
                    self, "Related Batch Load Features",
                    f"Could not open the related batch table form:\n{error}"
                )
                return

        if not self.linked_layer:
            return
        
        try:
            from qgis.core import QgsFeatureRequest, QgsWkbTypes
            from qgis.gui import QgsRubberBand
            from qgis.utils import iface
            from qgis.PyQt.QtCore import QTimer
            from qgis.PyQt.QtGui import QColor
            
            # Get selected rows
            selected_rows = set()
            for item in self.table.selectedItems():
                selected_rows.add(item.row())
            
            if not selected_rows:
                # No selection - clear layer selection and remove rubber band
                self.linked_layer.removeSelection()
                dock = getattr(self, '_related_features_dock', None)
                if dock is not None:
                    dock.close()
                if hasattr(self, '_highlight_rubber_band') and self._highlight_rubber_band:
                    self._highlight_rubber_band.reset()
                    self._highlight_rubber_band = None
                return
            
            # Convert table row indices to feature IDs
            # Table row index corresponds to feature index in the layer
            # (assuming features were added in the same order as table rows)
            feature_ids = []
            features_list = list(self.linked_layer.getFeatures())
            selected_features = []
            row_id_field = self.linked_layer.fields().indexOf('xlsx_row_id')
            
            for row_idx in selected_rows:
                if row_id_field >= 0:
                    row_id = self._row_id_at(row_idx)
                    feature = next(
                        (candidate for candidate in features_list
                         if self.normalize_row_id(candidate[row_id_field]) == row_id),
                        None
                    )
                else:
                    feature = features_list[row_idx] if row_idx < len(features_list) else None
                if feature is not None:
                    feature_ids.append(feature.id())
                    selected_features.append(feature)

            # Select features in the layer
            self.linked_layer.selectByIds(feature_ids)
            
            # Flash the features to make them visible (even if overlapping)
            if iface and feature_ids:
                # Flash effect - makes the point blink
                iface.mapCanvas().flashFeatureIds(
                    self.linked_layer,
                    feature_ids,
                    startColor=QColor(255, 0, 0, 255),  # Red
                    endColor=QColor(255, 255, 0, 200),  # Yellow
                    flashes=3,
                    duration=500  # milliseconds
                )
                
                # Create a persistent rubber band highlight on top of everything
                # Remove old rubber band if it exists
                if hasattr(self, '_highlight_rubber_band') and self._highlight_rubber_band:
                    self._highlight_rubber_band.reset()
                
                # Create new rubber band for point highlighting
                self._highlight_rubber_band = QgsRubberBand(
                    iface.mapCanvas(),
                    QgsWkbTypes.PointGeometry
                )
                self._highlight_rubber_band.setColor(QColor(255, 0, 0, 180))  # Red with transparency
                self._highlight_rubber_band.setWidth(3)
                self._highlight_rubber_band.setIconSize(20)
                self._highlight_rubber_band.setZValue(-1)  # Render below points
                
                # Add the selected feature geometries to rubber band
                for feature in selected_features:
                    if feature.hasGeometry():
                        self._highlight_rubber_band.addGeometry(
                            feature.geometry(),
                            self.linked_layer
                        )
            
            # Zoom to show all selected features
            if iface and selected_features:
                if len(feature_ids) == 1:
                    # Single selection - zoom to that point with buffer
                    feature = selected_features[0]
                    if feature.hasGeometry():
                        iface.mapCanvas().zoomToFeatureIds(self.linked_layer, feature_ids)
                        
                        # Get feature info for status message
                        attrs = feature.attributes()
                        fields = self.linked_layer.fields()
                        
                        # Try to find a name field to display
                        name_value = None
                        name_fields = ['new_name', 'name', 'toponyms', 'label', 'id']
                        for name_field in name_fields:
                            idx = fields.indexOf(name_field)
                            if idx >= 0 and idx < len(attrs):
                                name_value = attrs[idx]
                                if name_value:
                                    break
                        
                        # Show info in status
                        if name_value:
                            self._update_status(f"Selected: {name_value}")
                        else:
                            self._update_status(f"Selected row {list(selected_rows)[0] + 1}")
                else:
                    # Multiple selections - zoom to show all points
                    from qgis.core import QgsRectangle
                    
                    # Calculate combined bounding box for all selected features
                    combined_bbox = QgsRectangle()
                    combined_bbox.setMinimal()
                    
                    for feature in selected_features:
                        if feature.hasGeometry():
                            combined_bbox.combineExtentWith(feature.geometry().boundingBox())
                    
                    if not combined_bbox.isEmpty():
                        iface.mapCanvas().zoomToFeatureIds(self.linked_layer, feature_ids)
                    
                    # Show count in status
                    self._update_status(f"Selected {len(feature_ids)} points")
            
            QgsMessageLog.logMessage(
                f"Selected and flashed {len(feature_ids)} feature(s) on map",
                "ToponymsManager",
                Qgis.Info
            )
            
        except Exception as e:
            QgsMessageLog.logMessage(
                f"Error highlighting feature on map: {str(e)}",
                "ToponymsManager",
                Qgis.Warning
            )

    def _show_tabular_related_features(self):
        """Back spreadsheet forms with current table values, independently of map points."""
        from qgis.core import QgsFeature, QgsField, QgsProject, QgsVectorLayer
        from qgis.PyQt.QtCore import QVariant

        selected_rows = {item.row() for item in self.table.selectedItems()}
        if not self._confirm_related_selection_change(selected_rows):
            return False
        if not self._close_other_related_dock():
            return False
        previous_layer = getattr(self, '_tabular_related_layer', None)
        if previous_layer is not None:
            QgsProject.instance().removeMapLayer(previous_layer.id())
            self._tabular_related_layer = None
        if not selected_rows:
            return True

        layer = QgsVectorLayer("None", "Batch Load Table", "memory")
        provider = layer.dataProvider()
        if not provider.addAttributes([
                QgsField(str(header), QVariant.String) for header in self.data_dict['headers']]):
            raise RuntimeError("Could not create the related batch table fields.")
        layer.updateFields()
        features = []
        for row in sorted(selected_rows):
            feature = QgsFeature(layer.fields())
            feature.setAttributes([
                self.table.item(row, column).text() if self.table.item(row, column) else ''
                for column in range(self.table.columnCount())
            ])
            features.append(feature)
        added, features = provider.addFeatures(features)
        if not added:
            raise RuntimeError("Could not create the related batch table records.")
        QgsProject.instance().addMapLayer(layer, False)
        self._tabular_related_layer = layer
        self._tabular_feature_rows = dict(zip(
            (feature.id() for feature in features),
            (self.table.item(row, 0) for row in sorted(selected_rows)),
        ))
        self._show_related_features_dock(selected_rows, {layer: features}, set(), set())
        return True

    def _on_related_selection_changed(self):
        """Highlight related processed geometry layers by toponymic_feature_id."""
        try:
            from qgis.core import QgsCoordinateTransform, QgsProject, QgsRectangle, QgsWkbTypes
            from qgis.utils import iface
            from qgis.PyQt.QtGui import QColor

            selected_rows = {item.row() for item in self.table.selectedItems()}
            if not self._confirm_related_selection_change(selected_rows):
                return
            if not self._close_other_related_dock():
                return

            # names_6 is included so its record for the toponym is visible alongside geometry
            target_layers = self._related_project_layers(('names_6', 'points_0', 'lines_1', 'polygons_2'))
            if not selected_rows:
                for layer in target_layers.values():
                    layer.removeSelection()
                if iface:
                    iface.mapCanvas().refresh()
                return

            tfid_col = self._header_column('toponymic_feature_id')
            source_col = self._header_column('source_record_id')
            source_layer_col = self._header_column('source_layer')
            tfids = set()
            source_ids = set()
            fallback_rows = {}
            for row in selected_rows:
                tfid = self._cell_text(row, tfid_col)
                source_id = self._cell_text(row, source_col)
                if tfid:
                    tfids.add(tfid.casefold())
                if source_id:
                    source_ids.add(source_id.casefold())
                source_layer = self._cell_text(row, source_layer_col)
                if source_layer:
                    fallback_rows[source_layer.casefold()] = sum(
                        1 for prior_row in range(row + 1)
                        if self._cell_text(prior_row, source_layer_col).casefold() == source_layer.casefold()
                    ) - 1

            selected_features_by_layer = {}
            combined_bbox = QgsRectangle()
            combined_bbox.setMinimal()
            has_geometry = False
            canvas_crs = iface.mapCanvas().mapSettings().destinationCrs() if iface else None
            for layer_name, layer in target_layers.items():
                feature_ids = []
                features = []
                layer_tfid_idx = self._layer_field_index(layer, 'toponymic_feature_id')
                layer_source_idx = self._layer_field_index(layer, 'source_record_id')
                layer_features = list(layer.getFeatures())
                layer_row_index = 0
                for feature in layer_features:
                    layer_tfid = self._feature_value(feature, layer_tfid_idx)
                    layer_source = self._feature_value(feature, layer_source_idx)
                    identifier_match = (
                        (layer_tfid and layer_tfid.casefold() in tfids) or
                        (layer_source and layer_source.casefold() in source_ids)
                    )
                    fallback_match = (
                        layer_name.casefold() in fallback_rows and
                        layer_row_index == fallback_rows[layer_name.casefold()]
                    )
                    if identifier_match or fallback_match:
                        feature_ids.append(feature.id())
                        features.append(feature)
                        if feature.hasGeometry():
                            has_geometry = True
                            feature_bbox = feature.geometry().boundingBox()
                            if canvas_crs and layer.crs() != canvas_crs:
                                feature_bbox = QgsCoordinateTransform(
                                    layer.crs(), canvas_crs, QgsProject.instance()
                                ).transformBoundingBox(feature_bbox)
                            combined_bbox.combineExtentWith(feature_bbox)
                    layer_row_index += 1
                layer.selectByIds(feature_ids)
                selected_features_by_layer[layer] = features
                if iface and feature_ids and any(feature.hasGeometry() for feature in features):
                    iface.mapCanvas().flashFeatureIds(
                        layer,
                        feature_ids,
                        startColor=QColor(255, 0, 0, 255),
                        endColor=QColor(255, 255, 0, 200),
                        flashes=2,
                        duration=400
                    )

            # Also zoom/flash the lat-long 'Batch Load Coordinates' point (built from names_6),
            # without listing it in the related-features dock, so rows with no processed
            # points_0/lines_1/polygons_2 match (e.g. names_6-only, pre-processing) still zoom.
            coordinate_layer = getattr(self.parent_widget, 'coordinate_layer', None)
            if coordinate_layer and coordinate_layer.isValid():
                layer_tfid_idx = self._layer_field_index(coordinate_layer, 'toponymic_feature_id')
                layer_source_idx = self._layer_field_index(coordinate_layer, 'source_record_id')
                coord_feature_ids = []
                for feature in coordinate_layer.getFeatures():
                    layer_tfid = self._feature_value(feature, layer_tfid_idx)
                    layer_source = self._feature_value(feature, layer_source_idx)
                    if ((layer_tfid and layer_tfid.casefold() in tfids) or
                            (layer_source and layer_source.casefold() in source_ids)):
                        coord_feature_ids.append(feature.id())
                        if feature.hasGeometry():
                            has_geometry = True
                            feature_bbox = feature.geometry().boundingBox()
                            if canvas_crs and coordinate_layer.crs() != canvas_crs:
                                feature_bbox = QgsCoordinateTransform(
                                    coordinate_layer.crs(), canvas_crs, QgsProject.instance()
                                ).transformBoundingBox(feature_bbox)
                            combined_bbox.combineExtentWith(feature_bbox)
                coordinate_layer.selectByIds(coord_feature_ids)
                if iface and coord_feature_ids:
                    iface.mapCanvas().flashFeatureIds(
                        coordinate_layer,
                        coord_feature_ids,
                        startColor=QColor(255, 0, 0, 255),
                        endColor=QColor(255, 255, 0, 200),
                        flashes=2,
                        duration=400
                    )

            if iface and has_geometry:
                if combined_bbox.width() == 0 or combined_bbox.height() == 0:
                    combined_bbox.grow(0.01 if canvas_crs.isGeographic() else 1000)
                combined_bbox.scale(1.2)
                iface.mapCanvas().setExtent(combined_bbox)
                iface.mapCanvas().refresh()

            self._show_related_features_dock(selected_rows, selected_features_by_layer, tfids, source_ids)

            total = sum(len(features) for features in selected_features_by_layer.values())
            self._update_status(f"Selected {total} related feature(s)")
            QgsMessageLog.logMessage(
                f"Selected {total} related feature(s) by toponymic_feature_id/source_record_id",
                "ToponymsManager",
                Qgis.Info
            )
        except Exception as e:
            QgsMessageLog.logMessage(
                f"Error highlighting related features: {str(e)}",
                "ToponymsManager",
                Qgis.Warning
            )

    def _on_error_selection_changed(self):
        """Show the selected error feature and its related batch-load features."""
        from qgis.core import QgsCoordinateTransform, QgsProject, QgsRectangle
        from qgis.utils import iface
        from qgis.PyQt.QtGui import QColor

        selected_items = self.table.selectedItems()
        if not selected_items:
            return

        row = selected_items[0].row()
        if not self._confirm_related_selection_change({row}):
            return
        if not self._close_other_related_dock():
            return
        layer_column = self._header_column('source_layer')
        feature_column = self._header_column('objectid')
        layer_name = self._cell_text(row, layer_column)
        feature_text = self._cell_text(row, feature_column)
        if not layer_name or not feature_text:
            return

        try:
            feature_id = int(float(feature_text))
        except (TypeError, ValueError):
            return

        error_tfid = self._cell_text(row, self._header_column('toponymic_feature_id'))
        error_source = self._cell_text(row, self._header_column('source_record_id'))
        error_objectid = feature_text
        target_layers = self._related_project_layers(
            ('names_6', 'points_0', 'lines_1', 'polygons_2')
        )
        layers = QgsProject.instance().mapLayersByName(layer_name)
        layer = target_layers.get(layer_name) or (layers[-1] if layers else None)
        source_path = getattr(self.parent_widget, 'batch_load_source_path', None)
        feature = None
        if source_path:
            source_layer = self._get_error_source_layer(layer_name)
            if source_layer is not None:
                source_feature = next(
                    (candidate for candidate in source_layer.getFeatures()
                     if str(candidate.id()) == str(feature_id)),
                    None
                )
                if source_feature is not None:
                    # Authoritative match by the raw feature id preserved on the error layer;
                    # skip the tfid/source_id heuristic below, which can pick the wrong feature
                    # when those fields are empty or duplicated (common for erroring records).
                    layer = source_layer
                    feature = source_feature
        if layer is None:
            return

        if feature is None:
            layer_tfid_index = self._layer_field_index(layer, 'toponymic_feature_id')
            layer_source_index = self._layer_field_index(layer, 'source_record_id')
            layer_objectid_index = self._layer_field_index(
                layer, f'objectid_{layer_name.rstrip("_0123456789")}'
            )
            for candidate in layer.getFeatures():
                candidate_tfid = self._feature_value(candidate, layer_tfid_index).casefold()
                candidate_source = self._feature_value(candidate, layer_source_index).casefold()
                candidate_objectid = self._feature_value(candidate, layer_objectid_index).casefold()
                if ((error_tfid and candidate_tfid == error_tfid.casefold()) or
                        (error_source and candidate_source == error_source.casefold()) or
                        (error_objectid and candidate_objectid == error_objectid.casefold())):
                    feature = candidate
                    break
            if feature is None and source_path:
                feature = layer.getFeature(feature_id)
        if feature is None or not feature.isValid():
            QgsMessageLog.logMessage(
                f"Could not resolve error feature {layer_name} OBJECTID {error_objectid}",
                "ToponymsManager",
                Qgis.Warning
            )
            return

        layer.selectByIds([feature.id()])
        tfid_index = self._layer_field_index(layer, 'toponymic_feature_id')
        source_index = self._layer_field_index(layer, 'source_record_id')
        tfids = set()
        source_ids = set()
        if tfid_index >= 0 and self._feature_value(feature, tfid_index):
            tfids.add(self._feature_value(feature, tfid_index).casefold())
        if source_index >= 0 and self._feature_value(feature, source_index):
            source_ids.add(self._feature_value(feature, source_index).casefold())

        if error_tfid:
            tfids.add(error_tfid.casefold())
        if error_source:
            source_ids.add(error_source.casefold())

        selected_features_by_layer = {}
        combined_bbox = QgsRectangle()
        combined_bbox.setMinimal()
        has_geometry = False
        canvas_crs = iface.mapCanvas().mapSettings().destinationCrs() if iface else None
        for layer_name, target_layer in target_layers.items():
            features = []
            target_tfid_index = self._layer_field_index(target_layer, 'toponymic_feature_id')
            target_source_index = self._layer_field_index(target_layer, 'source_record_id')
            target_objectid_index = self._layer_field_index(
                target_layer, f'objectid_{layer_name.rstrip("_0123456789")}'
            )
            for target_feature in target_layer.getFeatures():
                target_tfid = self._feature_value(target_feature, target_tfid_index)
                target_source = self._feature_value(target_feature, target_source_index)
                target_objectid = self._feature_value(target_feature, target_objectid_index)
                matches = (
                    (target_tfid and target_tfid.casefold() in tfids) or
                    (target_source and target_source.casefold() in source_ids) or
                    (target_layer == layer and error_objectid and
                     target_objectid.casefold() == error_objectid.casefold())
                )
                if matches:
                    features.append(target_feature)
                    if target_feature.hasGeometry():
                        has_geometry = True
                        feature_bbox = target_feature.geometry().boundingBox()
                        if canvas_crs and target_layer.crs() != canvas_crs:
                            feature_bbox = QgsCoordinateTransform(
                                target_layer.crs(), canvas_crs, QgsProject.instance()
                            ).transformBoundingBox(feature_bbox)
                        combined_bbox.combineExtentWith(feature_bbox)
            if target_layer == layer:
                if not any(item.id() == feature.id() for item in features):
                    features.append(feature)
            target_layer.selectByIds([item.id() for item in features])
            selected_features_by_layer[target_layer] = features

        if source_path:
            selected_features_by_layer[layer] = [feature]

        if feature.hasGeometry():
            has_geometry = True
            feature_bbox = feature.geometry().boundingBox()
            if canvas_crs and layer.crs() != canvas_crs:
                feature_bbox = QgsCoordinateTransform(
                    layer.crs(), canvas_crs, QgsProject.instance()
                ).transformBoundingBox(feature_bbox)
            combined_bbox.combineExtentWith(feature_bbox)
        self._show_related_features_dock(
            {row}, selected_features_by_layer, tfids, source_ids
        )

        if iface:
            if has_geometry:
                if combined_bbox.width() == 0 or combined_bbox.height() == 0:
                    combined_bbox.grow(0.01 if canvas_crs.isGeographic() else 1000)
                combined_bbox.scale(1.2)
                iface.mapCanvas().setExtent(combined_bbox)
                iface.mapCanvas().refresh()
            if feature.hasGeometry():
                iface.mapCanvas().flashFeatureIds(
                    layer,
                    [feature.id()],
                    startColor=QColor(255, 0, 0, 255),
                    endColor=QColor(255, 255, 0, 200),
                    flashes=2,
                    duration=400
                )

    def _confirm_related_selection_change(self, selected_rows):
        dock = getattr(self, '_related_features_dock', None)
        if dock is None:
            return True

        previous_rows = getattr(dock, '_related_selected_rows', set())
        if selected_rows == previous_rows:
            return True

        if dock._related_editing:
            answer = QtWidgets.QMessageBox.question(
                self,
                "Unsaved related feature changes",
                "Save changes before selecting another row?",
                QtWidgets.QMessageBox.Save |
                QtWidgets.QMessageBox.Discard |
                QtWidgets.QMessageBox.Cancel,
                QtWidgets.QMessageBox.Save
            )
            if answer == QtWidgets.QMessageBox.Save:
                self._save_related_tree_edits()
            elif answer == QtWidgets.QMessageBox.Discard:
                self._discard_related_tree_edits()
            else:
                self.table.blockSignals(True)
                self.table.clearSelection()
                for row in previous_rows:
                    self.table.selectRow(row)
                self.table.blockSignals(False)
                return False

        dock.close()
        return True

    def _close_other_related_dock(self):
        """Close a related dock owned by the other open table, if any."""
        for dialog_attr in ('current_table_dialog', 'error_table_dialog'):
            dialog = getattr(self.parent_widget, dialog_attr, None)
            if dialog is None or dialog is self:
                continue
            if getattr(dialog, '_related_features_dock', None):
                if not dialog.prepare_for_replacement():
                    return False
        return True

    def prepare_for_replacement(self):
        """Confirm related edits before this table is replaced by another view."""
        dock = getattr(self, '_related_features_dock', None)
        if dock is not None and dock._related_editing:
            answer = QtWidgets.QMessageBox.question(
                self,
                "Unsaved related feature changes",
                "Save changes before replacing this table?",
                QtWidgets.QMessageBox.Save |
                QtWidgets.QMessageBox.Discard |
                QtWidgets.QMessageBox.Cancel,
                QtWidgets.QMessageBox.Save
            )
            if answer == QtWidgets.QMessageBox.Save:
                self._save_related_tree_edits()
            elif answer == QtWidgets.QMessageBox.Discard:
                self._discard_related_tree_edits()
            else:
                return False

        if dock is not None:
            dock.close()
        return True

    def _related_project_layers(self, layer_names):
        """Return loaded QGIS project layers by name, preferring the most recently added match."""
        from qgis.core import QgsProject

        layers = {}
        for layer_name in layer_names:
            matches = QgsProject.instance().mapLayersByName(layer_name)
            if matches:
                layers[layer_name] = matches[-1]
        return layers

    def _get_error_source_layer(self, layer_name):
        """
        Return the project-registered '{layer_name}_error' layer built by
        FileImportHandler._build_error_source_layers() when the error table was opened, or
        None if that source layer has no erroring records. Looking up an already-registered
        layer (instead of an ad-hoc one) lets edits made via the related-features dock be
        found and committed on save, and lets 'Reprocess file' merge them back in.
        """
        from qgis.core import QgsProject

        cache = getattr(self.parent_widget, 'error_source_layers', None)
        if not cache:
            return None
        layer = cache.get(layer_name)
        if layer is not None and QgsProject.instance().mapLayer(layer.id()):
            return layer
        return None

    def _header_column(self, header_name):
        headers = self.data_dict.get('headers', [])
        wanted = header_name.casefold()
        for index, header in enumerate(headers):
            if str(header).casefold() == wanted:
                return index
        return -1

    def _cell_text(self, row, column):
        if column < 0:
            return ''
        item = self.table.item(row, column)
        return item.text().strip() if item else ''

    @staticmethod
    def _geosys_tfids_with_points(headers, rows):
        """Return feature IDs that have Geosys coordinates in the supplied rows."""
        header_map = {
            str(header).strip().casefold(): index
            for index, header in enumerate(headers)
        }
        tfid_idx = header_map.get('toponymic_feature_id')
        lat_idx = header_map.get('latitude_geosys')
        lon_idx = header_map.get('longitude_geosys')
        if tfid_idx is None or (lat_idx is None and lon_idx is None):
            return set()

        tfids = set()
        for row in rows:
            tfid = row[tfid_idx] if tfid_idx < len(row) else None
            if tfid is None or str(tfid).strip().casefold() in ('', 'null', '<null>'):
                continue
            has_coordinates = any(
                index is not None and index < len(row) and row[index] is not None and
                str(row[index]).strip().casefold() not in ('', 'null', '<null>')
                for index in (lat_idx, lon_idx)
            )
            if has_coordinates:
                tfids.add(str(tfid).strip().casefold())
        return tfids

    @classmethod
    def _is_duplicate_geosys_row(cls, headers, values, geosys_tfids_with_points):
        """Whether a row with no point shares its feature ID with a row that has one."""
        header_map = {
            str(header).strip().casefold(): index
            for index, header in enumerate(headers)
        }
        tfid_idx = header_map.get('toponymic_feature_id')
        if tfid_idx is None or tfid_idx >= len(values):
            return False
        tfid = values[tfid_idx]
        if tfid is None:
            return False
        normalized_tfid = str(tfid).strip().casefold()
        if not normalized_tfid or normalized_tfid not in geosys_tfids_with_points:
            return False
        return not any(
            index is not None and index < len(values) and values[index] is not None and
            str(values[index]).strip().casefold() not in ('', 'null', '<null>')
            for index in (
                header_map.get('latitude_geosys'),
                header_map.get('longitude_geosys'),
            )
        )

    @staticmethod
    def _layer_field_index(layer, field_name):
        wanted = field_name.casefold()
        for index, field in enumerate(layer.fields()):
            if field.name().casefold() == wanted:
                return index
        return -1

    @staticmethod
    def _feature_value(feature, index):
        if index < 0:
            return ''
        value = feature[index]
        return '' if value is None else str(value).strip()

    def _open_related_feature_forms(self, selected_features_by_layer):
        """Open QGIS feature forms for the related spatial features from a single selected row."""
        from qgis.utils import iface

        for layer, features in selected_features_by_layer.items():
            for feature in features:
                try:
                    iface.openFeatureForm(layer, feature)
                except Exception as e:
                    QgsMessageLog.logMessage(
                        f"Could not open feature form for {layer.name()} feature {feature.id()}: {str(e)}",
                        "ToponymsManager",
                        Qgis.Warning
                    )

    def _get_code_list(self, field_name):
        """Return [(code, term, description)] for a controlled-vocabulary field, or None if unavailable."""
        key = str(field_name).casefold()
        endpoint = self.CODE_LIST_ENDPOINTS.get(key)
        if endpoint is None:
            return None
        cache = self.__dict__.setdefault('_code_lists', {})
        if cache.get(key):
            return cache[key]
        if key in getattr(self, '_code_list_failed', set()):
            return None
        try:
            import requests

            auth_handler = getattr(self.parent_widget, 'auth_handler', None)
            session = getattr(auth_handler, 'geoname_api_session', None) or requests
            response = session.get(
                f"{self.CODE_LIST_BASE_URL}/{endpoint}?sort-field=term&sort-order=asc", timeout=10
            )
            response.raise_for_status()
            cache[key] = [
                (str(d.get('code', '')).strip(), str(d.get('term', '')), str(d.get('description') or ''))
                for d in response.json().get('definitions', []) if d.get('code') is not None
            ]
            return cache[key]
        except Exception as e:
            self.__dict__.setdefault('_code_list_failed', set()).add(key)
            QgsMessageLog.logMessage(
                f"Could not load code list for '{field_name}': {str(e)}", "ToponymsManager", Qgis.Warning
            )
            return None

    def _show_related_features_dock(self, selected_rows, selected_features_by_layer, tfids, source_ids):
        """Show selected/related table and geometry attributes in a right-side QGIS dock."""
        from qgis.utils import iface

        if not iface:
            return

        self._code_list_failed = set()

        dock = getattr(self, '_related_features_dock', None)
        if dock is None:
            dock = QtWidgets.QDockWidget("Related Batch Load Features", iface.mainWindow())
            dock.setObjectName("ToponymsManagerRelatedFeaturesDock")
            container = QtWidgets.QWidget()
            layout = QtWidgets.QVBoxLayout(container)
            toolbar = QtWidgets.QHBoxLayout()
            expand_button = QtWidgets.QPushButton("Expand all")
            collapse_button = QtWidgets.QPushButton("Collapse all")
            toolbar.addWidget(expand_button)
            toolbar.addWidget(collapse_button)
            edit_button = QtWidgets.QPushButton("Edit")
            save_button = QtWidgets.QPushButton("Save")
            discard_button = QtWidgets.QPushButton("Discard")
            clear_selection_button = QtWidgets.QPushButton("Clear Selection")
            save_button.setEnabled(False)
            discard_button.setEnabled(False)
            toolbar.addWidget(edit_button)
            toolbar.addWidget(save_button)
            toolbar.addWidget(discard_button)
            toolbar.addWidget(clear_selection_button)
            toolbar.addStretch()
            layout.addLayout(toolbar)
            tree = QtWidgets.QTreeWidget()
            tree.setColumnCount(2)
            tree.setHeaderLabels(["Field", "Value"])
            tree.setItemDelegate(RelatedValueDelegate(tree))
            tree.setStyleSheet(
                "QTreeWidget { background: #f3f3f3; }"
                "QTreeWidget QLineEdit { background: #ffffff; color: #000000; border: 1px solid #b8b8b8; }"
            )
            tree.setEditTriggers(
                QtWidgets.QAbstractItemView.DoubleClicked |
                QtWidgets.QAbstractItemView.EditKeyPressed
            )
            layout.addWidget(tree)
            dock.setWidget(container)
            dock._related_tree = tree
            dock._related_edit_button = edit_button
            dock._related_save_button = save_button
            dock._related_discard_button = discard_button
            dock._related_edit_layers = set()
            dock._related_started_layers = set()
            dock._related_original_values = {}
            dock._related_editing = False
            tree.itemChanged.connect(self._on_related_tree_item_changed)
            expand_button.clicked.connect(tree.expandAll)
            collapse_button.clicked.connect(tree.collapseAll)
            edit_button.clicked.connect(lambda: self._set_related_tree_editing(True))
            save_button.clicked.connect(self._save_related_tree_edits)
            discard_button.clicked.connect(self._discard_related_tree_edits)
            clear_selection_button.clicked.connect(self._clear_related_features_selection)
            iface.addDockWidget(Qt.RightDockWidgetArea, dock)
            self._related_features_dock = dock

        tree = dock._related_tree
        dock._related_context = (selected_features_by_layer, tfids, source_ids)
        tree.blockSignals(True)
        tree.clear()

        for layer in selected_features_by_layer:
            features = selected_features_by_layer[layer]
            group = QtWidgets.QTreeWidgetItem([f"{layer.name()} ({len(features)})", ""])
            tree.addTopLevelItem(group)
            headers = [field.name() for field in layer.fields()]
            if layer is getattr(self, '_tabular_related_layer', None):
                all_rows = [
                    [
                        self.table.item(row, column).text()
                        if self.table.item(row, column) is not None else ''
                        for column in range(self.table.columnCount())
                    ]
                    for row in range(self.table.rowCount())
                ]
                all_headers = self.data_dict.get('headers', headers)
            else:
                all_features = list(layer.getFeatures())
                all_rows = [feature.attributes() for feature in all_features]
                all_headers = headers
            geosys_tfids_with_points = self._geosys_tfids_with_points(
                all_headers, all_rows
            )
            base_name = layer.name()[:-len('_error')] if layer.name().endswith('_error') else layer.name()
            hidden = self.LABEL_FIELDS if base_name in self.GEOMETRY_LAYERS else ()
            for feature in features:
                feature_item = QtWidgets.QTreeWidgetItem([f"Feature {feature.id()}", ""])
                group.addChild(feature_item)
                self._add_attribute_children(
                    feature_item, headers, feature.attributes(), layer, feature.id(), hidden,
                    duplicate_geosys_row=self._is_duplicate_geosys_row(
                        headers, feature.attributes(), geosys_tfids_with_points
                    )
                )

        tree.expandToDepth(1)
        tree.resizeColumnToContents(0)
        tree.blockSignals(False)
        dock._related_selected_rows = set(selected_rows)
        dock.show()
        dock.raise_()

    def _set_related_tree_editing(self, enabled):
        dock = getattr(self, '_related_features_dock', None)
        if dock is None:
            return

        tree = dock._related_tree
        tree.blockSignals(True)
        for row in range(tree.topLevelItemCount()):
            self._set_related_item_editing(tree.topLevelItem(row), enabled)
        tree.blockSignals(False)
        dock._related_editing = enabled
        dock._related_edit_button.setEnabled(not enabled)
        dock._related_save_button.setEnabled(enabled)
        dock._related_discard_button.setEnabled(enabled)

    def _set_related_item_editing(self, item, enabled):
        metadata = item.data(1, Qt.UserRole)
        if metadata:
            is_read_only = (
                item.text(0).strip().casefold() in self.READ_ONLY_COORDINATE_FIELDS or
                bool(item.data(1, self.DUPLICATE_GEOSYS_ROLE))
            )
            if enabled and not is_read_only:
                item.setFlags(item.flags() | Qt.ItemIsEditable)
            else:
                item.setFlags(item.flags() & ~Qt.ItemIsEditable)
        for child_index in range(item.childCount()):
            self._set_related_item_editing(item.child(child_index), enabled)

    def _save_related_tree_edits(self):
        dock = getattr(self, '_related_features_dock', None)
        if dock is None:
            return

        from qgis.core import QgsProject

        edited_feature_keys = {
            (layer_id, feature_id) for (layer_id, feature_id, _field_index) in dock._related_original_values
        }
        QgsMessageLog.logMessage(
            f"_save_related_tree_edits: edit_layers={sorted(dock._related_edit_layers)}, "
            f"edited_feature_keys={sorted(edited_feature_keys)}",
            "ToponymsManager",
            Qgis.Info
        )

        for layer_id in list(dock._related_edit_layers):
            layer = QgsProject.instance().mapLayer(layer_id)
            if not layer:
                QgsMessageLog.logMessage(
                    f"_save_related_tree_edits: layer_id={layer_id} not found in project, skipping commit",
                    "ToponymsManager",
                    Qgis.Warning
                )
                continue
            if not layer.isEditable():
                QgsMessageLog.logMessage(
                    f"_save_related_tree_edits: layer '{layer.name()}' not editable, skipping commit",
                    "ToponymsManager",
                    Qgis.Warning
                )
                continue
            commit_ok = layer.commitChanges()
            layer.triggerRepaint()
            QgsMessageLog.logMessage(
                f"_save_related_tree_edits: committed layer '{layer.name()}' commit_ok={commit_ok} "
                f"commitErrors={layer.commitErrors() if not commit_ok else []}",
                "ToponymsManager",
                Qgis.Success if commit_ok else Qgis.Warning
            )
            if not commit_ok:
                QtWidgets.QMessageBox.warning(
                    self,
                    "Save Failed",
                    f"Could not save edits to layer '{layer.name()}':\n\n" + '\n'.join(layer.commitErrors())
                )
            if layer.name().endswith('_error'):
                file_import_handler = getattr(self.parent_widget, 'file_import_handler', None)
                if file_import_handler:
                    file_import_handler._refresh_error_table_from_layer(layer.name()[:-len('_error')])
        dock._related_edit_layers.clear()
        dock._related_started_layers.clear()
        dock._related_original_values.clear()
        self._set_related_tree_editing(False)

        if self.data_type not in ('excel', 'csv'):
            self._sync_names_6_from_related_edits(edited_feature_keys)

    def _sync_names_6_from_related_edits(self, edited_feature_keys):
        """
        Propagate saved points_0/lines_1/polygons_2 edits (shared attributes, and point
        coordinates) into the matching names_6 feature, then rebuild the 'Batch Load
        Coordinates' layer as if 'Add coordinates as layer' had been re-clicked. A direct
        edit to names_6 itself also triggers that same coordinate-layer refresh.
        """
        if not edited_feature_keys:
            QgsMessageLog.logMessage("_sync_names_6_from_related_edits: no edited_feature_keys, skipping", "ToponymsManager", Qgis.Info)
            return

        from qgis.core import QgsProject

        project = QgsProject.instance()
        names_layers = project.mapLayersByName('names_6')
        names_layer = names_layers[-1] if names_layers else None
        if names_layer is None:
            QgsMessageLog.logMessage("_sync_names_6_from_related_edits: no 'names_6' layer found in project, skipping", "ToponymsManager", Qgis.Warning)
            return

        names_fields = names_layer.fields()
        names_tfid_idx = names_fields.indexOf('toponymic_feature_id')
        names_source_idx = names_fields.indexOf('source_record_id')
        names_lat_idx = names_fields.indexOf('latitude')
        names_lon_idx = names_fields.indexOf('longitude')

        was_editable = names_layer.isEditable()
        if not was_editable:
            names_layer.startEditing()

        updated = any(
            layer.name() == 'names_6' for layer in
            (project.mapLayer(layer_id) for layer_id, _feature_id in edited_feature_keys)
            if layer is not None
        )
        for layer_id, feature_id in edited_feature_keys:
            layer = project.mapLayer(layer_id)
            if layer is None or layer.name() not in ('points_0', 'lines_1', 'polygons_2'):
                QgsMessageLog.logMessage(
                    f"_sync_names_6_from_related_edits: skipping layer_id={layer_id} "
                    f"(name={layer.name() if layer else None}) - not points_0/lines_1/polygons_2",
                    "ToponymsManager",
                    Qgis.Info
                )
                continue
            feature = layer.getFeature(feature_id)
            if not feature.isValid():
                QgsMessageLog.logMessage(
                    f"_sync_names_6_from_related_edits: feature_id={feature_id} invalid on layer '{layer.name()}'",
                    "ToponymsManager",
                    Qgis.Warning
                )
                continue

            layer_fields = layer.fields()
            tfid = self._feature_value(feature, layer_fields.indexOf('toponymic_feature_id')).casefold()
            source_id = self._feature_value(feature, layer_fields.indexOf('source_record_id')).casefold()
            if not tfid and not source_id:
                QgsMessageLog.logMessage(
                    f"_sync_names_6_from_related_edits: layer '{layer.name()}' feature_id={feature_id} "
                    f"has no toponymic_feature_id/source_record_id, cannot match to names_6",
                    "ToponymsManager",
                    Qgis.Warning
                )
                continue

            matched = False
            for names_feature in names_layer.getFeatures():
                names_tfid = self._feature_value(names_feature, names_tfid_idx).casefold()
                names_source = self._feature_value(names_feature, names_source_idx).casefold()
                if not ((tfid and tfid == names_tfid) or (source_id and source_id == names_source)):
                    continue
                matched = True

                for field in layer_fields:
                    field_name = field.name()
                    if field_name.casefold() in ('toponymic_feature_id', 'source_record_id') + self.LABEL_FIELDS:
                        continue
                    names_field_idx = names_fields.indexOf(field_name)
                    if names_field_idx < 0:
                        continue
                    value = feature[field_name]
                    if names_feature[names_field_idx] != value:
                        names_layer.changeAttributeValue(names_feature.id(), names_field_idx, value)
                        updated = True

                if layer.name() == 'points_0' and feature.hasGeometry() and names_lat_idx >= 0 and names_lon_idx >= 0:
                    point = feature.geometry().asPoint()
                    lat, lon = round(point.y(), 7), round(point.x(), 7)
                    if names_feature[names_lat_idx] != lat:
                        names_layer.changeAttributeValue(names_feature.id(), names_lat_idx, lat)
                        updated = True
                    if names_feature[names_lon_idx] != lon:
                        names_layer.changeAttributeValue(names_feature.id(), names_lon_idx, lon)
                        updated = True
                break
            if not matched:
                QgsMessageLog.logMessage(
                    f"_sync_names_6_from_related_edits: no names_6 match for layer '{layer.name()}' feature_id={feature_id} "
                    f"(tfid='{tfid}', source_id='{source_id}')",
                    "ToponymsManager",
                    Qgis.Warning
                )

        if updated:
            commit_ok = names_layer.commitChanges()
            names_layer.triggerRepaint()
            QgsMessageLog.logMessage(
                f"_sync_names_6_from_related_edits: committed names_6 commit_ok={commit_ok} "
                f"commitErrors={names_layer.commitErrors() if not commit_ok else []}",
                "ToponymsManager",
                Qgis.Success if commit_ok else Qgis.Warning
            )
        elif not was_editable:
            names_layer.rollBack()
            QgsMessageLog.logMessage("_sync_names_6_from_related_edits: nothing updated, rolled back", "ToponymsManager", Qgis.Info)

        edited_names_features = [
            project.mapLayer(layer_id).getFeature(feature_id)
            for layer_id, feature_id in edited_feature_keys
            if project.mapLayer(layer_id) is not None and project.mapLayer(layer_id).name() == 'names_6'
        ]
        self._push_names_6_labels(edited_names_features)

        if updated:
            coordinate_handler = getattr(self.parent_widget, 'coordinate_layer_handler', None)
            if coordinate_handler:
                coordinate_handler.add_coordinate_as_layer(silent=True)

    def _push_names_6_labels(self, names_features):
        """Copy names_6 label fields onto matching points_0/lines_1/polygons_2 features."""
        names_features = [feature for feature in names_features if feature.isValid()]
        if not names_features:
            return

        keys = []
        for feature in names_features:
            fields = feature.fields()
            tfid = self._feature_value(feature, fields.indexOf('toponymic_feature_id')).casefold()
            source_id = self._feature_value(feature, fields.indexOf('source_record_id')).casefold()
            labels = {
                name: feature[fields.indexOf(name)] for name in self.LABEL_FIELDS if fields.indexOf(name) >= 0
            }
            if (tfid or source_id) and labels:
                keys.append((tfid, source_id, labels))

        for layer in self._related_project_layers(self.GEOMETRY_LAYERS).values():
            fields = layer.fields()
            tfid_idx = fields.indexOf('toponymic_feature_id')
            source_idx = fields.indexOf('source_record_id')
            started = not layer.isEditable()
            if started:
                layer.startEditing()
            changed = False
            for geo_feature in layer.getFeatures():
                geo_tfid = self._feature_value(geo_feature, tfid_idx).casefold()
                geo_source = self._feature_value(geo_feature, source_idx).casefold()
                for tfid, source_id, labels in keys:
                    if not ((tfid and tfid == geo_tfid) or (source_id and source_id == geo_source)):
                        continue
                    for name, value in labels.items():
                        index = fields.indexOf(name)
                        if index >= 0 and geo_feature[index] != value:
                            layer.changeAttributeValue(geo_feature.id(), index, value)
                            changed = True
                            if self.data_dict.get('type') == 'combined_gdb_view':
                                self._update_combined_cell(layer, geo_feature.id(), name, value)
            if changed and started:
                if not layer.commitChanges():
                    QgsMessageLog.logMessage(
                        f"_push_names_6_labels: commit failed on '{layer.name()}': {layer.commitErrors()}",
                        "ToponymsManager",
                        Qgis.Warning
                    )
                layer.triggerRepaint()
            elif started:
                layer.rollBack()

    def _discard_related_tree_edits(self):
        dock = getattr(self, '_related_features_dock', None)
        if dock is None:
            return

        from qgis.core import QgsProject

        if self.data_dict.get('type') == 'combined_gdb_view':
            for (layer_id, feature_id, field_index), original_value in dock._related_original_values.items():
                layer = QgsProject.instance().mapLayer(layer_id)
                if layer and field_index < layer.fields().count():
                    self._update_combined_cell(layer, feature_id, layer.fields()[field_index].name(), original_value)
        elif self.data_type in ('excel', 'csv'):
            for (layer_id, feature_id, field_index), original_value in dock._related_original_values.items():
                layer = QgsProject.instance().mapLayer(layer_id)
                if layer is getattr(self, '_tabular_related_layer', None):
                    anchor = self._tabular_feature_rows[feature_id]
                    self.table.item(anchor.row(), field_index).setText(
                        '' if original_value is None else str(original_value)
                    )

        for layer_id in list(dock._related_started_layers):
            layer = QgsProject.instance().mapLayer(layer_id)
            if layer and layer.isEditable():
                layer.rollBack()

        for (layer_id, feature_id, field_index), original_value in dock._related_original_values.items():
            if layer_id in dock._related_started_layers:
                continue
            layer = QgsProject.instance().mapLayer(layer_id)
            if layer and layer.isEditable():
                layer.changeAttributeValue(feature_id, field_index, original_value)
                layer.triggerRepaint()

        tree = dock._related_tree
        tree.blockSignals(True)
        for row in range(tree.topLevelItemCount()):
            self._refresh_related_item_values(tree.topLevelItem(row))
        tree.blockSignals(False)
        dock._related_edit_layers.clear()
        dock._related_started_layers.clear()
        dock._related_original_values.clear()
        self._set_related_tree_editing(False)

    def _clear_related_features_selection(self):
        """Remove map/table highlights while keeping the related-features dock content."""
        dock = getattr(self, '_related_features_dock', None)
        if dock is None:
            return

        selected_features_by_layer, _tfids, _source_ids = getattr(
            dock, '_related_context', ({}, set(), set())
        )
        for layer in selected_features_by_layer:
            layer.removeSelection()
        if self.linked_layer:
            self.linked_layer.removeSelection()

        if getattr(self, '_highlight_rubber_band', None):
            self._highlight_rubber_band.reset()
            self._highlight_rubber_band = None

        self.table.blockSignals(True)
        self.table.clearSelection()
        self.table.blockSignals(False)

        from qgis.utils import iface
        if iface:
            iface.mapCanvas().refresh()

        self._update_status("Related selection cleared")

    def _refresh_related_item_values(self, item):
        metadata = item.data(1, Qt.UserRole)
        if metadata:
            from qgis.core import QgsProject

            layer_id, feature_id, field_index = metadata
            layer = QgsProject.instance().mapLayer(layer_id)
            if layer:
                feature = layer.getFeature(feature_id)
                item.setText(1, '' if feature[field_index] is None else str(feature[field_index]))
        for child_index in range(item.childCount()):
            self._refresh_related_item_values(item.child(child_index))

    def _related_table_rows(self, tfids, source_ids):
        """Return combined-table rows related by selected toponymic_feature_id/source_record_id."""
        result = {'names_6': [], 'points_0': []}
        headers = self.data_dict.get('headers', [])
        source_layer_col = self._header_column('source_layer')
        tfid_col = self._header_column('toponymic_feature_id')
        source_col = self._header_column('source_record_id')
        for row_number, row_values in enumerate(self.data_dict.get('data', [])[1:]):
            layer_name = row_values[source_layer_col] if source_layer_col >= 0 and source_layer_col < len(row_values) else ''
            if layer_name not in result:
                continue
            tfid = str(row_values[tfid_col]).strip().casefold() if tfid_col >= 0 and tfid_col < len(row_values) and row_values[tfid_col] is not None else ''
            source_id = str(row_values[source_col]).strip().casefold() if source_col >= 0 and source_col < len(row_values) and row_values[source_col] is not None else ''
            if (tfid and tfid in tfids) or (source_id and source_id in source_ids):
                result[layer_name].append((row_number, row_values))
        return result

    def _add_attribute_children(
            self, parent_item, headers, values, layer=None, feature_id=None,
            hidden_fields=(), duplicate_geosys_row=False):
        """Add non-empty attribute values as child rows under a tree feature item."""
        from qgis.PyQt.QtGui import QColor, QBrush

        for index, header in enumerate(headers):
            if str(header).lower() in hidden_fields:
                continue
            value = values[index] if index < len(values) else ''
            value_text = '' if value is None else str(value)
            item = QtWidgets.QTreeWidgetItem([str(header), value_text])
            item.setForeground(0, QBrush(QColor(0, 0, 0)))
            item.setForeground(1, QBrush(QColor(0, 0, 0)))
            item.setBackground(1, QBrush(QColor(255, 255, 255)))
            if str(header).strip().casefold() in self.READ_ONLY_COORDINATE_FIELDS:
                item.setToolTip(0, "This field is not editable.")
                item.setToolTip(1, "This field is not editable.")
            if (duplicate_geosys_row and
                    str(header).strip().casefold() in self.GEOSYS_FIELDS):
                item.setToolTip(0, "This duplicate Geosys point is not editable.")
                item.setToolTip(1, "This duplicate Geosys point is not editable.")
                item.setData(1, self.DUPLICATE_GEOSYS_ROLE, True)
            if layer is not None and feature_id is not None:
                item.setData(1, Qt.UserRole, (layer.id(), feature_id, index))
                vocab = self._get_code_list(header)
                if vocab is not None:
                    item.setData(1, RelatedValueDelegate.VOCAB_ROLE, vocab)
            parent_item.addChild(item)

    @staticmethod
    def _coerce_field_value(field, text):
        """Convert dock text to the field's type so numeric fields commit correctly."""
        from qgis.PyQt.QtCore import QVariant

        if field.type() in (QVariant.Int, QVariant.LongLong, QVariant.Double):
            if text.strip() == '':
                return None
            try:
                return float(text) if field.type() == QVariant.Double else int(float(text))
            except ValueError:
                return text
        return text

    def _update_combined_cell(self, layer, feature_id, field_name, value):
        """Mirror a dock edit into the read-only combined names_6/points_0 table."""
        key_field = {'names_6': 'xlsx_row_id', 'points_0': 'objectid_points'}.get(layer.name())
        column = self._header_column(field_name)
        key_column = self._header_column(key_field) if key_field else -1
        source_column = self._header_column('source_layer')
        if column < 0 or key_column < 0 or source_column < 0:
            return
        key_value = self.normalize_row_id(layer.getFeature(feature_id)[key_field])
        self.table.blockSignals(True)
        try:
            for row in range(self.table.rowCount()):
                if (self._cell_text(row, source_column) == layer.name() and
                        self.normalize_row_id(self._cell_text(row, key_column)) == key_value):
                    cell = self.table.item(row, column)
                    if cell is not None:
                        cell.setText('' if value is None else str(value))
                    break
        finally:
            self.table.blockSignals(False)

    def _on_related_tree_item_changed(self, item, column):
        """Write edited dock attribute values back to the related QGIS layer feature."""
        if column != 1:
            return

        metadata = item.data(1, Qt.UserRole)
        if not metadata:
            return

        try:
            from qgis.core import QgsProject

            layer_id, feature_id, field_index = metadata
            layer = QgsProject.instance().mapLayer(layer_id)
            if not layer:
                QgsMessageLog.logMessage(
                    f"_on_related_tree_item_changed: layer_id={layer_id} not found in project (feature_id={feature_id}, field_index={field_index})",
                    "ToponymsManager",
                    Qgis.Warning
                )
                return

            dock = self._related_features_dock
            was_editable = layer.isEditable()
            if not was_editable:
                layer.startEditing()
                dock._related_started_layers.add(layer_id)

            key = (layer_id, feature_id, field_index)
            if key not in dock._related_original_values:
                dock._related_original_values[key] = layer.getFeature(feature_id)[field_index]

            value = item.text(1)
            field_name = layer.fields()[field_index].name() if field_index < layer.fields().count() else '?'
            if field_index < layer.fields().count():
                value = self._coerce_field_value(layer.fields()[field_index], value)
            if value == '' and item.data(1, RelatedValueDelegate.VOCAB_ROLE) is not None:
                value = None
            change_ok = layer.changeAttributeValue(feature_id, field_index, value)
            dock._related_edit_layers.add(layer_id)
            QgsMessageLog.logMessage(
                f"_on_related_tree_item_changed: layer='{layer.name()}' (id={layer_id}) feature_id={feature_id} "
                f"field='{field_name}' value='{value}' changeAttributeValue={change_ok} was_editable={was_editable}",
                "ToponymsManager",
                Qgis.Info
            )

            row_id_field = layer.fields().indexOf('xlsx_row_id')
            if layer is getattr(self, '_tabular_related_layer', None):
                anchor = self._tabular_feature_rows[feature_id]
                self.table.item(anchor.row(), field_index).setText(item.text(1))
            elif self.data_type in ('excel', 'csv') and row_id_field >= 0 and field_index < self.table.columnCount():
                self.update_cell(layer.getFeature(feature_id)[row_id_field], field_index, item.text(1))
            elif self.data_dict.get('type') == 'combined_gdb_view':
                self._update_combined_cell(layer, feature_id, field_name, value)

            layer.triggerRepaint()
            self._update_status(f"Updated {layer.name()}.{item.text(0)}")
            if field_name.strip().casefold() in (
                    'toponymic_feature_id', 'latitude_geosys', 'longitude_geosys'):
                self._refresh_related_duplicate_geosys_fields()
        except Exception as e:
            QgsMessageLog.logMessage(
                f"Error updating related feature attribute: {str(e)}",
                "ToponymsManager",
                Qgis.Warning
            )

    def _refresh_related_duplicate_geosys_fields(self):
        """Reapply row-specific Geosys locks after related-feature edits."""
        dock = getattr(self, '_related_features_dock', None)
        if dock is None:
            return

        selected_features_by_layer = dock._related_context[0]
        tree = dock._related_tree
        signals_blocked = tree.blockSignals(True)
        try:
            for group_index, (layer, features) in enumerate(selected_features_by_layer.items()):
                headers = [field.name() for field in layer.fields()]
                if layer is getattr(self, '_tabular_related_layer', None):
                    rows = [
                        [
                            self.table.item(row, column).text()
                            if self.table.item(row, column) is not None else ''
                            for column in range(self.table.columnCount())
                        ]
                        for row in range(self.table.rowCount())
                    ]
                    headers = self.data_dict.get('headers', headers)
                else:
                    rows = [feature.attributes() for feature in layer.getFeatures()]
                geosys_tfids_with_points = self._geosys_tfids_with_points(headers, rows)
                group = tree.topLevelItem(group_index)
                for feature_index, feature in enumerate(features):
                    feature_item = group.child(feature_index)
                    current_feature = layer.getFeature(feature.id())
                    duplicate = self._is_duplicate_geosys_row(
                        headers, current_feature.attributes(), geosys_tfids_with_points
                    )
                    for field_index in range(feature_item.childCount()):
                        field_item = feature_item.child(field_index)
                        if field_item.text(0).strip().casefold() not in self.GEOSYS_FIELDS:
                            continue
                        if duplicate:
                            field_item.setFlags(field_item.flags() & ~Qt.ItemIsEditable)
                            field_item.setToolTip(0, "This duplicate Geosys point is not editable.")
                            field_item.setToolTip(1, "This duplicate Geosys point is not editable.")
                            field_item.setData(1, self.DUPLICATE_GEOSYS_ROLE, True)
                        elif field_item.data(1, self.DUPLICATE_GEOSYS_ROLE):
                            field_item.setData(1, self.DUPLICATE_GEOSYS_ROLE, None)
                            field_item.setToolTip(0, "")
                            field_item.setToolTip(1, "")
                            if dock._related_editing:
                                field_item.setFlags(field_item.flags() | Qt.ItemIsEditable)
        finally:
            tree.blockSignals(signals_blocked)
    
    def closeEvent(self, event):
        """Treat a title-bar close as minimize; clean up on programmatic close."""
        if not getattr(self, '_allow_close', False):
            event.ignore()
            self._on_minimize()
            return

        try:
            dock = getattr(self, '_related_features_dock', None)
            if dock is not None:
                dock.close()
            table_layer = getattr(self, '_tabular_related_layer', None)
            if table_layer is not None:
                from qgis.core import QgsProject

                QgsProject.instance().removeMapLayer(table_layer.id())
                self._tabular_related_layer = None
            # Remove rubber band if it exists
            if hasattr(self, '_highlight_rubber_band') and self._highlight_rubber_band:
                self._highlight_rubber_band.reset()
                self._highlight_rubber_band = None
            
            # Clear layer selection
            if self.linked_layer:
                self.linked_layer.removeSelection()
        except Exception as e:
            QgsMessageLog.logMessage(
                f"Error cleaning up highlights: {str(e)}",
                "ToponymsManager",
                Qgis.Warning
            )
        
        # Call parent closeEvent
        super(DataTableDialog, self).closeEvent(event)
