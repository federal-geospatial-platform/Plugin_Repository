# -*- coding: utf-8 -*-
"""
Settings dialog for Toponyms Manager plugin.
"""

from qgis.PyQt import QtWidgets
from qgis.PyQt.QtWidgets import QDialog, QVBoxLayout, QLabel, QLineEdit, QPushButton, QHBoxLayout
from .plugin_settings import PluginSettings


class SettingsDialog(QDialog):
    """Dialog for plugin settings."""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Toponyms Manager Settings")
        self.setMinimumWidth(500)
        
        self.setup_ui()
        self.load_settings()
    
    def setup_ui(self):
        """Setup the user interface."""
        layout = QVBoxLayout()
        
        # FME Token
        layout.addWidget(QLabel("FME Token:"))
        self.token_input = QLineEdit()
        self.token_input.setEchoMode(QLineEdit.Password)
        self.token_input.setPlaceholderText("Enter your FME Flow authentication token")
        layout.addWidget(self.token_input)
        
        layout.addWidget(QLabel("<small>Generate this token in FME Flow under your user settings.</small>"))
        layout.addSpacing(10)
        
        # FME Repository
        layout.addWidget(QLabel("FME Repository:"))
        self.repository_input = QLineEdit()
        self.repository_input.setPlaceholderText("Toponymie")
        layout.addWidget(self.repository_input)
        layout.addSpacing(10)
        
        # FME Workspace
        layout.addWidget(QLabel("FME Workspace:"))
        self.workspace_input = QLineEdit()
        self.workspace_input.setPlaceholderText("toponymy_plugin_test.fmw")
        layout.addWidget(self.workspace_input)
        layout.addSpacing(20)
        
        # Buttons
        button_layout = QHBoxLayout()
        
        save_button = QPushButton("Save")
        save_button.clicked.connect(self.save_settings)
        button_layout.addWidget(save_button)
        
        cancel_button = QPushButton("Cancel")
        cancel_button.clicked.connect(self.reject)
        button_layout.addWidget(cancel_button)
        
        layout.addLayout(button_layout)
        
        self.setLayout(layout)
    
    def load_settings(self):
        """Load current settings."""
        self.token_input.setText(PluginSettings.get_fme_token())
        self.repository_input.setText(PluginSettings.get_fme_repository())
        self.workspace_input.setText(PluginSettings.get_fme_workspace())
    
    def save_settings(self):
        """Save settings."""
        PluginSettings.set_fme_token(self.token_input.text())
        PluginSettings.set_fme_repository(self.repository_input.text())
        PluginSettings.set_fme_workspace(self.workspace_input.text())
        self.accept()
