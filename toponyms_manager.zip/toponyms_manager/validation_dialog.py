# -*- coding: utf-8 -*-
"""Validation dialog for displaying batch-load checks in a status table."""

from qgis.PyQt import QtWidgets, QtGui, QtCore
from qgis.PyQt.QtCore import Qt


class ValidationDialog(QtWidgets.QDialog):
    """
    Dialog for displaying validation progress and results with visual indicators.
    """
    
    def __init__(self, parent=None):
        """Initialize validation dialog."""
        super(ValidationDialog, self).__init__(parent)
        
        self.validation_items = {}
        self._setup_ui()
        
    def _setup_ui(self):
        """Setup the user interface"""
        self.setWindowTitle("Batch Load File Validation")
        self.resize(700, 400)

        # Create main layout
        layout = QtWidgets.QVBoxLayout()
        
        # Title label
        title_label = QtWidgets.QLabel("<h2>Validating Batch Load File</h2>")
        title_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(title_label)
        
        # Create scroll area for validation results
        scroll_area = QtWidgets.QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setFrameShape(QtWidgets.QFrame.NoFrame)
        
        self.validation_table = QtWidgets.QTableWidget(0, 3)
        self.validation_table.setHorizontalHeaderLabels(["Validation", "Pass", "Fail"])
        self.validation_table.verticalHeader().setVisible(False)
        self.validation_table.setWordWrap(True)
        self.validation_table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.validation_table.setSelectionMode(QtWidgets.QAbstractItemView.NoSelection)
        header = self.validation_table.horizontalHeader()
        header.setSectionResizeMode(0, QtWidgets.QHeaderView.Stretch)
        header.setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeToContents)
        header.setSectionResizeMode(2, QtWidgets.QHeaderView.ResizeToContents)

        scroll_area.setWidget(self.validation_table)
        layout.addWidget(scroll_area, 1)  # Give scroll area stretch factor

        # Summary label
        self.summary_label = QtWidgets.QLabel("")
        self.summary_label.setWordWrap(True)
        self.summary_label.setStyleSheet("padding: 10px;")
        layout.addWidget(self.summary_label)
        
        # Button box
        button_box = QtWidgets.QDialogButtonBox()
        self.close_button = button_box.addButton("Close", QtWidgets.QDialogButtonBox.AcceptRole)
        self.close_button.clicked.connect(self.accept)
        self.close_button.setEnabled(False)  # Disabled until validation completes
        
        layout.addWidget(button_box)
        
        self.setLayout(layout)

    def add_section(self, title):
        """Add a source-layer heading above its validation results."""
        row = self.validation_table.rowCount()
        self.validation_table.insertRow(row)
        section_item = QtWidgets.QTableWidgetItem(title)
        font = section_item.font()
        font.setBold(True)
        section_item.setFont(font)
        self.validation_table.setItem(row, 0, section_item)
        self.validation_table.setSpan(row, 0, 1, 3)
        
    def add_validation(self, validation_id, description):
        """
        Add a validation item to the dialog.
        
        :param validation_id: Unique identifier for the validation
        :param description: Description of what is being validated
        """
        row = self.validation_table.rowCount()
        self.validation_table.insertRow(row)
        self.validation_table.insertRow(row + 1)
        self.validation_table.setItem(row, 0, QtWidgets.QTableWidgetItem(description))
        pass_item = QtWidgets.QTableWidgetItem("")
        fail_item = QtWidgets.QTableWidgetItem("")
        pass_item.setTextAlignment(Qt.AlignCenter)
        fail_item.setTextAlignment(Qt.AlignCenter)
        self.validation_table.setItem(row, 1, pass_item)
        self.validation_table.setItem(row, 2, fail_item)

        detail_item = QtWidgets.QTableWidgetItem("")
        detail_font = detail_item.font()
        detail_font.setPointSize(max(8, detail_font.pointSize() - 1))
        detail_font.setItalic(True)
        detail_item.setFont(detail_font)
        self.validation_table.setItem(row + 1, 0, detail_item)
        self.validation_table.setSpan(row + 1, 0, 1, 3)
        self.validation_table.setRowHidden(row + 1, True)

        self.validation_items[validation_id] = {
            'row': row,
            'detail_row': row + 1,
            'pass_item': pass_item,
            'fail_item': fail_item,
            'detail_item': detail_item,
            'status': 'pending'
        }
        
        # Force UI update
        QtWidgets.QApplication.processEvents()
        
    def update_validation(self, validation_id, status, message=""):
        """
        Update the status of a validation item.
        
        :param validation_id: Identifier of the validation to update
        :param status: Status - 'pass', 'fail', or 'pending'
        :param message: Optional message to display (typically for failures)
        """
        if validation_id not in self.validation_items:
            return
        
        item = self.validation_items[validation_id]
        item['status'] = status
        
        item['pass_item'].setText("")
        item['fail_item'].setText("")
        if status in ('pass', 'warning'):
            item['pass_item'].setText("✓")
        elif status == 'fail':
            item['fail_item'].setText("✓")

        detail = message
        if status == 'warning' and message:
            detail = f"Warning: {message}"
        item['detail_item'].setText(detail)
        self.validation_table.setRowHidden(
            item['detail_row'], not bool(detail)
        )
        self.validation_table.resizeRowsToContents()
        
        # Force UI update
        QtWidgets.QApplication.processEvents()
        
    def set_summary(self, passed, failed, warnings=0):
        """
        Set the summary message at the bottom of the dialog.
        
        :param passed: Number of validations that passed
        :param failed: Number of validations that failed
        :param warnings: Number of warnings
        """
        total = passed + failed + warnings
        
        if failed > 0:
            summary = f"Validation Failed: {failed} error(s), {passed} passed"
            if warnings > 0:
                summary += f", {warnings} warning(s)"
            summary += f" out of {total} checks."
        elif warnings > 0:
            summary = f"Validation Completed with Warnings: {warnings} warning(s), {passed} passed out of {total} checks."
        else:
            summary = f"Validation Passed: All {passed} checks completed successfully!"
        
        self.summary_label.setText(summary)
        
        # Enable close button
        self.close_button.setEnabled(True)
        
        # Force UI update
        QtWidgets.QApplication.processEvents()
        
    def get_results(self):
        """
        Get validation results.
        
        :return: Dictionary with counts and details
        """
        passed = sum(1 for item in self.validation_items.values() if item['status'] == 'pass')
        failed = sum(1 for item in self.validation_items.values() if item['status'] == 'fail')
        warnings = sum(1 for item in self.validation_items.values() if item['status'] == 'warning')
        
        return {
            'passed': passed,
            'failed': failed,
            'warnings': warnings,
            'total': len(self.validation_items),
            'success': failed == 0
        }
