# -*- coding: utf-8 -*-
"""
Data loading utilities for various file formats.
Provides generic data loaders for Excel, CSV, PostgreSQL, and QGIS layers.
"""

import os
import csv
from datetime import datetime

try:
    import openpyxl
except ImportError:
    openpyxl = None

try:
    import psycopg2
except ImportError:
    psycopg2 = None

from qgis.core import QgsMessageLog, Qgis, QgsVectorLayer


class DataLoadError(Exception):
    """Custom exception for data loading errors"""
    pass


class DataLoader:
    """Generic data loader for multiple file formats and data sources"""
    
    @staticmethod
    def load_excel(file_path, sheet_name=None):
        """
        Load Excel file and return as structured data.
        
        :param file_path: Path to Excel file
        :param sheet_name: Optional sheet name (uses active sheet if None)
        :return: Dictionary with metadata and data as list of lists
        :raises DataLoadError: If loading fails
        """
        if openpyxl is None:
            raise DataLoadError("openpyxl library is required to load Excel files")
        
        try:
            workbook = openpyxl.load_workbook(file_path)
            
            # Get sheet
            if sheet_name:
                if sheet_name not in workbook.sheetnames:
                    raise DataLoadError(f"Sheet '{sheet_name}' not found in workbook")
                sheet = workbook[sheet_name]
            else:
                sheet = workbook.active
                sheet_name = sheet.title
            
            # Extract data
            data = []
            for row in sheet.iter_rows(values_only=True):
                data.append(list(row))
            source_row_numbers = list(range(1, len(data) + 1))
            
            workbook.close()
            
            # Openpyxl often reports a used range larger than the actual data,
            # leaving trailing fully-empty rows; drop them (keep the header row).
            if data:
                header_row = data[0]
                filtered = [
                    (number, row) for number, row in enumerate(data[1:], start=2)
                    if any(cell is not None and str(cell).strip() != '' for cell in row)
                ]
                filtered_rows = [row for _number, row in filtered]
                source_row_numbers = [1] + [number for number, _row in filtered]
                removed = len(data) - 1 - len(filtered_rows)
                if removed:
                    QgsMessageLog.logMessage(
                        f"Removed {removed} empty row(s) from '{os.path.basename(file_path)}'",
                        "ToponymsManager",
                        Qgis.Info
                    )
                data = [header_row] + filtered_rows
            
            # Get headers (first row)
            headers = data[0] if data else []
            
            QgsMessageLog.logMessage(
                f"Loaded Excel file: {os.path.basename(file_path)} ({len(data)} rows)",
                "ToponymsManager",
                Qgis.Info
            )
            
            return {
                'type': 'excel',
                'source': file_path,
                'sheet_name': sheet_name,
                'headers': headers,
                'data': data,
                'source_row_numbers': source_row_numbers,
                'row_count': len(data),
                'column_count': len(headers) if headers else 0
            }
            
        except Exception as e:
            raise DataLoadError(f"Failed to load Excel file: {str(e)}")
    
    @staticmethod
    def get_excel_sheets(file_path):
        """
        Get list of sheet names from Excel file.
        
        :param file_path: Path to Excel file
        :return: List of sheet names
        :raises DataLoadError: If file cannot be read
        """
        if openpyxl is None:
            raise DataLoadError("openpyxl library is required")
        
        try:
            workbook = openpyxl.load_workbook(file_path, read_only=True)
            sheet_names = workbook.sheetnames
            workbook.close()
            return sheet_names
        except Exception as e:
            raise DataLoadError(f"Failed to read Excel file: {str(e)}")
    
    @staticmethod
    def load_csv(file_path, delimiter=',', encoding='utf-8', has_header=True):
        """
        Load CSV file and return as structured data.
        
        :param file_path: Path to CSV file
        :param delimiter: CSV delimiter (default: comma)
        :param encoding: File encoding (default: utf-8)
        :param has_header: Whether first row is a header
        :return: Dictionary with metadata and data
        :raises DataLoadError: If loading fails
        """
        try:
            data = []
            with open(file_path, 'r', encoding=encoding, newline='') as f:
                reader = csv.reader(f, delimiter=delimiter)
                for row in reader:
                    data.append(row)
            source_row_numbers = list(range(1, len(data) + 1))
            
            # Drop fully-empty rows, keeping the header row if present
            if data:
                start = 1 if has_header else 0
                header_rows = data[:start]
                filtered = [
                    (number, row) for number, row in enumerate(data[start:], start=start + 1)
                    if any(cell is not None and str(cell).strip() != '' for cell in row)
                ]
                filtered_rows = [row for _number, row in filtered]
                source_row_numbers = source_row_numbers[:start] + [number for number, _row in filtered]
                data = header_rows + filtered_rows
            
            headers = data[0] if data and has_header else []
            
            QgsMessageLog.logMessage(
                f"Loaded CSV file: {os.path.basename(file_path)} ({len(data)} rows)",
                "ToponymsManager",
                Qgis.Info
            )
            
            return {
                'type': 'csv',
                'source': file_path,
                'headers': headers,
                'data': data,
                'source_row_numbers': source_row_numbers,
                'row_count': len(data),
                'column_count': len(headers) if headers else (len(data[0]) if data else 0),
                'encoding': encoding,
                'delimiter': delimiter
            }
            
        except Exception as e:
            raise DataLoadError(f"Failed to load CSV file: {str(e)}")
    
    @staticmethod
    def load_postgres_table(host, database, user, password, table_name, port=5432, schema='public'):
        """
        Load PostgreSQL table and return as structured data.
        
        :param host: Database host
        :param database: Database name
        :param user: Database user
        :param password: Database password
        :param table_name: Table name
        :param port: Database port (default: 5432)
        :param schema: Schema name (default: public)
        :return: Dictionary with metadata and data
        :raises DataLoadError: If connection or query fails
        """
        if psycopg2 is None:
            raise DataLoadError("psycopg2 library is required to connect to PostgreSQL")
        
        try:
            # Connect to database
            conn = psycopg2.connect(
                host=host,
                database=database,
                user=user,
                password=password,
                port=port
            )
            
            cursor = conn.cursor()
            
            # Get column names
            cursor.execute(f"""
                SELECT column_name 
                FROM information_schema.columns 
                WHERE table_schema = %s AND table_name = %s
                ORDER BY ordinal_position
            """, (schema, table_name))
            
            headers = [row[0] for row in cursor.fetchall()]
            
            # Get data
            cursor.execute(f'SELECT * FROM "{schema}"."{table_name}"')
            rows = cursor.fetchall()
            
            # Convert to list of lists
            data = [headers] + [list(row) for row in rows]
            
            cursor.close()
            conn.close()
            
            QgsMessageLog.logMessage(
                f"Loaded PostgreSQL table: {schema}.{table_name} ({len(rows)} rows)",
                "ToponymsManager",
                Qgis.Info
            )
            
            return {
                'type': 'postgresql',
                'source': f"{host}/{database}",
                'table_name': table_name,
                'schema': schema,
                'headers': headers,
                'data': data,
                'row_count': len(data),
                'column_count': len(headers)
            }
            
        except Exception as e:
            raise DataLoadError(f"Failed to load PostgreSQL table: {str(e)}")
    
    @staticmethod
    def load_qgis_layer(layer_name_or_path):
        """
        Load QGIS vector layer and return as structured data.
        
        :param layer_name_or_path: Layer name from QGIS project or file path
        :return: Dictionary with metadata and data
        :raises DataLoadError: If layer cannot be loaded
        """
        try:
            from qgis.core import QgsProject
            
            # Try to get layer from project first
            layer = QgsProject.instance().mapLayersByName(layer_name_or_path)
            if layer:
                layer = layer[0]
            else:
                # Try to load as file
                layer = QgsVectorLayer(layer_name_or_path, "temp_layer", "ogr")
                if not layer.isValid():
                    raise DataLoadError(f"Failed to load layer: {layer_name_or_path}")
            
            # Get field names
            headers = [field.name() for field in layer.fields()]
            
            # Get features
            data = [headers]
            for feature in layer.getFeatures():
                data.append([feature[field] for field in headers])
            
            QgsMessageLog.logMessage(
                f"Loaded QGIS layer: {layer.name()} ({layer.featureCount()} features)",
                "ToponymsManager",
                Qgis.Info
            )
            
            return {
                'type': 'qgis_layer',
                'source': layer.source(),
                'layer_name': layer.name(),
                'headers': headers,
                'data': data,
                'row_count': len(data),
                'column_count': len(headers),
                'geometry_type': layer.geometryType()
            }
            
        except Exception as e:
            raise DataLoadError(f"Failed to load QGIS layer: {str(e)}")
    
    @staticmethod
    def save_to_excel(data_dict, output_path, sheet_name='Sheet1'):
        """
        Save structured data to Excel file.
        
        :param data_dict: Dictionary containing 'data' key with list of lists
        :param output_path: Output file path
        :param sheet_name: Sheet name (default: Sheet1)
        :raises DataLoadError: If save fails
        """
        if openpyxl is None:
            raise DataLoadError("openpyxl library is required to save Excel files")
        
        try:
            # Use write_only mode to avoid font copying issues that can cause
            # access violations on Windows systems with certain openpyxl versions
            workbook = openpyxl.Workbook(write_only=True)
            sheet = workbook.create_sheet(sheet_name)
            
            # In write_only mode, we must write entire rows at once
            for row_data in data_dict['data']:
                processed_row = []
                for value in row_data:
                    # Try to convert to appropriate type
                    try:
                        if value and isinstance(value, str):
                            if '.' in value and value.replace('.', '', 1).replace('-', '', 1).isdigit():
                                value = float(value)
                            elif value.isdigit() or (value.startswith('-') and value[1:].isdigit()):
                                value = int(value)
                    except (ValueError, AttributeError):
                        pass
                    processed_row.append(value)
                sheet.append(processed_row)
            
            workbook.save(output_path)
            workbook.close()
            
            QgsMessageLog.logMessage(
                f"Saved Excel file: {output_path}",
                "ToponymsManager",
                Qgis.Success
            )
            
        except Exception as e:
            raise DataLoadError(f"Failed to save Excel file: {str(e)}")
