print(45)
# print the path of python.exe being executed
import sys
print(sys.executable)
# print the path of the current script
import os
print(os.path.realpath(__file__))
