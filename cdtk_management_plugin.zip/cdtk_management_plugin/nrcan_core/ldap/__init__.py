"""
This package offers ldap connection.
"""

# 3rd party imports
from nrcan_core import config_env
from . import ldap

# Create the database connection object which is GLOBAL
ldap_conn = ldap.LDAPConnection(host=config_env.AWS_SECRET_VALUE['LDAP']['HOST'],
                                port=config_env.AWS_SECRET_VALUE['LDAP']['PORT'],
                                root_dn=config_env.AWS_SECRET_VALUE['LDAP']['ROOT_DN'],
                                bind_user=config_env.AWS_SECRET_VALUE['LDAP']['BIND_USER'],
                                bind_password=config_env.AWS_SECRET_VALUE['LDAP']['BIND_PASSWORD'])
