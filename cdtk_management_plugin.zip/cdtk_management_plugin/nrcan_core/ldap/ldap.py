from typing import Any
from ldap3 import Server, Connection, ALL, AUTO_BIND_NONE, SUBTREE


class LDAPConnection(object):
    """
    Class representing a LDAP connection.
    """

    def __init__(self, host: str, port: int, root_dn: str, bind_user: str, bind_password: str) -> None:
        """Constructor"""

        self.host: str = f"ldap://{host}:{port}"
        self.root_dn: str = root_dn
        self.bind_user: str = bind_user
        self.bind_password: str = bind_password


    def _init_connection(self) -> Connection:
        return self._init_bind(self.bind_user, self.bind_password)


    def _init_bind(self, username: str, password: str) -> Connection:
        # Init server
        server = Server(self.host, get_info=ALL)

        # Connect
        conn = Connection(server,
                          user=f'cn={username},{self.root_dn}',
                          password=password, auto_bind=AUTO_BIND_NONE)

        # Bind and return
        if conn.bind():
            #print(f" *** Response from the ldap bind is \n{conn}")
            #print(f" *** Response from the ldap bind is \n{conn.result}")
            #print(f" *** User is \n{conn.extend.standard.who_am_i()}")
            return conn

        else:
            print(f" *** Cannot bind to ldap server: {conn.last_error} ")
            print(f" *** Response from the ldap bind is \n{conn}" )
            raise Exception("Unable to bind in ldap")


    def query_user(self, username: str, password: str, ldap_attribute_key: str, ldap_attribute_display: str = "uid") -> dict[str, str] | None:
        try:
            # Look for the user
            entries = self.search(username, ldap_attribute_key)

            # If found
            if entries and len(entries) > 0:
                ldap_key = entries[0]['cn'][0]

                # Try to bind on the user themself using their password as provided.
                # This will throw an Exception if binding is impossible.
                with self._init_bind(ldap_key, password) as conn2:
                    id = entries[0][ldap_attribute_key][0]
                    username = entries[0][ldap_attribute_display][0]
                    return {'id': id, 'username': username}

        except (Exception,) as err:
            print(err)

        return None


    def search(self, username_to_search: str, ldap_attribute_key: str) -> Any:
        # Open connection
        with self._init_connection() as conn:
            # Search for the user
            conn.search(self.root_dn,
                        "(&(objectClass=person)(" + ldap_attribute_key + "=" + username_to_search + "))",
                        SUBTREE,
                        attributes=['*'])

            # Return the entries
            return conn.entries


    def add_user(self, sn_id: int, username_to_add: str, password_to_add: str, email_to_add: str, given_name: str) -> bool:
         # Open connection
        with self._init_connection() as conn:
            # Add the user
            conn.add(dn=f'cn={username_to_add},{self.root_dn}', attributes={
                'objectClass':  ['inetOrgPerson', 'top'],
                'sn': sn_id,
                'uid': username_to_add,
                'userPassword': password_to_add,
                #'gidNumber': 0,
                #'uidNumber': 14583103,
                #'homeDirectory': "/home/" + username_to_add,
                'givenName': given_name,
                #'gecos': username_to_add + " User",
                'mail': email_to_add
            })

            # If success
            if conn.result['result'] == 0:
                return True

            print(conn.result)
            raise Exception("Unable to add user in ldap")


    def delete_user(self, username_to_delete: str) -> bool:
         # Open connection
        with self._init_connection() as conn:
            # Delete the user
            conn.delete(dn=f'cn={username_to_delete},{self.root_dn}')

            # If success
            if conn.result['result'] == 0:
                return True

            print(conn.result)
            raise Exception("Unable to delete user in ldap")

