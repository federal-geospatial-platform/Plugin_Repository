"""Docstring"""

from nrcan_core import config_env
from nrcan_core.requests.cdtk_request import CDTKRequest


class CDTKRequestPublicationAPI(CDTKRequest):
    """Helper class to perform requests to the CDTK Publication API"""

    # Use __slots__ to disable dynamic attribute creation in order to control them at the class level
    __slots__: list[str] = ['api_key']


    def __init__(self, api_key: str) -> None:
        """Constructor"""

        # Call parent
        super().__init__(config_env.CDTK_PUBLICATION_URL)

        # Set the api key
        self.api_key = api_key


    def get_info_schema(self, schema: str) -> dict | None:
        # Call get or none
        return self.getOrNone(f"/services/{schema}")


    def get_info_schema_service(self, schema: str, service_name: str) -> dict | None:
        # Call get or none
        return self.getOrNone(f"/services/{schema}/{service_name}")


    def get_folders(self) -> dict | None:
        # Call get or none
        return self.getOrNone(f"/folders")
