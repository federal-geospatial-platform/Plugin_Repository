"""Docstring"""

import requests
from requests import Response

from ...nrcan_core.lib.exceptions import ApplicationException, UserMessageException
from ...nrcan_core.lib.cdtk_message import CDTKMessage


class CDTKRequest(object):
    """
    Helper class to perform get/post/patch/delete requests
    """

    def __init__(self, root_url: str, message: CDTKMessage | None = None) -> None:
        """Constructor"""

        self.root_url: str = root_url
        self.message: CDTKMessage | None = message
        self.access_token: str | None = None
        self.api_key: str | None = None


    def getOrNone(self, url_endpoint: str, payload: dict = {}) -> dict | None:
        # Call get
        res: Response | None = self._get(url_endpoint, payload, [200, 404], True)

        # If responded and 200
        if res and res.status_code == 200:
            return res.json()

        # 404 was returned, so none
        return None


    def getOrEmptyList(self, url_endpoint: str, payload: dict = {}) -> list:
        # Call get
        res: Response | None = self._get(url_endpoint, payload, [200, 404], True)

        # If responded and 200
        if res and res.status_code == 200:
            return res.json()

        # 404 was returned, so empty list
        return []


    def postOrNone(self, url_endpoint: str, payload: dict = {}) -> dict | None:
        # Call post
        res: Response | None = self._post(url_endpoint, payload, [200, 201], True)

        # If responded
        if res:
            # Return some body? (can be None here?)
            return res.json()

        # Unreachable code, because when it's not 200 or 201, an exception is raised
        raise ApplicationException("Unreachable code by logic")


    def put201(self, url_endpoint: str, payload: dict = {}) -> dict:
        # Call put
        res: Response | None = self._put(url_endpoint, payload, [201], True)

        # If responded
        if res:
            # Return the body
            return res.json()

        # Unreachable code, because when it's not 201, an exception is raised
        raise ApplicationException("Unreachable code by logic")


    def put204(self, url_endpoint: str, payload: dict = {}) -> None:
        # Call put
        res: Response | None = self._put(url_endpoint, payload, [204], True)

        # If responded
        if res:
            # Return no body
            return None

        # Unreachable code, because when it's not 204, an exception is raised
        raise ApplicationException("Unreachable code by logic")


    def delete204(self, url_endpoint: str, payload: dict = {}) -> bool:
        # Call delete
        res: Response | None = self._delete(url_endpoint, payload, [204, 404], False)

        # If responded and 204 (it could be another status, because error_raise is False)
        return bool(res and res.status_code == 204)


    def _get(self, url_endpoint: str, payload: dict, filter_res_code=None, if_error_raise=True) -> Response | None:
        """Wraps a get request"""

        return self._request_call("get", self.root_url + url_endpoint, payload, filter_res_code, if_error_raise)


    def _post(self, url_endpoint: str, payload: dict | None = None, filter_res_code=None, if_error_raise=True, files=None,
              data: dict | None = None) -> Response | None:
        """Wraps a post request"""

        return self._request_call("post", self.root_url + url_endpoint, payload, filter_res_code, if_error_raise, files, data)


    def _put(self, url_endpoint: str, payload: dict, filter_res_code=None, if_error_raise=True, files=None) -> Response | None:
        """Wraps a put request"""

        return self._request_call("put", self.root_url + url_endpoint, payload, filter_res_code, if_error_raise, files)


    def _delete(self, url_endpoint: str, payload: dict | None, filter_res_code=None, if_error_raise=True, files=None) -> Response | None:
        """Wraps a delete request"""

        return self._request_call("delete", self.root_url + url_endpoint, payload, filter_res_code, if_error_raise, files)


    def _request_call(self, request_type: str, full_url_address: str, payload: dict | None = None, filter_res_code=None, 
                      if_error_raise=True, files=None, data=None) -> Response | None:
        """This method is doing
            - The request call: Post, Put, Get or Delete
            - Manage the response code
            - Raise an exception if requested
        """
        headers: dict[str, str] | None = None
        if self.api_key:
            headers = {'x-API-key': self.api_key}

        if self.access_token:
            headers = headers or {}
            headers['Authorization'] = "Bearer " + self.access_token

        # The response
        res: Response | None = None
        try:
            if request_type == "get":
                res = requests.get(full_url_address, headers=headers)
            elif request_type == "put":
                res = requests.put(full_url_address, headers=headers, json=payload,  files=files)
            elif request_type == "post":
                res = requests.post(full_url_address, headers=headers, json=payload, files=files, data=data)
            elif request_type == "delete":
                res = requests.delete(full_url_address, headers=headers, files=files)
            else:
                raise ApplicationException("Invalid request type in _request_call function")

        except Exception as err:
            # If using the message class
            if self.message:
                # Raise error
                self.message.add_error_raise("Communication failure.", "Erreur de communication.", err)

            # Raise naturally
            raise UserMessageException(500, "Communication failure.", "Erreur de communication.", err)

        # Here, requests has returned something
        if res is not None:
            # Check the result code
            msg_en: str = ""
            msg_fr: str = ""
            if filter_res_code is None or len(filter_res_code) == 0:
                # If filter responde code is empty return everything
                return res

            if res.status_code in filter_res_code:
                # Return code specified to be returned
                return res

            elif res.status_code == 400:
                msg_fr = "Bad request received on server."
                msg_en = "Mauvaise requête reçu sur le serveur."

            elif res.status_code == 401:
                msg_en = "Invalid credentials provided."
                msg_fr = "Identification invalide fourni."

            elif res.status_code == 403:
                msg_en = "Access token does not have the required scope."
                msg_fr = "Le jeton d'accès n'a pas la valeur requise."

            elif res.status_code == 404:
                msg_en = f"The requested resource (URI) was not found in the Registry of the CDTK: {full_url_address}"
                msg_fr = f"La ressource demandé (URI) n'a pas été trouvé dans le registre du CDTK: {full_url_address}."

            else:
                msg_en = "Internal server error."
                msg_fr = "Erreur interne du serveur."

            # Create the UserMessageException
            user_msg_exc: UserMessageException = _create_exception_with_detail(res, msg_en, msg_fr)

            # If using the message class
            if self.message:
                # Add error
                self.message.add_error_exception(user_msg_exc)

            # If raise on error
            if if_error_raise:
                # If using the message class
                if self.message:
                    # Abort
                    self.message.if_errors_raise()

                # Raise naturally
                raise user_msg_exc

        return res


def _create_exception_with_detail(response: Response, msg_en: str, msg_fr) -> UserMessageException:
    detail: str = " | " + response.json()['detail'] if "detail" in response.json() else ""
    detail_fr: str = " | " + response.json()['detail_fr'] if "detail_fr" in response.json() else ""
    return UserMessageException(response.status_code, msg_en + detail, msg_fr + detail_fr)
