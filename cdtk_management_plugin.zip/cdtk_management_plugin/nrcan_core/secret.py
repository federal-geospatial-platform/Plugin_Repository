"""
This module handles the management of configuration values and secrets used in the application.
It retrieves secrets from environment variables (e.g., OS or Rancher).
"""

import os, json
from nrcan_core import config_env

# AWS region for fetching secrets
AWS_REGION_NAME: str = "ca-central-1"

# Caching the API secrets once gathered. Useful for mocking in tests.
SECRETS_API: dict | None = None

# Caching the QGIS database secrets once gathered. Useful for mocking in tests.
SECRETS_DB_QGIS: dict | None = None


def get_secrets_by_key(secret_key: str) -> dict:
    """
    Retrieves the secret associated with the given key.

    Args:
        secret_key (str): The key identifying the secret to retrieve.

    Returns:
        dict: The secret data, in dictionary format, for the given key.

    Raises:
        KeyError: If the secret key is not found in the environment variables.
    """

    # If not using AWS, fallback to Rancher (environment variables)
    value: str | None = os.environ.get(secret_key)

    # If not found
    if not value:
        # Try the Dockerfile local container mode which doesn't support '-' characters
        value = os.environ.get(secret_key.replace("-", "_"))

    # If found
    if value:
        try:
            # Parse the secret value from the environment variable (JSON format)
            return json.loads(value)
        except Exception as error:
            raise KeyError(f'Failed to read secret {secret_key}. {error}')

    # Raise an error if the secret key is not found in the environment variables
    raise KeyError(f'Missing environment variable {secret_key} to read secret from.')


def _get_secrets_api() -> dict:
    """
    Retrieves the API secrets. This will fetch and cache the secrets the first time it is called.
    Subsequent calls will return the cached secrets.

    Returns:
        dict: The cached API secrets.
    """
    global SECRETS_API

    # If the API secrets haven't been retrieved yet, fetch them now
    if not SECRETS_API:
        # Fetch and cache the secrets using the provided secret key
        SECRETS_API = get_secrets_by_key(config_env.SECRET_KEY)

    return SECRETS_API


def get_secrets_db_qgis() -> dict:
    """
    Retrieves the QGIS database secrets.
    These secrets are cached after the first retrieval to avoid fetching them repeatedly.

    Returns:
        dict: The cached QGIS database secrets.
    """
    global SECRETS_DB_QGIS

    # If the QGIS database secrets haven't been fetched yet, fetch them now
    if not SECRETS_DB_QGIS:
        # Fetch and cache the secrets using the QGIS secret key
        SECRETS_DB_QGIS = get_secrets_by_key(config_env.DB_QGIS_KEY)

    return SECRETS_DB_QGIS


def get_secret_web_token_api() -> str:
    """
    Retrieves the API token used for web authentication from the API secrets.

    Returns:
        str: The web token for API authentication.
    """
    return _get_secrets_api()['WEB']['TOKEN_API']


def get_secret_oauth_id() -> str:
    """
    Retrieves the OAuth ID based on whether the application is running in local or production environment.

    Returns:
        str: The OAuth ID.
    """
    # Return the production OAuth ID
    return _get_secrets_api()['OAUTH']['ID']


def get_secret_oauth_redirect_uri() -> str:
    """
    Retrieves the OAuth redirect URI based on whether the application is running locally or in production.

    Returns:
        str: The OAuth redirect URI.
    """
    # Return the production redirect URI
    return _get_secrets_api()['OAUTH']['REDIRECT_URI']


def get_secret_oauth_secret() -> str:
    """
    Retrieves the OAuth secret based on whether the application is running locally or in production.

    Returns:
        str: The OAuth secret.
    """
    # Return the production OAuth secret
    return _get_secrets_api()['OAUTH']['SECRET']


def get_secret_email_config() -> dict:
    """
    Retrieves the email configuration secrets (such as SMTP settings) from the API secrets.

    Returns:
        dict: The email configuration details.
    """
    return _get_secrets_api()['EMAIL']


def get_secret_api_registry_api_key() -> str:
    """
    Retrieves the API key for the registry API from the API secrets.

    Returns:
        str: The API registry key.
    """
    return _get_secrets_api()['API_REGISTRY']['APIKEY']


def get_secret_api_publication_api_key() -> str:
    """
    Retrieves the API key for the publication API from the API secrets.

    Returns:
        str: The API publication key.
    """
    return _get_secrets_api()['API_PUBLICATION']['APIKEY']


def get_secret_db_publisher_host() -> str:
    """
    Retrieves the host address for the database publisher from the API secrets.

    Returns:
        str: The host address for the database publisher.
    """
    return _get_secrets_api()['DB_PUBLISHER']['HOST']


def get_secret_db_publisher_port() -> int:
    """
    Retrieves the port number for the database publisher from the API secrets.

    Returns:
        int: The port number for the database publisher.
    """
    return _get_secrets_api()['DB_PUBLISHER']['PORT']


def get_secret_db_publisher_name() -> str:
    """
    Retrieves the name of the database publisher from the API secrets.

    Returns:
        str: The name of the database publisher.
    """
    return _get_secrets_api()['DB_PUBLISHER']['NAME']


def get_secret_db_publisher_schema() -> str:
    """
    Retrieves the schema name for the database publisher from the API secrets.

    Returns:
        str: The schema name for the database publisher.
    """
    return _get_secrets_api()['DB_PUBLISHER']['SCHEMA']


def get_secret_db_publisher_user() -> str:
    """
    Retrieves the username for the database publisher from the API secrets.

    Returns:
        str: The username for the database publisher.
    """
    return _get_secrets_api()['DB_PUBLISHER']['USER']


def get_secret_db_publisher_password() -> str:
    """
    Retrieves the password for the database publisher from the API secrets.

    Returns:
        str: The password for the database publisher.
    """
    return _get_secrets_api()['DB_PUBLISHER']['PASS']
