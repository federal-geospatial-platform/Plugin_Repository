"""
This module stores all configurations used by this application.
"""

import logging

# Environment name
ENV_NAME: str = 'LOCAL'
IS_LOCAL: bool = True

FAKE_OAUTH: bool = False
USER_LOCAL: str = 'alexandre.roy@nrcan-rncan.gc.ca'  # This config is only used when debugging. It does not exist for other environments.

# The log parameters
LOG_FILE: str = r"c:\temp\output.log"
LOG_LEVEL_CONSOLE: int = logging.DEBUG
LOG_LEVEL_FILE: int = logging.DEBUG  # 5  # Trace level

# Determine if setting allow-origin for CORS
USE_CORS: bool = True

# Running port
PORT_API: int = 5031
PORT_WEB: int = 5030

# Secret key
SECRET_KEY: str = "cdtk-api-publication-dev"
DB_QGIS_KEY: str = "cdtk-postgis-datastore-dev"

# For the WEB interface to call the API
API_URL: str = "http://localhost:5031/api"
# For the WEB interface to indicate url to user
WEB_REGISTRY_URL: str = "http://localhost:5020"
# For the WEB interface to call pygeoapi
PYGEOAPI_URL: str = "http://localhost:5000"

# CDTK Registry and Publication URLs for internal communication
CDTK_REGISTRY_URL: str = "http://localhost:5021/api"
CDTK_PUBLICATION_URL: str = "http://localhost:5031/api"

# Email configs
EMAIL_ADMIN_CONTENT: list[str] = [] # Ignored when running local (in config_env)
EMAIL_TIMEOUT: int = 5

# QGIS configs
QGIS_JOBS_PATH: str = "..\\jobs"
QGIS_IN_PACKAGES_PATH: str = "..\\in_packs"
QGIS_PROJECTS_PATH: str = "..\\data"
QGIS_PYTHON_PATH: str = "nrcan_qgis"
