import emails

from core.lib.logger import *
from nrcan_core import config, config_env, util
from nrcan_core.lib.exceptions import *
from nrcan_core.lib.cdtk_message import CDTKMessage


def send_emails(action: str, config_email: dict, to_email_user: str, publisher_name: str, message: CDTKMessage, html_services: dict) -> None:
    """
    Utility function creating a CDTK Email class and sending email
    """
    LOG.trace_func()

    # Get the to email (overridden when running local!)
    to_email_user = config.EMAIL_USER(to_email_user)

    # Instantiate the email class
    cdtk_email = CDTKEmail(to_email_user, publisher_name, config_email, config_env.EMAIL_TIMEOUT)

    # If running in local mode
    email_admins: list[str] = config_env.EMAIL_ADMIN_CONTENT
    if config_env.IS_LOCAL:
        email_admins = [to_email_user]

    # Send emails
    cdtk_email.send_emails(action, email_admins, message, html_services)


class CDTKEmail(object):
    """
    Class to send Emails related to the Publication process.
    """

    def __init__(self, to_email_user: str, publisher_name: str, config_email: dict, email_timeout: int) -> None:
        """Constructor"""
        self.to_email_user: str = to_email_user
        self.publisher_name: str = publisher_name
        self.config_email: dict = config_email
        self.email_timeout: int = email_timeout


    def send_emails(self, action: str, to_email_admins: list, message: CDTKMessage, html_services: dict) -> None:
        """
        Sends emails about what has happened.
        """
        LOG.trace_func()

        # Keep track
        message.add_progress("Sending emails", "Envoi courriels")

        if self.to_email_user is not None:
            # Prepare the email
            email_message = emails.html(
                html=self.build_body_user(action, message, html_services),
                subject="Résultat de votre requête au CDTK / Result of your CDTK request",
                mail_from=self.config_email['FROM']
            )

            # Send the email
            r = email_message.send(
                to=self.to_email_user,
                smtp={
                    'host': self.config_email['HOST'],
                    'port': self.config_email['PORT'],
                    'timeout': self.email_timeout,
                    'user': self.config_email['USER'],
                    'password': self.config_email['PASS'],
                    'tls': True
                }
            )
        else:
            message.add_progress("No email sent to the user (unknown address)", "Aucun courriel envoyé à l'usager (adresse inconnu)")

        # If there was some error
        if message.errors or message.big_error:
            # Prepare the email
            email_message: emails.Message = emails.html(
                html=self.build_body_admin(action, message),
                subject="Résultat d'une requête au CDTK / Result of a CDTK request",
                mail_from=self.config_email['FROM']
            )

            # Send the email
            r = email_message.send(
                to=to_email_admins,
                smtp={
                    'host': self.config_email['HOST'],
                    'port': self.config_email['PORT'],
                    'timeout': self.email_timeout,
                    'user': self.config_email['USER'],
                    'password': self.config_email['PASS'],
                    'tls': True
                }
            )


    def build_body_user(self, action: str, message: CDTKMessage, html_services: dict) -> str:
        """Builds the body message of the email"""
        LOG.trace_func()

        # Read the warnings
        [english_warnings, french_warnings] = util.combine_warnings_for_response(message.warnings, prefix="<li>", suffix="</li>")

        # If the process was a success
        html_title_color = "#1877f2"
        html_title = "Succès de l'opération de publication / Success of the publication process"
        if action == 'Update':
            html_title = "Succès de l'opération de mise-à-jour / Success of the update process"
        elif action == 'Unpublish':
            html_title = "Succès de l'opération de dépublication / Success of the unpublication process"

        #
        # French version
        #
        html_content: str = "<i>(English message follows)</i><br/><br/>"
        if self.publisher_name is not None:
            html_content = html_content + f"Bonjour {self.publisher_name},<br/><br/>"
        else:
            html_content = html_content + "Bonjour,<br/><br/>"

        if not message.errors and not message.big_error:
            html_content += html_services['french']

        # If there's been a major error the user shouldn't necessary know the details
        user_msg: UserMessageException | None = None
        if message.big_error and not message.errors:
            html_title_color = "#e80000"
            html_title = "Échec de l'opération de publication / Failure of the publication process"
            if action == 'Update':
                html_title = "Échec de l'opération de mise-à-jour / Failure of the update process"
            elif action == 'Unpublish':
                html_title = "Échec de l'opération de dépublication / Failure of the unpublication process"

            html_content = html_content + f"Un incident est survenu. Un administrateur a été immédiatement informé. <a href=\"mailto:{self.config_email['FROM']}\">SVP contactez nous</a>.<br/><br/>"

        # If there's been an issue the user should be informed
        elif message.errors:
            html_title_color = "#e80000"
            html_title = "Échec de l'opération de publication / Failure of the publication process"
            if action == 'Update':
                html_title = "Échec de l'opération de mise-à-jour / Failure of the update process"
            elif action == 'Unpublish':
                html_title = "Échec de l'opération de dépublication / Failure of the unpublication process"

            user_msg = util.combine_exceptions_for_response(message.errors, prefix="<li>", suffix="</li>")
            html_content = html_content + f"L'opération a échoué pour la (les) raison(s) suivantes:<ul>{user_msg.message_fr}</ul><br/>"

        # If there was any warning
        if message.warnings:
            html_content = html_content + f"Les avertissements suivants sont survenus:<ul>{french_warnings}</ul><br/>"

        # French closing
        html_content = html_content + f"<div>Merci,<br/>L'équipe du CODC<br/><i>Avez-vous besoin d'aide pour votre service cartographique? <a href=\"mailto:{self.config_email['FROM']}\">Contactez notre équipe</a>.</i></div>"
        html_content = html_content + "<br/>-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------<br/><br/>"

        #
        # English version
        #
        if self.publisher_name is not None:
            html_content = html_content + f"Hi {self.publisher_name},<br/><br/>"
        else:
            html_content = html_content + "Hi,<br/><br/>"

        if not message.errors and not message.big_error:
            html_content += html_services['english']

        if message.big_error and not message.errors:
            html_content = html_content + f"An error happened. A CDTK admin has been immediately notified. <a href=\"mailto:{self.config_email['FROM']}\">Please contact us</a>.<br/><br/>"

        elif user_msg:
            html_content = html_content + f"The operation failed due to the following reason(s):<ul>{user_msg.message}</ul><br/>"

        # If there was any warning
        if message.warnings:
            html_content = html_content + f"The following warnings happened:<ul>{english_warnings}</ul><br/>"

        # English closing
        html_content = html_content + f"<div>Thanks,<br/>The CDTK Team<br/><i>Need help with your map service? <a href=\"mailto:{self.config_email['FROM']}\">Contact our team</a>.</i></div>"

        # Global Footer
        html_footer_sent_to = f"<br/><br/>Ce message a été envoyé automatiquement à / This message was automatically sent to : <a href='mailto:{self.to_email_user}' style='color:#1b74e4;text-decoration:none' target='_blank'>{self.to_email_user}</a>"

        # Redirect
        return CDTKEmail.build_body(html_title, html_title_color, html_content, html_footer_sent_to)


    def build_body_admin(self, action: str, message: CDTKMessage) -> str:
        """Builds the email body for the administrator"""
        LOG.trace_func()

        # Read the progress marks
        [english_log, french_log] = util.combine_progress_marks_for_response(message.progress_marks, prefix="<li>", suffix="</li>")

        # Read the warnings
        [english_warnings, french_warnings] = util.combine_warnings_for_response(message.warnings, prefix="<li>", suffix="</li>")

        # Titles
        html_title_color = "#e80000"
        html_title = "Échec de l'opération de publication / Failure of the publication process"
        if action == 'Update':
            html_title = "Échec de l'opération de mise-à-jour / Failure of the update process"
        elif action == 'Unpublish':
            html_title = "Échec de l'opération de dépublication / Failure of the unpublication process"

        #
        # French version
        #
        html_content: str = "<i>(English message follows)</i><br/><br/>"
        html_content = html_content + f"Bonjour à l'administrateur,<br/><i style='font-size:smaller;'>éditeur: {self.publisher_name}</i><br/><br/>"

        if action == 'Publish':
            html_content = html_content + f"La requête de publication a échoué.<br/><br/>"
        elif action == 'Update':
            html_content = html_content + f"La requête de mise-à-jour a échoué.<br/><br/>"
        elif action == 'Unpublish':
            html_content = html_content + f"La requête de dépublication a échoué.<br/><br/>"

        # If there was any errors
        user_msg: UserMessageException | None = None
        if message.errors:
            user_msg = util.combine_exceptions_for_response(message.errors, admin=True, prefix="<li>", suffix="</li>")
            html_content = html_content + f"L'utilisateur a été informé des erreurs suivantes:<ul>{user_msg.message_fr}</ul><br/>"

        # If there was any warning
        if message.warnings:
            html_content = html_content + f"L'utilisateur a été informé des avertissements suivants:<ul>{french_warnings}</ul><br/>"

        # If there's been a major error
        if message.big_error:
            html_content = html_content + f"Une erreur majeure est survenue. Voici le message seulement visible par un administrateur:<ul><li>{str(message.big_error)}</li></ul><br/>"
            stack_trace: str = message.stack_trace.replace("\n", "<br/>")
            html_content = html_content + f"Voici la stack trace pour l'erreur majeure:<ul><li>{stack_trace}</li></ul><br/>"

        # If log
        if french_log:
            html_content = html_content + f"<div>Voici le log:<ul>{french_log}</ul></div>"
        html_content = html_content + "<br/>-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------<br/><br/>"


        #
        # English version
        #
        html_content = html_content + f"Hi administrator,<br/><i style='font-size:smaller;'>publisher: {self.publisher_name}</i><br/><br/>"

        if action == 'Publish':
            html_content = html_content + f"The publication request failed.<br/><br/>"
        elif action == 'Update':
            html_content = html_content + f"The update request failed.<br/><br/>"
        else:
            html_content = html_content + f"The unpublication request failed.<br/><br/>"


        # If there was any errors
        if user_msg:
            html_content = html_content + f"The user was made aware of the following errors:<ul>{user_msg.message}</ul><br/>"

        # If there was any warning
        if message.warnings:
            html_content = html_content + f"The user was made aware of the following warnings:<ul>{english_warnings}</ul><br/>"

        # If there's been a major error
        if message.big_error:
            html_content = html_content + f"A major error happened. Here's the message only visible to an admin:<ul><li>{str(message.big_error)}</li></ul><br/>"
            stack_trace = message.stack_trace.replace("\n", "<br/>")
            html_content = html_content + f"Here's the stack trace for the major error:<ul><li>{stack_trace}</li></ul><br/>"

        # If log
        if english_log:
            html_content = html_content + f"Here's the log:<ul>{english_log}</ul><br/>"

        # Redirect
        return CDTKEmail.build_body(html_title, html_title_color, html_content, "")

    @staticmethod
    def build_body(html_title: str, title_color: str, html_body_content: str, html_footer_sent_to: str) -> str:
        """Builds the html body of the email"""
        LOG.trace_func()

        # OLD: data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJgAAABvCAIAAACfN57XAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAABnTSURBVHhe7V0HfFRFHj5RT+/Ou1NBmqD0IqAUBekQQJBy9CIKSjlBPRWQqoiNLiBIkaIoFpqHSUhCSKMnIYQWUkgjISGQkLa9t/t2ZzM7md232XBm315uv9/3yy9v3swr8735z/8/M+/tHyx+1Ar4hawl8AtZS+AXspbAL2QtgV/IWgK/kLUEfiFrCfxC1hL4hawl8AtpMZotP+XrZl1WTUpQjYhTBpxVBJxVDotVjjuvnHlJ9WGqZmeOLqbYUKQxmcz2Ij6I2i8kKl9ttFyVGg/c0q9I07xyQbUxS8sqsjJde1+g5A+/VcH7AyXQ1Wj2UTFroZCQ7ZrMePCW7uM0DVpVu0jZg5V1ejxUKtU79GgVKWf3uudNlclezMfgW0Kikvbl6ZamqPE3odxQoDZpXdUbWoVzuzhdYpiYoGwfJX8oSHKfkwAsO0XLafFiremBQCmXQYh/CpbIDfaCOMKmLO2EBOXJEoMvtFLfEjKsUE81wD+Q5K9HpQ3DpK0jZB2j5Z2iZW2j5E3CZY+FStGMUmVGezGLJb7MiFqmNe6er19U2YtZLJF3DdxeN+x2UkG7yRKd+eEgayJM7rjzqmylyC3Vt4RclqphK8490efZi1ks86+pub1uuPWG1l7MYlmdXo0z/vOy4wmILjaw7f6xEOnuXB38JrHgW0IOjVXSqnHP+wOl6AjtxSyWfmcUXAY3jCursI8Wy4QEFbfXDXfl6uzFLJY1GVpub51Aa1uXG8QR04eE1BjNTcNlXO0I8fFQGTxIWrBuqKcFYavLdPaCsJMtjntaELwkcTw6cKO4vYS9TskLNSKYWR8SMldlQn/D1YsQUV/2YhZLiszoecHOMXLaz93Vmuo4ZRDin4OlmoqS8HlbRgg+AXC4bqm9raUPCRl0R8/ViBu+m6S2F7NYfs7XcXvdcOYlR8Hwokr9nHv2PKWgRvOW2vygzdMRYrso2W3vtksfEvLj1Go4LD/kObqrBdXxdLYxns4X1fF08OhQIUMKq37mup2Qs9FqTcOHhBwR56nDUidQmiR1dFf9q+PpnC93eDqj4z31rUCEtvZiFsuKNI+egLHnlXpvNUtfERI3/FS4p4F53VApdQ71JjNcfy6DEB856hjTwQHaeDymA480mXGSh3vmXcNu/5TvkL9G4StC3lSZ/ui212GJ7spezGJJlRvvd8ogxPHnHXE79Fyaom50TPZUuKx9lKzrCTmMIVyhtpGyRsekj4ZI2V6wSbgMTwwpqDWam3j8zA0447jUGoWvCBlWVA1P552rjsD8l3zHYJBLYu/DQRIENnOvqMorAg8Kk6vhNUiGhpujMp0sMXydrf0oVcNa8hyl6QGPneTG4TLvBJa+IuSBW9UQcu9Nh73iBoMg24OBEsQGo+IUS1M0P+bpLpQbi7Q04qgEldGSoTBdlhjPlRpOlVgZX26ECb2jMetM1oFfl8hTmR4O9rRFdjnhCJNqFL4ipNJomZigIqOX7tn8uAzxn72YbZR14FkFbOZHqWp0SBclRg/HVpQG8ysXlEIB6ENB0lYRsuFxyo9TNXcrzXpZ8dl1jYeRKzuqV6PwFSEJ0HIQ3SOg3JqtRQ2+l6RGRcy8pJp9WYX/0fi2ZGuLnapVCEajsbCoOO161tWk1OSUjLy8Ao3WEXsQZClMc65U8QANjVXaczNIlBgHn6vaW97DjOrVKHxFSEj4u4xSms1mKLdx857R42c3b9OnXuMuf3+i09/qdcTfxxs+1+jp7n0DJi7+cE3MiVi1xiFqmtz4cqxCqK9tH1XJPEL7XNusJFla8ESooJm9L1ByhRnVq1H4hJCpchPsGBzFZ2PkkxJUS1LUW7J1qKPA2/rwIsPxIj3a6P5bejzdMcWCauv1hpCwmKEjpkOwv9bt4J6Qtv1zg1ev215cUkaK47g7c3V/O+pClamJDvN4VWr8c7D0T8EStOMCjfVa0GUOOuu6adYLk8m8NSbgE0J6PnuFnomN5yguXU5+acQ0yMMJViWbtemzbcc+rc5uAOPLDM4D95uyHG33q2zHpMcTYdLvblqnrjRG87wktfOwbW9mQLim4RNCvuRBZ0MI60fMGoXBYFy/cdcTjbtyChHWa9TlyeYvNm/Tt2nLng2aPg8Dy2UgfGn4tBs5eeSAsJwtIyoNFJwpdQwGTb1QaSgAxnNigrJMZ4ZbvCFLy4Ul8645xnVrGuILCVkaHPN0LunJcJmGaZA5ufljJ83hVEG77NR16IrPNqEjLCgo1Oms888mk6m8XJp0LW3Xt/vHTHyzbqPOXKmW7fqdi7tIDpupMDWquKRHjkpZ96pNpItLbR8luy63RqTbc3SsN/uLt4Z1APGFvOFxfI0uh454QZ7NW/c2fOoFTo8+AyYEh0bDXyXZhJCff3vRstVcO4YrFH0ilmRAZPknW7DYMdphHhGHPCTg39YPkyIGhZZolyQFjTVD4SVPBxBfSHg0tDqEWCdQ8mqiisZzFxKv9h4wgdUArN+k29YdP8DlIXk8wfX07EHDprIHadysx5WrqWQvukOc9w1mgU+U2wU+cNYgPy7x/STrbEyjY1K1F5d+iC9klbNXrSPlYUV2508ikaElORvGVu37x5+/bMtSPSCyfHfeJ6yXBLNcVibBLr3JPOCMAtaS5AScl3dwrBcqvSw1QsxpF1VTLriIPmsO4gs5Mk5wJgHGbVGymsxXIEAMCYvu0OUlWuOULdr2vZacTo52DzAaTUuXr2O1nD13KU6HXRclxivMKOt4geUdLJ8+LstXW9ek64SG+GoG4gvZWMDT6XlKnlhur8Rbt+5MmzHfpc+J1nnydDzJds+AQZ4+cwE9Jk506sx5pENOdlAdInEX6ZL9zii8K6IVIgt5W2NyHk/5e4gU/RMZ6IZTs/u7A0+37k1rmePnq7aQQwkBjg/sJ6IU+7YASsvKYVTpYYcMfw0t1b7Phjsas+crgyLuVqOr/l0gspChlddMQNRR8cqcikjxWkr6sJGv08p15jOdh6jVGpKZA+KNk6fi3nx72Qu9/tG248Au3Ue89sa8I4HhJBpxiaCjkbTRw9KejU2077AhhFk8XSXnX3OsC/EORBZyfWYl9+GritdrIM9nK7cIhfmUO3f/bMvO425x6fgpb7kc6Ondf7xQh4pWGzDU4cTOnruENaxbs7WeC/n2VdX/l5CnSwxsEBlw1r7IZd9PR1zKwBJBJGJ822EqASqi/XGZWTZp8WLChav23JVx4NBRmq1Z6z5yuWN+P0th/KurkViX9NqkB4X4zs7FcsPaDM1ricqepxQtImQ7c6wDm+jYxk2eS+vUJSe/+i9yBBawqJOmvsPldCZscmlpub0MA6lU3ujp7jTbubhK1vVCubH/GcFJEpZJrgaEaxTiC8kCgQZdDVpQUIjokNapM7/e/r09K4PTZxOEBlQ5frZys70MA9jSUWNn0Tybt/KnMJjNhwr07t3XvwRL6AIfr0FMIVVGy6p07QfJmu/zdOfLjQVqE0JGOKu0EuB9PFpfUJXomHP2fAzeef9jLpsQ4QG5HAZa/skGmgdHI4lwWW3zaxryOkCx1gQTUkfAie1z2ksLrliIKSTn6aCzfDxU2jRc1ipStibDamDRPt6b/ymtVo5JydfJcShgV3v2G8tlE+Kj9Z+9np5tL8lgz96DNA/MO0nckWNfzP5EmHTrDa11RY/ZsjNHR8ZjOS7w4qQHhZhC/kN4ffAfgyTnbJNHMpni+Z6jaM1Swn6mZ9wgx6FAaOFy6EeIsMP2kgx+PRJGMwwdMZ0kfptb6a2EgWeV8H2QfqLYgIeP3QWy7/t5DaIJie4Qrg1XBSzbRMoltsG5C4lXXcYhSdfSyKEo0CIRNXLZ3NCl73rwcAjNgCiWJH57k3+9pF6Y7GihVbBLEmP9MMeN3O/dSQ8K0YS8o6n63as3LqrIutMvN+2mlUt5PPI0ORSLmW8u5rIJEQ8HAhV7MQaITWkeOMAkcXPF5BTLB4Kkm7OtXcBlqbFuRbuE7fW6o2OFaEIe9+Cd7zq/SQ4WWJ96eCUvj+KHeDZu3kMOxSIs/ESVASjhiNEz7GUqY+HS1TTP/IWfk8SlKa6naBCKfJqmwdMGG/uILcocFiuCpwOIJuTqDI/W6cBqkbUdN28WIJCnVQyOnTSHHIoFJB/88qtsNpeEMxwVfdZehgGMc//Bk2m2XXt+Ielu5j2g5Rfp1mVY+/J0DwZJV6S5HjKsaYgm5EQPpoQIXzqnIEvnDhw6ysaIDZo+X+IqqM/IzGnepi/N5pILFq+sNK9RAQSv7GTn5SspSMTZ27pa4UGJPuKbHOvbCKdKDGRpnfchjpBVVg3LBmFSna3bQdVzXeC2HfvIATlcTUp7ttswNicl2uLCJavosjkOm7fupTnbPTtIpbYGEvnqqrvzh4NEmPFgIY6QRVqzywjMJYecU9KHvLS0vGNXR4DRrlOASuU6aJNIZGvWbX+m8xAypICOs16jLiPHzIyOOeeyLQJKpaojM5P1wZJVJOPu3CoWBhC2iZSpRXBX7RBHyBPF1ZgSWpJSaUro5Ol41vq5n480Go1Z2bmx8RcRw5SU2tciC2HDVw7f+NH6zyanZCARpx7k8WrNyLsiRJAE4gi50ZU3L8TDBbwZXLh0Fa3xxxs+x00c3huuJKWya/KmTn+PNNxkmZH7Apobfm2LRkSBOELihj1skQ8ESjKdFk4Ul5S16TCQVnrrZwZkZuXa990Tbt+5y858IcSkw0bOQwFuGHzn/6xFKg3medfUHaLlLt+1oITYMy6pXMbX3Hg6Os6U1Ez7vmoCnmrv/uPpocC1X35j32cd2TdPtr59V3WP/lCQVMRPDoojJAEUKteb0xWm6GLD/lu6HTnaTVnadRmaDVna7Td0e2/q4M2TwMMZsHvsNAXYrE2f34KOIxC05/AM6D654dnR42dzsyI4YuRdQ5eYKj440Oy4TMTPC4ogJO41SWqMLTOW6MwkrvAQqKVzpYbFyeqYYmtFo7q5aAQeyvSZC9Izc0h+9yi6W7Jo2Wq4suwR0DRLyxyxqdZkviQxkjBWYzSvStf8WdjZHnfeqwtZOYgg5L8LdOTLmg8FSZpHyPqclk9KUL51RQWFlqeqP0nTLEvVwPDOvaL6Ia/SO//YJOtCGoTJrsutnr5Op3/z7WXcmFy9xl0gZ3jEKYVC6RxpqDWauPhLCxZ9wY0TgX0DJhXcLrTnswGXhNO1iJDty9OTVeMJ5cZWAmP9qzPEGdMhEEHI1y96+h2/h4OlRcxb5h2jHTWI2sy3RSUIMNZt2OnynUh4of0HT575z0ULl6xa/OGauf/6aNjI14VWVr76+vsIPcmJKJ6NdpjT/mcUGbZvghRrzQGuXoiMKhbN0wFEEJLVwz0bHXN8OVBp5JeVtoyQp9vaJRB//rLnU8ocn2rV67sfDjl3rsVaE7fa6pFg6xe3cEFqoxlWhN0Fk1vo8iPB3oK3hSzV8bXjhnjw7cXglZQZub1gvVBpeJHdMdFqddDD/fo5jo2b9Vjy0Vp2Mov9GODpEhdfqqsTKH0vSaUzWd8ImJroMC3PRHl9uVVleFvIuLJqfMdvUbJj+O3rG67HEB4MknyQrKFveGt1uoioM7PnLm3bKUBoPgv6jRg9Y9e3++l75wAiohVpmg+YVRpCoxb3BUrHJ6hgIeD+DI+129hpid5eyMrB20JuF9DDJclkJIH7nrVlhPXVSdSsPbfNqcnIzEG4uW3HvlVrt32+asuGr3b/vD8w4cLV8nIp6wTBJw26o+9o6w5/yHeccUrll5M5johVKI0WqcHc2RaWsF9lFgXeFnLWJU89nfsCJZkVHxxDkPJcVWEc8rePkm3O0nr+fU1Esd/n6V44KSdGAlE/+4UrIe+UckKCEobgpso0Mk6RVtFbiwVvC1llWE3ZkPF05AbBV4WdCWFIKQDlIaveZMaR0PLgjpTrzAgh0IDGxCsfrfw1QvS4MJikYKHGozMiTHI0bVHhVSERWf/F498CGHjWEV/Hu/J0hDjjkuMd4xS5qW6oFNFq20gZWliDY7IHggRdLQQYVBXPf33gEGP/RYRXhUwsN8Lr4ypCiKzfse2GpyPXMJJszcLu1fP4c+fwraiQqzz+Jm+naDnTNYsGrwq5p/LqUPfcz6wOnelBz/pAoHUIZkPln0sCpHrzDZUJHSd6RJhoid5cqDGh94X//O/b+vWZWrRgWOOhsYo8xkyO9XglCh6dAu9+9dolvCrk2qrewWdJg32gx0m+Z0X31iFajur+MFX9Y54OqiB+r9bILQsU48by+p6uxqd/vP8pemd4VcgCtQmSeOJEvHjKvuCKYO9N3eCzilmXVesytYF39HAR4fffq2oe4ed8Pfu+nxs2CZfd8wP0O8KrQgLoTvD8nig27MrRLk/VvGn9sT/lqDjrz/whuB5/XvlaogqBeYnTF3K9j4i7+u4nq36JbkScOAtZOXhbyP8t6EyWb3J0zm93sPz0upiTHhR+IatGjso0QOD7j+CxisFeceEX0iPozdZfF7nPqdeE4YWTZc8kKvxCegq4tdtuaLkf4GkZ4fgpSnHhF7J62Jene4gZG5p8wUufLK8SfiGrjT251pd1iJAbMn3C0wH8QlYbsKWr0jXoHdFlni7xCU8H8At5L0A0POeKmv2BJtHhF/IeYTSbRf9dZRZ+IWsJ/ELWEviFrCXwC1lLUA0hzWazyQnscrQqMxBw2eypAkBmvd7AkjsgNukXctn/KZDCkhbHqSsSXa+bclvESu7isUkvj/xP0inoLRByxVHQesQK0JN6iGoIuXPP/hd6j+HYo+/YFZ9/pdNbZ/OXrVjP7QV7D5ywY9dP5LLyb915Zfp7XIYBQ6b8FnTcdgYe8QmXh4yY1rn7CJZIiU+4QjKEHIvpP3hKt56jyFchDhwOwf/jp7yde/MWNm/mFUx+7V2ksOw3aPKRwHDs3bP3IEmZNnOB9ViVUXC7sHufMSRDTu4t1PuHKzbgakkKITaRSL7NHBgc0XfQpOd7jb5z5y42Dx8J69Jj5NhJc7KyrS9u5uTmj5vyFlLYG+k9cOLBX0OxF8/E6nXbe/YfT+sERMUuWrZG6LPCzqiGkDjZYw07uyS5oJlzlnDphPWe7JZ48RoyTJ/1AbeLsHHzFwsLi20ncQC3h8richJ27zMWNSuRypq07EVS7t61rhbHo0Y2X5n+PjanzVhANjmiVFFRyZdf7Sabg15+zXbCSsCjUL/p89j7eKMumVm5+w8dJZmdiXsvLil7qnVv/N+g6Qt4WFF8775fH2tk3YunCpt4fGl+lsiPKwk9dqJu4y7cLsJd3+63XU7V+H2EXLV2OzIICQniCUWGPgETuXTKS7YPobCQyRRNW1lrx5nN2vSVyuTpGTdoCicknmhYJxgDmoHjlaTUagmJGySZKdt0DBg1bjYazYXEpNS0TJLoLGTXF0fCGvUaIHglFy9d2/bNj1wi5dLl68j1VIl7EfLJFj3HTJqz7OMvYStIysq125CBCtmiXX/YtE9XbqEt5tC/rU2WCvnGPxf9+PNvtN5BZyGlUjkV8qNPNiI/bDjZbNa2L5qjGyFh4tDzUSFxOtTslm3f123claRcSUq7NyFf6DU6+kQsDC8eFGTDRaI5uhcSOWE2SQZyJSyLi0u37thH9nboMhS3CcJKk5QlH621XU7VuBchR46dRVLwD0nhhJy38Ats4kls3TGApHBC4tKxCatCNkH3Qp44Zf1BiJOnz5PN6gq5YPHK7344/O78T6EKNiHn9fTsexOy3+DJR0Oj1375DXpWnKVRsx5r1u+gQqLIt98fWrdx1+Dh00gKJ+TyTzcGh0ShJmfNXYJbIOeiQqJ+sIn8E6e+Q1JEFnL+opXYdCMkPBT4LC3b9yeb+AeiWo/IgBVy9IQ3A4ZOfbpNH7JZXSFZ1nuyK+whOuD/0rRSolqokM7khKSEW0DfAqNCNm/bDxJ26jbsiSbdsIlT7/vpCMlTJcQRkiUu+pMvNsOZtx6RASskx/9GSLB1h4EwaD4oJEc87rhOkqdKiC8kCLc2M4t/8d+lkGhPaJfDR89QKlWskKlpWccjT0+ZZncOOSHRdbXvPGT46JnEtIIunR2NRpt942ZwaPS5uItCQsIs46ogDFoPSeGEhAPxYr9x9E45IXGn8G+h0HsffIZbIOcVEhLEwUmeKnEvQo4YM7O0TIK77dF3DEnhhHx/4ecIJ2JOxhKnHOSExK0u+3j9N7t/Jpug+z4S/iG6IvQu6NtoaMUKSWwRJSfk+k27EOkiwqPZWGcnYNiriAXBV9+YR1JgITghEel+tmrLr0eOXUtOl8utL6XQh5gVEk8Mrgp74cW4dHY+X/01vHFyOkI87lRI+IZvvbscmwOGvEJSaraPRLOgjzYhJyRXraBLZ6dcIqUZPHF2OLBCcuSEhCl+pvNL7Z4bTDOwQqL2sRds+HQPkuIsJE4HARIuXIVCiz9cCxVhG0lmTkj3XivMCTkXIdxUPJpUSNSP7c4Qd75PUmpWSGeiUpCBCulMNCZkEEtIZ7JCOtNZyE1bvqOhC8dqCenMaynpviIkegtiT4SExM3AFCPD/66QHjo7/xtCJiVf/+VgMMfDR8LIpQPoNbm9IHoX+nnco2HRJOCFb4JNnU6HGyZ0/oQuerXA4AgcHyROKQepTM6dizLkWAz6nrDwk1w6ZVm5NCU1k0ukhMwKhfLA4RD8v//QURhVl/dOiF1woZEN/x/8NYS4MFnZuWQvbhlXAkeM3IgzURa1QarlaFgMubWomHOkWuITPP1102oI6Ycvwy9kLYFfyFoCv5C1BH4hawn8QtYS+IWsJfALWUvgF7KWwC9krYDF8h/O9bCbRY+MtgAAAABJRU5ErkJggg==
        return f"""
                <div style='margin:0;padding:0' dir='ltr' bgcolor='#ffffff'>
                    <table border='0' cellspacing='0' cellpadding='0' align='center' style='border-collapse:collapse'>
                        <tbody>
                            <tr>
                                <td style='font-family:Helvetica Neue,Helvetica,Lucida Grande,tahoma,verdana,arial,sans-serif;background:#ffffff'>
                                    <table border='0' width='100%' cellspacing='0' cellpadding='0' style='border-collapse:collapse'>
                                        <tbody>
                                            <tr>
                                                <td height='20' style='line-height:20px' colspan='3'></td>
                                            </tr>
                                            <tr>
                                                <td height='1' colspan='3' style='line-height:1px'></td>
                                            </tr>
                                            <tr>
                                                <td width='15' style='display:block;width:15px'></td>
                                                <td>
                                                    <table border='0' width='100%' cellspacing='0' cellpadding='0' style='border-collapse:collapse'>
                                                        <tbody>
                                                            <tr>
                                                                <td height='15' style='line-height:15px' colspan='3'></td>
                                                            </tr>
                                                            <tr>
                                                                <td width='32' align='left' valign='middle' style='height:32;line-height:0px;margin-right:15px;'>
                                                                    <div><img src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKgAAABkCAYAAAASYXt7AAAAAXNSR0IArs4c6QAAIABJREFUeF7tfQd4VFXa/+/26ZNJMimTkEBICB2CKLZdRcBeVlcRLKvrKoh0BBessXdEOliwomJlXQu2dVVQEUJoCSQhvdfpc/v9f2dCWCAgrN9+/l0y93nyBDLnnvKe37zn7YdC7IlR4DdMAeo3PLfY1GIUQAygMRD8pikQA+hventik4sBNIaB3zQFYgD9TW9PbHIxgMYw8JumQAyg/4vtueqqdQx5vTYdvOw0U1m7I9Lbb4/X/hddxl49jAIxgB4vJPLz6RHimDxRNf6oC6YRumA6RaZYKKrhokGBpXQwhgpa17y0rlYYqvgRrQX+qUjl35YtmSEd7zCxdodSIAbQYyDi9LmvJLUxCRMjfPrdrQEmUdJ4aJoK0BLAswCE/T1IYA2FABTQDRg6A9qQkRLHt9Biw8o4pXnJtiU3tcQA+O9RIAbQn6HX4DkfzZDMzmcr2wNgzE7IuhmgXeDMFtCMgkgwAHC2zh4MEaCkKBelDIA2WFDgIUs6KDWCrBSHQQUqH3L4Sx/bunpy+N/bpp7bOgbQI+z9KXNe7qe58tYV14eGKaBhT4yHN9gBW1wi/F4VUDWAMRB1czDm/T0ogCGBMhQwFAUdLHTKBBg8OMEKxd8OVm5Dv3ilOV6rveG7J6/5tOfC7vhXHgPoYbQaNGvtRNGes7aihYZgd8PQFVC0BkmJQFdFMDYbKIoCIipMJjNCuhLtgdcAVjfAGDoMCpAZQKUBzQCgAyzhupEQrGoIDkoEFWzNr3z+qvuPf6t6ZssYQA/a96G3vzixVklb66NSAFMCNEkDTRvQFREWmwWyFoJOK2ApQI0YoCgaGkV+U2B1gNGpKGPVYEBhAI3SQVst0MMhADQsZitEnxcCdDC6ilQutKp00dhbeyb0jm/VMYDup1P/216d2GwkrZXsvRChTNDJ+R1lf4QVEtQp4C085IgXlImDQdGAooNiiKKkd4qh5G/Rf9D/+tE0MCYO0HVoET9ogYMgcIiEw7CIDRhC19z347KbHzi+7ep5rWIABZAzZflYxTz08zCfjOZAGLDaQdE6DEUDiByp6+B4FookgiYYZBnoSgQQBNCyBsMwYDB6p0xKQGqwgM7vBynAMQYUJdLZB1SA9GsxQRBbkRQsRTofuPX7JZNX9Tz4HXvFPR6gp81eZ65iEysjWnySBA4KZUChqU6QURwog4IBopnvN2UaPAzyOXTQ5KjWDLAsDclQoRsyQHMALQAa4awMYGigoYGCGpVNyVtREJMfXYZD8iLZFIFFaxqxfeHEbcfesp7VoscDNH3WJ/e18558XTdBNyiolAydUMUQQIGJckdQKhha7kSGboYRBW0nYAnjpGkaCqODomnQLAdV1QHRAIi5iQislAoqKpkCOlGwQMBLuCxg5xhI3hr0dgQ3lTxxwRk9C37HXm2PBuiIKc8NLTflbveyyYAu7D+iJYDS9x/RhIAaGFoHTalRsBIgRwFKEWO9Aeg0wBAZk6Bv/zFvkP/QYDkOhiJHAWrQCnTSL2lo8GA0AbTBQNUk2AUNVLAKHr51QvGzN7x17G3rOS16NED7zV6/uppKvUWkEwBwnbtOEc5IQES4HEARLd1QYEDeL1MKMCgGYIh8StR58ioPiniPNI04lwijpAhWo9xX7+TABKCksU4ZoA0OlGYGDA6CmYccbgOndMAj+DftW3hxjIse9P3rsQAdPuuN3n5rv4qaCA2FJt4gphNwFAES4aAkDoTIikRwJMd7p70TsABRGVUjCATLm6GKIqB4YWYp2Cz8NFWnx4Uk4zJFo0FxfLQ/KtovQTM5+VnoIAZ+DpDEKCfmGQUWpQFJetXYkmU3f9lzeOTPr7THArT//C+n7fNZllBmO1SaAbWfg+rk6CYgMvYDNPofDaCJokOBIoqTrkEjBnpNB0tZQEGBwETgsDMP1ucPvTdpQcGUoEgvN1gLJJ2KyrQ0ZBDJlWhKWlRJIj58FmDYqHGfplUYoXqkCW3PVz15yS0xgO4/0HoqIVLnbtzcosSfTJOjOmrDJHIl+SHmzy5FhpiMOuVKcqrTOgkGIce2DoZRwRgcdIVFYmK8z+TQzzOMcD9G0x82VHayP6h+3BFSoNDE5UlsU5220k65gQCUcGwAErHwE46sAHoQaTat3slW9CnKH79fK+upO9SDAXrSpFWJTUmntzREbDCMyP4juPMwIcb2qCko+rMfVwwFmkSAqBKgyeAoHRaehcBbdtnsSWvjEpzf+Lwt0/ZV7pnAsxwyevW+SJIxvaqy/nzG6oBGE3Tv7y86CAErERGItEBALkcjoxhGgUkKISVcOWTfyit29Wxo9mCAjpi29px9XL8vfVTcv4BDdQLm0KdTGyeKkqHKxOiEeKdVYaAtTIqP/8AwqPigTI3xhQJzfO3tMFkEhMISnPGJD2uKXhv0+VYwvKkToMTjFAWpHvVKWeQQWEOHzJggEo7NMYCugpIi6Mu1jC9beO7bMYB2HjI97smb8faEcvR6w8cnARQxyBOuRmTPf4GUNvROsxCxc7KEu3FQ5TASXPYvM9PSZ9fXVPzgC4QsokZB11SYWAaULELgABPPjraa7EVtfl+TqPOQaAEGx+0/yrsASuJHdcgsB9mgoDPE82QAUgRZXFt++cLRsUASIg31OHQCyJv6/pQyJC6PWFKgkoDjqHuSmJdIRDwhSqe9kjA2hhOgeIOAxQ6oKtL6ZqzgKcOo2LfvNormwPACNCkIJ6sigRWbhVDNDUWLx0dD6UbO/3z7vpB5aIBxQOUIB90vaxJfPYktJWoSLULXiZZvJlZ8aGoAWWz7C+ULz7m5J+7N4WvukQAdftsHt+0z4pbJjlRIGtcJUERAuCZDDO9RRUaDRixMRAUn3I1o3ZqCQYOy5oT83ol11dUn05oGJRxCdroLTLjuoWQzf//X+aM7zQAAxjz0zZ0FjdrDQdYJleGiLlKOuETBQouamQywjAhd1cBRtihQNTWMPmzL+n0Lx/4hBtAeykGH3/b2beVIXKbYUyGrRHMnsUskNFkHpXMwyL8oHRrBqkHBZHZADkvQpSBGDMq4QvS3vldbXoYUm6XJqovPJcH3zIZnxrcfDqj+d2/9vNqnjJVZU1Rrj0Y7UVxUY2dAjP8qDJaHplIQYIKh6VB0MQbQgwjZIzlo3ozXJ1TonjdESwo0jRznnd6eqNJumDsN6UT+JD+yDDA0EApiYFaKjwlWj6HDbVdaVOnr75+9esPRuFxe/o9LWg3ntBZfBCrNRsEZtX+CBQ0VbFSk6JRBCasWohFQJOpJQR++7fl9C0fHbKE9VQYdMeuVcyrQ+8sAmwgqakgnYCRHOok+snZ6eGjiylTBEHt92IdUgYIpXLelbMlFJ//c0Xvp4+vtHbTnR0Vwb7QmZa7e+NOuzQrNRQObD0j8RIzQiXJGxAeCUxm8oUXdpYpEI0tou79s4e/yY0d8Dz3iR854fnAlN2hnu+GKmpA6FSIDehdAyW+i0ROuqhvgDQWstw79neH7CxZeclTgjH30qz9q1qRXJNYynzdTr1Y3KKsb2sWrSHqyRhNAdkY4RQOaiexLbK2MCmgSeDKWpkNVKGRyHVdXPHPWuhhAeyhAB16Vzwf7/qG6VrInk+AQmjGgSjIYqw1aNI6TAqWS4GSSYsxHceTQ/UhSSseXLb2sm33y7PyP060uz0sRsOkyI6yWdWTroK5t7Ag8JBvCvGZf2A3ODrACIJPkOgo0iSbRZTAs4eBG1H3Kc0w0+imDbsna+9R5FTGA9lCAko3vNfPbd2vU+CvMVh4q4Z4krJhwt4gUjXbnVBGGTkGlnWA5FmpbFYalyIO3P3jm7i7gjMt/wyNyaTdITNx8myu+zh8I/sDyvOoLBUopiVlRdN+gUNL9xT81e8MngbUBRFlSSJgeTUKjozn0qqqA4dioeKGJfmQlWTro5urUsiUXxoo99FQZlABswLwvri7xmd7UWDPAWzrBQ5ShqHFeBUiasSMOoqRGuVuSw9R0+p5taaS0Td7sd0ZSDsdVsCTe4VMYpKT3/k4JByoUVS4xRLU2JIoyb7ZdHlaMOEmjxzZ5w9AowolJJh1JWe6MtIeuRRPwolYDkw1GRy1yrR0P733ivLtj3HO/ta+nEiJ7+seCYXWXt8hmj2aJR0ilAClMIkLAmxmoighdlCDwpqj9085qtU4Tu9hqFa6rq28cGlB0pGb20R0J8XvEcBA2jm21mnnZ2+qLSKpSTDO2Vt5s/66pvf2hdn/4nE4LAeHURucXgTyEYxMrARmDEuCkvejrKxhWsOKGHT11X2KG+oMo0H/Gh/kVYcd9sjkFhtUZtcdr/sZOpSUuHnJY7QQRZcAGORp0FJAM6DQLizMeAkd1ZnkaIuKsdtKzTNGCLmuMEhB1u9nqUIPBICuHg2ApJZr2QbxJBstBIYoSzYMmwSmyBEgSellDH9Q8furlMXD+iwI90g7atfxTpr6cEHIMbG3SXWiNdIbV2SwqRCkElTYBnAVgTEAwAIaSwTM0IsQ1qpBkTxOMcBAMK4FnDWiKBFlUYHEmQNEZKAYHKAaiznk1Aj4qcypR7mnQDCQSEE1soIoGi4kBE2mBR2kYs3fpFV/FABoD6AEKDJv21q2VasIKyZUDUVbBU2EwlIaIogO8A+BtQDgCltehhvygzQ4wDBPletGAEk0BQxvR1GJSwEHRDEiKDsbmhEYASo5zQ4vG0EOVSWxUdGyZZINyXDQjVPfXI9ceXrPz8QtvioHzUAr0aA7aRYrcWX9/e6+YcCXvzoDsbwXP0WAZBtFIJYMoT8Rfr4AmfnSi6msqWJJIRyyZxAivdVYgIb8JSCmehawo0VylaNEH8jeGgqFqILH7pA3J/LQKDAzRi0y71JrdXJz5YayoWLfvZwygAAbfvCg5mHrG9ko/l8xZXVAVBYwcinJKiUSMcHw0tVgnfxcEaJFANPZTESUwtCkagd+Z804M8QSQJBPUiDJPORyGyWGHGJFhssVB9AZAWawwCNDDrUgTgnDrlXmFi/5cGOOe3SkQA+h+moyYvz673ZRRVFkd4JyePogEfeAZ4gHq9KErOg2DmJ9IakY0iITkEdHQSUQJCQAhXLYrmU4j6RtyVPt3OGzwB0ltJgaQddBOR2dOU7ADHieDuODesUWLJ8aS5I7y7YwB9CDCDLxtzXAtLndLtZdmeFsCApIWLeYQBR5PAoqJFq5D4FlIogiayKLEI9RViCGK3Gj0c7Q4GGUQ16UMxmSBpusQLDyghKCFWpBoAQRv+ZiqlX+KKUU/c3TEAHoYcUbNXJvcQrnfbVHtZ4iMFYzZGlXGiQ3TEENgLDw0YrskR7SJZGYSJShaMuRAXhwxHXUpQxTNQCEclcitpEZjsB45braN8leOLYod68eUamIAPRKJ8vPp1PoRyxVHyuSASkHSabACD44oOpoaLSACzhw1K0EwdypBhgIOOngSvqcb0Rq3xNapMwI4Ew8l3AaT1oFsa+Q5vqNmVqzK8jGxGW0QA+jP0Knf9DeHRTjXfWGdvVyJckLil+TACFZIJMCYNUMlRnaiFJEYT52kIutRgz4VjSkliaAiGCOCVAc2c5HGu4oXXf3F8W1NrFUMoMeJgeHzXh/eITHTWLvnL2HNhIYOGbAkR0uBMwypXqd01m2CEZVZSS0nC8vAykQQTwc/toQbF2159vrPj3O4WLODKBDjoP8GHE6atMoSNNuzJSP+dIO1ncQybBIPycPSBqUxJE7eaNQ0BTrU7ZxhfGXX1O1bn76k9d8YItb0MArEABqDxG+aAjGA/qa3Jza5GEBjGPhNUyAG0N/09sQm12MAOmjOp8NCYPubmUg0kdLQuGYTpew8khJz5pTlrmDygMzWCK0JmmhImkpxDIlo5sGyXFBprKmvfOnP4pHg8/sHPh9Sr1hZSiNV6zVdk8h1SZrORUKUwaiUyZ7CEg8+IEMPdqj7FncWCRsw973BhtlOKb6A4TDC+rYl1xUdqf/T5ryTJ+sURYdKpZ+em38g/eREhfIJD9CTb1s9XI7Ler5Jc55EyiFy8EfrekBi4OIopPLBl+yBqts3vDDnQOGFM/LXP7G5PW6eIiSC1xU4BANhbwM4joNkCEi0m+EMNfwYLzUt/XbFLa91geOceav6bg+nlrUzLpgECyJhCbzNBTkUhFPQwDIU2oKR6EULZrMJqRag/P6TqKxprw0JOLN2tIoczAbQL45SC/W/C8jPP6hmIzB0zut/atQ8LyuShAEO38xNT1y9+EQFZte6TmiA5s16Z2KrZlobpCxQGCt4lgpY9PZnbLSykZWMZJPJMbvJG8pLSbC2pzGNp3zw0IR9hDCn//Xtxwu8jjvY+EwdskgLivfvfeKpFbK/LVFkbecEJf6GDr8Ch8WEeCa8yUGJV/z47GVNeQvWuRVLytqwxidGwjrMjmTUtEWGE3c+T4dhYokDiiu08QLtbWjQernMxYX3n37tsPnr8/ZIjgKJTwACCvqnWFuG7NyRevDV3gNmvZuqJ+fWllc305lx7OayR38/6kQH5wltqM+b8/aYRtn+hSzEIyhGkOa2KSaxZWDRY+eXHbyxwxdsfLymoeWOzATqp4KnLzuFfDZizruzykX3M5o1CWIwgHSr8nLFU6ff2PXe4OnvnxtwDn6nwavZeYiIs6gtDos+tCj/lMaD+857pHRguRe7w6SwTqgZiQl802A6kH5w/SbSftD094bVW9IKO2ADpQtI5aTWM0p3p3QBlNxLv33ogK1ljYFhyQ4j7KEas7c+8seGGED/SykwMH8dDzGprT7M2zTGDFb1wcM0XbN70dVvHGlJo+75poTjWU9LoCV17xOXBQbO2TCjOhz/LGNPQSTgRZY1uGbP06cdEu2eOefbqQ16wlKOVGSWOpCexHxSln/qhQf3P3L+P/NKlcQCP2WGoQfhsSuNqQ1bMrauntxV8D7afPDcd4bWKMnbw4wDMBikONhWw78jo/aZ8aS6LvrcW/BpRZt2XpzZQBZbN7Lgscu3/pduzb897RPyiB81e82EKr33G2HGDVnVkWGXWkoePjnpaNQ5e966FN4QA5899ScSuIkR87+bVtwhLDHMidHg5Ey+8fmyJeceUiuJZIWq7py6pjYxgeXJ3fBe9OGb8gofufxA4PGImeuHlrO9t3tpUroxjGSbVNe0Z18m3h7fWXd8/9Nn8gvDvObcwhDlhCJGkJkW31S5vSCNtEu7v+yVpvbA9S4zi3it6YK9T47tUbckn5gAnfvaq0WB1OtgT4ckRpBMNdxTs+SCh4736zt85rsPVxiZd6q8C0akDf2s7c8VPnH+pMPf7zf384+qwrYLJd4ZjVfOoJtnVDx+9pKudoPmvDesnu5T6KWsMBQJyVatLqGkJKvo7UPrz5M41EbTwG0+3QGW1mA3M40OO99fjEReq68PXZyeEg+7uOei4icv+fh413CitDshAXr6XR9sKGyLP5dyZESLy7qUikkNyy957ng3bdTcNx7Z5k9aYHL3Rbi9BllCy/Mli67oVm3u5Ds+fKQ46FygOjwQwxH0dfhe2ffQmTd0jTN81vvDq7m0bT7YoCkKki2o5yJ7s7uO7q52ObetGd5GAErFwTAU2C2cLIeDW3TdOJ3mHEg0yR/WPDj40uOd/4nU7oQE6Ki7Pvm0sM15HuXsBU2KIFEqm9yw4sLVx7txZ9/5xmObA6l/DQuJgBRAptD+QtVTF3WreHza3PcfKQ45Fhj2FISDHRjoDL+6/dFz/9Q1zilzXh1WSfUu9FJxkDUdHivVgObvs+sPS44jAPWaB23roBxQoYETSKpzGIxhQKNVsFoQbs5/ffXCiw+YtI53Lf/t7U5IgA6b97dX9wQSr4MjDbIYhkdvuLdu6TkPHu9mnTrn9ccKwp6/Mu6+kAJt6GvteLH04XP+cvj7Q2d9+EqF6Lhe5SywMiJ6MS2PbXv6igUHADr91WGVXFahlyYAleGxUY1o+rFvN4DOen24n8/Z5jXs0VtpaI4Rk03CAk1TFgbFCKUqIaS7zHAEq/sVPnlJ6fGu40Rod0ICdOic92bU6p5nw6wLqqoiyxL5oOSRkcddsWPU7etn7gp7FkWERFBSB/pw9S+WLb64G0Cz84vb6rx6PMcy4NU69DW1jfzxsfEHNOzBU94ZWm/tu90HKzQ9hBSL1MiGNmXVPjMnqp13PWm3rBkeseduC9NxEMNhJLrj6lvvz06z3f7DpGCYWRWflApvczUyHfIPFY+ffdqJALzjXcMJCdDT576S1MHmNNWGeSicCWa5DVkoz9665MaoIf7w59x5K18VDLnuw6dmzCef5c366JHiUPICPjETorcefS0tLxY/PfYQgGbM/mp8vZ7wFsPZYESa0c/lL9j10HknHdz3kGkfDKk1Ze3wwgZD6UCKNVLPRjZnHw7QgbPWDa/RkrdJXAIoika8mWpuYN9KJZ6kpPk7v28La6eaeUaH1EJ7LOEHSh6/+L7j3eD/9nYnJEDJppwy8/1pZQHTEjk+HbKmIlHzfVu/+OzfH75huXM+mOH1i89mJ5ESNV7Hxif+Ehi54NOHd7XF3UnH9YISbkcy3fx87eIxB5SkgbPXZ4ctOd81RuhkUY2gT4KOpOBP/X588tZDjt+BU98ZVM1l7QrzTkDqQG+7WqfXfppd+VL+IX78QZNfHdZkzyn0wgFVlJERxzSO2lucTgz1qX95PdPSZ2hFU4uPIveCiqKKXkJ4XOlTo3tE6sgJC1ACxJGz3s/fqzrvi7B2mMHASUe+pX0lSxIsxu5wRGTt7owZpS34S0a6W6PqC0/ZsXpyAXlv0Iy3ptbrvZfKpiRIER8ykpkPLIGtc8VAoJdoSTlLcGTe11AXpmiWh9PFNjnF6guKFl657XDwD7x93cAWPnd3uyqA1iS4jY4ai7ojp2zJjENqfw6Z9NqQanPmjiCfAIaikSg11NY/O7pXV38pU968ShQS17G2VLS2iki16rUjAwW5PaESyQkNULLBA+e9d1VAyFhX3xyB1eKAKndAoLXodTOKGEBqonOjJVh9Y8Hy6w+4QPNmvnZ/RST5XtnkhiyLoDhyC0gYFKWB5kwQdApJPKtpvsb7hBT1yaPdq5l6/bIB4fjcImLfJHXvB7g5KN+vMpV9suQQgA6cunZQg7nvrg6JBZQwTuttwvfzTz5kb9Lu+HpVXbs8ye5KhFXswCBz2ydfPjH+EM/Vf/txfqT5n/AAJYs+adKHFtHGjQop+B1o2qMYuk7rep1FUz7cu+KybrU4z56+OL1DS7zIq/CtdofT6IiIdIRhwJvNEIPtbS6Gao+XuNKtqy8JHwsU2dNev8qvWnSN4VWb3EFXPXfd+93fMai0SWuvhOAyKD2i2fwV1J5X5753SLv8fDo7cuqVcrhDT6Q1xiI20t+tmntE1+2x5vTf9HmPAOh/04bE5nooBWIAjSHiN02BGEB/09sTm1wMoDEM/KYpEAPob3p7YpM7boCSy6+K3s6Xs6cvFsoS2hXsHkhdtZ9+bw8qMg7PnzmctPn/o4W+1hbP8QntRlF+vtyN9Pn59FW7B1KDBhUZX1eC//owY/bZN64xff3SjVLv/K+Fyt0tStfYpJ9jjp+fT5+EVFNSm6R9smS63Hnl288/p81eZ25RG3W+McU4PDzu8DfJ3JAg2OoDAWKGMva4KzqORY+D+zht9kKzqMbZQpJisB0u/9HGIzTMPyhP6ez8f7Du3S1G9GaxAzGmBnXa7GdM3x/kTo3u2ZLp8kmTVpuPVbTsgumLhUakOIAgNIWlYLNhx1NXNP8ctci83gtmmXOrTOLBaSpHe4es9+D5/VzfxwXQodc/2SfsHrA5yMQFGauLUlTVZOepZBJCpoEnNcgaQr6OfW5eaeJ9lSt3PnfTIV6OvDvWe1Sz50tJ0xMYX2NNmtR4zherJ/sOntiwe7//QjKEMUFve01aHGsXvMXnfLNkStT4fcaM514LOftf64Or0qfSgolnUkmlOOL9C0sgyWxVfm9zdZyF/cwI+1aVLRnf0tX3yfPWpMDZ+7tmkXaoGq24BK6Fato3eueKazuORpiBt7/xghTX/6ZWv1zpcdrcStXWi8qe+9M/D28/eObacZI5cZrC2i/1BmRwrBlaJAKnhQGl++40+RpWFb1wc7dbkLv66X/7RxNpmGZpNHOKV5ZAvrU2h4tk6L2doLU8Wrjo2gPBzyff+/4jzZp7gRKianizU20JyrDGOehAsJV22k06ranQNBG6IhnJFqO3uXnXhJ9WzXprwB1fro5wrlsEga+jQo1pNt+eiVtWTnvz8LWMvH39OC8XP0OFcUpbRyBJMMdB1sn1kCrinOZNfCT0BS22Lj2Ytl19DJ637m+GLesSXVG98WzbuI35F205Gm373rpmgsPteU2pLrhw18sLPjsWozgugPb50/KhIfeQ7V7aAVLMzWQzgw52vOOwmXiWs3pCYWVoWKF5JdiKDGsECVrjyq1Lr5vSNfjQBwueKm4Qb2fBICfOqNvxyKnp3Tb7/h3tJfVBF8uyiGNFOMNl44r3A/3Mez4pLGjghkXMSTBoE+IEfWM83bKXUiKMzCXmdkT0U4OkihzLICXeBqpl57DaFddE7Zt5+es9bXpyXX1IBUVzYFUNCf7ahNoXul+f3TWnrDv/sbkiaDnZ4OPAqGG4perxjSsOvQJxwNS3Hmyi3XeLrBOyqiLBwvlYJfgZq4RbeY4d0hiUz+yTYgfbXDimYOX0Q4vU5ufTHnnc+60h7lJOlpDstIQNpWOtxlCGyMbf4gsEwKt+9OJ944uevTbKIIfmf7K22meeaOUdUDQePpghkVKPDAnOV8BpEuwCBV2TYVHb4A5XTdi+aupbKbdvercxYr6C3G4Xz0eQKpVM273sT8sOpv+Q2evuLwsn3itSPDx2DWZD2iRGtF28Lc4tsty4Jn/EpukCcjyuerblh0uKF10f9bh1PgY18IFvGorqjGSOtyGJC3tuDLd2AAAW+UlEQVTdavMphYuvPGLUVb87PslvEdn7MjnvdYVPX/X6fwSg6dcuGaL1GrWjXRV0VVVpVo3sk5aemX2ASz1U1qs8yP4QUVQPL7fDKlbDY9RO+On5WW8NnbvB6nNkVLb4qUSKeG6M1mVlyy6YdvjEhv31663lQesImTHpdlaiPVLp2B3LOktjj1rw8ae7fHHnhSiHKPCMKZXxjq586rSvu/rIyd/5WqNXvDYk66KZM5n62MRNux4edUbnxm5MatFdTWFDhS/gRaLdpjrkssTyx8cfwsEPnk/OnPc31ygpJ8Pq1qVQgM4ytU3Y9+TYt7ra5N3z+YOlbfzdnCMDwbAKFx36rhdTdPnWp685UCgsbfLLV2ps3NupVhOM5qI+hS/Nrux6v8+8D5+rUFw3gzEjkVXKe9Htp2579MIo10+7cc1wodewbxtCsFmNAHrJxWO3Lbv1S5JnZfZKCaSNPS49UEGlr6vyiRfwFjNkXwsy7PQMdyuzsjZSxKcmaFzhoj97Sdv0ORvfaWPcf1RU1bCoLVRfpu6abYuuOWDgz57x0X31RkI+GAvsTBj9rS03/fOBS9Z0zZUUTCu3ZHzs0+PPIhX80sxysLfQdvZ3D/4rL6rvHR9/XxVJOFVwpMAId8Cm+MrTqNCp25Z0rungJ+nmdVNUq3t5ilx9fdGKG44Z33pcHDR3ytqhlbp7u2FzQ2Ao2BAqb3ji9L6HfAufbrlnZ0XzA2YTpZq1Djad9W7c8eRFZ2bc+dO4Zsn0maTQslUL8qnKvltLV1+z6vCJD719w7ZqKm14mLIBwQbkCnXjdi66MioqnDb/ow2FwcRzaUe6HuloopP1+j82rLr4gKdl4P07LqhqD33MW1wI+yLobQkhE9/bPntqXuik/C2JdUhoafS1wGwR4OQZ2FqrnWVLLvQf7dv7+we/+mlbMz9SNSVBUSRksq0T9z01OnosZk1/eWyN2utzxpwCXaaR6DDVonVnbv0RvEp9b331Hl1SH+hlo+75ZsmN0ZSTgdNf/V2NHv+N5Mg0FEWi3FT7Dc1Pjnvl4Ll4bvvoPq+tb3446MOQOLV+5yNnpB0+1/S/bvx7rShcJDhc0P2NyGZ8E4oXXnjgS9TVvvecb9+rkl2XCyYOTKAGA2xt12x5ujN5cNikF0aXmwd9FeGTDVYJUrlx8pvb80+aePhYA2evy66jM0sjlB0cFUGq3ri57OmLDqQ959z53Q9VQesoGWbwvA5GDCLdJHxfanv/zMNl8UF//cfUar+2tJ+p7catz1z98n+EgybdvHZo0Ja5XaZtIFzQY9WrEn3FOQdnJw7I/+nCEtH2ETlGVV8H0uKEmrqHh2Yk3Vv1RGtAmqfrihRHdQjJwZ1j9j4/pVtd9ty7fti2t40dTjmTYdHakCkXH7hcYOS89zYUeOPP1e3puplRaXtk35XNSy96t2txaXd8M6ZNNX1hUKzBRkRqgEPauuWx0SPJ53kLCtx1nKu5OSJG7+BMsvBwSXscJHvzaMQZMvPtLc1M75O8ugOyJiGda55Qs7CTg/a9+6utNUryCJMuwPC3IMXcNqN00cUH8pAO7vPcuU9aI22Rkd+uufeA/Dr0jq/eLfXhCtaZCJsAJBuN/QofOveQ4/CU+RvO2dzGf2lJzlCllka2N9N6zr7ll/3j4L77/vUfH+wL2i6DxQqL1IaBRuWtW5Zc3+2LnzP3n++WBuOuSE52IdhQjF5s8zV7ll8fBWju7Rs2VWoJp6mMFRYlhFyr/6Itj55zxLynvn/94f0KyfIHmmNglZqQJzRe8PWT13xKjvjMe/e21LTLCVaHE7oagpWl4W/2oZdNfK900Vl/PHjeA2d+PaMyJD873C3dtOnRf3Hqo+3FcXHQtMlvDhMd2YV+jQOjiEi1KNVGU2nuweVfsu/55roy0fkqdEaCpgtunt7U8sTgMzz5dZ/XN7WM5ew2CFI9MqS9Y4pW3tJNJsvWLysoC1mHUawALtyI3nr52JKuI/6O9Z8Wyynn+SmHAV2mHGrLRP+ysVGOljHr71mixfNSu6j9ztB0ZNgsDa5A2SUFizuPoFF3/pBcIaQ1NpNbjFUFveIsEJp2/ywHHbXgw61F/rgRhi0dkiQhlWq6uvqZs9aNm/FszhZuUEmHngwLbYZT70CcVtKvePG1xxXlTm628zsGtDaKHAKSjIwkc7Pi29P78BylfpNfHdYeP7SwVebBkDWhYXXForGTD97EnLlfvFequC/n7C6YArXI8hdM3r5mWre0lpw5X79XQ6VdTmrwCFIrMrjGibsXT3iz96z34+DM7qgLUtAoCul2AdaO7Z7iRUfOt0+57aP7GumUfKs7BaGaYpzm1p76/tHz5p00aQsX7hPfUN0cSsjMzl5ZU7n7VlLY11DMKq8F2URz3fMlC686EKqYM/ufM/0wLfKo5X/ZtmTii/8RDtrnpheGBR39CkNU9D5KuC16ZdXDI/oc3Hna3T+9Wxfir+AZTmEiXi6NDU8te3bs8n75O3bVeJVBIm2FmQojOVgyvGLVhO2HT6zfQyXbSxrFoYzAwKJ54Vbqx5Yvuyoqg54y59NPSmX7+UHBaeiUTlk4yhcPPcQxrKfOJ0OiaFAmWrdCfTfHq127dfXIA3nnefkFniok1LWLWidAHRwS2re7ChddHpXRjvScfNf7Wwu9rhFwZBiUJFFOqeHqlmXnrPv97DfP/UlybZAdmdAVHWlWqqWWfivleE1K2be8NMhIHLyrQaQR0Rkk29HU+NCwlG5H6m3rsveZs0slzglG9KMv1/JDyZPnHhJJP2DeVx8UR1yXsdYE8OFG9FWKb9258oZuHDRz3j/er0PGH0g9cj7cgD5008Tdy6540zH5sxza1avEKxJFi0ZqgqWDqtyRfiRRhcwvadb7U1q5Pst1wwwm3I6hTnnDtkfPOp98NuTur1rL/VzCqFFn9t6945+XhvzhxZyQBA0CNEhwqU35tUsvup+07TPv26kdAX3pUJvv5m+euvSF/whASUBtA+sp1Gyp8IVFxNu5sN5acjEXbqyxalqa4O41fm/YfpvgSAQTbEESG3mrcvmlE8jgJ92/Zdeu5sggiXfBBBGp4bLuAM3Pp1PEy7a1KJahHKNGI+Dtgeqx1S9cFwXoqXd8+8luP86n45ONQCRAmXm2OpEztcgRGSKpwsULuR0Bb7zdboY9Evg2Qaq/ceeKK8vJu2c8vsezRzTVtYUVQJGRamGR2FYav3PFxUc1M428a/3WUj1jhE91GLQsUamcfHXdU8PX9b9xzTUtif1eD5mTIbb54HbwP7Q8NuS4UzAGzHhzcD2SdpJUFEWl4XGbGuvvyU3tBtDZ67PL2cxSkbXBqgThjpRvrlx2xSGlbnLmfflhuey+mOedoMUGZOiVtxUvm7Di8L76zP96faWUfKnVZIXaWolhNv/EH5+5+E3hlo/60c7MvQbFR/Ol7Dbem03vTduaf+QIrZQ566c0qknLLXHpoHyt8KCpsPTZ8/Oie3zXR00VYVtSQnz8wNJ7hhQPvuODh6oD8XeplnQjrNGUFa3ore26ZveSG99wTd0wida5VcMTlJu/fOi8/wxAc25ZPbzdmr2tnY6HQZvBCSwYXwNs5AZfXYJO8ZAoO9w2rsnh37N8+7IJD3QRKnvuF5/WyI7zKKsTgtKG+PYtwytenNGNg+Y8VLK9tFEcylt4xFFeJAaK84qWd96+dvK9Wz8t9eE8n2boZoGmPQ76/LL7hm/oGiPrjh9HtjOmDbLOxEfa2jHYzcAT2eXZsGhyQ17+d54qJaHObzAwdB0pPAVnoCKh6Jnzj2qfzJ3+3tZS1TNCt6UaCAUoj0OdUP/Y8LeGTXrt3CprxoYgmxC9UDYzztSsVX6TebRKd93AMuW5oUry8O0NYRaGzsNKy7WBJ/IOBCZ3te87+9PsBi6pNCwCvCZhRIK6+YcHfncIQHPv+f6jve38hVaLLcpBU43a6UXLr116+JhD7v5m/e5286UWkxkmsQ3JUtXE3S/86c3EKZ/k6taUPbKkQqeB+NQUJIuF1qMBNHPu3x+oR/o9ikjDyWvINXd8tPnhcy4m4+XN/7ihRnSmZCSYBhbcc1Ix+VvqzB9WNogJk82uOMihRsQxLTBBzVMY8ylqyLuqlyX8l+0Lr/7PHPEEoG1xg7d1UE4YNA+TIfvTERyPcGOzBtnNMEIra3YFh5Q17Dvck5B399eP7GhlFxhWp2xRO/hk//Yx+9YcahcktYc2DxzUXOen4nVDQlacCkvj18k7Vs6LejCy5325ozpkHULZXZADrUhmA1c3Lj5/3cGbkXlv4StVzZHrTfaECOOtMg+3VD2w8dmb7xv54PbcWtW6pzEkAqqKdKcFDn/5zwJ0yIKNWysUxwhZcBmqKFFuum1C05OnvHX2vDUpDY5hDXubNPCcA2bFD2e4pG/1i9dGufWxnsFzXx5aZaRvD2g2wODRyx0vBupLnrexKqVLYcrhsDHhoLJAd1oTmmVHqckeD6m1GWl6wwflK/5wSNJf7j2bPtnrN59vFQQIkWakGPUzipZe001Zy5335d+qlPhLLCYrwvWlGGDxTty28to3M6a87hLcA9obWkTIFAvGYoKHbcvZ99joQ2pXda0pd8HGF/cGzH+2O1wwvNXI5Rsf3bro6jvJ5/1nrq9pNdzpA1JMg769c0Rn2cj8fDpNvn5dXVvoj5Y4hxEONFHu5PjytsbGTyx6YOqAJPXPPz146UvHotlxKUk5s14fXiomb2NcmdBDfqRR3uraZ8dkHqtz8jkpjNVu6VPYonDQwl70Rs2kipUTDymiMHjm2uQO55C6piC5aDiIFKrp7ZpFfxjf1X//O/7+abnmOU81JwChVmQwHRMrn+pUkrqefvO/mV0SsC4ktkuT1EoPZEo+KFg44fLc/AJPkHLX1RF2JIvo5TLD3lGQUPTM0Q31A/MLC4qaO/JgidcRoei+ltCEfU+eFtXic+Z/9rfSiOsSWoiTzWqY7yXV37ln2QWPHokWJ834W4ZusV5Y6297rWX5+CA54pvNnp0R2gVDZqFJclTrJdVEyE0hpGqo3WY5LywzLSHGVqCQK5d1mR4UJz64+5Ez7z14jCF3f/PJzg72fIs1HrzYhnRUzdi1uDtABy345/rdAcelDG+DRW5DulI2oXjVddG19Jv999W1mucW2p6iBDvquYGO0HVFj511RON5+rxtP9ZFuFOIGckpN2C40DDys6dvjCqiA6b/vaTdiM8ZnuUcvGHOoAM1S0mgeK3D83m7bjmd3DMVIXvAmuCgQ0gI7/5TxbKJrx4LQ8cF0GFz1uftoz0FQZWHAAVZQqCs+PHROcfqvOvzQXdt+qDEz18GhoXbaHuz/tkxh9ja+s//bOKeFnatIz4JQqQBceHScaUv3nbAXXp6/uefbvbGnacKbiDQCofeMtG/8oJDAJox75sPmuC+zBBckBv24My0wJrvHrjkpqF3/5TrZZP2VAeJmUlGsssKs1ZlrswffcQCtFGOcNdPBWXBcB5tcem8bKJdwYoJNavOi27q8Bmv57Sa+5S06A5oEQl9ODEiSNW5u5ZPrDmcHp45W9d7fd5L3Xb67qpFox/OmrZmSIc5a4dfscBEO2Bh6NqMJPZKw9fop1jRkBTFtuvhc7e4Z22aGmQSloLnNT3SxvQROs7f8/i4AyINGWfIPf/4eGcre4HJnhgFaKZRO33nkgndjvjceV+u3yslXGpLSIPYUIpecsnVFS/eGD19hk9emVNjGlzSYRDzkII0U+CHuoVndZOpe9+yfkIzn/aGJSEFvuYKDHBJL+94dOyBan9Dpn+4p0525A5Lcw7+x73DDymqO3jm+mSf2bOrOcIlGrwLOiWACdWhD7Xv2j1Lx689FoaOC6CDp6wd2mrO3u6jLTA00bAZvrLWRWP6Havzrs+JP7xUztrqNRweK8dBCNVe3b6y84juPe8fw9uV+HdVg88yawEkiaX3Fj9/7SFFFvKmr/2knOp3foBNVJxWC8dI7de1PtH/wDc9YeqnUwNswlLKROSdADyWCNLpypE/Pnbt1tPztyfV6damhlAYGsdDEASovvbrBiWbmwKNdQxrYuCwOBH0NiZYKeXbnxb+oWb4gi8LajRLXofEiLzCmTLZ0NV7F595QKQYcdsL11bxfV8LGQ44yd1eYkcpb9ZuSQ5VbCK24b63vpIUNGU/GIhgkpNVvnG5m8aRvKWBU18aVMdl7oqwiZIShpATx9SXPDKwmxF+xKwv1uwJ229UTSakJWhtmcb29K/zD63onHvH5x9V6YkX6mBhklqRidrrdi65vhv3y5390d8q6d6XSCqrmxCg+zPV4wsXXhF1n0a539Q3JzTRSW+IXDIAFXa9cTUTlmcTbd4zaZUFdMal5vjea6p9kknTZKS7jG39Fe/vPnvqvGihNfIMmvRaUYstZ8AQj3XQl3MHd6sMfdr0l/Pa7MMK6gImUBRnUOF6KsfaPKHg2T92cywcjqnjAujQvzw/uJHy7AxydtCMgdQ4Suf2fmkm0U3HC9IB8z7M8TGeVxp90qmCLqG/PVyjSHJVE5LPDMoMbBzg0lvzS5Z3miMOfi69+709mxrYXFFIgSLLcDkcsPIMGJ6YayJo8/lBMyZokTB6u20aH6m+aPvTV0Y5Tt6Cj93esK25XZGgsizCkgaiMNCyBIpioJLrCjXif1bQK4F9eMdjo+8+6653d+1uUgfpQjxoxUASguOLVv9rU0m/g2e/fW5E6PWRtyPEagwHv2YgIdERZOXWZkaWs0SRhpXFO05zy407uqrm3bxsQBWfXiTxbqhhGQPjDBQ8MbrbHpz0100/7A2YRhmsjhS2aea+hRd1q6Q8Yv7HHxd72Qt4kwBBakcG1Tx9y/LJ3TjoqfM/3rytQziZscWDCjUhC3WTdq78yyEi1oCpr46TnQNfrverqZoegd0mgNXlGqfD0au5MQBZUuBymJFgxavxrHTb1/mjgwfvz8hbVxXV0mkDeqcKA3+4Z1xUSTr8GXzze+MiJs9nvmAYdjYCD980YePym/4zAM296XE77xqxKKDxbo7RFHOkbseO5dd3A9IxwZqfT2d6T55imFw32DjuZEYjtkm5TVf877Fq24rtS27olrpL+jzr5odmhB29x+h8nCGJCk2Bo8EIAE1TYHQoUsCw8HwLwr6tDp568+uDfOLk/dNmvfeSTqsug4ahUhQFg6YYg6Vkiqf8nI0VeMEQQi2IM9oX/vPp6z8fM+PxR1QucYA3bGhWs5WjAg13bnxuTrd68GffviqxTXb+sV01jTNcnlGMwHl0X321XQ9uMUttq7at+JeYQuZx+vX5Sf747MV+3UTZKYO2y827f1g5Nf9guvWZ+lFmu5BVGVJZJFkj9XHCnj5HyhodM+/1mV7Gca6iqLqD1zg+UPPEV0tnd/PQnT3zxWntbNK4iGpodl5jzB0lT218/o5vD98rEjLY7Ei6NMSaxtEWx+XgmAQGFEwGtYsT2za49MZ1Xz1x7eYj7fHo2x6/R3JmDGAi/tu/XTT5qIV1T7vh+TGMxTGN51RG7Ci5c9Or+dH6/D/3HBcHPUIH5L1jxlT+3MBEcyefH0/84LEW8Zv5/H/iNY/XaH+0OcdN3XC3l0570MkbSNAarilfdO7/n8zNq9YxJOb2//f+/FKA/mYwcSJNhASFU3mXNO0ub4rrLYirKpddceuJtL5fspYYQH8J1f4P3+l763PnxLmTz9rKFNz/v+XG/4fT/NW6jgH0VyN1bKBfQoEYQH8J1WLv/GoUiAH0VyN1bKBfQoEYQH8J1WLv/GoUiAH0VyN1bKBfQoEYQH8J1WLv/GoUiAH0VyN1bKBfQoEYQH8J1WLv/GoU+H8pmc3N+7MFhgAAAABJRU5ErkJggg==' style='max-width: 120px;'></div>
                                                                </td>
                                                                <td width='15' style='display:block;width:15px'></td>
                                                                <td width='100%'><span style='font-family:Helvetica Neue,Helvetica,Lucida Grande,tahoma,verdana,arial,sans-serif;font-size:19px;line-height:32px;color:{title_color}'>{html_title}</span></td>
                                                            </tr>
                                                            <tr style='border-bottom:solid 1px #e5e5e5'>
                                                                <td height='15' style='line-height:15px' colspan='3'></td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                                <td width='15' style='display:block;width:15px'></td>
                                            </tr>
                                            <tr>
                                                <td width='15' style='display:block;width:15px'></td>
                                                <td>
                                                    <table border='0' width='100%' cellspacing='0' cellpadding='0' style='border-collapse:collapse'>
                                                        <tbody>
                                                            <tr>
                                                                <td>
                                                                    <span style='font-family:Helvetica Neue,Helvetica,Lucida Grande,tahoma,verdana,arial,sans-serif;font-size:16px;line-height:21px;color:#141823'>
                                                                        <div>{html_body_content}</div>
                                                                    </span>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td><td width='15' style='display:block;width:15px'></td>
                                            </tr>
                                            <tr>
                                                <td width='15' style='display:block;width:15px'></td>
                                                <td>
                                                    <table border='0' width='100%' cellspacing='0' cellpadding='0' align='left' style='border-collapse:collapse'>
                                                        <tbody>
                                                            <tr>
                                                                <td style='font-family:Helvetica Neue,Helvetica,Lucida Grande,tahoma,verdana,arial,sans-serif;font-size:11px;color:#aaaaaa;line-height:16px'>{html_footer_sent_to}.<br>Équipe du CODC / Équipe CDTK Team - Ressources Naturelles Canada / National Resources Canada</td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                                <td width='15' style='display:block;width:15px'></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <br/><br/>
                </div>
            """
