"""
This module offers functions to communicate with AWS services
"""

# 3rd party imports
import os, glob, boto3, json
from typing import Any
from botocore.exceptions import ClientError
from boto3 import Session
from pathlib import Path


def get_ecs_client(iam_role: str):

    # Create an STS client object that represents a live connection to the
    # STS service
    sts_client = boto3.client('sts')

    # Call the assume_role method of the STSConnection object and pass the role
    # ARN and a role session name.
    assumed_role_object = sts_client.assume_role(
        RoleArn=iam_role,
        RoleSessionName="AssumeRoleECS"
    )

    # From the response that contains the assumed role, get the temporary
    # credentials that can be used to make subsequent API calls
    credentials = assumed_role_object['Credentials']

    # Use the temporary credentials that AssumeRole returns to make a
    # connection to Amazon ECS
    ecs_client = boto3.client(
        'ecs',
        aws_access_key_id=credentials['AccessKeyId'],
        aws_secret_access_key=credentials['SecretAccessKey'],
        aws_session_token=credentials['SessionToken'],
        region_name='ca-central-1'
    )

    # Return the Amazon ECS client object that is now configured with the
    # credentials to access your ECS Service.
    return ecs_client


def get_s3_resource(iam_role: str):

    # Create an STS client object that represents a live connection to the
    # STS service
    sts_client = boto3.client('sts')

    # Call the assume_role method of the STSConnection object and pass the role
    # ARN and a role session name.
    assumed_role_object = sts_client.assume_role(
        RoleArn=iam_role,
        RoleSessionName="AssumeRoleECS"
    )

    # From the response that contains the assumed role, get the temporary
    # credentials that can be used to make subsequent API calls
    credentials = assumed_role_object['Credentials']

    # Use the temporary credentials that AssumeRole returns to make a
    # connection to Amazon S3
    s3_resource = boto3.resource(
        's3',
        aws_access_key_id=credentials['AccessKeyId'],
        aws_secret_access_key=credentials['SecretAccessKey'],
        aws_session_token= credentials['SessionToken']
    )

    # Return the Amazon S3 resource object that is now configured with the
    # credentials to access your ECS Service.
    return s3_resource


def get_secret(region: str, service_name: str, secret_key: str) -> dict:

    # Create a Secrets Manager client
    session = Session()
    client = session.client(
        service_name=service_name,
        region_name=region
    )

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_key
        )

    except ClientError as e:
        # For a list of exceptions thrown, see
        # https://docs.aws.amazon.com/secretsmanager/latest/apireference/API_GetSecretValue.html
        raise e

    # Decrypts secret using the associated KMS key.
    return json.loads(get_secret_value_response['SecretString'])


def list_bucket(bucket_name: str, iam_role: str, filter_prefix: str | None = None) -> Any:

    try:
        # Get S3 resource using iam_role
        s3_resource = get_s3_resource(iam_role)

        # If filtering
        if filter_prefix:
            # Return the list of objects
            return s3_resource.Bucket(bucket_name).objects.filter(Prefix=filter_prefix) # type: ignore

        else:
            # Return the list of objects
            return s3_resource.Bucket(bucket_name).objects.all() # type: ignore

    except ClientError as e:
        print("ERROR LISTING FILE ON S3")
        print(str(e))
        raise


def upload_bucket_file(source_file: str, iam_role: str, bucket_name: str, prefix: str, file: str) -> None:
    """
    Uploads the given file to an S3 Bucket, given an iam_role and a bucket name.
    """

    try:
        # Get S3 resource using iam_role
        s3_resource = get_s3_resource(iam_role)

        # Make sure it ends with a "/"
        if not prefix.endswith("/"):
            prefix = prefix + "/"

        # Send the file to the bucket
        s3_resource.Bucket(bucket_name).upload_file(source_file, prefix + os.path.basename(file)) # type: ignore

    except ClientError as e:
        print("ERROR UPLOADING FILE TO S3")
        print(str(e))
        raise


def upload_bucket_folder(source_folder: str, iam_role: str, bucket_name: str, prefix: str) -> None:
    """
    Uploads the given folder to an S3 Bucket, given an iam_role and a bucket name.
    """

    try:
        # Get S3 resource using iam_role
        s3_resource = get_s3_resource(iam_role)

        # Make sure it ends with a "/"
        if not prefix.endswith("/"):
            prefix = prefix + "/"

        p = Path(source_folder)
        mydirs = list(p.glob('**'))
        for mydir in mydirs:
            file_names = glob.glob(os.path.join(mydir, "*.*"))
            file_names = [f for f in file_names if not Path(f).is_dir()]
            for i, file_name in enumerate(file_names):
                file_path = file_name.replace(source_folder, "").replace("\\", "/").replace("//", "/").strip("/")

                # Create the AWS path
                aws_path = os.path.join(prefix, file_path)

                # Send the file to the bucket
                s3_resource.Bucket(bucket_name).upload_file(file_name, aws_path) # type: ignore

    except ClientError as e:
        print("ERROR UPLOADING FOLDER TO S3")
        print(str(e))
        raise


def copy_bucket_folder(bucket_name_from: str, prefix_from: str, bucket_name_to: str, prefix_to: str, iam_role: str, delete_og: bool) -> None:

    try:
        # Get S3 resource using iam_role
        s3_resource = get_s3_resource(iam_role)

        # Get Bucket from
        bucket_from = s3_resource.Bucket(bucket_name_from) # type: ignore

        # Get Bucket to
        bucket_to = s3_resource.Bucket(bucket_name_to) # type: ignore

        # Get all keys in folder
        objects_from = bucket_from.objects.filter(Prefix=prefix_from)

        # For each key
        for key in objects_from:
            dest = prefix_to + "/" + os.path.basename(key.key)

            # The og file param
            params = {
                'Bucket': bucket_name_from,
                'Key': key.key
            }

            # Copy the object
            s3_resource.meta.client.copy(params, bucket_name_to, dest) # type: ignore

            # If deleting the original
            if delete_og:
                key.delete()

    except ClientError as e:
        print("ERROR COPYING FOLDER IN S3")
        print(str(e))
        raise


def delete_bucket_folder(source_folder: str, iam_role: str, bucket_name: str, prefix: str) -> None:
    """
    Deletes the given folder from an S3 Bucket, given an iam_role and a bucket name.
    """

    try:
        # Get S3 resource using iam_role
        s3_resource = get_s3_resource(iam_role)

        # Make sure it ends with a "/"
        if not prefix.endswith("/"):
            prefix = prefix + "/"

        # For each key
        for key in s3_resource.Bucket(bucket_name).objects.filter(Prefix=(prefix + source_folder + "/")): # type: ignore
            key.delete()

        return

    except ClientError as e:
        print("ERROR DELETING FOLDER FROM S3")
        print(str(e))
        raise

def download_bucket_file(bucket_name: str, input_package_path: str, destination_path: str) -> str:

    # Connect to S3
    s3 = boto3.resource('s3')

    # Copy the file locally
    s3.Bucket(bucket_name).download_file(input_package_path, destination_path) # type: ignore

    # Return the destination path
    return destination_path
