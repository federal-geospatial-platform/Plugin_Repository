"""
This module handles the JWT authentication model and essential API validations.
"""

# 3rd party imports
from __future__ import annotations
import json
import datetime
from typing import Any, Literal
from flask_jwt_extended import create_access_token, create_refresh_token, decode_token, verify_jwt_in_request, get_jwt

# Application modules
from core.lib.msauth import MSAuth
from nrcan_core import config
from nrcan_core.lib.exceptions import *
from nrcan_core.db import db_conn
from nrcan_core.db.entity.user import DBUser


class User:
    """
    Class representing a User in the authentication system.
    """

    def __init__(self, _id: str, username: str, role: int) -> None:
        """
        Initializes a User object.

        :param _id: The unique identifier of the user
        :param username: The username of the user
        :param role: The role of the user (permissions level)
        """
        self.id: str = _id
        self.username: str = username
        self.role: int = role

    def __str__(self) -> str:
        """
        String representation of the User object.

        :return: A formatted string representing the User.
        """
        return f"User(id='{self.id}', username='{self.username}', role='{self.role}')"

    def toJSON(self) -> str:
        """
        Convert the User object to a JSON string.

        :return: The JSON representation of the User object.
        """
        return json.dumps(self, default=lambda o: o.__dict__, sort_keys=True, indent=None)

    @staticmethod
    def fromJSON(userjson: str) -> User:
        """
        Convert a JSON string to a User object.

        :param userjson: A JSON string representing a User.
        :return: A User object constructed from the JSON string.
        """
        userdic = json.loads(userjson)
        return User(userdic['id'], userdic['username'], userdic['role'])


def query_user(username: str) -> DBUser | None:
    """
    Query the database to find a user by their username.

    :param username: The username of the user.
    :return: A DBUser object if found, None otherwise.
    """
    return db_conn.query_user(username)


def query_user_and_generate_token(username: str, userfullname: str) -> dict:
    """
    Generate an access and refresh token for a user.

    :param username: The username to generate a token for.
    :param userfullname: The full name of the user.
    :return: A dictionary containing access and refresh tokens.
    :raises TokenInsufficientException: If the user credentials are invalid.
    """
    dbUser: DBUser | None = query_user(username)

    # If user found in the database
    if dbUser:
        # Create a User object
        user = User(username, userfullname, dbUser.role())

        # Generate token payload (access and refresh tokens)
        return _create_token_payload(user, True)

    else:
        # User credentials are invalid
        raise UserNotFound(username)


def refresh_token(ref_token: str) -> dict:
    """
    Refresh the user's token using the provided refresh token.

    :param ref_token: The refresh token.
    :return: A dictionary containing a new access and refresh token.
    :raises UserMessageException: If the refresh token is invalid.
    """
    # Decodes the refresh token. Will succeed only if valid.
    payload = decode_token(ref_token)

    # If token is of type "refresh"
    if payload['type'] == "refresh":
        # Create a new token payload using the user data
        return _create_token_payload(User.fromJSON(payload['sub']), False)

    else:
        # Invalid refresh token type
        raise UserMessageException(400,
                                   "Only refresh tokens are allowed.",
                                   "Seuls les tokens de type refresh sont permis.")


def generate_url_for_msauth(client_id: str, redirect_uri: str, scopes: list[str], code_challenge: str) -> str:
    """
    Generate an authorization URL to call the Microsoft Authentication (MSAuth) service.

    :param client_id: The client ID for the Azure AD app.
    :param client_secret: The client secret for the Azure AD app.
    :param redirect_uri: The redirect URI to be used in the OAuth flow.
    :param code_challenge: The PKCE code challenge.
    :return: The authorization URL.
    """
    # Instantiate MSAuth to handle MS authentication flow
    ms_auth = MSAuth(client_id, config.AUTHORITY)

    # Generate the OAuth URL
    return ms_auth.get_auth_request_url(redirect_uri, scopes, code_challenge)


def exchange_code_for_token(client_id: str, client_secret: str, redirect_uri: str, scopes: list[str], code_received: str, code_verifier: str) -> dict:
    """
    Exchange a code for a token
    """
    # Instantiate MSAuth
    ms_auth = MSAuth(client_id, config.AUTHORITY)

    # Acquire code for creds
    return ms_auth.acquire_token(client_secret, redirect_uri, scopes, code_received, code_verifier)


def read_claims_in_token(client_id: str, id_token: str) -> dict:
    """
    Read the claims inside the token
    """
    # Instantiate MSAuth
    ms_auth = MSAuth(client_id, config.AUTHORITY)

    # Acquire code for creds
    return ms_auth.decode_id_token(id_token)


def logout() -> bool:
    """
    Logs out the current user by revoking their JWT token.

    :return: True if the token has been revoked successfully.
    """
    # Retrieve the current JWT token
    jwt_token: Any = get_jwt()

    # Revoke the token and add to blacklist in the database
    return db_conn.add_token_revoked(jwt_token['jti'], datetime.datetime.fromtimestamp(jwt_token['exp'], datetime.timezone.utc))


def current_user() -> User | None:
    """
    Get the currently logged-in user based on the JWT token.

    :return: A User object if the token is valid, None if the token is invalid or expired.
    """
    try:
        # Verify JWT in request (optional verification)
        verify_jwt_in_request(optional=True)

        # Retrieve the current JWT token
        jwt_token: Any = get_jwt()

        # If valid token and subject exists
        if 'sub' in jwt_token:
            # Validate user's role (level 1 is the minimal required)
            validate_user(1)

            # Return User object based on the data in the JWT token
            return User.fromJSON(jwt_token['sub'])

    except Exception as err:
        # Handle token invalidation (expired, malformed, etc.)
        print(err)
        return None

    return None


def check_token_revoked(jwt_data_jti: str) -> Any | None:
    """
    Check if the token has been revoked (e.g., user logged out).

    :param jwt_data_jti: The JWT's jti claim (unique token identifier).
    :return: True if the token has been revoked, None otherwise.
    """
    # Query the database to check if this token is revoked
    return db_conn.query_token_revoked(jwt_data_jti)


def validate_api_key(api_key: str, role_level: int) -> Literal[True]:
    """
    Validates the provided API key and ensures the system using the api-key has sufficient permissions.

    :param api_key: The API key to validate.
    :param role_level: The minimum role level required for access.
    :return: True if the API key is valid and user has sufficient permissions.
    :raises TokenInvalidException: If the API key is invalid.
    :raises TokenInsufficientException: If the system using the api-key lacks sufficient permissions.
    """
    try:
        # Query user from database using the API key
        user: DBUser | None = query_user(api_key)

        # If the user is found in the database
        if user:
            # Check if the user has sufficient permissions
            if user.role() >= role_level:
                return True
            else:
                # System using the api-key lacks sufficient permissions
                raise TokenInsufficientException()

    except Exception:
        # API key is invalid or not found
        raise TokenInvalidException()

    # API key is invalid
    raise TokenInvalidException()


def validate_user(role_level: int) -> Literal[True]:
    """
    Validate the current user based on their role level.

    :param role_level: The minimum role level required for access.
    :return: True if the user has sufficient permissions, raises exceptions otherwise.
    :raises TokenInsufficientException: If the user's role is insufficient.
    :raises TokenRevokedException: If the token has been revoked.
    :raises TokenInvalidException: If the token is invalid.
    """
    # Verify JWT token in the request
    verify_jwt_in_request()

    # Retrieve the current user's JWT data
    jwt_data = get_jwt()

    # If the token contains the 'sub' key (user identifier)
    if 'sub' in jwt_data:
        # Construct a User object from the token's 'sub' claim
        user: User = User.fromJSON(jwt_data['sub'])

        # If the token has not been revoked
        if 'jti' in jwt_data and not check_token_revoked(jwt_data['jti']):
            # Check if the user has the required role level
            if user.role >= role_level:
                return True
            else:
                # Insufficient permissions
                raise TokenInsufficientException()

        else:
            # Token has been revoked
            raise TokenRevokedException()

    # Token is invalid
    raise TokenInvalidException()


def _create_token_payload(user: User, fresh: bool) -> dict:
    """
    Create a token payload containing access and refresh tokens for the user.

    :param user: The User object for whom the tokens are generated.
    :param fresh: Whether the access token should be fresh (new session).
    :return: A dictionary containing the access and refresh tokens.
    """
    # Return a dictionary containing both access and refresh tokens
    return {
        'token_type': "Bearer",
        'expires_in': config.TOKEN_EXP_MINUTES * 60,
        'refresh_expires_in': config.TOKEN_REFRESH_EXP_MINUTES * 60,
        'access_token': create_access_token(user.toJSON(), fresh),
        'refresh_token': create_refresh_token(user.toJSON())
    }
