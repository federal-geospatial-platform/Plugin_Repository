"""
This module handles Users management logic (create User, read User permissions, etc).
"""

# Application modules
from nrcan_core.db.entity.user import DBUser
from nrcan_core.db import db_conn
from nrcan_core.lib.exceptions import *


def get_users() -> list[DBUser]:
    """
    Gets a list of users in the system.
    """

    return db_conn.query_users()


def create_user(email: str, role: str) -> None:
    """
    Verifies if the user doesn't already exist and adds it in the database.

    :param email: The email of the User to create
    :raises UserMessageException: Raised when the user already existed or no email was defined.
    """

    # Validate the email is set
    if email:
        # Trim it
        email = email.strip()

        # Get the user by this email
        user: DBUser | None = db_conn.query_user(email)

        # If no user
        if user is None:
            # Add the User in the database
            db_conn.add_user(email, role)

        else:
            raise UserMessageException(500,
                                       "This user already exists.",
                                       "Cet utilisateur existe déjà.")

    else:
        raise UserMessageException(400,
                                   "Username undefined.",
                                   "Aucun nom d'utilisateur défini.")


def update_user(email: str, patch_operations: list) -> None:
    """
    Updates the given user in the database.

    :param email: The email of the User to update
    :param patch_operations: The list of operations to apply on the user
    """

    # Get the user by email
    user: DBUser | None = db_conn.query_user(email)

    # If found
    if user:
        # Update the department depending on the operations to apply
        for p in patch_operations:
            # If updating the English name
            if p["op"] == "update" and p["path"] == "/role":
                user.role_string_set(p["value"])

        # Save it back
        db_conn.update_user(email, user.role_string())

    else:
        # Not found
        raise UserMessageException(404,
                                    "User couldn't be found.",
                                    "Cet utilisateur n'existe pas.")


def delete_user(email: str) -> None:
    """
    Verifies if the user exists and deletes it from the database.

    :param email: The email of the User to delete
    :raises UserMessageException: Raised when the email doesn't exist or no email was defined.
    """

    # Validate the email is set
    if email:
        # Trim it
        email = email.strip()

        # Get the user by this email
        user: DBUser | None = db_conn.query_user(email)

        # If user exists
        if user is not None:
            # Delete the user in the database
            db_conn.delete_user(email)

        else:
            raise UserMessageException(404,
                                       "This user couldn't be found.",
                                       "Cet utilisateur n'existe pas.")

    else:
        raise UserMessageException(400,
                                   "Username undefined.",
                                   "Aucun nom d'utilisateur défini.")
