"""
This module provides functionality for managing progress mark indicators in the application.
Each progress mark includes a timestamp, an English message, and a French message.
"""

from datetime import datetime
from .exceptions import *  # Importing custom exceptions (if needed)


class ProgressMark(object):
    """
    A base class representing a progress mark indicator.

    Each progress mark includes a timestamp and messages in English and French.

    Attributes:
        date (datetime): The date and time when the progress mark was created.
        message (str): The message in English associated with the progress mark.
        message_fr (str): The message in French associated with the progress mark.
    """

    def __init__(self, message: str, message_fr: str) -> None:
        """
        Initializes a new progress mark with the given messages and the current timestamp.

        Args:
            message (str): The progress message in English.
            message_fr (str): The progress message in French.
        """
        self.date: datetime = datetime.now()  # Record the current date and time
        self.message: str = message  # Store the English message
        self.message_fr: str = message_fr  # Store the French message

    def __str__(self) -> str:
        """
        Returns a string representation of the progress mark, including the date,
        English message, and French message.

        Returns:
            str: A formatted string containing the timestamp and both messages.
        """
        return f"{self.date.strftime('%Y-%m-%d %H:%M')} - ENG: {self.message} | FR: {self.message_fr}"
