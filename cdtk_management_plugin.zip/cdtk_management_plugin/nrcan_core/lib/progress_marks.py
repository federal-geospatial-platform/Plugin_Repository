"""
This module offers application progress marks indicators.
"""

from datetime import datetime
from .exceptions import *


class ProgressMark(object):
    """Base class for Progress marks"""
    def __init__(self, message: str, message_fr: str) -> None:
        self.date: datetime = datetime.now()
        self.message: str = message
        self.message_fr: str = message_fr

    def __str__(self) -> str:
        return f"{self.date.strftime('%Y-%m-%d %H:%M')} - ENG: {self.message} | FR: {self.message_fr}"
