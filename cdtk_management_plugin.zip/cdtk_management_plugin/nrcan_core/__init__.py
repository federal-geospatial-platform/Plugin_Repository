# Start the log
from ..core.lib.logger import init_log
from ..nrcan_core import config_env

# Init the log
init_log('cdtk_log', config_env.LOG_FILE, config_env.LOG_LEVEL_FILE, config_env.LOG_LEVEL_CONSOLE)
