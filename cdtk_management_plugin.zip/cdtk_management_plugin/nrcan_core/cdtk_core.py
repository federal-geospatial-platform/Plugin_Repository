import os
from concurrent.futures import ThreadPoolExecutor

from core.lib.logger import *
from core.lib import aws
from nrcan_core import config, secret
from nrcan_core.requests.cdtk_request_registry_api import CDTKRequestRegistryAPI
from nrcan_core.requests.cdtk_request_publication_api import CDTKRequestPublicationAPI
from nrcan_core.db import db_conn
from nrcan_core.lib import auth
from nrcan_core.lib.exceptions import *


def get_cdtk_my_email() -> str | None:
    """
    Gets the email of the currently logged in user based on the Publisher table
    """
    LOG.trace_func()

    # Get current user
    cur_user: auth.User | None = auth.current_user()

    # If valid
    if cur_user:
        # Get the current user email
        return cur_user.id

    # Not found
    return None


def get_cdtk_my_departments() -> list:
    """
    Uses the CDTK Registry API to fetch the CDTK Departments of the currently logged in user based on the Publisher table
    """
    LOG.trace_func()

    # Instantiate the request and message classes
    cdtk_request = CDTKRequestRegistryAPI(secret.get_secret_api_registry_api_key())

    # Get current user
    cur_user: auth.User | None = auth.current_user()

    # If valid
    if cur_user:
        # Get the departments using the email of the logged in user
        return cdtk_request.get_departments_by_publisher(cur_user.id)

    # Empty list
    return []


def get_cdtk_my_servers() -> list:
    """
    Uses the CDTK Registry API to fetch the CDTK Servers of the currently logged in user based on the Publisher table
    """
    LOG.trace_func()

    # Instantiate the request and message classes
    cdtk_request = CDTKRequestRegistryAPI(secret.get_secret_api_registry_api_key())

    # Get current user
    cur_user: auth.User | None = auth.current_user()

    # If valid
    if cur_user:
        # Get the servers using the email of the logged in user
        return cdtk_request.get_servers_by_publisher(cur_user.id)

    # Empty list
    return []


def get_cdtk_my_downloads() -> list:
    """
    Uses the CDTK Registry API to fetch the CDTK Downloads of the currently logged in user based on the Publisher table
    """
    LOG.trace_func()

    # Instantiate the request and message classes
    cdtk_request = CDTKRequestRegistryAPI(secret.get_secret_api_registry_api_key())

    # Get current user
    cur_user: auth.User | None = auth.current_user()

    # If valid
    if cur_user:
        # Get the downloads using the email of the logged in user
        return cdtk_request.get_downloads_by_publisher(cur_user.id)

    # Empty list
    return []


def get_cdtk_dataset(metadata_id: str | None) -> dict:
    """
    Uses the CDTK Registry API to fetch the dataset information on the metadata id
    """
    LOG.trace_func()

    # Instantiate the request and message classes
    cdtk_request = CDTKRequestRegistryAPI(secret.get_secret_api_registry_api_key())

    # If metadata id defined
    dataset_info: dict | None = None
    if metadata_id:
        # Get the datasets associated with the metadata id
        dataset_info = cdtk_request.get_dataset(metadata_id)

    # If found
    if dataset_info:
        # Read the dataset id
        dataset_id: str = dataset_info['dataset_id']

        # Get the map services associated with the dataset
        data_pub_infos: list[dict] = cdtk_request.get_data_publication_by_dataset(dataset_id)

        # Only return metadata_id, download_folder_name, core_subject_term and thumbnail_image_file
        return {
            'dataset': dataset_info,
            'data_publications': data_pub_infos
        }

    else:
        # Not found
        raise NotFoundException()


def _get_info_services_thread(request: CDTKRequestPublicationAPI, schema: str) -> dict:
    # The returned object
    retObj = {'schema': schema, 'services': []}

    # Query
    res = request.get_info_schema(schema)
    if res:
        # Store
        retObj['services'] = res['results']

    # Return the result object
    return retObj


def get_info_services_via_api() -> dict[str, list]:
    """
    Uses the CDTK Publication API to get the schema information on the given schema
    """
    LOG.trace_func()

    # Instantiate the request and message classes
    cdtk_request = CDTKRequestRegistryAPI(secret.get_secret_api_registry_api_key())

    # Get all the departments
    departments = cdtk_request.get_departments()

    # Get each schema
    schemas = [d['tbs_dept_acrn_en'] for d in departments]

    # Prepare the requester
    req: CDTKRequestPublicationAPI = CDTKRequestPublicationAPI(secret.get_secret_api_publication_api_key())

    # Prepare thread pool executor to submit parallel requests
    futures: list = []
    with ThreadPoolExecutor(max_workers=config.MAX_WORKERS) as executor:
        # Submit request for each schema
        futures = [executor.submit(_get_info_services_thread, req, schema) for schema in schemas]

    # Get all service names for each schema
    services: dict[str, list] = {}
    for future in futures:
        # Read
        read_result = future.result()
        # Compile
        services[read_result['schema']] = read_result['services']

    # Return services
    return services


def get_info_schema_service_via_api(schema: str, service_name: str) -> dict:
    """
    Uses the CDTK Publication API to get the service information on the given schema/service_name
    """
    LOG.trace_func()

    # Redirect call to API to execute QGIS stuff
    req: CDTKRequestPublicationAPI = CDTKRequestPublicationAPI(secret.get_secret_api_publication_api_key())

    # Return info as is from API
    return req.get_info_schema_service(schema, service_name) or {}


def get_info_data() -> dict[str, list[str]]:
    """
    Uses the CDTK Publication API to get the data information
    """
    LOG.trace_func()

    # Instantiate the request and message classes
    cdtk_request = CDTKRequestRegistryAPI(secret.get_secret_api_registry_api_key())

    # Get all the departments
    departments = cdtk_request.get_departments()

    # Get all table names for each schema
    data: dict[str, list] = {}
    for dept_acrn in [d['tbs_dept_acrn_en'] for d in departments]:
        # Redirect
        data[dept_acrn] = info_data(dept_acrn)

    # Return the data info
    return data


def info_data(schema: str) -> list[str]:
    """
    Gets the data table names published under the given schema
    """
    LOG.trace_func()

    # Return the result
    return db_conn.query_all_tables(schema)


def delete_table(schema: str, table_name: str) -> bool:
    """
    Deletes a table from the database
    """
    LOG.trace_func()

    # Return the result
    return db_conn.drop_table(schema, table_name)


def get_info_files_via_api() -> dict:
    """
    Uses the CDTK Publication API to get the folders information
    """
    LOG.trace_func()

    # Redirect call to API to execute QGIS stuff
    req: CDTKRequestPublicationAPI = CDTKRequestPublicationAPI(secret.get_secret_api_publication_api_key())

    # Return info as is from API
    return req.get_folders() or {}


def get_info_files() -> dict[str, dict[str, dict[str, list]]]:
    """
    Uses the CDTK Registry API to get the folders information from S3 bucket
    """
    LOG.trace_func()

    # Instantiate the request and message classes
    cdtk_request = CDTKRequestRegistryAPI(secret.get_secret_api_registry_api_key())

    # Get all the departments
    departments = cdtk_request.get_departments()

    # Get all datastores
    datastores = cdtk_request.get_datastores()

    # For each datastore
    files_total: dict[str, dict[str, dict[str, list]]] = {}
    for datastore in datastores:
        # If it's a datastore that points to an s3 download
        if str(datastore['datastore_type'] or '').startswith('s3_download'):
            # Read the secret
            secret_value = secret.get_secrets_by_key(datastore['connection_string'])

            # Get all folders/files for each root
            file_ds: dict[str, dict[str, list]] = {}
            for root in [f"{d['tbs_dept_acrn_en'].lower()}_{d['tbs_dept_acrn_fr'].lower()}" for d in departments]:
                # Grab the folders for the schema
                coresubs = info_files(secret_value['bucket_name'], f"{secret_value['subfolder_name']}/{root}")

                # For each folders/files read from S3
                file_coresub: dict[str, list] = {}
                for coresub in coresubs:
                    # If the content is a folder
                    if coresub['type'] == 'folder':
                        # Strip the prefix
                        dir_path = coresub['path'].removeprefix(f"{secret_value['subfolder_name']}/{root}")

                        # Read the pending dir name
                        dir_name: str = dir_path.removeprefix("/")

                        # If the dir name contains "/"
                        if "/" in dir_name:
                            # Split the pending dir
                            dir_name_split: list[str] = dir_name.split("/")

                            # Read the core_subject_term and the folder name
                            core_subject_term = dir_name_split[0]
                            folder_name = dir_name_split[1]

                            # If the core subject term hasn't been read yet
                            if core_subject_term not in file_coresub:
                                file_coresub[core_subject_term] = []

                            # If the folder_name hasn't been added yet
                            if folder_name not in file_coresub[core_subject_term]:
                                file_coresub[core_subject_term].append(folder_name)

                # Compile information
                file_ds[root] = file_coresub

            # Add to the dict
            files_total[datastore['datastore_id']] = file_ds

    # Return the files
    return files_total


def info_files(bucket_name: str, root: str) -> list[dict]:
    """
    Gets the data from files repository
    """
    LOG.trace_func()

    # Return the result
    folder_paths: list[str] = []
    all_paths: list[dict] = []
    for obj in aws.list_bucket(bucket_name, root.lower()):
        full_path: str = obj.key
        dir_path: str = os.path.dirname(full_path)
        file_name: str = os.path.basename(full_path)
        file_name = file_name.strip("/")
        if len(file_name) > 1 and not file_name in config.SYS_DOWNLOAD_ROOTS:
            if not dir_path in folder_paths:
                folder_paths.append(dir_path)
                all_paths.append({'type': 'folder', 'path': dir_path})
            all_paths.append({'type': 'file', 'path': obj.key})
    return all_paths


def delete_folder(datastore_id: str, schema: str, core_subject_term: str, folder_name: str) -> bool:
    """
    Deletes a file from the file repository
    """
    LOG.trace_func()

    # Validate there are no "/" or "\" in the parameters
    if not '/' in schema and not "\\" in schema and \
       not '/' in core_subject_term and not "\\" in core_subject_term and \
       not '/' in folder_name and not "\\" in folder_name:
        # Validate the schema and core_subject_term look like we expect
        if "_" in schema and "_" in core_subject_term and len(schema.split("_")) == 2 and len(core_subject_term.split("_")) >= 2:
            # Instantiate the request and message classes
            cdtk_request = CDTKRequestRegistryAPI(secret.get_secret_api_registry_api_key())

            # Get the datastore id
            datastore = cdtk_request.get_datastore(datastore_id)

            # If found
            if datastore:
                # Read the secret
                secret_value = secret.get_secrets_by_key(datastore['connection_string'])

                # Delete the folder
                aws.delete_bucket_folder(secret_value['bucket_name'], f"{secret_value['subfolder_name']}/{schema}/{core_subject_term}/{folder_name}")

                # Return true
                return True

    # Failed
    return False
