import json
import os
import subprocess
import uuid
from chardet import detect

from nrcan_core import config, config_env
from nrcan_core.core import util
from nrcan_core.core.cdtk_message import CDTKMessage
from nrcan_core.lib import aws
from nrcan_qgis.lib.progress_marks import *
from nrcan_qgis.lib.exceptions import *
from nrcan_qgis.lib.warnings import *


def run_pyqgis(operation: str, run_file: dict, db_secret_key: str, message: CDTKMessage | None = None):

    def _read_exceptions_based_on_stderr(stderr: str):

        # Very experimental, but better than nothing for now!
        for l in stderr.splitlines():
            if l.startswith("lib.exceptions.QGISAggregationException: "):
                line = l[41:]
                ex_list = json.loads(line)
                return QGISApplicationException.list_dict_as_list_ex(ex_list)

            elif l.startswith("Exception: "):
                return [Exception(l[11:])]

            elif l.startswith("TypeError: "):
                return [Exception(l[11:])]

        # Catch all
        return [Exception(stderr)]

    def _read_result_based_on_stdout(stdout: str):
        result = True
        progress_marks = []
        warnings = []

        # If debug
        if config_env.IS_LOCAL:
            print()
            print("Catching the results from the stdout:")
            print("-------------------------------------")
            print(stdout.strip(os.linesep))
            print("-------------------------------------")
            print()

        # For each line
        for l in stdout.splitlines():
            if l.startswith("Result: "):
                line: str = l[8:]
                output = json.loads(line)
                result = output['result']
                progress_marks = QGISProgressMark.list_dict_as_list_progress_marks(output['progress_marks'])
                warnings =  QGISWarning.list_dict_as_list_warn(output['warnings'])
        return [result, progress_marks, warnings]

    def _copy_run_file(run_file: dict) -> str:

        # If the folder doesn't exist, create it
        if not os.path.exists(config.QGIS_JOBS_PATH("")):
            os.makedirs(config.QGIS_JOBS_PATH(""))

        # Generate a randomly generated filename to hold the control file information for the nrcan_qgis process
        filepath: str = config.QGIS_JOBS_PATH(str(uuid.uuid4()) + ".json")

        # Create the file with the control file information
        with open(filepath, 'w') as outfile:
            json.dump(run_file, outfile, indent=4)

        # Return the path of the created file
        return filepath


    # Extract the credentiels for the postgres vector datastore
    db_secret_value = aws.get_secret("ca-central-1", "secretsmanager", db_secret_key)
    host: str = db_secret_value['host']
    port: str = db_secret_value['port']
    dbname: str = db_secret_value['dbname']
    user: str = db_secret_value['user']
    password: str = db_secret_value['password']

    filepath: str | None = None
    try:
        # Copy the control file to a local file on server
        filepath = _copy_run_file(run_file)

        # Run it
        main_file: str = config.QGIS_PYTHON_PATH("main.py")
        try:
            res = subprocess.run(f"python {main_file} --operation={operation} --file=\"{filepath}\" --proj_path=\"{config_env.QGIS_PROJECTS_PATH}\" --db_host=\"{host}\" --db_port={port} --db_name=\"{dbname}\" --db_user=\"{user}\" --db_pass=\"{password}\"",
                                 shell=True, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

            # Read the result information
            [result, qgis_progress_marks, qgis_warnings] = _read_result_based_on_stdout(res.stdout.decode(detect(res.stdout)['encoding'])) # type: ignore

            # If part of a greater process, append the information
            if message is not None:
                message.progress_marks += qgis_progress_marks
                message.warnings += qgis_warnings

            return result

        except subprocess.CalledProcessError as e:
            # Unwrap the exception from the sub process
            if e.stdout:
                # Read the result information
                [result, qgis_progress_marks, qgis_warnings] = _read_result_based_on_stdout(e.stdout.decode(detect(e.stdout)['encoding']))

                # If part of a greater process, append the information
                if message is not None:
                    message.progress_marks += qgis_progress_marks
                    message.warnings += qgis_warnings

            print("THE ERROR")
            print(e.stderr.decode(detect(e.stderr)['encoding']))

            # Read the exceptions
            exs = _read_exceptions_based_on_stderr(e.stderr.decode(detect(e.stderr)['encoding']))

            # If part of a greater process, append the error(s), flag progress and raise an abort exception
            if message is not None:
                message.errors.extend(exs)
                message.add_progress("ERROR when executing PyQGIS.", "ERREUR lors de l'exécution du PyQGIS.")

            # Raise a UserMessageException, as reconstructed from PyQGIS code, right away
            raise util.combine_exceptions_for_response(exs)

    finally:
        # If not running in DEV, delete the file
        if filepath and not config_env.IS_LOCAL:
            os.remove(filepath)
