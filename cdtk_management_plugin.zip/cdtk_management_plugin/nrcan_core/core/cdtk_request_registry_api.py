"""Docstring"""

import json

from nrcan_core import config_env
from nrcan_core.core.cdtk_message import CDTKMessage
from nrcan_core.core.cdtk_request import CDTKRequest


class CDTKRequestRegistryAPI(CDTKRequest):
    """Helper class to perform requests to the CDTK Registry API"""

    def __init__(self, message: CDTKMessage) -> None:
        """Constructor"""

        # Call parent
        super().__init__(config_env.CDTK_ADMIN_URL, message)

        # Set an access code for the CDTK Registry API
        self._init_access_token()


    def _init_access_token(self) -> None:
        """Sets an access token using the system credentials"""

        payload: dict [str, str] = {
            'username': config_env.AWS_SECRET_VALUE['API_REGISTRY']['USER'],
            'password': config_env.AWS_SECRET_VALUE['API_REGISTRY']['PASS']
        }

        # Call post
        content: dict | None = self.postOrNone("/login", payload)

        # If found
        if content:
            # Set the token value
            self.access_token = content['access_token']


    def get_server(self, server_id: str) -> dict | None:
        # Call get or none
        return self.getOrNone("/servers/" + server_id)


    def get_servers_by_publisher(self, email: str) -> list[dict]:
        # Call get or empty list
        return self.getOrEmptyList(f"/servers?publisher={email}")


    def get_department(self, dept_acrn_en: str) -> dict | None:
        # Call get or none
        return self.getOrNone("/departments/" + dept_acrn_en)


    def get_departments_by_publisher(self, email: str) -> list[dict]:
        # Call get or empty list
        return self.getOrEmptyList(f"/departments?publisher={email}")


    def get_departments_by_dept_id(self, dept_id: str) -> list[dict]:
        # Call get or empty list
        return self.getOrEmptyList(f"/departments?dept_id={dept_id}")


    def get_publisher(self, email: str) -> dict | None:
        # Call get or none
        return self.getOrNone("/publishers/" + email)


    def get_publishers(self) -> list[dict]:
        # Call get or empty list
        return self.getOrEmptyList("/publishers")


    def get_dataset(self, metadata_uuid: str) -> dict | None:
        # Call get or none
        return self.getOrNone("/datasets/" + metadata_uuid)


    def put_dataset(self, dataset_name: str, department_acrn_en: str, metadata_uuid: str) -> dict:
        # Format the dataset payload
        payload: dict[str, str] = {
            'dataset_name' : dataset_name,
            'department_acrn_en': department_acrn_en,
            'metadata_id': metadata_uuid
        }

        # Call put 201
        return self.put201("/datasets", payload)


    def put_data_publication(self, publication_type: str, server_id: str, dataset_id: str, publisher_email: str) -> dict:
        # Format the data publication payload
        payload: dict[str, str] = {
            'server_id': server_id,
            'dataset_id': dataset_id,
            'publication_type': publication_type,
            'publisher_email': publisher_email
        }

        # Call put201
        return self.put201("/data_publications", payload)


    def get_data_publication(self, publication_id: str) -> dict | None:
        # Call get or none
        return self.getOrNone("/data_publications/" + publication_id)


    def get_data_publication_by_dataset(self, dataset_id: str) -> list[dict]:
        # Call get or empty list
        return self.getOrEmptyList("/data_publications/dataset/" + dataset_id)


    def get_datastore(self, datastore_id: str) -> dict | None:
        # Call get or none
        datastore_info: dict | None = self.getOrNone("/datastores/" + datastore_id)

        # If found
        if datastore_info:
            if 'external' in datastore_info['datastore_type'].lower():
                datastore_info['hosting'] = 'EXTERNAL'
            elif 'internal' in datastore_info['datastore_type'].lower():
                datastore_info['hosting'] = 'INTERNAL'

        # Return
        return datastore_info


    def get_datasource(self, datasource_id: str) -> dict | None:
        # Call get or none
        return self.getOrNone("/datasources/" + datasource_id)


    def put_datasource(self, datastore_id: str, datasource_name: str, datasource_path: str) -> dict:
        # Format the paylaod
        payload: dict[str, str] = {
            'datastore_id': datastore_id,
            'datasource_name': datasource_name,
            'datasource_path': datasource_path
        }

        # Call put201
        return self.put201("/datasources", payload)


    def get_download(self, core_subject_term: str, folder_name: str) -> dict | None:
        # Call get or none
        return self.getOrNone(f"/downloads/{core_subject_term}/{folder_name}")


    def get_downloads_by_publisher(self, email: str) -> list[dict]:
        # Call get or empty list
        # TODO: It seems there's no way to filter the downloads by publisher email. Fix it.
        return self.getOrEmptyList(f"/downloads?publisher={email}")


    def put_downloads(self, data_publication_id: str, datastore_id: str, core_subject_term: str, folder_name: str) -> None:
        # Format the payload
        payload: dict[str, str] = {
            'data_publication_id': data_publication_id,
            'datastore_id': datastore_id,
            'core_subject_term': core_subject_term,
            'folder_name': folder_name
        }

        # Call put204
        return self.put204("/downloads", payload)


    def delete_downloads(self, core_subject_term: str, folder_name: str) -> bool:
        # Call delete204
        return self.delete204(f"/downloads/{core_subject_term}/{folder_name}")


    def get_ows_services(self, service_name: str) -> list[dict]:
        # Call get or empty list
        return self.getOrEmptyList("/ows_services/" + service_name)


    def get_ows_service(self, service_name: str, service_type: str) -> dict | None:
        # Call get or none
        return self.getOrNone(f"/ows_services/{service_name}?service_type={service_type}&unique=true")


    def put_ows_service(self, service_name: str, service_type: str, data_publication_id: str,
                        datasource_id: str, project_filename: str, language: str) -> None:
        # Format the paylaod
        payload: dict[str, str] = {
            'service_name': service_name,
            'service_type': service_type,
            'data_publication_id': data_publication_id,
            'datasource_id': datasource_id,
            'project_filename': project_filename,
            'service_language': language
        }

        json_payload: str = json.dumps(payload, ensure_ascii=False)
        json_payload = json_payload.replace("'", "\u0060") # Replace single quote by inverse accent
        payload = json.loads(json_payload)

        # Call put204
        return self.put204("/ows_services", payload)


    def delete_ows_service(self, service_name: str) -> bool:
        # Call delete204
        return self.delete204(f"/ows_services/{service_name}")


    def get_oapi_service(self, collection_name: str, service_type: str) -> dict | None:
        # Call get or none
        return self.getOrNone(f"/oapi_services/{collection_name}?service_type={service_type}")


    def put_oapi_service(self,
                         collection_name: str, data_publication_id: str, datasource_id: str, group_name: str,
                         provider_name: str, provider_type: str, service_type: str, collection_metadata: str,
                         provider_map_wmsfacade: str, provider_feature_postgres: str, provider_coverage_rasterio: str) -> None:
        # Format the paylaod
        payload: dict[str, str] = {
            'collection_name' : collection_name,
            'data_publication_id': data_publication_id,
            'datasource_id': datasource_id,
            'group_name': group_name,
            'provider_name': provider_name,
            'provider_type': provider_type,
            'service_type': service_type,
            'collection_metadata': collection_metadata,
            'provider_map_wmsfacade': provider_map_wmsfacade,
            'provider_feature_postgres': provider_feature_postgres,
            'provider_coverage_rasterio': provider_coverage_rasterio
        }

        json_payload: str = json.dumps(payload, ensure_ascii=False)
        json_payload = json_payload.replace("'", "\u0060") # Replace single quote by inverse accent
        payload = json.loads(json_payload)

        # Call put204
        return self.put204("/oapi_services?reload_pygeoapi=false", payload)


    def delete_oapi_service(self, collection_name: str, service_type: str) -> bool:
        # Call delete204
        return self.delete204(f"/oapi_services/{collection_name}/{service_type}")


    def get_cdtk_email_by_ad_user_name(self, ad_user_name: str) -> str | None:
        # Get the publishers
        publishers: list[dict] = self.get_publishers()

        # If any
        if len(publishers) > 0:
            pubs = list(filter(lambda l: l['ad_user_name'] == ad_user_name, publishers))

            # If found
            if len(pubs) >= 1:
                return pubs[0]['email']

        # Not found
        return None
