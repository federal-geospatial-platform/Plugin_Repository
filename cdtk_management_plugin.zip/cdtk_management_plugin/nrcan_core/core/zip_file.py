"""Manage a ZipFile"""

import json
import os
import uuid
import re
import zipfile

from nrcan_core import config, config_env

class ZipFile(object):
    """This class manages the zip and offer different methods to access the information"""


    def __init__(self, zip_file, message):
        """Constructor"""

        self.message = message  # Error message object
        self.name_zip_file = None  # File address of the zip file
        self.name_files_extracted: list[str] = []  # List of the file name extracted
        self.control_file_str: str = ""
        self.infos = None

        self._save_zip_file(zip_file)

        if not self.message.if_errors():
            self._validate_zip_file(zip_file)

        if self.message.if_errors():
            self.message.add_progress("The zip file is invalid.", "Le fichier zip est invalide.")
            self.message.add_error_raise("ERROR while trying to read the zip file.", "Erreur lors de la lecture du fichier zip.")
        else:
            self.message.add_progress("The zip file is valid.", "Le fichier zip est valide.")


    def _save_zip_file(self, zip_file):
        """Save the ZIP file and raise exception if there is an error"""

        # If there's a zip file attached to the request
        if zip_file:
            # Save the file local
            if not os.path.exists(config.QGIS_IN_PACKAGES_PATH("")):
                os.makedirs(config.QGIS_IN_PACKAGES_PATH(""))
            self.name_zip_file = config.QGIS_IN_PACKAGES_PATH(str(uuid.uuid4()) + ".zip")
            zip_file.save(self.name_zip_file)

        else:
            self.message.add_error("Invalid request, no zip file", "Requête invalide, pas de fichier zip")


    def _validate_zip_file(self, zip_file):
        """Validate the content of the zip file and extract file: ControlFile.json
        The zip file must
           - contain a file named ControlFile.json
           - have all its file at the root level directory
           - any contains file with extension: .json, .zip or .qgs
        """

        # Keep track
        self.message.add_progress(f"Unzipping zip file package {zip_file}",
                                  f"Extraction du paquet fichier zip {zip_file}")

        # Work with a zip file
        with zipfile.ZipFile(zip_file, 'r') as zip_ref:
            # Get the list of files in the zip
            self.infos = zip_ref.infolist()

            # If the zip file has any folder
            if all(len(os.path.dirname(a.filename)) == 0 for a in self.infos):
                # If the zip file has a control file at the root
                if "ControlFile.json" in [i.filename for i in self.infos]:
                    # Loop on the files in the zip
                    for info in self.infos:
                        # If it's the control file
                        if "ControlFile.json" == info.filename:
                            try:
                                # Read the control file content
                                self.control_file_str = zip_ref.read(info).decode("utf-8")
                            except json.decoder.JSONDecodeError as e:
                                self.message.add_error(f"The structure of the control file is invalid: {e.args[0]}",
                                                       f"La structure du fichier de contrôle est invalide: {e.args[0]}")

                else:
                    self.message.add_error(f"The input package {zip_file} does not contain a JSON control file",
                                           f"Le paquetage d'entrée {zip_file} ne contient pas de fichier de contrôle JSON")
            else:
                self.message.add_error(f"Folders in the zip file {zip_file} aren't supported",
                                       f"Le fichier zip {zip_file} ne doit pas contenir de dossiers")

            # Extract the files from zip file
            for info in self.infos:
                # If not the control file
                if not re.match(r'.*\.json$', info.filename):
                    self.name_files_extracted.append(info.filename)
                    zip_ref.extract(info, config.QGIS_PROJECTS_PATH(""))

        return


    def clean_up_directory(self) -> None:
        """
        Cleans the directory from the temporary files either received from
        the API payload or extracted from an input zip file package.
        """

        # Keep track
        self.message.add_progress("Cleaning up workspace",
                                  "Nettoyage de l'espace de travail")

        # If there was a zip package
        if not config_env.IS_LOCAL and self.name_zip_file is not None:
            os.remove(self.name_zip_file)

        # If any working files
        if not config_env.IS_LOCAL:
            for file in self.name_files_extracted:
                os.remove(config.QGIS_PROJECTS_PATH(file))


