from typing import Union

from ..lib.progress_marks import *
from ..lib.exceptions import *
from . import util


class CDTKMessage(object):
    """
    Manages the messages related to the Publication process.
    """

    def __init__(self) -> None:
        """Constructor"""

        self.progress_marks: list = []
        self.warnings: list = []
        self.errors: list = []
        self.stack_trace: str = ""
        self.big_error: Union[BaseException, None] = None


    def get_user_message(self) -> Union[UserMessageException, None]:
        """Gets a UserMessagseException based on all the gathered errors"""

        if self.if_errors():
            return util.combine_exceptions_for_response(self.errors)
        return None


    def get_last_internal_error(self) -> Union[BaseException, None]:
        """Gets the last internal error"""

        if self.if_errors() and isinstance(self.errors[-1], UserMessageException) and self.errors[-1].internal_error is not None:
            return self.errors[-1].internal_error
        return None


    def set_stack(self, stack_trace: str) -> None:
        """Sets the stack list"""

        self.stack_trace = stack_trace


    def set_big_error(self, big_error: BaseException) -> None:
        """Sets the big error"""

        self.big_error = big_error


    def add_progress(self, english: str, french: str) -> None:
        """Keeps track"""

        self.progress_marks.append(ProgressMark(english, french))


    def add_error(self, english: str, french: str, internal_error: Union[BaseException, None] = None) -> None:
        """Adds an exception error"""

        self.add_error_exception(UserMessageException(500, english, french, internal_error))


    def add_error_exception(self, exception: UserMessageException) -> None:
        """Adds an exception error"""

        self.errors.append(exception)


    def add_error_raise(self, english: str, french: str, internal_error: Union[BaseException, None] = None) -> None:
        """Adds an error and raise the exceptions"""

        if internal_error is None:
            internal_error = self.get_last_internal_error()
        self.add_error(english, french, internal_error)
        self.if_errors_raise()


    def add_warning(self, english: str, french: str, internal_error: Union[BaseException, None] = None) -> None:
        """Adds an exception"""

        self.warnings.append(UserMessageException(500, english, french, internal_error))


    def if_errors(self) -> bool:
        """Returns True if errors are logged; False otherwise"""

        return len(self.errors) != 0


    def if_errors_mark(self, english: str, french: str) -> None:
        """If errors, add a marker with the information"""

        if self.if_errors():
            self.add_progress(english, french)


    def if_errors_raise(self) -> None:
        """If errors, raise an abort exception"""

        if self.if_errors():
            raise util.combine_exceptions_for_response(self.errors)
