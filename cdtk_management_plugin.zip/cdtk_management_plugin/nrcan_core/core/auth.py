"""
This module handles the JWT authentication model and essential API validations.
"""

# 3rd party imports
from __future__ import annotations
import json, datetime
from typing import Any, Literal
from flask import jsonify
from flask_jwt_extended import create_access_token, create_refresh_token, decode_token, verify_jwt_in_request, get_jwt

# Application modules
from nrcan_core import config, config_env
from nrcan_core.lib.exceptions import *
from nrcan_core.db import db_conn
from nrcan_core.db.entity.user import DBUser
from nrcan_core.ldap import ldap_conn


class User(object):
    """
    Class representing a User.
    """

    def __init__(self, _id: str, username: str, role: int) -> None:
        """Constructor"""
        self.id: str = _id
        self.username: str = username
        self.role: int = role


    def __str__(self) -> str:
        return f"User(id='{self.id}', username='{self.username}', role='{self.role}')"


    def toJSON(self) -> str:
        return json.dumps(self, default=lambda o: o.__dict__, sort_keys=True, indent=None)


    @staticmethod
    def fromJSON(userjson) -> User:
        userdic = json.loads(userjson)
        return User(userdic['id'], userdic['username'], userdic['role'])


def generate_token_ldap(username, password):
    """
    Reads the email and password parameters in the query string and generates a JWT with it. The JWT includes an
    access token and a refresh token.

    :param username: The username to generate a token for
    :param password: The password associated with the email
    :returns: A Flask response which contains a JWT Token Payload to be used as Bearer
    :raises UserMessageException: Raised when the user credentials are invalid
    """

    # If not running debug (default)
    ldapUser: dict[str, Any] | None = None
    if config_env.IS_LOCAL:
        # Pretend user in ldap was found
        ldapUser = { 'id': config_env.USER_LOCAL, 'username': config_env.USER_LOCAL}

    else:
        # Find the user in ldap
        ldapUser = ldap_conn.query_user(username, password,
                                        config_env.AWS_SECRET_VALUE['LDAP']['KEY_ATTRIBUTE'],
                                        config_env.AWS_SECRET_VALUE['LDAP']['DISPLAY_ATTRIBUTE'])

    # If User was found
    if ldapUser:
        # Check in the database using the user ldap key
        dbUser: DBUser | None = db_conn.query_user(ldapUser['id'])

        # If found
        if dbUser:
            # Create the User object
            user = User(ldapUser['id'], ldapUser['username'], dbUser.role())

            # Create a fresh token payload
            return _create_token_payload(user, True)

        else:
            # Couldn't find the User
            raise UserMessageException(403, "Invalid permissions.", "Permissions invalides.")

    else:
        # Couldn't find the User
        raise UserMessageException(401, "Invalid credentials.", "Crédits invalides.")


def refresh_token(ref_token):
    """
    Reads the refresh_token in the query string, validates it and creates another JWT with it. The JWT includes an
    access token and a refresh token.

    :param ref_token: The refresh token to verify
    :returns: A Flask response which contains a JWT Token Payload to be used as Bearer
    :raises UserMessageException: Raised when the refresh token is invalid
    """

    # Decodes the token. Will succeed only if valid.
    payload = decode_token(ref_token)

    # If refresh token only
    if payload['type'] == "refresh":
        # Create an unfresh token payload
        return _create_token_payload(User.fromJSON(payload['sub']), False)

    else:
        # Invalid refresh token
        raise UserMessageException(400,
                                   "Only refresh tokens are allowed.",
                                   "Seuls les tokens de type refresh sont permis.")


def logout() -> bool:
    """
    Logs out the current User completely and blacklists their token in the database.

    :returns: True if the token has been revoked.
    """

    # Get the jwt_token
    jwt_token = get_jwt()

    # Revoke the token for real in the blacklist
    return db_conn.add_token_revoked(jwt_token['jti'], datetime.datetime.fromtimestamp(jwt_token['exp']))


def current_user() -> User | None:
    """
    Gets the User object from the token.

    :returns: If the token is valid a :class:`~auth.User` object representing the currently logged User is returned.
     Otherwise, None is returned.
    """

    try:
        # Verify jwt
        verify_jwt_in_request(optional=True)

        # Get the jwt_token
        jwt_token: Any = get_jwt()

        # If valid
        if 'sub' in jwt_token:
            # Validate still good, role 1 is enough for this check
            validate_user(1)

            # Parse the token info to a User object
            return User.fromJSON(jwt_token['sub'])

    except (Exception,) as err:
        # Token probably was existing and was invalid (for example, expired)
        print(err)
        return None
    return None


def check_token_revoked(jwt_data_jti) -> Any | None:
    """
    Checks if the token has been revoked.

    :param jwt_data_jti: The jwt jti data from the token.
    :returns: True if the token has been revoked (if the user has logged out manually somewhere).
    """

    # Try to find the token in the revoked tokens in the database
    return db_conn.query_token_revoked(jwt_data_jti)


def validate_user(role_level: int) -> Literal[True]:
    """
    Validates the current user and raises exceptions when validation fails.

    :param role_level: The role level the user should have
    :raises TokenInsufficientException: Raised when the token is missing privileges.
    :raises TokenRevokedException: Raised when the token has been revoked.
    :raises TokenInvalidException: Raised when the token is invalid.
    """

    # Verify the jwt
    verify_jwt_in_request()
    jwt_data = get_jwt()

    # If the grab worked and the sub identity key exists
    if 'sub' in jwt_data:
        # Read the User
        user: User = User.fromJSON(jwt_data['sub'])

        # Check if the token has not been revoked
        if 'jti' in jwt_data and not check_token_revoked(jwt_data['jti']):
            # If sufficient role (or just no role check at all)
            if role_level == 0 or user.role >= role_level:
                # Ok
                return True

            else:
                # Insufficient permission
                raise TokenInsufficientException()

        else:
            # Token revoked
            raise TokenRevokedException()

    else:
        # Unexpected crash
        raise TokenInvalidException()


def _create_token_payload(user: User, fresh: bool) -> Any:
    """
    Creates an official JWT Bearer response which contains 2 payload-tokens:
     (1) the official access token and
     (2) the refresh token.

    :returns: A JSON indicating a standard JWT Bearer response.
    """

    # The access token
    return jsonify(
        token_type="Bearer",
        expires_in=config.TOKEN_EXP_MINUTES * 60,
        refresh_expires_in=config.TOKEN_REFRESH_EXP_MINUTES * 60,
        access_token=create_access_token(user.toJSON(), fresh),
        refresh_token=create_refresh_token(user.toJSON())
    )
