"""
This class represents a User record in the database.
"""

# Application modules
from nrcan_core import config


class DBUser(object):
    """
    Class representing a User record in the database.
    """

    def __init__(self, dictcursor) -> None:
        """Constructor"""

        self.dictcursor: dict = dictcursor


    def id(self) -> int:
        return self.dictcursor[config.DB_TABLE_USERS['FIELD_ID']]


    def username(self) -> str:
        return self.dictcursor[config.DB_TABLE_USERS['FIELD_LDAP_KEY']]


    def role(self) -> int:
        return self.dictcursor[config.DB_TABLE_USERS['FIELD_ROLE']]


    def to_json_simple(self) -> dict:
        return {
            'username': self.username(),
            'role': self.role()
        }


    def __str__(self) -> str:
        return "User(id='{id}', username='{username}', role='{role}')".format(id=self.id(),
                                                                              username=self.username(),
                                                                              role=self.role())

