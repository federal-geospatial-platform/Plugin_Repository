"""
This class represents a User record in the database.
"""

# Application modules
from nrcan_core import config
from nrcan_core.lib.exceptions import *
from psycopg2.extras import RealDictRow


class DBUser(object):
    """
    Class representing a User record in the database.
    """

    def __init__(self, dictcursor: RealDictRow) -> None:
        self.dictcursor: RealDictRow = dictcursor

    def id(self) -> int:
        return self.dictcursor[config.DB_TABLE_USERS['FIELD_ID']]

    def email(self) -> str:
        return self.dictcursor[config.DB_TABLE_USERS['FIELD_EMAIL']]

    def role(self) -> int:
        return self.dictcursor[config.DB_TABLE_USERS['FIELD_ROLE']]

    def role_set(self, role: int) -> None:
        self.dictcursor[config.DB_TABLE_USERS['FIELD_ROLE']] = role

    def role_string(self) -> str:
        return DBUser.convert_role_to_str(self.role())

    def role_string_set(self, role: str) -> None:
        self.role_set(DBUser.convert_role_to_int(role))

    def to_dict(self) -> dict:
        return {
            'email': self.email(),
            'role': self.role()
        }

    def __str__(self) -> str:
        return f"User(id='{self.id()}', email='{self.email()}', role='{self.role()}')"


    @staticmethod
    def convert_role_to_int(role: str) -> int:
        # Get the right role number based on the string
        if role == "admin":
            return config.ROLE_LEVEL_ADMIN
        elif role == "publisher":
            return config.ROLE_LEVEL_PUBLISHER
        elif role == "basic":
            return config.ROLE_LEVEL_USER
        else:
            raise UserMessageException(500, f"The provided role '{role}' isn't supported", f"Le rôle fourni '{role}' n'est pas supporté")


    @staticmethod
    def convert_role_to_str(role: int) -> str:
        # Get the right role number based on the string
        if role == config.ROLE_LEVEL_ADMIN:
            return "admin"
        elif role == config.ROLE_LEVEL_PUBLISHER:
            return "publisher"
        elif role == config.ROLE_LEVEL_USER:
            return "basic"
        else:
            raise UserMessageException(500, f"The provided role '{role}' isn't supported", f"Le rôle fourni '{role}' n'est pas supporté")
