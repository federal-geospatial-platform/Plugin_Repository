"""
This package offers database connection.
"""

# 3rd party imports
from nrcan_core import secret
from . import db_connection

# Create the database connection object using secret
db_conn = db_connection.DBConnection(host=secret.get_secret_db_publisher_host(),
                                     port=secret.get_secret_db_publisher_port(),
                                     dbname=secret.get_secret_db_publisher_name(),
                                     schema=secret.get_secret_db_publisher_schema(),
                                     user=secret.get_secret_db_publisher_user(),
                                     password=secret.get_secret_db_publisher_password())
