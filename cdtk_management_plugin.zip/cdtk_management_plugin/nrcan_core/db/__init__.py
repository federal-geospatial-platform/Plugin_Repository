"""
This package offers database connection.
"""

# 3rd party imports
from nrcan_core import config_env
from . import db_connection

# Create the database connection object which is GLOBAL
db_conn = db_connection.DBConnection(host=config_env.AWS_SECRET_VALUE['DB_PUBLISHER']['HOST'],
                                     port=config_env.AWS_SECRET_VALUE['DB_PUBLISHER']['PORT'],
                                     dbname=config_env.AWS_SECRET_VALUE['DB_PUBLISHER']['NAME'],
                                     user=config_env.AWS_SECRET_VALUE['DB_PUBLISHER']['USER'],
                                     password=config_env.AWS_SECRET_VALUE['DB_PUBLISHER']['PASS'])
