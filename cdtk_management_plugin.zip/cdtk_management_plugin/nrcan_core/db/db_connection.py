"""
This module offers functions to query and manage a Postgresql database.
"""

# 3rd party imports
import datetime
from typing import Any

import psycopg2
import psycopg2.extras
from psycopg2 import sql

# Application modules
from nrcan_core import config, config_env
from nrcan_core.lib import encr
from .entity.user import DBUser


class DBConnection(object):
    """
    Class representing a Database connection.
    """

    def __init__(self, host: str, port: str, dbname: str, user: str, password: str) -> None:
        """Constructor"""

        self.host: str = host
        self.port: str = port
        self.dbname: str = dbname
        self.user: str = user
        self.password: str = password


    def open_conn(self) -> Any:
        """
        Connects to the database.

        :returns: A :class:`~psycopg2` connection
        """

        # Connects and returns the connection
        return psycopg2.connect(host=self.host, port=self.port, dbname=self.dbname, user=self.user, password=self.password, sslmode="allow")


    def query_users(self) -> list[DBUser]:
        """
        Queries for all the Users in the system.

        :returns: A list of :class:`~entity.DBUser` objects
        """

        # Connect to the database
        with self.open_conn() as conn:
            # Open a cursor
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                str_query = "SELECT * FROM {table} ORDER BY {field_order}"

                # Query in the database
                query = sql.SQL(str_query).format(
                    table=sql.Identifier(config_env.AWS_SECRET_VALUE['DB_PUBLISHER']['SCHEMA'], config.DB_TABLE_USERS['TABLE_NAME']),
                    field_order=sql.Identifier(config.DB_TABLE_USERS['FIELD_LDAP_KEY']))

                # Execute cursor and fetch
                cur.execute(query)
                res = cur.fetchall()
                users: list[DBUser] = []
                for u in res:
                    users.append(DBUser(u))
                return users


    def query_user(self, ldap_key: str) -> DBUser | None:
        """
        Queries for a user given their ldap key.

        :returns: A list of :class:`~entity.DBUser` objects
        """

        # Connect to the database
        with self.open_conn() as conn:
            # Open a cursor
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                str_query = "SELECT * FROM {table} WHERE {field_ldap_key} ILIKE %s"

                # Query in the database
                query = sql.SQL(str_query).format(
                    table=sql.Identifier(config_env.AWS_SECRET_VALUE['DB_PUBLISHER']['SCHEMA'], config.DB_TABLE_USERS['TABLE_NAME']),
                    field_ldap_key=sql.Identifier(config.DB_TABLE_USERS['FIELD_LDAP_KEY']))

                # Execute cursor and fetch
                cur.execute(query, (ldap_key,))
                res = cur.fetchone()
                if res:
                    return DBUser(res)
                else:
                    return None


    def add_user(self, ldap_key: str, admin_flag: bool) -> None:
        """
        Adds a user in the database.

        :param ldap_key: The ldap_key of the User to create
        """

        # Connect to the database
        with self.open_conn() as conn:
            # Open a cursor
            with conn.cursor() as cur:
                str_query = "INSERT INTO {table} ({field_user}, {field_role}) VALUES (%s, %s)"

                # Query in the database
                query = sql.SQL(str_query).format(
                    table=sql.Identifier(config_env.AWS_SECRET_VALUE['DB_PUBLISHER']['SCHEMA'], config.DB_TABLE_USERS['TABLE_NAME']),
                    field_user=sql.Identifier(config.DB_TABLE_USERS['FIELD_LDAP_KEY']),
                    field_role=sql.Identifier(config.DB_TABLE_USERS['FIELD_ROLE']))

                # Execute cursor
                cur.execute(query, (ldap_key, 100 if admin_flag else 1, ))
            conn.commit()


    def delete_user(self, ldap_key: str) -> None:
        """
        Deletes a user from the database.

        :param ldap_key: The Ldap name to delete
        """

        # Connect to the database
        with self.open_conn() as conn:
            # Open a cursor
            with conn.cursor() as cur:
                str_query = "DELETE FROM {table} WHERE {field} ILIKE %s;"

                # Query in the database
                query = sql.SQL(str_query).format(
                    table=sql.Identifier(config_env.AWS_SECRET_VALUE['DB_PUBLISHER']['SCHEMA'], config.DB_TABLE_USERS['TABLE_NAME']),
                    field=sql.Identifier(config.DB_TABLE_USERS['FIELD_LDAP_KEY']))

                # Execute cursor
                cur.execute(query, (ldap_key,))
            conn.commit()


    def query_token_revoked(self, jti_uid) -> Any | None:
        """
        Queries the tokens blacklist table to see if the given token was revoked.

        :param jti_uid: The JTI of the Token to check if it has been revoked
        """

        # Connect to the database
        with self.open_conn() as conn:
            # Open a cursor
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                str_query = "SELECT * FROM {table} WHERE {field} = %s"

                # Query in the database
                query = sql.SQL(str_query).format(
                    table=sql.Identifier(config_env.AWS_SECRET_VALUE['DB_PUBLISHER']['SCHEMA'], config.DB_TABLE_TOKEN_BLACKLIST['TABLE_NAME']),
                    field=sql.Identifier(config.DB_TABLE_TOKEN_BLACKLIST['FIELD_JTI_UID']))

                # Execute cursor and fetch
                cur.execute(query, (jti_uid,))
                res = cur.fetchone()
                if res:
                    return res

        # None
        return None


    def add_token_revoked(self, jti_uid, expiration_date) -> bool:
        """
        Adds a token in the tokens blacklist table so that the token becomes officially revoked.

        :param jti_uid: The JTI of the Token to add to the table in order to revoke it.
        :param expiration_date: The Expiration date of the Token being revoked. This serves to keep the
         table clean and not store revoked tokens forever in the database.
        """

        # Connect to the database
        with self.open_conn() as conn:
            # *For a lack of a better place to do this*
            # Clear the old revoked tokens to clean up the database with time
            # Open a cursor
            with conn.cursor() as cur:
                str_query = "DELETE FROM {table} WHERE {field} < %s;"

                # Query in the database
                query = sql.SQL(str_query).format(
                    table=sql.Identifier(config_env.AWS_SECRET_VALUE['DB_PUBLISHER']['SCHEMA'], config.DB_TABLE_TOKEN_BLACKLIST['TABLE_NAME']),
                    field=sql.Identifier(config.DB_TABLE_TOKEN_BLACKLIST['FIELD_EXP_DATE']))

                # Execute cursor
                cur.execute(query, (datetime.datetime.now(),))

            # Open a cursor
            with conn.cursor() as cur:
                str_query = "INSERT INTO {table} ({field_jti_uid}, {field_exp_date}) VALUES (%s, %s)"

                # Query in the database
                query = sql.SQL(str_query).format(
                    table=sql.Identifier(config_env.AWS_SECRET_VALUE['DB_PUBLISHER']['SCHEMA'], config.DB_TABLE_TOKEN_BLACKLIST['TABLE_NAME']),
                    field_jti_uid=sql.Identifier(config.DB_TABLE_TOKEN_BLACKLIST['FIELD_JTI_UID']),
                    field_exp_date=sql.Identifier(config.DB_TABLE_TOKEN_BLACKLIST['FIELD_EXP_DATE']))

                # Execute cursor
                cur.execute(query, (jti_uid, expiration_date,))
            conn.commit()
            return True


