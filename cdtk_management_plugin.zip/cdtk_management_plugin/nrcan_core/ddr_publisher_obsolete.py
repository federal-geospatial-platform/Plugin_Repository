"""
This module handles the NRCan business logic to work with the CDTK API.
"""

# Imports
import os, subprocess, uuid, json, zipfile, re
import requests
from chardet import detect

# Application modules
from nrcan_core import config, config_env
from nrcan_core.core import auth, util, cdtk_email
from nrcan_core.lib import aws
from nrcan_core.lib.progress_marks import *
from nrcan_core.lib.exceptions import *
from nrcan_qgis.lib.progress_marks import *
from nrcan_qgis.lib.warnings import *
from nrcan_qgis.lib.exceptions import *
from nrcan_core.core.cdtk_message import CDTKMessage


def info_schema(payload: dict):
    """
    Gets the service names published under the given schema
    """

    # Start the messager
    message = CDTKMessage()

    # Run PyQGIS to read and validate the project file
    res = _run_pyqgis("info_schema", payload, message)

    # If only 1 exception and it's a SchemaNotFound
    if len(message.errors) == 1 and isinstance(message.errors[0], SchemaNotFound):
        raise NotFoundException()

    # If any errors, raise
    message.if_errors_raise()

    # Return the result
    return res


def info_service(payload: dict):
    """
    Gets the information on a particular service
    """

    # Start the messager
    message = CDTKMessage()

    # Run PyQGIS to read and validate the project file
    res = _run_pyqgis("info_service", payload, message)

    # If only 1 exception and it's a ProjectNotFound
    if len(message.errors) == 1 and isinstance(message.errors[0], ProjectNotFoundFromDatabase):
        raise NotFoundException()

    # If any errors, raise
    message.if_errors_raise()

    # Return the result
    return res


def get_versions():
    """
    Fetches the QGIS Versions used by the Publication API
    """

    # Run PyQGIS to read and compare the project file
    pyqgis_version = _run_pyqgis("version", None, None)

    # Get the versions
    return pyqgis_version


def get_czs_themes():
    """
    Fetches the CZS Themes from CZS API
    """

    # Gets the CZS token
    czs_access_token = _call_czs_admin_get_access_code()

    # Get the themes
    return _get_czs_themes(czs_access_token, None)


def get_cdtk_departments():
    """
    Fetches the CDTK Departments
    """

    # Gets the CDTK token
    access_token = _call_cdtk_admin_get_access_code()

    # Get the current user email
    email = _get_cdtk_my_email(access_token)

    # Get the departments
    return _get_cdtk_departments(email, access_token)


def get_cdtk_servers():
    """
    Fetches the CDTK Servers
    """

    # Gets the CDTK token
    access_token = _call_cdtk_admin_get_access_code()

    # Get the current user email
    email = _get_cdtk_my_email(access_token)

    # Return
    return _get_cdtk_servers(email, access_token)


def get_cdtk_downloads():
    """
    Fetches the CDTK Downloads
    """

    # Gets the CDTK token
    access_token = _call_cdtk_admin_get_access_code()

    # Get the current user email
    email = _get_cdtk_my_email(access_token)

    # Get the downloads
    return _get_cdtk_downloads(email, access_token)


def get_cdtk_dataset(metadata_id: str):
    """
    Fetches the CDTK Downloads
    """

    # Gets the CDTK token
    access_token = _call_cdtk_admin_get_access_code()

    # Get the dataset
    return _get_cdtk_dataset(metadata_id, access_token)


def get_cdtk_my_email():
    """
    Fetches the email of the currently logged in user based on the Publisher table
    """

    # Gets the CDTK token
    access_token = _call_cdtk_admin_get_access_code()

    # Get the departments
    return _get_cdtk_my_email(access_token)


def compare(zip_file):
    """
    Compares the information between the provided service and the one in the database (when any)
    """

    # Start the messager
    message = CDTKMessage()

    zip_res = None
    big_error = None
    try:
        try:
            # Keep track
            message.add_progress("Service started for 'compare'",
                                 "Service démarré pour 'compare'")

            # Ingest the zip file
            zip_res = ingest_zip_file("compare", zip_file, message)

            # If any errors, raise
            message.if_errors_raise()

            # Run PyQGIS to read and compare the project file
            res = _run_pyqgis("compare", zip_res['control_file'], message)

            # If any errors, raise
            message.if_errors_raise()

            # Return the result
            return res

        except Exception as err:
            big_error = err
            print(err)
            raise

    finally:
        # Clean up
        clean_up_directory(zip_res, message)

        # Print out the progress and errors if any
        _print_out(message, big_error)


def validate_project(operation: str, zip_file):

    # Start the messager
    message = CDTKMessage()

    zip_res = None
    big_error = None
    try:
        try:
            # Standardize to lowercase
            operation = operation.lower()

            # Validate the operation mode
            if not operation in ["publish", "update", "unpublish"]:
                raise UserMessageException(500, "Operation mode invalid", "Mode d'opération non supporté")

            # Keep track
            message.add_progress("Service started for 'validate_project'",
                                 "Service démarré pour 'validate_project'")

            # Ingest zip file
            zip_res = ingest_zip_file(operation, zip_file, message)

            # If any errors, raise
            message.if_errors_raise()

            # If running publish or update operation (unpublish has no local projects provided in the package)
            res = {'results':[]}
            if operation in ["publish", "update"]:
                # Run PyQGIS to read and validate the project file
                res = _run_pyqgis("validate", zip_res['control_file'], message)

            # If any errors, raise
            message.if_errors_raise()

            # Return the validation results
            return res

        except Exception as err:
            big_error = err
            print(err)
            raise

    finally:
        # Clean up
        clean_up_directory(zip_res, message)

        # Print out the progress and errors if any
        _print_out(message, big_error)


def export_publish_project(zip_file):

    # Start the messager
    message = CDTKMessage()

    zip_res = None
    big_error = None
    try:
        try:
            # Keep track
            message.add_progress("Service started for 'export_publish_project'",
                                 "Service démarré pour 'export_publish_project'")

            # Ingest the zip file
            zip_res = ingest_zip_file("publish", zip_file, message)

            # If any errors working with the zip file, mark it and raise it
            message.if_errors_mark("ERROR when validating zip file.", "ERREUR lors de la validation du fichier zip.")
            message.if_errors_raise()

            # If map services are set to be published
            if len(zip_res['control_file']['service_parameters']) > 0:
                # Run PyQGIS
                project_infos = _run_pyqgis("export_publish", zip_res['control_file'], message)

                # If any errors when publishing the service(s), mark it and raise it
                message.if_errors_mark("ERROR when processing the map service.", "ERREUR lors du traitement du service cartographique.")
                message.if_errors_raise()

            # Try to save in ddr registry
            try_save_in_cdtk_registry(zip_res['control_file'], message)

            # If saving in CZS
            if len(zip_res['control_file']['service_parameters']) > 0 and \
               zip_res['control_file']['generic_parameters']['czs_collection_theme']:
                # Try to save in clip zip ship
                try_save_in_czs_registry(zip_res['control_file'], project_infos['results'], message)

            # Update the ECS Service (attempt to clear cache)
            # update_ecs_service(message)

            # Keep track
            message.add_progress("Done!", "Terminé!")

            # Done
            return True

        except Exception as err:
            big_error = err
            print(err)
            raise

    finally:
        # Print out the progress and errors if any
        _print_out(message, big_error)

        if zip_res:
            # Clean up
            clean_up_directory(zip_res, message)

            if "control_file" in zip_res:
                # Send emails when this endpoint has processed
                cdtk_email.send_emails("export_publish", zip_res['control_file'], message, big_error)


def update_project(zip_file):

    # Start the messager
    message = CDTKMessage()

    zip_res = None
    big_error = None
    try:
        try:
            # Keep track
            message.add_progress("Service started for 'update_project'",
                                 "Service démarré pour 'update_project'")

            # Ingest the zip file
            zip_res = ingest_zip_file("update", zip_file, message)

            # If any errors working with the zip file, mark it and raise it
            message.if_errors_mark("ERROR when validating zip file.", "ERREUR lors de la validation du fichier zip.")
            message.if_errors_raise()

            # If map services are set to be republished
            if len(zip_res['control_file']['service_parameters']) > 0:
                # Run PyQGIS
                project_infos = _run_pyqgis("export_republish", zip_res['control_file'], message)

                # If any errors when publishing the service(s), mark it and raise it
                message.if_errors_mark("ERROR when processing the map service.", "ERREUR lors du traitement du service cartographique.")
                message.if_errors_raise()

                # Delete from Clip Zip Ship
                delete_from_czs_registry(zip_res['control_file']['process_parameters']['czs_admin_access_token'],
                                         zip_res['control_file']['generic_parameters']['metadata_uuid'],
                                         None,
                                         message)

                # If saving in CZS
                if zip_res['control_file']['generic_parameters']['czs_collection_theme']:
                    # Save in clip zip ship
                    save_in_czs_registry(zip_res['control_file'], project_infos['results'], message)

            # If a download package name is set
            if zip_res['control_file']['generic_parameters']['download_package_name']:
                # Update the download package
                try_update_download_package(zip_res['control_file'], message)

            # Update the ECS Service (attempt to clear cache)
            # update_ecs_service(message)

            # Keep track
            message.add_progress("Done!", "Terminé!")

            # Done
            return True

        except Exception as err:
            big_error = err
            print(err)
            raise

    finally:
        # Print out the progress and errors if any
        _print_out(message, big_error)

        if zip_res:
            # Clean up
            clean_up_directory(zip_res, message)

            if "control_file" in zip_res:
                # Send emails when this endpoint has processed
                cdtk_email.send_emails("export_republish", zip_res['control_file'], message, big_error)


def delete_service_and_data(zip_file):

    # Start the messager
    message = CDTKMessage()

    zip_res = None
    big_error = None
    try:
        try:
            # Keep track
            message.add_progress("Service started for 'delete_service_and_data'",
                                 "Service démarré pour 'delete_service_and_data'")

            # Ingest the zip file
            zip_res = ingest_zip_file("unpublish", zip_file, message)

            # If any errors, raise
            message.if_errors_raise()

            # If map services are set to be unpublished
            if len(zip_res['control_file']['service_parameters']) > 0:
                # Run PyQGIS
                _run_pyqgis("delete_service_and_data", zip_res['control_file'], message)

                # If any errors, raise
                message.if_errors_raise()

                # Delete from Clip Zip Ship Registry
                delete_from_czs_registry(zip_res['control_file']['process_parameters']['czs_admin_access_token'],
                                         zip_res['control_file']['generic_parameters']['metadata_uuid'],
                                         None,
                                         message)

            # Update/Delete in CDTK Registry
            delete_from_cdtk_registry(zip_res['control_file'],
                                     zip_res['control_file']['process_parameters']['cdtk_registry_access_token'],
                                     message)

            # Update the ECS Service (attempt to clear cache)
            update_ecs_service(message)

            # Keep track
            message.add_progress("Done!", "Terminé!")

            # Done
            return True

        except Exception as err:
            big_error = err
            print(err)
            raise

    finally:
        # Print out the progress and errors if any
        _print_out(message, big_error)

        if zip_res:
            # Clean up
            clean_up_directory(zip_res, message)

            if "control_file" in zip_res:
                # Send emails when this endpoint has processed
                cdtk_email.send_emails("delete_service_and_data", zip_res['control_file'], message, big_error)


def ingest_zip_file(mode: str, zip_file, message: CDTKMessage):
    # If there's a zip file attached to the request
    if zip_file:
        # Save the file local
        if not os.path.exists(config_env.QGIS_IN_PACKAGES_PATH("")):
            os.makedirs(config_env.QGIS_IN_PACKAGES_PATH(""))
        input_package = config_env.QGIS_IN_PACKAGES_PATH(str(uuid.uuid4()) + ".zip")
        zip_file.save(input_package)

    else:
        raise UserMessageException(500, "Invalid request, no zip file", "Requête invalide, pas de fichier zip")

    # Uzip it and retrieve the control file
    zip_res = unzip_input_package(mode, input_package, message)

    # If any errors
    if len(message.errors):
        return zip_res

    # If running publish or update operation
    if mode in ["publish", "update"] and len(zip_res['control_file']['service_parameters']) > 0:
        # Validate files exists
        _validate_project_files_exist(zip_res['control_file'], message)

    # Return the zip result
    return zip_res


def clean_up_directory(zip_res: dict, message: CDTKMessage):
    """
    Cleans the directory from the temporary files either received from
    the API payload or extracted from an input zip file package.
    """

    # Keep track
    message.add_progress("Cleaning up workspace",
                         "Nettoyage de l'espace de travail")

    # If there was a zip package
    if not config_env.IS_LOCAL and zip_res['zip_file']:
        os.remove(zip_res['zip_file'])

    # If any working files
    if not config_env.IS_LOCAL and zip_res['extracted_files']:
        for f in zip_res['extracted_files']:
            os.remove(f)


def update_ecs_service(message: CDTKMessage):
    """
    Updates a ECS Service in AWS in an attempt to clear its cache
    """

    try:
        # Keep track
        message.add_progress(f"Attempting to update ECS Service..",
                             f"Tentative de mise à jour du service ECS..")

        # Connect to ECS
        ecs_client = aws.get_ecs_client(config_env.ECS_IAM_ROLE)

        # Update the ECS service
        response = ecs_client.update_service(
            cluster=config_env.ECS_CLUSTER,
            service=config_env.ECS_SERVICE,
            forceNewDeployment=True
        )

        # Read result
        res = json.dumps(response, indent=4, default=str)

        # Keep track
        message.add_progress(f"ECS Service updated.",
                             f"Service ECS mis à jour.")

        # Return result
        return res

    except Exception as ex:
        # Keep track
        message.add_progress(f"ECS Service couldn't be updated. " + str(ex),
                             f"Service ECS n'a pu être mis à jour. " + str(ex))


def unzip_input_package(mode: str, zip_file: str, message: CDTKMessage):
    """
    Validates the provided zip file, checks its content, unzips the files to the workspace folder.
    :returns: A dictionary holding process information state.
    """

    # The control file dict content to be returned
    zip_wrap_object = {
        "control_file": None,
        "zip_file": zip_file,
        "extracted_files": []
    }

    # Keep track
    message.add_progress(f"Unzipping zip file package {zip_file}",
                         f"Extraction du paquet fichier zip {zip_file}")

    # Work with a zip file
    with zipfile.ZipFile(zip_file, 'r') as zip_ref:
        # Get the infos in the zip
        infos = zip_ref.infolist()

        # If the zip file has any folder
        if all(len(os.path.dirname(a.filename)) == 0 for a in infos):
            # If the zip file has a control file at the root
            if "ControlFile.json" in [i.filename for i in infos]:
                # Loop on the files in the zip
                for info in infos:
                    # If it's the control file
                    if "ControlFile.json" == info.filename:
                        # Read the control file content
                        zip_wrap_object['control_file'] = json.loads(zip_ref.read(info).decode("utf-8"))

                # If not comparing
                if mode != "compare":
                    # Validate the control file
                    validate_control_file(mode, zip_wrap_object['control_file'], None, message)

                    # If publishing or updating
                    if mode == "publish" or mode == "update":
                        # If a download package is set, validate it is part of the zip
                        if zip_wrap_object['control_file']['generic_parameters']['download_package_name']:
                            if not any(b.filename == zip_wrap_object['control_file']['generic_parameters']['download_package_name'] + ".zip" for b in infos):
                                _validate_throws_or_append(UserMessageException(500,
                                                           f"The control file specifies a download package which isn't in the main package",
                                                           f"Le fichier de contrôle pointe vers un paquet de données qui n'est pas dans le paquet principal"), message.errors)

            else:
                _validate_throws_or_append(UserMessageException(500,
                                           f"The input package {zip_file} does not contain a JSON control file",
                                           f"Le paquetage d'entrée {zip_file} ne contient pas de fichier de contrôle JSON"), message.errors)

        else:
            _validate_throws_or_append(UserMessageException(500,
                                       f"Folders in the zip file {zip_file} aren't supported",
                                       f"Le fichier zip {zip_file} ne doit pas contenir de dossiers"), message.errors)

        # If not comparing and not unpublishing
        if mode != "compare" and mode != "unpublish":
            # Validate the zip contains all input project files specified in the control file
            for sp in zip_wrap_object['control_file']['service_parameters']:
                if 'in_project_filename' in sp and not any(b.filename == sp['in_project_filename'] for b in infos):
                    _validate_throws_or_append(UserMessageException(500,
                                               f"The {sp['in_project_filename']} project file as defined in the control file has not been included in the input package",
                                               f"Le fichier de projet {sp['in_project_filename']} tel que défini dans le fichier de contrôle n'a pas été inclus dans le paquetage d'entrée"), message.errors)

        # Looking good, proceed with official extraction of the zip!

        # If no errors
        if len(message.errors) == 0:
            # Loop on the files in the zip
            for info in infos:
                # If not the control file
                if not re.match(r'.*\.json$', info.filename):
                    zip_ref.extract(info, config_env.QGIS_PROJECTS_PATH(""))
                    zip_wrap_object["extracted_files"].append(config_env.QGIS_PROJECTS_PATH(info.filename))

    # Return the control file
    return zip_wrap_object


def validate_control_file(mode: str, control_file: dict, files: list, message : CDTKMessage):

    # Append some dynamic information to the control file
    control_file['process_parameters'] = {
        'department_info': None,
        'publisher_name': "PUBLISHER_NAME",
        'server_info': None,
        'download_info': None,
        'dataset_info': None,
        'cdtk_registry_access_token': None,
        'czs_admin_access_token': None
    }

    # Keep track
    message.add_progress("Input package contains a JSON control file. The parameters it contains will be used to complete the service call.",
                         "Le paquetage d'entrée contient un fichier de contrôle JSON. Les paramètres qu'il contient seront utilisés pour compléter l'appel de service.")

    # First, validate the structure
    validate_control_file_structure(mode, control_file, message.errors)

    # If any errors, stop there
    if len(message.errors):
        return

    # Keep track
    message.add_progress("JSON control file has valid structure.",
                         "Le fichier de contrôle JSON a une structure valide.")

    # Keep track
    message.add_progress("Testing communication with CDTK Registry.",
                         "Test du canal de communication avec le Registre CDTK.")

    # Obtention du access token avec CDTK Registry
    control_file['process_parameters']['cdtk_registry_access_token'] = _call_cdtk_admin_get_access_code()

    # Obtention du access token avec CZS Admin (we won't need it when not publishing, but for simplification when unpublishing, let's do it..)
    control_file['process_parameters']['czs_admin_access_token'] = _call_czs_admin_get_access_code()

    # Keep track
    message.add_progress("Validating content of the JSON control file.",
                         "Validation du contenu du fichier de contrôle JSON.")

    # Normalize its inputs
    validate_normalize_inputs(mode, control_file, message.errors)

    # Validate the department exists
    control_file['process_parameters']['department_info'] = validate_department_exists(control_file['generic_parameters']['department'],
                                                                                       control_file['process_parameters']['cdtk_registry_access_token'],
                                                                                       message.errors)

    # Validate the department exists
    control_file['process_parameters']['publisher_name'] = validate_publisher_exists_and_department(control_file['generic_parameters']['email'],
                                                                                                    control_file['generic_parameters']['department'],
                                                                                                    control_file['process_parameters']['cdtk_registry_access_token'],
                                                                                                    message.errors)

    # If the qgis_server_id isn't set, use the department default
    if not control_file['generic_parameters']['qgis_server_id']:
        control_file['generic_parameters']['qgis_server_id'] = control_file['process_parameters']['department_info']['default_qgis_server_id'].upper()

    # If the download_info_id isn't set, use the department default
    if not control_file['generic_parameters']['download_info_id']:
        control_file['generic_parameters']['download_info_id'] = control_file['process_parameters']['department_info']['default_download_id'].upper()

    # Validate the server id exists
    control_file['process_parameters']['server_info'] = validate_server_id_exists(control_file['generic_parameters']['qgis_server_id'],
                                                                                  control_file['process_parameters']['cdtk_registry_access_token'],
                                                                                  message.errors)

    # Validate the download id exists
    control_file['process_parameters']['download_info'] = validate_download_id_exists(control_file['generic_parameters']['download_info_id'],
                                                                                      control_file['process_parameters']['cdtk_registry_access_token'],
                                                                                      message.errors)

    # If publishing
    if mode == "publish":
        # Validate the dataset doesn't exist or it does and it's on same department
        control_file['process_parameters']['dataset_info'] = validate_dataset_department(control_file['generic_parameters']['metadata_uuid'],
                                                                                         control_file['generic_parameters']['department'],
                                                                                         control_file['process_parameters']['cdtk_registry_access_token'],
                                                                                         message)

        # Validate no map service by that name already exist in CDTK
        validate_map_services_not_existing(control_file['service_parameters'],
                                           control_file['process_parameters']['cdtk_registry_access_token'],
                                           message.errors)

        # If there's a download package
        if control_file['generic_parameters']['download_package_name']:
            # Get S3 path prefix
            s3_path_prefix = util.get_download_path(control_file, True, None)

            # Get list of objects in bucket on the s3 path prefix
            res = aws.list_bucket(control_file['process_parameters']['download_info']['download_root_path'],
                                  control_file['process_parameters']['download_info']['owner_username'],
                                  s3_path_prefix)

            # For each object bucket key in S3
            for b_key in [x.key for x in res]:
                # Validate that it doesn't already exist in S3
                if b_key.startswith(s3_path_prefix):
                    _validate_throws_or_append(UserMessageException(500,
                                                                   f"The download package folder {s3_path_prefix} already exists on the server",
                                                                   f"Le paquet de téléchargement {s3_path_prefix} existe déjà sur le serveur"),
                                                                   message.errors)
                    break # Skip the rest of the S3

    elif mode == "update" or mode == "unpublish":
        # Validate the map service by that name already exists in CDTK
        validate_map_services_existing(mode, control_file['service_parameters'],
                                       control_file['process_parameters']['cdtk_registry_access_token'],
                                       message.errors)

        # If there's a download package
        if control_file['generic_parameters']['download_package_name']:
            # Get S3 path prefix
            s3_path_prefix = util.get_download_path(control_file, True, None)

            # Get list of objects in bucket on the s3 path prefix
            res = aws.list_bucket(control_file['process_parameters']['download_info']['download_root_path'],
                                  control_file['process_parameters']['download_info']['owner_username'],
                                  s3_path_prefix)

            # Validate the main folder exists
            if len(list(res.limit(1))) == 0:
                _validate_throws_or_append(UserMessageException(500,
                                                               f"The download package folder {s3_path_prefix} doesn't exist on the server",
                                                               f"Le paquet de téléchargement {s3_path_prefix} n'existe pas sur le serveur"),
                                                               message.errors)

    # If this is going in Clip Zip Ship
    if 'czs_collection_theme' in control_file['generic_parameters'] and control_file['generic_parameters']['czs_collection_theme']:
        # Keep track
        message.add_progress("Testing communication with Clip Zip Ship Admin.",
                             "Test du canal de communication avec le Clip Zip Ship Admin.")

        # Check if the theme exists
        _validate_czs_theme_existing(control_file['generic_parameters']['czs_collection_theme'],
                                     control_file['process_parameters']['czs_admin_access_token'],
                                     message)

    # If no errors
    if len(message.errors) == 0:
        # Keep track
        message.add_progress("JSON Control file validated with success.",
                             "Le paquetage d'entrée a été validé avec succès.")

    else:
        # Keep track
        message.add_progress("JSON Control file validated with errors.",
                             "Le paquetage d'entrée a été validé et contenait des erreurs.")


def validate_control_file_structure(mode: str, control_file: dict, errors: list):
    """
    Validates the control file structure.
    """

    if not 'generic_parameters' in control_file:
        # Too big of a problem to even pursue other validations
        raise UserMessageException(500,
                                   f"Control file missing 'generic_parameters' in its structure",
                                   f"Le fichier de contrôle manque 'generic_parameters' dans sa structure")

    if not 'service_parameters' in control_file:
        # Too big of a problem to even pursue other validations
        raise UserMessageException(500,
                                   f"Control file missing 'service_parameters' in its structure",
                                   f"Le fichier de contrôle manque 'service_parameters' dans sa structure")

    if not 'department' in control_file['generic_parameters']:
        _validate_throws_or_append(UserMessageException(500,
                                   f"Control file missing 'department' in its structure",
                                   f"Le fichier de contrôle manque 'department' dans sa structure"), errors)

    if not 'download_info_id' in control_file['generic_parameters']:
        _validate_throws_or_append(UserMessageException(500,
                                   f"Control file missing 'download_info_id' in its structure",
                                   f"Le fichier de contrôle manque 'download_info_id' dans sa structure"), errors)

    if not 'email' in control_file['generic_parameters']:
        _validate_throws_or_append(UserMessageException(500,
                                   f"Control file missing 'email' in its structure",
                                   f"Le fichier de contrôle manque 'email' dans sa structure"), errors)

    if 'email' in control_file['generic_parameters'] and not control_file['generic_parameters']['email']:
        _validate_throws_or_append(UserMessageException(500,
                                   f"The publisher's email address is missing from the generic parameters",
                                   f"L'adresse email de l'éditeur est absente des paramètres génériques"), errors)

    if not 'metadata_uuid' in control_file['generic_parameters']:
        _validate_throws_or_append(UserMessageException(500,
                                   f"Control file missing 'metadata_uuid' in its structure",
                                   f"Le fichier de contrôle manque 'metadata_uuid' dans sa structure"), errors)

    if mode == "publish" and \
       'metadata_uuid' in control_file['generic_parameters'] and \
       not control_file['generic_parameters']['metadata_uuid']:
        _validate_throws_or_append(UserMessageException(500,
                                   f"The metadata UUID is missing from the generic parameters",
                                   f"Le UUID de métadonnées est absente des paramètres génériques"), errors)

    if not 'qgis_server_id' in control_file['generic_parameters']:
        _validate_throws_or_append(UserMessageException(500,
                                   f"Control file missing 'qgis_server_id' in its structure",
                                   f"Le fichier de contrôle manque 'qgis_server_id' dans sa structure"), errors)

    if not 'download_package_name' in control_file['generic_parameters']:
        _validate_throws_or_append(UserMessageException(500,
                                   f"Control file missing 'download_package_name' in its structure",
                                   f"Le fichier de contrôle manque 'download_package_name' dans sa structure"), errors)

    if not 'core_subject_term' in control_file['generic_parameters']:
        _validate_throws_or_append(UserMessageException(500,
                                   f"Control file missing 'core_subject_term' in its structure",
                                   f"Le fichier de contrôle manque 'core_subject_term' dans sa structure"), errors)

    if mode == "publish" and \
       ('download_package_name' in control_file['generic_parameters'] and \
        control_file['generic_parameters']['download_package_name'] and \
        'core_subject_term' in control_file['generic_parameters'] and \
        not control_file['generic_parameters']['core_subject_term']):
        _validate_throws_or_append(UserMessageException(500,
                                   f"When the 'download_package_name' generic parameter has a value, the CORE_SUBJECT_TERM generic parameter must also have a value",
                                   f"Lorsque le paramètre générique 'download_package_name' a une valeur, le paramètre générique CORE_SUBJECT_TERM doit aussi avoir une valeur"), errors)


    if not 'czs_collection_theme' in control_file['generic_parameters']:
        _validate_throws_or_append(UserMessageException(500,
                                   f"Control file missing 'czs_collection_theme' in its structure",
                                   f"Le fichier de contrôle manque 'czs_collection_theme' dans sa structure"), errors)

    # If it's NOT the 'empty' map services sent for the unpublishing mode
    if not (mode == "unpublish" and \
            len(control_file['service_parameters']) == 1 and \
            not bool(control_file['service_parameters'][0])):
        # For each service parameter
        for sp in control_file['service_parameters']:
            if not "in_project_filename" in sp:
                _validate_throws_or_append(UserMessageException(500,
                                           f"Control file missing 'in_project_filename' in its structure",
                                           f"Le fichier de contrôle manque 'in_project_filename' dans sa structure"), errors)
            if not "language" in sp:
                _validate_throws_or_append(UserMessageException(500,
                                           f"Control file missing 'language' in its structure",
                                           f"Le fichier de contrôle manque 'language' dans sa structure"), errors)

            if not "service_schema_name" in sp:
                _validate_throws_or_append(UserMessageException(500,
                                           f"Control file missing 'service_schema_name' in its structure",
                                           f"Le fichier de contrôle manque 'service_schema_name' dans sa structure"), errors)

    else:
        # User wants to unpublish the map services and voluntarily hasn't listed them explicitely.
        # They'll be read from the existing data later in the process.
        pass


def validate_normalize_inputs(mode: str, control_file: dict, errors: list):

    # Make sure the department is written in lowercase
    control_file['generic_parameters']['department'] = control_file['generic_parameters']['department'].lower()

    # Make sure the email is lowercase
    control_file['generic_parameters']['email'] = control_file['generic_parameters']['email'].lower()

    # Make sure the server id is uppercase
    control_file['generic_parameters']['qgis_server_id'] = control_file['generic_parameters']['qgis_server_id'].upper()

    # Make sure the download id is uppercase
    control_file['generic_parameters']['download_info_id'] = control_file['generic_parameters']['download_info_id'].upper()

    # Make sure there's at least either some map services or a download package name, otherwise, there's nothing to do in the control file
    if len(control_file['service_parameters']) == 0 and \
      (not control_file['generic_parameters']['download_package_name'] or len(control_file['generic_parameters']['download_package_name']) == 0):
        # Too big of a problem to even pursue other validations
        raise UserMessageException(500,
                                   f"Control file is missing either map services and/or a download package",
                                   f"Le fichier de contrôle n'a pas de services cartographiques ni de paquet de téléchargement")

    # Check for the email value
    if not '@' in control_file['generic_parameters']['email']:
        _validate_throws_or_append(UserMessageException(500,
                                   f"The publisher's email address entered in the generic parameters is invalid. It must contain at least the @ character",
                                   f"L'adresse email de l'éditeur dans les paramètres génériques n'est pas valide. Elle doit au moins contenir le caractère @"),
                                   errors)

    # If mode republish or unpublish
    if mode == "update" or mode == "unpublish":
        # If update mode and any service parameters
        if mode == "update" and len(control_file['service_parameters']) > 0:
            # Take any project name/schema name in the control file
            sp_service_name = os.path.basename(control_file['service_parameters'][0]['in_project_filename']).split(".")[0]
            sp_folder = control_file['service_parameters'][0]['service_schema_name']

            # Retrieve the existing dataset id and metadata id
            dataset_id, metadata_id = validate_get_dataset_metadata_id(sp_folder, sp_service_name, control_file['process_parameters']['cdtk_registry_access_token'])
            # The metadata_uuid specified in the control file must be the same as in the database
            if metadata_id and \
            control_file['generic_parameters']['metadata_uuid'] != metadata_id:
                # Wrong metadata_uuid
                _validate_throws_or_append(UserMessageException(500,
                                                                f"The metadata_uuid specified {control_file['generic_parameters']['metadata_uuid']} doesn't match the one in the database {metadata_id}",
                                                                f"L'identifiant de métadonnées spécifié {control_file['generic_parameters']['metadata_uuid']} ne correspond pas avec le celui dans la base de donées {metadata_id}"),
                                                                errors)

        # Retrieve the CZS parent information if any
        parent_id, theme_id = validate_get_czs_parent_theme(control_file['generic_parameters']['metadata_uuid'],
                                                            control_file['process_parameters']['czs_admin_access_token'])

        # If a czs_collection_theme is specified in the control file, it must be the same as in the database
        if control_file['generic_parameters']['czs_collection_theme'] and \
           control_file['generic_parameters']['czs_collection_theme'] != theme_id:
            # Wrong theme
            _validate_throws_or_append(UserMessageException(500,
                                                           f"The czs_collection_theme specified {control_file['generic_parameters']['czs_collection_theme']} doesn't match the one in the database {theme_id}",
                                                           f"Le thème spécifié {control_file['generic_parameters']['czs_collection_theme']} ne correspond pas avec le celui dans la base de donées {theme_id}"),
                                                           errors)

        if theme_id and not control_file['generic_parameters']['czs_collection_theme']:
            # Set the theme with the one found in the database
            control_file['generic_parameters']['czs_collection_theme'] = theme_id

    # Check the metadata_uuid is a valid uuid
    if not _is_valid_uuid(control_file['generic_parameters']['metadata_uuid']):
        _validate_throws_or_append(UserMessageException(500,
                                   f"Metadata UUID has an invalid format '{control_file['generic_parameters']['metadata_uuid']}'",
                                   f"Le UUID du metadata est dans un format invalide '{control_file['generic_parameters']['metadata_uuid']}'"),
                                   errors)

    # If mode republish or unpublish
    if mode == "update" or mode == "unpublish":
        # Retrieve information of prior dataset
        res = _call_cdtk_admin_get("/datasets/" + control_file['generic_parameters']['metadata_uuid'],
                                  control_file['process_parameters']['cdtk_registry_access_token'])
        if res.status_code == 200:
            content = json.loads(res.content.decode("utf-8"))

            # If Updating mode
            if mode == "update":
                # If a download_package_name is specified in the control file, it must be the same as in the database
                if control_file['generic_parameters']['download_package_name'] and \
                   control_file['generic_parameters']['download_package_name'] != content['download_folder_name']:
                    # Wrong download_package_name
                    _validate_throws_or_append(UserMessageException(500,
                                                                   f"The download_package_name specified {control_file['generic_parameters']['download_package_name']} doesn't match the one in the database {content['download_folder_name']}",
                                                                   f"Le paquet de téléchargement spécifié {control_file['generic_parameters']['download_package_name']} ne correspond pas avec le celui dans la base de donées {content['download_folder_name']}"),
                                                                   errors)

                # If a core_subject_term is specified in the control file, it must be the same as in the database
                if control_file['generic_parameters']['core_subject_term']:
                    if control_file['generic_parameters']['core_subject_term'] != content['core_subject_term']:
                        # Wrong core_subject_term
                        _validate_throws_or_append(UserMessageException(500,
                                                                       f"The core_subject_term specified {control_file['generic_parameters']['core_subject_term']} doesn't match the one in the database {content['core_subject_term']}",
                                                                       f"Le core_subject_term spécifié {control_file['generic_parameters']['core_subject_term']} ne correspond pas avec le celui dans la base de donées {content['core_subject_term']}"),
                                                                       errors)

                elif control_file['generic_parameters']['download_package_name']:
                    # core_subject_term is empty and download_package_name is set
                    # Set the core_subject_term to the same as DB, always (may be null in db too)
                    control_file['generic_parameters']['core_subject_term'] = content['core_subject_term']

            elif mode == "unpublish":
                # Unpublishing mode
                # If unpublishing a download package and there is indeed something there according to the database
                if control_file['generic_parameters']['download_package_name'] and content["download_folder_name"]:
                    # Always use the existing download package name and core subject term,
                    # as they exist, no matter what's in the control file
                    control_file['generic_parameters']['download_package_name'] = content["download_folder_name"]
                    control_file['generic_parameters']['core_subject_term'] = content["core_subject_term"]

                # If unpublishing map services
                if len(control_file['service_parameters']) >= 1:
                    # Get the map services on the dataset
                    res2 = _call_cdtk_admin_get(f"/map_services/dataset/{content['id']}", control_file['process_parameters']['cdtk_registry_access_token'])
                    if res2.status_code == 200:
                        content2 = json.loads(res2.content.decode("utf-8"))

                        # Rebuild the control file service_parameters property with info from the database
                        new_services = []
                        for ms in content2:
                            new_services.append({
                                'service_schema_name': ms['service_folder'],
                                'in_project_filename': ms['qgis_project_filename'],
                                'language': ms['service_language']
                            })
                        control_file['service_parameters'] = new_services

                    else:
                        # Couldn't find the existing map services
                        control_file['service_parameters'] = []

        else:
            # Couldn't find the existing dataset
            # Too big of a problem to even pursue other validations
            raise UserMessageException(500,
                                       f"The dataset for metadata uuid {control_file['generic_parameters']['metadata_uuid']} doesn't exist",
                                       f"Le jeu de données ayant metadata uuid {control_file['generic_parameters']['metadata_uuid']} n'existe pas")

    # For each service parameter
    for sp in control_file['service_parameters']:
        # Make sure the schema name is lowercase
        sp['service_schema_name'] = sp['service_schema_name'].lower()

        # Make sure the project file is lowercase
        sp['in_project_filename'] = sp['in_project_filename']  #.lower() not anymore..

        # Make sure the language has lowercase and first letter uppercase
        sp['language'] = sp['language'][0].upper() + sp['language'][1:].lower()

        # Check for the language value
        if "English" != sp['language'] and "French" != sp['language']:
            _validate_throws_or_append(UserMessageException(500,
                                       f"Invalid language {sp['language']}",
                                       f"Langue invalide {sp['language']}"), errors)


def validate_get_dataset_metadata_id(folder_name: str, service_name: str, access_token: str):
    # Get the map services
    res = _call_cdtk_admin_get(f"/map_services/{folder_name}/{service_name}", access_token)
    if res.status_code == 200:
        content = json.loads(res.content.decode("utf-8"))

        dataset_id = content['dataset_id']

        # Find the metadata_uuid for the dataset id
        res2 = _call_cdtk_admin_get("/datasets/dataset/" + dataset_id, access_token)
        if res2.status_code == 200:
            content2 = json.loads(res2.content.decode("utf-8"))
            return dataset_id, content2['metadata_id']

        else:
            return dataset_id, None

    # Not found
    return None, None


def validate_get_czs_parent_theme(metadata_id: str, access_token: str):
    # Get the parents
    res = _call_czs_admin_get(f"/collections?metadata_uuid={metadata_id}", access_token)
    if res.status_code == 200:
        content = json.loads(res.content.decode("utf-8"))

        parent_id = None
        theme_id = None
        if content and len(content) > 0:
            # Read the parent id
            parent_id = content[0]['parent_uuid']

            # Now fetch the theme id based on the parent id
            res2 = _call_czs_admin_get(f"/parents/{parent_id}", access_token)
            if res2.status_code == 200:
                content = json.loads(res2.content.decode("utf-8"))

                # Read the theme id
                theme_id = content['theme_uuid']

        # Return
        return parent_id, theme_id

    # Not found
    return None, None


def validate_department_exists(dept_acrn_en: str, access_token: str, errors: list):

    res = _call_cdtk_admin_get("/departments/" + dept_acrn_en, access_token)
    if res.status_code == 200:
        return res.json()

    elif res.status_code == 404:
        _validate_throws_or_append(UserMessageException(500,
                                   f"The department with the English TBS acronym {dept_acrn_en} does not exists in the DDR Registry",
                                   f"Le département dont l'acronyme anglais du TBS est {dept_acrn_en} n'existe pas dans le registre du DDR"), errors)

    else:
        _validate_throws_or_append(UserMessageException(500,
                                   f"The department {dept_acrn_en} couldn't be validated",
                                   f"Le ministère {dept_acrn_en} n'a pu être validé"), errors)


def validate_publisher_exists_and_department(email: str, dept_acrn_en: str, access_token: str, errors: list):

    res = _call_cdtk_admin_get("/publishers/" + email, access_token)
    if res.status_code == 200:
        # The publisher exists
        # Check if the publisher is linked to the department
        res2 = _call_cdtk_admin_get(f"/departments?publisher={email}", access_token)

        # If exists
        if dept_acrn_en.lower() in [x['tbs_dept_acrn_en'].lower() for x in res2.json()]:
            return res.json()["name"]

        else:
            _validate_throws_or_append(UserMessageException(500,
                                       f"Publisher with email {email} is not allowed to publish for department with acronym {dept_acrn_en}",
                                       f"L'éditeur avec le email {email} n'est pas autorisé à publier pour le ministère {dept_acrn_en}"), errors)

    elif res.status_code == 404:
        _validate_throws_or_append(UserMessageException(500,
                                   f"Publisher with email {email} is not registered in DDR registry",
                                   f"L'éditeur avec le courriel {email} n'est pas enregistré dans le registre du DDR"), errors)

    else:
        _validate_throws_or_append(UserMessageException(500,
                                   f"The publisher {email} couldn't be validated",
                                   f"L'éditeur {email} n'a pu être validé"), errors)


def validate_server_id_exists(server_id: str, access_token: str, errors: list):

    res = _call_cdtk_admin_get("/servers/" + server_id, access_token)
    if res.status_code == 200:
        content = json.loads(res.content.decode("utf-8"))
        return content

    elif res.status_code == 404:
        _validate_throws_or_append(UserMessageException(500,
                                   f"QGIS Server with ID {server_id} does not exist in the DDR Registry",
                                   f"Le serveur QGIS avec l'identifiant unique {server_id} n'existe pas dans le registre du DDR"), errors)

    else:
        _validate_throws_or_append(UserMessageException(500,
                                   f"QGIS Server with ID {server_id} couldn't be validated in the DDR Registry",
                                   f"Le serveur QGIS avec l'identifiant unique {server_id} n'a pu être validé"), errors)


def validate_download_id_exists(download_id: str, access_token: str, errors: list):

    res = _call_cdtk_admin_get("/downloads/" + download_id, access_token)
    if res.status_code == 200:
        content = json.loads(res.content.decode("utf-8"))
        return content

    elif res.status_code == 404:
        _validate_throws_or_append(UserMessageException(500,
                                   f"The download site with ID {download_id} does not exist in the DDR Registry",
                                   f"Le site de téléchargement avec l'identifiant unique {download_id} n'existe pas dans le registre du DDR"), errors)

    else:
        _validate_throws_or_append(UserMessageException(500,
                                   f"The download site with ID {download_id} couldn't be validated",
                                   f"Le site de téléchargement avec l'identifiant unique {download_id} n'a pu être validé"), errors)


def validate_dataset_department(metadata_uuid: str, dept_acrn_en: str, access_token: str, message: CDTKMessage):

    res = _call_cdtk_admin_get("/datasets/" + metadata_uuid, access_token)
    if res.status_code == 200:
        content = json.loads(res.content.decode("utf-8"))

        # Get the department id for the dataset
        dept_id = content["department_id"]

        # Get the dataset id which will be returned if all goes well
        dataset_id = content["id"]

        # Get the list of departments (because can't get via dept_id directly - fine)
        res2 = _call_cdtk_admin_get("/departments", access_token)
        if res2.status_code == 200:
            depts = json.loads(res2.content.decode("utf-8"))

            # Find the department with the same id
            dept = list(filter(lambda f: f["id"] == dept_id, depts))

            # If found
            if len(dept) == 1:
                # If the department of the existing metadata uid is the same as the department in the control file
                if (dept[0]["tbs_dept_acrn_en"].lower() == dept_acrn_en.lower()):
                    # Get the linked map services if any
                    res_ms = _call_cdtk_admin_get("/map_services/dataset/" + dataset_id, access_token)
                    map_servs = None
                    if res_ms.status_code == 200:
                        # Read
                        map_servs = json.loads(res_ms.content.decode("utf-8"))

                    elif res_ms.status_code == 404:
                        pass  # Okay

                    else:
                        _validate_throws_or_append(UserMessageException(500,
                                                   f"Failed to check the map services for the dataset {dataset_id}",
                                                   f"Échec lors de la vérification des services cartographiques pour le jeu de données {dataset_id}"), message.errors)

                    # Return the dataset id
                    return {
                        'dataset_id': dataset_id,
                        'map_services': map_servs
                    }

                else:
                    _validate_throws_or_append(UserMessageException(500,
                                               f"Dataset with metadata uuid {metadata_uuid} already exist in the DDR registry and is associated to another department than yours",
                                               f"Le jeu de données associé à la métadonnée {metadata_uuid} existe déjà dans le registre du DDR et est associé à un autre ministère que le votre"), message.errors)

            else:
                _validate_throws_or_append(UserMessageException(500,
                                           f"Dataset with metadata {metadata_uuid} couldn't be validated with the department information",
                                           f"Le jeu de données avec metadonnée {metadata_uuid} n'a pu être validé avec les informations des ministères"), message.errors)

    elif res.status_code == 404:
        # Dataset with metadata doesn't exist, it'll be created, fine
        # Keep track
        message.add_progress(f"A new record will be created in the dataset table with {metadata_uuid} as value for the metadata_id field",
                             f"Un nouvel enregistrement sera créé dans la table dataset avec {metadata_uuid} comme valeur pour le champ metadata_id")

        # Flag to create the dataset
        return {
            'dataset_id': "CREATE_IT",
            'map_services': []
        }

    else:
        _validate_throws_or_append(UserMessageException(500,
                                   f"Dataset with metadata {metadata_uuid} couldn't be validated",
                                   f"Le jeu de données avec metadonnée {metadata_uuid} n'a pu être validé"), message.errors)


def validate_map_services_existing(mode: str, service_parameters: list, access_token: str, errors: list):

    # Get the map services
    res = _call_cdtk_admin_get("/map_services", access_token)
    if res.status_code == 200:
        content = json.loads(res.content.decode("utf-8"))

        # For each service parameter
        for sp in service_parameters:
            sp_service_name = os.path.basename(sp['in_project_filename']).split(".")[0]
            sp_folder = sp['service_schema_name']

            # Filter the list to find map services on the folder_name and service_name clause
            map_servs = list(filter(lambda f: f["service_name"].lower() == sp_service_name.lower() and \
                                              f["service_folder"].lower() == sp_folder.lower(), content))

            if len(map_servs) == 0:
                mode_fr = 'republication' if mode == "update" else 'dépublication'
                _validate_throws_or_append(UserMessageException(500,
                                           f"You have asked to {mode} the service {sp_service_name} in the folder {sp_folder} but there is no such service in the DDR Registry",
                                           f"Vous avez demandé la {mode_fr} du service {sp_service_name} dans le dossier {sp_folder} mais l'enregistrement de ce service n'existe pas dans le registre du DDR"),
                                           errors)

    else:
        _validate_throws_or_append(UserMessageException(500,
                                   f"Map services in the control file couldn't be pre-validated with the DDR Registry",
                                   f"Les map services dans le fichier de contrôle n'ont pu être pré-validé avec le registre du DDR"),
                                   errors)


def validate_map_services_not_existing(service_parameters: list, access_token: str, errors: list):

    # For each service parameter
    for sp in service_parameters:
        # Get the dataset/metadata ids from the service
        sp_service_name = os.path.basename(sp['in_project_filename']).split(".")[0]
        sp_folder = sp['service_schema_name']
        dataset_id, metadata_id = validate_get_dataset_metadata_id(sp_folder, sp_service_name, access_token)

        # If any dataset associated with it
        if dataset_id:
            if metadata_id:
                _validate_throws_or_append(UserMessageException(500,
                                           f"You have asked to publish the service {sp_service_name} in the folder {sp_folder} but the record of this service already exists in the DDR registry for the dataset {dataset_id} having the metadata id {metadata_id}",
                                           f"Vous avez demandé la publication du service {sp_service_name} dans le dossier {sp_folder} mais l'enregistrement de ce service existe déjà dans le registre du DDR pour le jeu de données {dataset_id} ayant l'identifiant de métadonnée {metadata_id}"), errors)

            else:
                _validate_throws_or_append(UserMessageException(500,
                                           f"You have asked to publish the service {sp_service_name} in the folder {sp_folder} but the record of this service already exists in the DDR registry for the dataset {dataset_id} having some metadata id",
                                           f"Vous avez demandé la publication du service {sp_service_name} dans le dossier {sp_folder} mais l'enregistrement de ce service existe déjà dans le registre du DDR pour le jeu de données {dataset_id} ayant un autre identifiant de métadonnée."), errors)


def _validate_project_files_exist(control_file: dict, message: CDTKMessage):

    # Keep track
    message.add_progress("Validating the QGS files are readable.",
                         "Validation de l'accessibilité des fichiers QGS.")

    # For each service parameter
    for sp in control_file['service_parameters']:
        filepath = config_env.QGIS_PROJECTS_PATH(sp['in_project_filename'])
        if not os.path.exists(filepath):
            _validate_throws_or_append(UserMessageException(500,
                                       f"Project file {filepath} not found on the server",
                                       f"Le fichier de projet {filepath} est introuvable sur le serveur"), message.errors)


def _validate_throws_or_append(exception: UserMessageException, errors: list):

    # If we have provided a list, append the exception to it, otherwise, throw it immediately
    if errors != None:
        # Append to the list
        errors.append(exception)

    else:
        # Throw it
        raise exception


def _call_cdtk_admin_get_access_code():

    try:
        # Get an access token using the system credentials
        res = requests.post(config_env.CDTK_ADMIN_URL + "/login", json={'username': config_env.AWS_SECRET_VALUE["API_REGISTRY"]["USER"], 'password': config_env.AWS_SECRET_VALUE["API_REGISTRY"]["PASS"]})

        if res.status_code == 200:
            content = json.loads(res.content.decode("utf-8"))
            return content['access_token']

        else:
            raise Exception()

    except Exception as err:
        print("ERROR:" + str(err))
        raise UserMessageException(500,
                                   f"Failed to authenticate with the DDR Registry.",
                                   f"Erreur lors de l'authentification avec le Registre DDR.")


def _call_czs_admin_get_access_code():

    try:
        # Get an access token using the system credentials
        res = requests.post(config_env.CZS_ADMIN_URL + "/login", json={'username': config_env.AWS_SECRET_VALUE["API_CZS"]["USER"], 'password': config_env.AWS_SECRET_VALUE["API_CZS"]["PASS"]})

        if res.status_code == 200:
            content = json.loads(res.content.decode("utf-8"))
            return content['access_token']

        else:
            raise Exception()

    except Exception as err:
        print("ERROR:" + str(err))
        raise UserMessageException(500,
                                   f"Failed to authenticate with the CZS Admin.",
                                   f"Erreur lors de l'authentification avec l'Administration CZS.")


def _validate_czs_theme_existing(theme_uuid: str, access_token: str, message: CDTKMessage):
    # Keep track
    message.add_progress("Validating the theme exists in Clip Zip Ship.",
                         "Validation que le thème existe dans Clip Zip Ship.")

    # Fetch the themes from CZS API
    themes = _get_czs_themes(access_token, message.errors)

    # If themes
    if themes:
        # For each theme
        for t in themes:
            if t['theme_uuid'] == theme_uuid:
                return True

    # Not found
    _validate_throws_or_append(UserMessageException(500,
                               f"You have asked to publish in Clip Zip Ship on a theme {theme_uuid}, but that theme doesn't exist.",
                               f"Vous avez demandé la publication dans Clip Zip Ship sur le thème {theme_uuid}, mais ce thème n'existe pas."), message.errors)


def _get_czs_themes(access_token: str, errors: list):
    try:
        # Get the themes
        res = _call_czs_admin_get("/themes", access_token)
        if res.status_code == 200:
            return json.loads(res.content.decode("utf-8"))

        else:
            raise Exception("Couldn't fetch the themes")

    except Exception as err:
        _validate_throws_or_append(UserMessageException(500,
                                   f"Failed to get the available themes from CZS Admin.",
                                   f"Erreur lors de l'obtention des thèmes à partir de CZS Admin."), errors)


def _get_cdtk_departments(publisher_email: str, access_token: str):
    try:
        # Get the departments
        res = _call_cdtk_admin_get(f"/departments?publisher={publisher_email}", access_token)
        if res.status_code == 200:
            return json.loads(res.content.decode("utf-8"))

        elif res.status_code == 404:
            raise NotFoundException()

        else:
            raise Exception("Couldn't fetch the departments")

    except Exception as err:
        if isinstance(err, UserMessageException):
            raise

        raise UserMessageException(500,
                                   f"Failed to get the available departments from DDR Registry.",
                                   f"Erreur lors de l'obtention des ministères à partir du Registre DDR.")


def _get_cdtk_servers(publisher_email: str, access_token: str):
    try:
        # Get the servers the particular email has access
        res = _call_cdtk_admin_get(f"/servers?publisher={publisher_email}", access_token)
        if res.status_code == 200:
            results = json.loads(res.content.decode("utf-8"))

            # Only return the ids to make sure to not expose too much from registry via publisher creds
            ret = []
            for r in results:
                ret.append({'id': r['id']})
            return ret

        elif res.status_code == 404:
            raise NotFoundException()

        else:
            raise Exception("Couldn't fetch the servers")

    except Exception as err:
        if isinstance(err, UserMessageException):
            raise

        raise UserMessageException(500,
                                   f"Failed to get the available servers from DDR Registry.",
                                   f"Erreur lors de l'obtention des serveurs à partir du Registre DDR.")


def _get_cdtk_downloads(publisher_email: str, access_token: str):
    try:
        # Get the downloads the particular email has access
        res = _call_cdtk_admin_get(f"/downloads?publisher={publisher_email}", access_token)
        if res.status_code == 200:
            results = json.loads(res.content.decode("utf-8"))

            # Only return the ids to make sure to not expose too much from registry via publisher creds
            ret = []
            for r in results:
                ret.append({'id': r['id']})
            return ret

        elif res.status_code == 404:
            raise NotFoundException()

        else:
            raise Exception("Couldn't fetch the downloads")

    except Exception as err:
        if isinstance(err, UserMessageException):
            raise

        raise UserMessageException(500,
                                   f"Failed to get the available downloads from DDR Registry.",
                                   f"Erreur lors de l'obtention des téléchargements à partir du Registre DDR.")


def _get_cdtk_dataset(metadata_id: str, access_token: str):
    try:
        # Get the datasets associated with the metadata id
        res = _call_cdtk_admin_get(f"/datasets/{metadata_id}", access_token)
        if res.status_code == 200:
            r = json.loads(res.content.decode("utf-8"))

            # Read the dataset id
            dataset_id = r['id']

            # Get the map services associated with the dataset
            res2 = _call_cdtk_admin_get(f"/map_services/dataset/{dataset_id}", access_token)

            map_servs = []
            if res2.status_code == 200:
                r2 = json.loads(res2.content.decode("utf-8"))
                for map_s in r2:
                    map_servs.append({
                        'qgis_server_id': map_s['qgis_server_id'],
                        'qgis_project_filename': map_s['qgis_project_filename'],
                        'service_folder': map_s['service_folder'],
                        'service_language': map_s['service_language'],
                        'service_name': map_s['service_name'],
                    })

            elif res2.status_code == 404:
                # No map services, ok
                pass

            else:
                raise Exception("Couldn't fetch the map services")

            # Only return metadata_id, download_folder_name, core_subject_term and thumbnail_image_file
            return {
                'map_services': map_servs,
                'dataset':
                {
                    'metadata_id': r['metadata_id'],
                    'download_folder_name': r['download_folder_name'],
                    'core_subject_term': r['core_subject_term'],
                    'thumbnail_image_file': r['thumbnail_image_file']
                }
            }

        elif res.status_code == 404:
            raise NotFoundException()

        else:
            raise Exception("Couldn't fetch the dataset")

    except Exception as err:
        if isinstance(err, UserMessageException):
            raise

        raise UserMessageException(500,
                                   f"Failed to get the dataset from DDR Registry.",
                                   f"Erreur lors de l'obtention du dataset à partir du Registre DDR.")


def _get_cdtk_my_email(access_token: str):
    try:
        # Get the publishers
        res = _call_cdtk_admin_get("/publishers", access_token)
        if res.status_code == 200:
            publishers = json.loads(res.content.decode("utf-8"))
            pubs = list(filter(lambda l: l['ad_user_name'] == auth.current_user().id, publishers))

            # If found
            if len(pubs) >= 1:
                return pubs[0]['email']

            else:
                raise NotFoundException()

        elif res.status_code == 404:
            raise NotFoundException()

        else:
            raise Exception("Couldn't fetch the publishers")

    except Exception as err:
        if isinstance(err, UserMessageException):
            raise

        raise UserMessageException(500,
                                   f"Failed to get the publisher email for the logged user.",
                                   f"Erreur lors de l'obtention du email de l'éditeur pour l'utilisateur connecté.")


def _call_cdtk_admin_get(url: str, access_token: str):

    # Get the headers with access code to communicate with DDR Registry
    headers = {'Authorization': "Bearer " + access_token}

    # Call get
    return requests.get(config_env.CDTK_ADMIN_URL + url, headers=headers)


def _call_czs_admin_get(url: str, access_token: str):

    # Get the headers with access code to communicate with DDR Registry
    headers = {'Authorization': "Bearer " + access_token}

    # Call get
    return requests.get(config_env.CZS_ADMIN_URL + url, headers=headers)


def try_save_in_cdtk_registry(control_file: dict, message: CDTKMessage):

    try:
        # Save the service in the registry
        save_in_cdtk_registry(control_file, message)

    except Exception as err:
        # Failed saving in DDR registry, unpublish everything
        message.add_progress("ERROR when saving in DDR Registry, cancelling publication.",
                             "ERREUR lors de la sauvegarde dans le Registre DDR, annulation de la publication.")

        # ROLLBACK, abort
        _run_pyqgis("delete_service_and_data", control_file, message)

        # Keep raising err
        raise err


def save_in_cdtk_registry(control_file: dict, message: CDTKMessage):

    # Keep track
    message.add_progress("Saving services in DDR Registry",
                         "Sauvegarde des services dans le Registre DDR")

    # Get the headers with access code to communicate with DDR Registry
    headers = {'Authorization': "Bearer " + control_file['process_parameters']['cdtk_registry_access_token']}

    try:
        # If the dataset must be created
        dataset_id = control_file['process_parameters']['dataset_info']['dataset_id']
        if dataset_id == "CREATE_IT":
            # Format the payload
            payload = {
                "department_acrn_en": control_file['generic_parameters']['department'],
                "metadata_id": control_file['generic_parameters']['metadata_uuid'],
                "thumbnail_image_file": "",
                "download_id": "",
                "core_subject_term": "",
                "download_folder_name": "",
                "download_folder_path": ""
            }

            # If a download package name is set
            if control_file['generic_parameters']['download_package_name']:
                payload["download_id"] = control_file['generic_parameters']['download_info_id']
                payload["core_subject_term"] = control_file['generic_parameters']['core_subject_term']
                payload["download_folder_name"] = control_file['generic_parameters']['download_package_name']
                payload["download_folder_path"] = util.get_download_path(control_file, True, None)

            # Saves in the registry
            req = requests.put(config_env.CDTK_ADMIN_URL + "/datasets", json=payload, headers=headers)

            # If saved in the registry
            if (req.status_code == 204):
                req = _call_cdtk_admin_get("/datasets/" + control_file['generic_parameters']['metadata_uuid'],
                                          control_file['process_parameters']['cdtk_registry_access_token'])
                if req.status_code == 200:
                    # Get the dataset id which has just been created
                    dataset_id = json.loads(req.content.decode("utf-8"))["id"]

                else:
                    raise UserMessageException(500,
                                               f"Failed to retrieve the newly created dataset from the DDR Registry.",
                                               f"Erreur lors de la récupération du dataset fraîchement créé dans le Registre DDR.")

            else:
                detail = req.json()['detail'] if "detail" in req.json() else ""
                detail_fr = req.json()['detail_fr'] if "detail_fr" in req.json() else ""
                raise UserMessageException(500,
                                           f"Failed to save the new dataset in the DDR Registry. " + detail,
                                           f"Erreur lors de la sauvegarde du nouveau jeu de données dans le Registre DDR. " + detail_fr)

        else:
            # The dataset was already existing upon publishing
            # If a download package name is set
            if control_file['generic_parameters']['download_package_name']:
                # Make sure to update the download package metadata in the dataset
                # (there probably were map services using it and no download package before)
                # The payload to clear the download id information from the dataset
                payload2 = [{
                    "op": "update",
                    "path": "/download_id",
                    "value": control_file['generic_parameters']['download_info_id']
                },
                {
                    "op": "update",
                    "path": "/download_folder_name",
                    "value": control_file['generic_parameters']['download_package_name']
                },
                {
                    "op": "update",
                    "path": "/core_subject_term",
                    "value": control_file['generic_parameters']['core_subject_term']
                },
                {
                    "op": "update",
                    "path": "/download_folder_path",
                    "value": util.get_download_path(control_file, True, None)
                }]

                # Update the download package references from the dataset in case they were NULL before
                req = requests.patch(config_env.CDTK_ADMIN_URL + "/datasets/" + control_file['generic_parameters']['metadata_uuid'],
                                     json=payload2, headers=headers)

                # If failed to save in the registry
                if (req.status_code != 204):
                    detail = req.json()['detail'] if "detail" in req.json() else ""
                    detail_fr = req.json()['detail_fr'] if "detail_fr" in req.json() else ""
                    raise UserMessageException(500,
                                               f"Failed to update dataset download package metadata in the DDR Registry. " + detail,
                                               f"Erreur lors de la mise à jour du paquet de téléchargement dans le Registre DDR. " + detail_fr)

        # If a download package name is set
        if control_file['generic_parameters']['download_package_name']:
            # Save the download package
            save_download_package(control_file, message)

        # For each service_parameters
        for sp in control_file['service_parameters']:
            # Format the payload
            payload = {
                "dataset_id": dataset_id,
                "qgis_project_filename": sp['in_project_filename'],
                "qgis_server_id": control_file['generic_parameters']['qgis_server_id'],
                "service_data_path": "",
                "service_folder": sp['service_schema_name'],
                "service_language": sp['language'],
                "service_name": os.path.basename(sp['in_project_filename']).split(".")[0]
            }

            # Saves in the registry
            req = requests.put(config_env.CDTK_ADMIN_URL + "/map_services", json=payload, headers=headers)

            # If failed to save in the registry
            if (req.status_code != 204):
                detail = req.json()['detail'] if "detail" in req.json() else ""
                detail_fr = req.json()['detail_fr'] if "detail_fr" in req.json() else ""
                raise UserMessageException(500,
                                           f"Failed to save the new service in the DDR Registry. " + detail,
                                           f"Erreur lors de la sauvegarde du nouveau service dans le Registre DDR. " + detail_fr)

    except Exception as err:
        # Keep track
        message.add_progress("Failed saving in DDR Registry, reverting. " + str(err),
                             "Échec lors de la sauvegarde dans Registre DDR, retour arrière. " + str(err))

        # ROLLBACK, cascade
        # Delete from DDR Registry
        delete_from_cdtk_registry(control_file, control_file['process_parameters']['cdtk_registry_access_token'], message)

        # Keep raising err
        raise err


def delete_from_cdtk_registry(control_file: dict, cdtk_registry_access_token: str, message: CDTKMessage):

    # Keep track
    message.add_progress("Deleting services from the DDR Registry",
                         "Suppression des services dans le Registre DDR")

    # Get the headers with access code to communicate with DDR Registry
    headers = {'Authorization': "Bearer " + cdtk_registry_access_token}

    # If deleting a download package
    if control_file['generic_parameters']['download_package_name']:
        # The payload to clear the download id information from the dataset
        payload = [{
            "op": "update",
            "path": "/download_id",
            "value": None
        }]

        # Clean the download package references from the dataset
        req = requests.patch(config_env.CDTK_ADMIN_URL + "/datasets/" + control_file['generic_parameters']['metadata_uuid'],
                             json=payload, headers=headers)

        # If cleaned or just not found
        if (req.status_code == 204 or req.status_code == 404):
            # Delete the download package from S3 too
            delete_download_package(control_file, message)

        else:
            # Failed to clean up dataset
            detail = req.json()['detail'] if "detail" in req.json() else ""
            detail_fr = req.json()['detail_fr'] if "detail_fr" in req.json() else ""
            raise UserMessageException(500,
                                       f"Failed to cleanup the dataset in the DDR Registry. " + detail,
                                       f"Erreur lors du nettoyage du dataset dans le Registre DDR. " + detail_fr)

    # For each service_parameters
    for sp in control_file['service_parameters']:
        # Deletes from the registry
        req = requests.delete(config_env.CDTK_ADMIN_URL +
                              "/map_services/" + sp['service_schema_name'] + "/" + os.path.basename(sp['in_project_filename']).split(".")[0],
                              headers=headers)

        # If deleted in CZS or just not found
        if (req.status_code == 204 or req.status_code == 404):
            pass  # Okay

        else:
            detail = req.json()['detail'] if "detail" in req.json() else ""
            detail_fr = req.json()['detail_fr'] if "detail_fr" in req.json() else ""
            raise UserMessageException(500,
                                       f"Failed to delete the service in the DDR Registry. " + detail,
                                       f"Erreur lors de la suppression du service dans le Registre DDR. " + detail_fr)

    # Clean up the DDR Registry for orphan datasets
    clean_up_cdtk_registry_dataset(control_file, cdtk_registry_access_token, message)


def clean_up_cdtk_registry_dataset(control_file: dict, cdtk_registry_access_token: str, message: CDTKMessage):

    # Keep track
    message.add_progress("Verification of the use for the dataset in the DDR Registry",
                         "Vérification de la pertinence du jeu de données dans le Registre DDR")

    # Get the headers with access code to communicate with DDR Registry
    headers = {'Authorization': "Bearer " + cdtk_registry_access_token}

    # Retrieve the latest information on the dataset
    req = _call_cdtk_admin_get("/datasets/" + control_file['generic_parameters']['metadata_uuid'],
                              cdtk_registry_access_token)
    if req.status_code == 200:
        # Read the dataset information
        dataset_info = json.loads(req.content.decode("utf-8"))

        # If there's no download id on it
        if not dataset_info["download_id"]:
            # Get the map services on the dataset (if any)
            res_ms = _call_cdtk_admin_get("/map_services/dataset/" + dataset_info['id'], cdtk_registry_access_token)
            map_servs = None
            if res_ms.status_code == 200:
                # Read
                map_servs = json.loads(res_ms.content.decode("utf-8"))

            # If no map services
            if not map_servs or len(map_servs) == 0:
                # Keep track
                message.add_progress("Deleting dataset from the DDR Registry, no more used",
                                     "Suppression du jeu de données du Registre DDR, n'est plus utile")

                # Delete the dataset from the registry
                requests.delete(config_env.CDTK_ADMIN_URL + "/datasets/" + control_file['generic_parameters']['metadata_uuid'], headers=headers)


def try_save_in_czs_registry(control_file: dict, project_infos: list, message: CDTKMessage):

    try:
        # Save in Clip Zip Ship
        save_in_czs_registry(control_file, project_infos, message)

    except Exception as err:
        # Failed saving in CZS, unregister from DDR and unpublish everything
        message.add_progress("ERROR when saving in Clip Zip Ship, cancelling publication.",
                             "ERREUR lors de la sauvegarde dans Clip Zip Ship, annulation de la publication.")

        # ROLLBACK, abort
        # Delete from DDR Registry
        delete_from_cdtk_registry(control_file, control_file['process_parameters']['cdtk_registry_access_token'], message)

        # Call unpublish
        _run_pyqgis("delete_service_and_data", control_file, message)

        # Keep raising err
        raise err


def save_in_czs_registry(control_file: dict, project_infos: list, message: CDTKMessage):

    # Keep track
    message.add_progress("Save services in Clip Zip Ship",
                         "Sauvegarde des services dans Clip Zip Ship")

    # Get the headers with access code to communicate with Clip Zip Ship
    headers = {'Authorization': "Bearer " + control_file['process_parameters']['czs_admin_access_token']}

    # Init
    sp_en = None
    proj_status_en = None
    sp_fr = None
    proj_status_fr = None

    # Read the service parameter English
    sp_lst = list(filter(lambda sp: sp['language'].lower() == "english", control_file['service_parameters']))
    if len(sp_lst) > 0:
        sp_en = sp_lst[0]

        # Read the project info for the corresponding service parameter
        pr_st_lst = list(filter(lambda prst: sp_en['in_project_filename'].lower() == prst['project'].lower() + ".qgs", project_infos))
        if len(pr_st_lst) > 0:
            proj_status_en = pr_st_lst[0]

    # Read the service parameter French
    sp_lst = list(filter(lambda sp: sp['language'].lower() == "french", control_file['service_parameters']))
    if len(sp_lst) > 0:
        sp_fr = sp_lst[0]

        # Read the project info for the corresponding service parameter
        pr_st_lst = list(filter(lambda prst: sp_fr['in_project_filename'].lower() == prst['project'].lower() + ".qgs", project_infos))
        if len(pr_st_lst) > 0:
            proj_status_fr = pr_st_lst[0]

    parent_uuid = None
    try:
        # Save the Parent information
        parent_uuid = save_in_clip_zip_ship_parent(headers,
                                                   control_file['generic_parameters']['czs_collection_theme'],
                                                   proj_status_en['project'] if proj_status_en and 'project' in proj_status_en else "",
                                                   proj_status_fr['project'] if proj_status_fr and 'project' in proj_status_fr else "",
                                                   proj_status_en['project_title'] if proj_status_en and 'project_title' in proj_status_en else "",
                                                   proj_status_fr['project_title'] if proj_status_fr and 'project_title' in proj_status_fr else "",
                                                   control_file['generic_parameters']['department'])

        # Save the Collections
        save_in_clip_zip_ship_collections(headers, control_file['generic_parameters']['metadata_uuid'], parent_uuid,
                                          sp_en, proj_status_en, sp_fr, proj_status_fr, message)

    except Exception as err:
        # Keep track
        message.add_progress("Failed saving in Clip Zip Ship, reverting. " + str(err),
                             "Échec lors de la sauvegarde dans Clip Zip Ship, retour arrière. " + str(err))

        # ROLLBACK, cascade
        # Delete from Clip Zip Ship Registry
        delete_from_czs_registry(control_file['process_parameters']['czs_admin_access_token'],
                                 control_file['generic_parameters']['metadata_uuid'],
                                 parent_uuid,
                                 message)

        # Keep raising err
        raise err


def save_in_clip_zip_ship_parent(headers: dict, theme_uuid: str, name_en: str, name_fr: str, title_en: str, title_fr: str, org_schema: str):
    # Create the payload
    payload = {
        'theme_uuid': theme_uuid,
        'name_en': name_en,
        'name_fr': name_fr if name_fr else name_en,
        'title_en': title_en,
        'title_fr': title_fr if title_fr else title_en,
        'org_schema': org_schema
    }

    # Add a parent
    req = requests.put(config_env.CZS_ADMIN_URL + "/parents", json=payload, headers=headers)

    # If saved in the registry, get the parent UUID
    if (req.status_code == 201):
        return req.text

    else:
        detail = req.json()['detail'] if "detail" in req.json() else ""
        detail_fr = req.json()['detail_fr'] if "detail_fr" in req.json() else ""
        raise UserMessageException(500,
                                   f"Failed to save the parent information in CZS. " + detail,
                                   f"Erreur lors de la sauvegarde d'information du parent dans CZS. " + detail_fr)


def delete_from_czs_registry(czs_access_token: str, metadata_uuid: str, parent_uuid: str, message: CDTKMessage):

    # Keep track
    message.add_progress("Deleting services information in Clip Zip Ship",
                         "Suppression des informations dans le Clip Zip Ship")

    # Get the headers with access code to communicate with DDR Registry
    headers = {'Authorization': "Bearer " + czs_access_token}

    # If no parent set
    if parent_uuid == None:
        # Get the parent uuid based on an existing collection
        req = requests.get(config_env.CZS_ADMIN_URL + "/collections?metadata_uuid=" + metadata_uuid, headers=headers)

        # If request was valid
        if (req.status_code == 200):
            # Get the first collection if any
            res = req.json()
            if len(res) > 0:
                # Get the parent_uuid
                parent_uuid = res[0]['parent_uuid']

    # Delete all collections on metadata_uuid
    req = requests.delete(config_env.CZS_ADMIN_URL + "/collections/metadata/" + metadata_uuid, headers=headers)

    # If deleted or just not found
    if (req.status_code == 204 or req.status_code == 404):
        # If parent_uuid is set, delete the parent too, to make sure
        if parent_uuid:
            # Explicitely delete the parent
            req2 = requests.delete(config_env.CZS_ADMIN_URL + "/parents/" + parent_uuid, headers=headers)

            # If not deleted or just not found
            if not (req2.status_code == 204 or req2.status_code == 404):
                detail = req.json()['detail'] if "detail" in req.json() else ""
                detail_fr = req.json()['detail_fr'] if "detail_fr" in req.json() else ""
                raise UserMessageException(500,
                                           f"Failed to delete the parent information in CZS. " + detail,
                                           f"Erreur lors de la suppression du parent dans CZS. " + detail_fr)

        # If deleted
        if req.status_code == 204:
            try:
                # Hot-reload PyGeoAPI
                response = requests.get(config_env.PYGEOAPI_URL)
            except Exception as err:
                print("Failed to reload resources")
                print(err)
                pass  # No worries

        # All good
        return True

    else:
        detail = req.json()['detail'] if "detail" in req.json() else ""
        detail_fr = req.json()['detail_fr'] if "detail_fr" in req.json() else ""
        raise UserMessageException(500,
                                   f"Failed to delete the collections in CZS. " + detail,
                                   f"Erreur lors de la suppression des collections dans CZS. " + detail_fr)


def save_in_clip_zip_ship_collections(headers: dict, metadata_uuid: str, parent_uuid: str,
                                      sp_en: dict, proj_status_en: dict, sp_fr: dict, proj_status_fr: dict,
                                      message: CDTKMessage):

    """
    For all types, properties are:
    - type: can be 1 of 2 values: "feature" or "coverage"
    - parent_uuid: indicates the parent identifier on which to add the collection
    - metadata_uuid: indicates the metadata catalog identifier representing the collection
    - name: the collection name (must be unique)
    - title_en: the English title of the collection
    - title_fr: the French title of the collection
    - description_en: the English description of the collection
    - description_fr: the French description of the collection
    - keywords_en: the English keywords of the collection
    - keywords_fr: the French keywords of the collection
    - crs: the spatial reference of the collection
    - extent_bbox: the spatial extent of the bbox representing the collection
    - extent_crs: the spatial reference of the extent bbox
    - extent_temporal_begin: the starting date for the data in the collection
    - extent_temporal_end: the ending date for the data in the collection
    - max_extract_area: the maximum area allowed for an extraction by CZS

    For type=="feature":
    - table_name: the table name of the feature type collection being added
    - table_schema: the database schema holding the table
    - table_id_field: the field in the table which holds the identifier key
    - table_queryables: the list of queryables fields in the table

    For type=="coverage":
    - geom_wkt: the geometry in well known text format
    - geom_crs: the spatial reference for the geometry wkt
    - cov_data: the cog of the raster
    - cov_format_name: the format name of the cog file (e.g.: GTiff)
    """

    # If English
    if proj_status_en:
        # For each layer in the English project
        for layer_en in proj_status_en['layers']:

            #print("CZS Project status English")
            #print(proj_status_en)

            # If the layer is valid and either (1) is feature and points to a database table or (2) is coverage
            if layer_en['is_valid'] and \
               ((layer_en['type'] == 'feature' and layer_en['data_exists_in_database']) or \
                (layer_en['type'] == 'coverage')):
                # Find the French equivalent if any
                layer_fr = None
                if proj_status_fr:
                    layers_lst = list(filter(lambda l: len(l['name_short']) and l['name_short'] == layer_en['name_short'], proj_status_fr['layers']))
                    if len(layers_lst) > 0:
                        layer_fr = layers_lst[0]

                # Build the payload
                payload = {
                    'type': layer_en['type'],
                    'parent_uuid': parent_uuid,
                    'metadata_uuid': metadata_uuid,
                    'title_en': layer_en['name'],
                    'title_fr': layer_fr['name'] if layer_fr else layer_en['name'],
                    'description_en': layer_en['abstract'],
                    'description_fr': layer_fr['abstract'] if layer_fr else layer_en['abstract'],
                    'keywords_en': layer_en['keywords'],
                    'keywords_fr': layer_fr['keywords'] if layer_fr else layer_en['keywords'],
                    'crs': int(layer_en['crs']),
                    'extent_bbox': [
                        layer_en['extent4326']['xMinimum'],
                        layer_en['extent4326']['yMinimum'],
                        layer_en['extent4326']['xMaximum'],
                        layer_en['extent4326']['yMaximum']
                    ],
                    'extent_crs': "http://www.opengis.net/def/crs/OGC/1.3/CRS84",
                    'extent_temporal_begin': layer_en['temporal']['begin'] or "",
                    'extent_temporal_end': layer_en['temporal']['end'] or ""
                }

                if payload['type'] == 'feature':
                  payload['name'] = layer_en['uri']['table']
                  payload['table_name'] = layer_en['uri']['table']
                  payload['table_schema'] = layer_en['uri']['schema']
                  payload['table_id_field'] = layer_en['fields_ids'][0]
                  payload['table_queryables'] = []    # hardcoded, as specified in the provided spreadsheet (see Martin)

                  # Depending on the type of geometry
                  # These conditions support the Multi/Curve variants of each geometry type:
                  # https://qgis.org/pyqgis/master/core/QgsWkbTypes.html#qgis.core.QgsWkbTypes.geometryType
                  payload['max_extract_area'] = config.COLL_MAX_AREA_POLYGON # Polygon (default)
                  if layer_en['geom_type'] == "Line":
                    payload['max_extract_area'] = config.COLL_MAX_AREA_POLYLINE # Line
                  elif layer_en['geom_type'] == "Point":
                    payload['max_extract_area'] = config.COLL_MAX_AREA_POINT # Point

                  # Not sending layer connectivity information as we don't remote connect (db-link) to an external database with service creds stored in a QGIS file anymore
                  # payload['db_host'] = layer_en['uri']['host']
                  # payload['db_port'] = int(layer_en['uri']['port'])
                  # payload['db_name'] = layer_en['uri']['dbname']
                  # payload['db_user'] = layer_en['uri']['username']
                  # payload['db_password'] = layer_en['uri']['password']


                elif payload['type'] == 'coverage':
                  payload['name'] = layer_en['name_table']
                  payload['cov_data'] = layer_en['uri']['path']
                  payload['cov_format_name'] = "GTiff"
                  payload['geom_crs'] = int(layer_en['crs'])
                  payload['geom_wkt'] = f"""POLYGON((
                                            {layer_en['extent']['xMinimum']} {layer_en['extent']['yMinimum']},
                                            {layer_en['extent']['xMinimum']} {layer_en['extent']['yMaximum']},
                                            {layer_en['extent']['xMaximum']} {layer_en['extent']['yMaximum']},
                                            {layer_en['extent']['xMaximum']} {layer_en['extent']['yMinimum']},
                                            {layer_en['extent']['xMinimum']} {layer_en['extent']['yMinimum']}
                                        ))"""

                  # Use the units_per_pixel_x to determine the max area threshold
                  payload['max_extract_area'] = config.COLL_MAX_AREA_RASTER_RES_0 # Default
                  if layer_en['units_per_pixel_x'] >= 6:
                    payload['max_extract_area'] = config.COLL_MAX_AREA_RASTER_RES_6
                  if layer_en['units_per_pixel_x'] >= 16:
                    payload['max_extract_area'] = config.COLL_MAX_AREA_RASTER_RES_16
                  if layer_en['units_per_pixel_x'] >= 30:
                    payload['max_extract_area'] = config.COLL_MAX_AREA_RASTER_RES_30

                # Add a collection
                req = requests.put(config_env.CZS_ADMIN_URL + "/collections?reload_pygeoapi=false", json=payload, headers=headers)

                # If failed to save in the registry
                if (req.status_code != 204):
                    detail = req.json()['detail'] if "detail" in req.json() else ""
                    detail_fr = req.json()['detail_fr'] if "detail_fr" in req.json() else ""
                    raise UserMessageException(500,
                                               f"Failed to save the collection information in CZS. " + detail,
                                               f"Erreur lors de la sauvegarde d'information de la collection dans CZS. " + detail_fr)

        try:
            # Hot-reload PyGeoAPI
            response = requests.get(config_env.PYGEOAPI_URL)
        except Exception as err:
            print("Failed to reload resources")
            print(err)
            pass  # No worries


def try_update_download_package(control_file: dict, message: CDTKMessage):

    try:
        # Backup the download package
        backup_download_package(control_file, message)

        # Save the download package
        save_download_package(control_file, message)

        # Clean the download package backup
        clean_download_package(control_file, message)

    except Exception as err:
        # Restore the backup
        restore_download_package(control_file, message)
        raise


def save_download_package(control_file: dict, message: CDTKMessage):

    try:
        # Keep track
        message.add_progress("Extracting and saving download package to FTP",
                             "Extraction et sauvegarde du paquet de téléchargement dans le FTP")

        # Get S3 path
        s3_path_prefix = util.get_download_path(control_file, False, None)

        # Set the destination folder and zip file path
        dest_path = config_env.QGIS_PROJECTS_PATH(control_file['generic_parameters']['download_package_name'])

        # If the folder doesn't exist, create it
        if not os.path.exists(dest_path):
            os.makedirs(dest_path)

        # Extract the zip content in the folder
        zip_path = dest_path + ".zip"
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            for info in zip_ref.infolist():
                # Extract the file
                zip_ref.extract(info, dest_path)

        # Upload the folder to S3
        aws.upload_bucket_folder(dest_path,
                                 control_file['process_parameters']['download_info']['owner_username'],
                                 control_file['process_parameters']['download_info']['download_root_path'],
                                 s3_path_prefix)

        # Keep track
        message.add_progress(f"Download package saved to {s3_path_prefix}/{control_file['generic_parameters']['download_package_name']}",
                             f"Paquet de téléchargement sauvegardé dans {s3_path_prefix}/{control_file['generic_parameters']['download_package_name']}")

    except Exception as err:
        # Failed saving download package, unregister from DDR and unpublish everything
        message.add_progress("ERROR when saving download package, reverting. " + str(err),
                             "ERREUR lors de la sauvegarde du paquet de téléchargement, retour arrière. " + str(err))

        # ROLLBACK, cascade
        # Delete the folder
        aws.delete_bucket_folder(control_file['generic_parameters']['download_package_name'],
                                 control_file['process_parameters']['download_info']['owner_username'],
                                 control_file['process_parameters']['download_info']['download_root_path'],
                                 s3_path_prefix)

        # Keep raising err
        raise err


def backup_download_package(control_file: dict, message: CDTKMessage):

    # Keep track
    message.add_progress("Backuping download package in FTP",
                         "Copie de sauvegarde du paquet de téléchargement du FTP")

    # Get S3 path
    s3_path_prefix = util.get_download_path(control_file, True, None)
    s3_path_prefix_backup = util.get_download_path(control_file, True, "_bck_")

    # Copy download package
    aws.copy_bucket_folder(control_file['process_parameters']['download_info']['download_root_path'],
                           s3_path_prefix,
                           control_file['process_parameters']['download_info']['download_root_path'],
                           s3_path_prefix_backup,
                           control_file['process_parameters']['download_info']['owner_username'],
                           True)


def restore_download_package(control_file: dict, message: CDTKMessage):

    # Keep track
    message.add_progress("Restoring the download package backup in FTP",
                         "Récupération de la copie de sauvegarde du paquet de téléchargement du FTP")

    # Get S3 path
    s3_path_prefix_restore = util.get_download_path(control_file, True, "_bck_")
    s3_path_prefix = util.get_download_path(control_file, True, None)

    # Copy download package
    aws.copy_bucket_folder(control_file['process_parameters']['download_info']['download_root_path'],
                           s3_path_prefix_restore,
                           control_file['process_parameters']['download_info']['download_root_path'],
                           s3_path_prefix,
                           control_file['process_parameters']['download_info']['owner_username'],
                           True)


def clean_download_package(control_file: dict, message: CDTKMessage):

    # Keep track
    message.add_progress("Cleaning the download package backup from FTP",
                         "Nettoyage de la copie de sauvegarde du paquet de téléchargement du FTP")

    # Get S3 path
    s3_path_prefix = util.get_download_path(control_file, False, None)

    # Copy download package
    aws.delete_bucket_folder("_bck_" + control_file['generic_parameters']['download_package_name'],
                             control_file['process_parameters']['download_info']['owner_username'],
                             control_file['process_parameters']['download_info']['download_root_path'],
                             s3_path_prefix)


def delete_download_package(control_file: dict, message: CDTKMessage):

    # Keep track
    message.add_progress("Deleting download package from FTP",
                         "Suppression du paquet de téléchargement du FTP")

    # Get S3 path
    s3_path_prefix = util.get_download_path(control_file, False, None)

    # Delete the folder from S3
    aws.delete_bucket_folder(control_file['generic_parameters']['download_package_name'],
                             control_file['process_parameters']['download_info']['owner_username'],
                             control_file['process_parameters']['download_info']['download_root_path'],
                             s3_path_prefix)


def _run_pyqgis(operation: str, run_file: dict, message: CDTKMessage):

    filepath = None
    try:
        # Copy the control file to a local file on server
        filepath = _copy_run_file(run_file)

        # Run it
        main_file = config_env.QGIS_PYTHON_PATH("main.py")
        try:
            #print(f"LAUNCHING PROCESS: {main_file} --operation={operation} --file=\"{filepath}\"")
            res = subprocess.run(f"python {main_file} --operation={operation} --file=\"{filepath}\" --proj_path=\"{config_env._QGIS_PROJECTS_PATH}\" --db_host=\"{config_env.AWS_SECRET_VALUE['DB_PUBLISHER']['HOST']}\" --db_port={config_env.AWS_SECRET_VALUE['DB_PUBLISHER']['PORT']} --db_name=\"{config_env.AWS_SECRET_VALUE['DB_PUBLISHER']['NAME']}\" --db_user=\"{config_env.AWS_SECRET_VALUE['DB_PUBLISHER']['USER']}\" --db_pass=\"{config_env.AWS_SECRET_VALUE['DB_PUBLISHER']['PASS']}\"",
                                 shell=True, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

            # Read the result information
            [result, qgis_progress_marks, qgis_warnings] = _read_result_based_on_stdout(res.stdout.decode(detect(res.stdout)['encoding']))

            # If part of a greater process, append the information
            if message != None:
                message.progress_marks += qgis_progress_marks
                message.warnings += qgis_warnings

            return result

        except subprocess.CalledProcessError as e:
            # Unwrap the exception from the sub process
            if e.stdout:
                # Read the result information
                [result, qgis_progress_marks, qgis_warnings] = _read_result_based_on_stdout(e.stdout.decode(detect(e.stdout)['encoding']))

                # If part of a greater process, append the information
                if message != None:
                    message.progress_marks += qgis_progress_marks
                    message.warnings += qgis_warnings

            print("THE ERROR")
            print(e.stderr.decode(detect(e.stderr)['encoding']))

            # Read the exceptions
            exs = _read_exceptions_based_on_stderr(e.stderr.decode(detect(e.stderr)['encoding']))

            # If part of a greater process, append the error
            if message != None:
                message.errors.extend(exs)

            else:
                raise util.combine_exceptions_for_response(exs)  # Raise right away

    finally:
        # If not running in DEV, delete the file
        if filepath and not config_env.IS_LOCAL:
            os.remove(filepath)


def _read_result_based_on_stdout(stdout: str):
    result = True
    progress_marks = []
    warnings = []

    # If debug
    if config_env.IS_LOCAL:
        print()
        print("Catching the results from the stdout:")
        print("-------------------------------------")
        print(stdout.strip(os.linesep))
        print("-------------------------------------")
        print()

    # For each line
    for l in stdout.splitlines():
        if l.startswith("Result: "):
            line = l[8:]
            output = json.loads(line)
            result = output["result"]
            progress_marks = QGISProgressMark.list_dict_as_list_progress_marks(output["progress_marks"])
            warnings =  QGISWarning.list_dict_as_list_warn(output["warnings"])
    return [result, progress_marks, warnings]


def _read_exceptions_based_on_stderr(stderr: str):

    # Very experimental, but better than nothing for now!
    for l in stderr.splitlines():
        if l.startswith("lib.exceptions.QGISAggregationException: "):
            line = l[41:]
            ex_list = json.loads(line)
            return QGISApplicationException.list_dict_as_list_ex(ex_list)

        elif l.startswith("Exception: "):
            return [Exception(l[11:])]

        elif l.startswith("TypeError: "):
            return [Exception(l[11:])]

    # Catch all
    return [Exception(stderr)]


def _copy_run_file(run_file: dict):

    # If the folder doesn't exist, create it
    if not os.path.exists(config_env.QGIS_JOBS_PATH("")):
        os.makedirs(config_env.QGIS_JOBS_PATH(""))

    # Generate a randomly generated filename to hold the control file information for the nrcan_qgis process
    filepath = config_env.QGIS_JOBS_PATH(str(uuid.uuid4()) + ".json")

    # Create the file with the control file information
    with open(filepath, 'w') as outfile:
        json.dump(run_file, outfile, indent=4)

    # Return the path of the created file
    return filepath


def _is_valid_uuid(uuid_to_test):
    """
    Checks if uuid_to_test is a valid UUID.
    """

    try:
        UUID_PATTERN = re.compile(r'^[\da-f]{8}-([\da-f]{4}-){3}[\da-f]{12}$', re.IGNORECASE)
        return bool(UUID_PATTERN.match(uuid_to_test))

    except ValueError:
        return False


def _print_out(message: CDTKMessage, big_error: Exception):
    """
    Prints out what has happened.
    """

    # Read the progress marks
    [english, french] = util.combine_progress_marks_for_response(message.progress_marks)

    print()
    print()
    print("---------------------- PRINT OUT ----------------------")
    print()
    if big_error and not message.user_error:
        print("Here's the big error:")
        print(str(big_error))
        print()
        print("----------------------")
        print()

    if message.user_error:
        print("Here's the error message sent to the user:")
        print(message.user_error.message)
        print()

    print("Here's what's happened:")
    print(english)
    print()
    print("----------------------")
    print()
    if message.user_error:
        print("Voici le message d'erreur envoyé à l'utilisateur:")
        print(message.user_error.message_fr)
        print()

    print("Voici ce qui est arrivé:")
    print(french)
    print()
