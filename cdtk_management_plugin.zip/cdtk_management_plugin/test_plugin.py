import sys
import os
from unittest.mock import patch
# Append QGIS Python paths
sys.path.append('C:/Program Files/QGIS 3.34.10/apps/qgis-ltr/python')
sys.path.append('C:/Program Files/QGIS 3.34.10/apps/Python312/Lib/site-packages')
sys.path.append('C:/Users/dpilon/AppData/Roaming/QGIS/QGIS3/profiles/default/python/plugins/cdtk_management_plugin')
sys.path.append('C:/Users/dpilon/AppData/Roaming/QGIS/QGIS3/profiles/default/python/plugins')
os.chdir('C:/Users/dpilon/AppData/Roaming/QGIS/QGIS3/profiles/default/python/plugins/cdtk_management_plugin')
print (sys.executable)


import unittest
from .cdtk_publisher_dialog import CdtkPublisherDialog
from qgis.core import *
from PyQt5 import QtCore, QtGui
from PyQt5.QtGui import *
from PyQt5.QtWidgets import QApplication, QMainWindow, QUndoCommand, QUndoStack, QFileDialog, QVBoxLayout, QAction
from PyQt5.QtWidgets import QAbstractItemView, QMessageBox, QMenu, QInputDialog, QDockWidget

# Import QGIS and other dependencies
from qgis.core import QgsApplication, QgsProject
from qgis.gui import QgsMapCanvas, QgsFileWidget
from qgis.PyQt import QtWidgets
from PyQt5.QtTest import QTest
from PyQt5.QtCore import Qt
from unittest.mock import patch


# Supply path to qgis install location
QgsApplication.setPrefixPath("C:/Program Files/QGIS 3.34.10", True)

# Create a reference to the QgsApplication.  Setting the
# second argument to False disables the GUI.
qgs = QgsApplication([], False)

# Load providers
qgs.initQgis()

# Write your code here to load some layers, use processing
# algorithms, etc.

# Create the main application window
app = QtWidgets.QApplication(sys.argv)
canvas = QgsMapCanvas()
canvas.setWindowTitle("Standalone QGIS Application with Plugin")
canvas.show()

# Load the plugin using QGIS Plugin Manager
plugin_dir = 'C:/Users/dpilon/AppData/Roaming/QGIS/QGIS3/profiles/default/python/plugins'
if plugin_dir not in sys.path:
    sys.path.append(plugin_dir)

from qgis.utils import plugins, loadPlugin, startPlugin

#from qgis.utils import loadPlugin, startPlugin

plugin_name = 'cdtk_management_plugin'


# Dynamically set the __package__ attribute
sys.modules['__main__'].__package__ = plugin_name

# Import the plugin's main class and initialize it

# Instantiate and show the plugin dialog
dialog = CdtkPublisherDialog()
dialog.show()

# Mock the QFileDialog to simulate file selection
mock_in_file_patch = 'C:/Users/dpilon/OneDrive - NRCan RNCan/DATA/CDTK_test/ControlFile.json'
with patch('PyQt5.QtWidgets.QFileDialog.exec_', return_value=QFileDialog.Accepted), \
     patch('PyQt5.QtWidgets.QFileDialog.selectedFiles', return_value=[mock_in_file_patch, 'dummy']):
    
    # Simulate a button click to open the control file
    open_control_file_button = dialog.findChild(QtWidgets.QPushButton, 'open_ctl_file_push_button')
    if open_control_file_button:
        QTest.mouseClick(open_control_file_button, Qt.LeftButton)

# Mock the QFileDialog to simulate file selection
mock_out_file_patch = 'C:/Users/dpilon/OneDrive - NRCan RNCan/DATA/CDTK_test/ControlFileOut.json'
with patch('PyQt5.QtWidgets.QFileDialog.exec_', return_value=QFileDialog.Accepted), \
     patch('PyQt5.QtWidgets.QFileDialog.selectedFiles', return_value=[mock_out_file_patch]), \
     patch('PyQt5.QtWidgets.QMessageBox.exec_', return_value=QMessageBox.Ok):
    
    # Simulate a button click to open the control file
    save_control_file_button = dialog.findChild(QtWidgets.QPushButton, 'save_ctl_file_push_button') 
    if save_control_file_button:
        QTest.mouseClick(save_control_file_button, Qt.LeftButton)

# Start the application event loop
sys.exit(app.exec_())


# Finally, exitQgis() is called to remove the
# provider and layer registries from memory
qgs.exitQgis()