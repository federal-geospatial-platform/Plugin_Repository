
#import requests
#from requests import Response

print (45)