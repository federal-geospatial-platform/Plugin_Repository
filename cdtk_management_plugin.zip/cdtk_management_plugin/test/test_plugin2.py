import sys
import os
from unittest.mock import patch
# Append QGIS Python paths
if os.name == 'nt':
    sys.path.append('C:/Program Files/QGIS 3.34.10/apps/qgis-ltr/python')
    sys.path.append('C:/Program Files/QGIS 3.34.10/apps/Python312/Lib/site-packages')
    sys.path.append('C:/Users/dpilon/AppData/Roaming/QGIS/QGIS3/profiles/default/python/plugins/cdtk_management_plugin')
    sys.path.append('C:/Users/dpilon/AppData/Roaming/QGIS/QGIS3/profiles/default/python/plugins')
    os.chdir(r'c:\test\cdtk_management_plugin\cdtk_management_plugin')
#set PYTHONPATH=%PYTHONPATH%;"C:\Program Files\QGIS 3.34.10\apps\qgis-ltr\python"
#set PYTHONPATH=%PYTHONPATH%;"C:\Program Files\QGIS 3.34.10\apps\Python312\Lib\site-packages"
#set PYTHONPATH=%PYTHONPATH%;"C:\Users\dpilon\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\cdtk_management_plugin"
#set PYTHONPATH=%PYTHONPATH%;"C:\Users\dpilon\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins"
#set PATH=%PATH%;"C:\Users\dpilon\AppData\Roaming\Python\Python312\Scripts"
#
#c:\test\cdtk_management_plugin\cdtk_management_plugin>"
#
#cd "C:\Users\dpilon\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\cdtk_management_plugin"


print("Current Directory:", os.getcwd())
print("System Path:", sys.path)

import unittest
from ..ui_logic.cdtk_publisher_dialog import CdtkPublisherDialog
#from qgis.core import *
#from PyQt5 import QtCore, QtGui
#from PyQt5.QtGui import *
from PyQt5.QtWidgets import QApplication, QFileDialog
from PyQt5.QtWidgets import QMessageBox

# Import QGIS and other dependencies
from qgis.core import QgsApplication, QgsProject
from qgis.gui import QgsMapCanvas, QgsFileWidget
from qgis.PyQt import QtWidgets
from PyQt5.QtTest import QTest
from PyQt5.QtCore import Qt
from unittest.mock import patch
import pytest

def test_simple():


    ## Supply path to qgis install location
    #QgsApplication.setPrefixPath("C:/Program Files/QGIS 3.34.10", True)

    # Create a reference to the QgsApplication.  Setting the
    # second argument to False disables the GUI.
    QgsApplication.setPrefixPath("/usr", True)
    qgs = QgsApplication([], False)

    # Load providers
    qgs.initQgis()

     # Create the main application window
    canvas = QgsMapCanvas()
    canvas.setWindowTitle("Standalone QGIS Application with Plugin")
    canvas.show()

     # Dynamically set the __package__ attribute
    plugin_name = 'cdtk_management_plugin'
    sys.modules['__main__'].__package__ = plugin_name

    # Import the plugin's main class and initialize it

    # Instantiate and show the plugin dialog
    dialog = CdtkPublisherDialog()
    dialog.show()

    # Select input/output files accordint to the os
    if os.name == 'nt':
        mock_in_file_patch = r'C:\test\cdtk_management_plugin\cdtk_management_plugin\test\ControlFile_in1.json'
        mock_out_file_patch = r'C:\test\cdtk_management_plugin\cdtk_management_plugin\test\ControlFile_Out1.json'
    else:
        mock_in_file_patch = r'/builds/geodiscovery-data-team/cdtk/cdtk_management_plugin/cdtk_management_plugin/test/ControlFile_in1.json'
        mock_out_file_patch = r'/builds/geodiscovery-data-team/cdtk/cdtk_management_plugin/cdtk_management_plugin/test/ControlFile_Out1.json'


    with patch.object(CdtkPublisherDialog, 'file_open_dialog', return_value=mock_in_file_patch):
        open_control_file_button = dialog.findChild(QtWidgets.QPushButton, 'open_ctl_file_push_button')
        if open_control_file_button:
            QTest.mouseClick(open_control_file_button, Qt.LeftButton)

    print ('ici')


    if dialog is not None:
        dialog.close()
        if 'dialog' in locals():
            del dialog

    if canvas is not None:
        canvas.close()
        if 'canvas' in locals():
            del canvas

    assert True

    qgs.exitQgis()

def test_simple1():

    os.environ['QT_QPA_PLATFORM'] = 'offscreen'

    ## Supply path to qgis install location
    #QgsApplication.setPrefixPath("C:/Program Files/QGIS 3.34.10", True)

    # Create a reference to the QgsApplication.  Setting the
    # second argument to False disables the GUI.
    QgsApplication.setPrefixPath("/usr", True)
    qgs = QgsApplication([], False)

    # Load providers
    qgs.initQgis()
  
    assert True
    qgs.exitQgis()