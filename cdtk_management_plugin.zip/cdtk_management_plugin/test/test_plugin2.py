import sys
import os
from unittest.mock import patch

# Append QGIS Python paths needed for the import
if os.name == 'nt':
    current_dir = 'C:/test/cdtk_management_plugin/cdtk_management_plugin'  # Directory of the plugin
    sys.path.append('C:/Program Files/QGIS 3.34.10/apps/qgis-ltr/python')
    sys.path.append('C:/Program Files/QGIS 3.34.10/apps/Python312/Lib/site-packages')
    sys.path.append('C:/Users/dpilon/AppData/Roaming/QGIS/QGIS3/profiles/default/python/plugins/cdtk_management_plugin')
    sys.path.append('C:/Users/dpilon/AppData/Roaming/QGIS/QGIS3/profiles/default/python/plugins')

import filecmp
from ..ui_logic.cdtk_publisher_dialog import CdtkPublisherDialog
from PyQt5.QtWidgets import QMessageBox

# Import QGIS and other dependencies
from qgis.core import QgsApplication
from qgis.gui import QgsMapCanvas
from qgis.PyQt import QtWidgets
from PyQt5.QtTest import QTest
from PyQt5.QtCore import Qt, QTimer
import pytest

os.environ["QT_LOGGING_RULES"] = "qt.timers.qbasictimer.debug=false"


@pytest.fixture
def command_line_args(request) -> dict:
    """This method extracts and returns the command line arguments."""
    args = {}
    args['in_file'] = request.config.getoption('--in_file')
    args['out_file'] = request.config.getoption('--out_file')
    return args


def test_ctl_file(command_line_args) -> None:
    """This method tests the OWS functionality of the plugin."""
    in_ctlf_file = command_line_args['in_file']
    out_ctl_file = command_line_args['out_file']
    print("--in_file=", in_ctlf_file)
    print("--out_file=", out_ctl_file)
    exec_standalone_qgis(in_ctlf_file, out_ctl_file)


def exec_standalone_qgis(in_file, out_file) -> None:
    """This method tests the control file open and save functionality of the plugin."""

    # Extract the current directory
    current_dir = os.path.dirname(__file__)

    # Create the full path to the input and output files
    mock_in_file_patch = os.path.join(current_dir, in_file)
    mock_out_file_patch = os.path.join(current_dir, out_file)

    # Check the input file is present and raise error if not present
    if not os.path.exists(mock_in_file_patch):
        print(f"Input file not found: {mock_in_file_patch}")
        assert False

    # Check the output file is not present and raise error if present
    if os.path.exists(mock_out_file_patch):
        print(f"Output file already exists: {mock_out_file_patch}")
        # Delete output file
        os.remove(mock_out_file_patch)

    # Print the input and output file paths
    print(f"Input control file: {mock_in_file_patch}")
    print(f"Output control file: {mock_out_file_patch}")

    # Create a reference to the QgsApplication.  Setting the
    # second argument to False disables the GUI.
    QgsApplication.setPrefixPath("/usr", True)
    qgs = QgsApplication([], False)

    # Load providers
    qgs.initQgis()

    # Create the main application window
    canvas = QgsMapCanvas()
    canvas.setWindowTitle("Standalone QGIS Application with Plugin")
    canvas.show()

    # Dynamically set the __package__ attribute
    plugin_name = 'cdtk_management_plugin'
    sys.modules['__main__'].__package__ = plugin_name

    # Import the plugin's main class and initialize it

    # Instantiate and show the plugin dialog
    dialog = CdtkPublisherDialog()
    dialog.setAttribute(Qt.WA_DeleteOnClose)  # Disable ennoying message during garbage collection
    dialog.show()

    with patch.object(QTimer, 'start', lambda x, y=None: None):

        # Mock the file CdtkPublisherDialog.file_open_dialog method by passing the name of the control_file
        # I was unable to QTest the real file dialog; it was causing thread errors in the GitLab CI/CD process
        with patch.object(CdtkPublisherDialog, 'file_open_dialog', return_value=mock_in_file_patch):
            open_control_file_button = dialog.findChild(QtWidgets.QPushButton, 'open_ctl_file_push_button')
            if open_control_file_button:
                QTest.mouseClick(open_control_file_button, Qt.LeftButton)

        # Mock the file CdtkPublisherDialog.file_save_dialog method by passing the name of the control_file
        # Mock also the QMessageBox dialog
        # I was unable to QTest the real file dialog; it was causing thread errors in the GitLab CI/CD process
        with patch.object(CdtkPublisherDialog, 'file_save_dialog', return_value=mock_out_file_patch), \
             patch('PyQt5.QtWidgets.QMessageBox.exec_', return_value=QMessageBox.Ok):
            save_control_file_button = dialog.findChild(QtWidgets.QPushButton, 'save_ctl_file_push_button')
            print("save_control_file_button:", save_control_file_button)
            if save_control_file_button:
                QTest.mouseClick(save_control_file_button, Qt.LeftButton)

    # Compare the input/output file  they must have the  same content
    if filecmp.cmp(mock_in_file_patch, mock_out_file_patch):
        assert True
    else:
        assert False

    # Clean up to prevent thread and garbage collection errors in the CI/CD
    # Close the dialog
    if dialog is not None:
        dialog.close()
        if 'dialog' in locals():
            del dialog

    # Close the Canvas
    if canvas is not None:
        canvas.close()
        if 'canvas' in locals():
            del canvas

    # Exit QGIS
    qgs.exitQgis()

