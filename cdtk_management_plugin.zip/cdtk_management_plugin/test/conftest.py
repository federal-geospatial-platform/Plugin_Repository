"""
Configuration file for the house parameter to pytest
    Two parameters are configures
          --in_file: Input control file
          --out_file: Output control file
    """


def pytest_addoption(parser):
    parser.addoption('--in_file', action='store', default='', help='Input control file')
    parser.addoption('--out_file', action='store', default='', help='Input control file')
