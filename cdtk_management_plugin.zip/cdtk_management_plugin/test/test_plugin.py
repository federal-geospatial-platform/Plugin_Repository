import sys
import os
from unittest.mock import patch
# Append QGIS Python paths
if os.name == 'nt':
    # Some setup to run on windows
    sys.path.append('C:/Program Files/QGIS 3.34.10/apps/qgis-ltr/python')
    sys.path.append('C:/Program Files/QGIS 3.34.10/apps/Python312/Lib/site-packages')
    sys.path.append('C:/Users/dpilon/AppData/Roaming/QGIS/QGIS3/profiles/default/python/plugins/cdtk_management_plugin')
    sys.path.append('C:/Users/dpilon/AppData/Roaming/QGIS/QGIS3/profiles/default/python/plugins')
    sys.path.append('C:/Users/dpilon/AppData/Roaming/Python/Python312/Scripts')
    os.chdir('C:/test/cdtk_management_plugin/cdtk_management_plugin')

print("Current Directory:", os.getcwd())
print("System Path:", sys.path)

import filecmp
from ..ui_logic.cdtk_publisher_dialog import CdtkPublisherDialog
from PyQt5.QtWidgets import QFileDialog
from PyQt5.QtWidgets import QMessageBox

# Import QGIS and other dependencies
from qgis.core import QgsApplication
from qgis.gui import QgsMapCanvas
from qgis.PyQt import QtWidgets
from PyQt5.QtTest import QTest
from PyQt5.QtCore import Qt


def test_simple():

    ## Supply path to qgis install location

    # Create a reference to the QgsApplication.  Setting the
    # second argument to False disables the GUI.
    qgs = QgsApplication([], False)

    # Load providers
    qgs.initQgis()

    # Write your code here to load some layers, use processing
    # algorithms, etc.

    # Create the main application window
    canvas = QgsMapCanvas()
    canvas.setWindowTitle("Standalone QGIS Application with Plugin")
    canvas.show()

    # Dynamically set the __package__ attribute
    plugin_name = 'cdtk_management_plugin'
    sys.modules['__main__'].__package__ = plugin_name

    # Import the plugin's main class and initialize it

    # Instantiate and show the plugin dialog
    dialog = CdtkPublisherDialog()
    dialog.show()

    # Select input/output files accordint to the os
    if os.name == 'nt':
        mock_in_file_patch = r'C:\test\cdtk_management_plugin\cdtk_management_plugin\test\ControlFile_in1.json'
        mock_out_file_patch = r'C:\test\cdtk_management_plugin\cdtk_management_plugin\test\ControlFile_Out1.json'
    else:
        mock_in_file_patch = r'/builds/geodiscovery-data-team/cdtk/cdtk_management_plugin/cdtk_management_plugin/test/ControlFile_in1.json'
        mock_out_file_patch = r'/builds/geodiscovery-data-team/cdtk/cdtk_management_plugin/cdtk_management_plugin/test/ControlFile_Out1.json'


    # Mock the QFileDialog to simulate file open selection
    with patch('PyQt5.QtWidgets.QFileDialog.exec_', return_value=QFileDialog.Accepted), \
         patch('PyQt5.QtWidgets.QFileDialog.selectedFiles', return_value=[mock_in_file_patch, 'dummy']):

        # Simulate a button click to open the control file
        open_control_file_button = dialog.findChild(QtWidgets.QPushButton, 'open_ctl_file_push_button')
        if open_control_file_button:
            QTest.mouseClick(open_control_file_button, Qt.LeftButton)

    # Mock the QFileDialog to simulate file save selection
    with patch('PyQt5.QtWidgets.QFileDialog.exec_', return_value=QFileDialog.Accepted), \
         patch('PyQt5.QtWidgets.QFileDialog.selectedFiles', return_value=[mock_out_file_patch]), \
         patch('PyQt5.QtWidgets.QMessageBox.exec_', return_value=QMessageBox.Ok):

        # Simulate a button click to open the control file
        save_control_file_button = dialog.findChild(QtWidgets.QPushButton, 'save_ctl_file_push_button')
        if save_control_file_button:
            QTest.mouseClick(save_control_file_button, Qt.LeftButton)

    # Compare the two file  they must have the  same content
    if filecmp.cmp(mock_in_file_patch, mock_out_file_patch):
        assert True
    else:
        assert False

    if dialog is not None:
        dialog.close()
        if 'dialog' in locals():
            del dialog


    if canvas is not None:
        canvas.close()
        if 'canvas' in locals():
            del canvas

    # Finally, exitQgis() is called to remove the
    # provider and layer registries from memory
    qgs.exitQgis()
