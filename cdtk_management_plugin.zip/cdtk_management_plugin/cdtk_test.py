

from .cdtk_publisher_dialog import CdtkPublisherDialog


class TestCdtkPublisherDialog(unittest.TestCase):
    def setUp(self):
        """Set up the test environment before each test."""
        self.app = QtWidgets.QApplication([])
        self.dialog = CdtkPublisherDialog()

    def tearDown(self):
        """Clean up the test environment after each test."""
        self.dialog = None
        self.app = None

    def test_initial_state(self):
        """Test the initial state of the dialog."""
        self.assertEqual(self.dialog.params, None)

    def test_set_params(self):
        """Test setting parameters in the dialog."""
        params = {'key': 'value'}
        self.dialog.params = params
        self.assertEqual(self.dialog.params, params)

    def test_click_ok_button(self):
        """Test clicking the OK button."""
        ok_button = self.dialog.button_box.button(QtWidgets.QDialogButtonBox.Ok)
        QTest.mouseClick(ok_button, Qt.LeftButton)
        self.assertTrue(self.dialog.result(), QtWidgets.QDialog.Accepted)

    def test_click_cancel_button(self):
        """Test clicking the Cancel button."""
        cancel_button = self.dialog.button_box.button(QtWidgets.QDialogButtonBox.Cancel)
        QTest.mouseClick(cancel_button, Qt.LeftButton)
        self.assertTrue(self.dialog.result(), QtWidgets.QDialog.Rejected)

if __name__ == '__main__':
    unittest.main()