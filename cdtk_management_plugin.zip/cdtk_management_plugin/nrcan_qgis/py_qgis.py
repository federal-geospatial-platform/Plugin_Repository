# System imports
import os
from datetime import datetime

from psycopg2._psycopg import connection, cursor
import processing # type: ignore
from processing.core.Processing import Processing # type: ignore
from osgeo import ogr

# QGIS imports
from qgis.core import Qgis, QgsApplication, QgsProject, QgsProviderRegistry # type: ignore
from qgis.core import QgsVectorLayer, QgsLayerTree, QgsProjectVersion # type: ignore
from qgis.PyQt.QtXml import QDomDocument # type: ignore
from qgis.PyQt.QtCore import QFile, QIODevice # type: ignore

# Application imports
from db import db_connection
from lib.progress_marks import *
from lib.exceptions import *


def get_version():
    """
    Gets the QGIS Version
    """

    return QgsProjectVersion(Qgis.QGIS_VERSION)


def compare_version(version1: QgsProjectVersion, version2: QgsProjectVersion) -> int:
    if version1.majorVersion() < version2.majorVersion():
        return -1

    elif version1.majorVersion() == version2.majorVersion():
        if version1.minorVersion() < version2.minorVersion():
            return -1

        elif version1.minorVersion() == version2.minorVersion():
            return 0 # Subversion should be fine, considering it valid.

        else:
            return 1
    else:
        return 1


def get_geometry_type_string(geometry_type: int) -> str:
    if geometry_type == 2:
        return "Polygon"
    elif geometry_type == 1:
        return "Line"
    elif geometry_type == 0:
        return "Point"
    else:
        return "Unknown geometry"


def _format_crs_epsg(crs_authid: str) -> str:
    """
    Helper function to format the crs (EPSG) to a short number
    """

    return crs_authid.replace("EPSG:","").strip()


class PyQgis(object):
    """
    A PyQGIS management class
    """

    def __init__(self, qgis_install_path: str) -> None:
        """
        Constructor

        :param qgis_install_path: The path to QGIS install
        """

        self.progress_marks: list[QGISProgressMark] = []
        self.qgis_project_id: str | None
        self.qgis_project_id_short: str | None
        self.qgis_project_lang: str | None
        self.qgis_db_host: str | None
        self.qgis_db_port: int | None
        self.qgis_db_name: str | None
        self.qgis_db_user: str | None
        self.qgis_db_password: str | None
        self.qgis_app_reference = QgsApplication([], False)
        self.set_qgis_path = QgsApplication.setPrefixPath(qgis_install_path, True)
        self.init_qgis = self.qgis_app_reference.initQgis()

        # Add to progress mark
        self.progress_marks = [ProgressMarkInitialized(datetime.now(), get_version().text())]


    def close(self) -> None:
        """
        Exits a QgsApplication
        """

        # Exit QGIS
        self.qgis_app_reference.exitQgis()


    def init_project_from_file(self, qgis_project_file: str) -> None:
        """
        Initializes a QGIS project from the file path;
        for the functions in this class that require project connectivity.

        :param qgis_project_file: The path to the QGIS project file
        """

        # Keep track
        self.progress_marks.append(ProgressMarkInitializingProjectFromFile(datetime.now(), qgis_project_file))

        # QGIS props
        self.project = QgsProject.instance()
        read_success = self.project.read(qgis_project_file)

        # If failed to read the project
        self.qgis_project_id = None
        if read_success:
            # Initialized
            self.qgis_project_id = os.path.basename(qgis_project_file).split(".")[0]
            self.qgis_project_id_short = self.qgis_project_id
            self.qgis_project_lang = "en"
            if self.qgis_project_id.endswith("_en") or self.qgis_project_id.endswith("-en"):
                self.qgis_project_id_short = self.qgis_project_id[:-3]

            elif self.qgis_project_id.endswith("_fr") or self.qgis_project_id.endswith("-fr"):
                self.qgis_project_id_short = self.qgis_project_id[:-3]
                self.qgis_project_lang = "fr"

            # Keep track
            self.progress_marks.append(ProgressMarkInitializedProject(datetime.now()))

        else:
            self.project = None
            raise ProjectNotFoundFromFile(qgis_project_file)


    def init_project_from_db(self, qgis_project_id: str) -> None:
        """
        Initializes a QGIS project from the database;
        for the functions in this class that require project connectivity.

        :param qgis_project_id: The project id as stored in the database
        """

        # Keep track
        self.progress_marks.append(ProgressMarkInitializingProjectFromDatabase(datetime.now(), qgis_project_id))

        # If the database has been initialized
        if self.qgis_db and self.qgis_db.schema:
            # QGIS props
            self.project = QgsProject.instance()
            read_success = self.project.read(self.qgis_db.gen_uri_project(qgis_project_id))

            # If failed to read the project
            self.qgis_project_id = None
            if read_success:
                # Initialized
                self.qgis_project_id = qgis_project_id
                self.qgis_project_id_short = self.qgis_project_id
                self.qgis_project_lang = "en"
                if self.qgis_project_id.endswith("_en") or self.qgis_project_id.endswith("-en"):
                    self.qgis_project_id_short = self.qgis_project_id[:-3]

                elif self.qgis_project_id.endswith("_fr") or self.qgis_project_id.endswith("-fr"):
                    self.qgis_project_id_short = self.qgis_project_id[:-3]
                    self.qgis_project_lang = "fr"

                # Keep track
                self.progress_marks.append(ProgressMarkInitializedProject(datetime.now()))

            else:
                self.project = None
                raise ProjectNotFoundFromDatabase(qgis_project_id, self.qgis_db.schema)

        else:
            # Throws
            raise DatabaseNotInitialized("init_project_from_db")


    def init_database(self, qgis_db_host: str, qgis_db_port: int, qgis_db_name: str, qgis_db_user: str, qgis_db_password: str) -> None:
        """
        Initializes the database parameters for the functions in this class
        that require database connectivity.

        :param qgis_db_host: The Database host server
        :param qgis_db_port: The Database port
        :param qgis_db_name: The Database name
        :param qgis_db_user: The Database username
        :param qgis_db_password: The Database password
        :param qgis_db_ssl_mode: True if the Database is to be connected in SSL mode
        """

        # Create database connection
        self.qgis_db = db_connection.PyDB(qgis_db_host, qgis_db_port, qgis_db_name, qgis_db_user, qgis_db_password)

        # Keep a copy of the credentials if an alternative connection access to the database is needed
        self.qgis_db_host = qgis_db_host
        self.qgis_db_port = qgis_db_port
        self.qgis_db_name = qgis_db_name
        self.qgis_db_user = qgis_db_user
        self.qgis_db_password = qgis_db_password

        # Mark progression
        self.progress_marks.append(ProgressMarkInitializedDatabase(datetime.now(), qgis_db_host, qgis_db_name))


    def init_schema(self, qgis_db_schema: str) -> None:
        """
        Initializes the database schema for the functions in this class
        that require a database schema.

        :param qgis_db_schema: The database schema
        """

        # If the database has been initialized
        if self.qgis_db:
            # Validate the schema exists in the database
            self.qgis_db.init_schema(qgis_db_schema)

            # All good
            self.progress_marks.append(ProgressMarkInitializedSchema(datetime.now(), qgis_db_schema))

        else:
            # Throws
            raise DatabaseNotInitialized("init_schema")


    def get_projects_in_db(self):
        """
        Gets the list of projects as stored in the QGIS repository for the active schema
        """

        # Get the uri
        uri: str = self.qgis_db.gen_uri_storage_schema()

        # Get the storage
        storage = QgsApplication.projectStorageRegistry().projectStorageFromUri(uri)

        # If found
        if storage:
            # Return the list of projects
            return storage.listProjects(uri)

        else:
            # Throws
            raise StorageNotFound(self.qgis_project_id, uri)


    def project_exists_in_db(self, qgis_project_id: str) -> bool:
        """
        Checks if the given project exists in the QGIS repository
        """

        # If the project exists
        return qgis_project_id in self.get_projects_in_db()


    def get_dom_document(self) -> Any | None:
        # If the valid is defined
        if self.project:
            # Open the QGS file
            f: Any = None
            try:
                f = QFile(self.project.fileInfo().absoluteFilePath())
                f.open(QIODevice.ReadOnly)

                doc = QDomDocument()
                doc.setContent(f.readAll())
                return doc

            except Exception as err:
                print(str(err))
                pass # Skip

            finally:
                if f:
                    f.close()

        return None


    def get_dom_document_qgis_node(self) -> Any | None:
        # Get the doc
        doc: Any | None = self.get_dom_document()

        # If defined
        if doc:
            # Open the QGS file
            node = doc.elementsByTagName("qgis").item(0)
            return node


    def get_crs(self) -> str:
        """
        Gets the CRS of the main dataframe
        """

        # If the project has been initialized
        if self.project:
            return _format_crs_epsg(self.project.crs().authid())

        else:
            # Throws
            raise ProjectNotInitialized("get_crs")


    def get_layers_in_order(self) -> list[Any]:
        """
        Helper function to get the layers list in order.
        """

        layers: list[Any] = []
        if self.project:
            self._get_layers_all_rec(layers, self.project.layerTreeRoot())
        return layers


    def get_group_layers_all(self, include_root_node: bool = False) -> list[Any]:
        """
        Recursively get all group layers in the project and return a list.
        """

        layers: list[Any] = []
        if self.project:
            # For each layer at the tree
            self._get_group_layers_all_rec(layers, self.project.layerTreeRoot(), include_root_node)
        return layers


    def _get_group_layers_all_rec(self, results: list, layer, include_root_node: bool = False) -> None:
        """
        Recursive function to get all the group layers in the QGIS table of contents
        """

        # If the layer is a group
        if QgsLayerTree.isGroup(layer):
            # If root node and we want root node
            if isinstance(layer, QgsLayerTree):
                if include_root_node:
                    # Keep the group layer
                    results.append(layer)

            else:
                # Keep the group layer
                results.append(layer)

            # For each child
            for c in layer.children():
                self._get_group_layers_all_rec(results, c)


    def _get_layers_all_rec(self, results: list, layer) -> None:
        """
        Recursive function to get all the layers in the QGIS table of contents
        """

        # If the layer is a group
        if QgsLayerTree.isGroup(layer):
            # For each child
            for c in layer.children():
                self._get_layers_all_rec(results, c)

        else:
            results.append(layer.layer())


    def get_layers_in_database(self, valid_only: bool) -> list[Any]:
        """
        Helper function to get the layers pointing to our database in order.
        """

        # Redirect
        layers: list[Any] = self.get_layers_in_order()

        # Filter
        return list(filter(lambda l: self.get_layer_is_database(l, valid_only), layers))


    def get_layer_properties(self, layer) -> Any:
        """
        Helper function to get the layer properties.
        """

        return QgsProviderRegistry.instance().decodeUri(layer.providerType(), layer.dataProvider().dataSourceUri())


    def get_layers_from_gpkg(self, gpkg_file) -> list[str]:
        """Get the list of layer names in a GeoPackage file"""

        layer_names: list[str] = []

        # Open the GeoPackage
        try:
            geopackage = ogr.Open(gpkg_file)

            if geopackage is None:
                raise UnableAccessGpkg(gpkg_file)
            else:
                # Get number of layers
                num_layers = geopackage.GetLayerCount()

                # Iterate over each layer and extract their name
                for i in range(num_layers):
                    layer = geopackage.GetLayerByIndex(i)
                    layer_names.append(layer.GetName())

                self.progress_marks.append(ProgressMarkReadTablesGpkg(datetime.now(), gpkg_file))

        except Exception as exc:
            raise UnableAccessGpkg(gpkg_file) from exc

        return layer_names

    def copy_gpkg_tables_to_postgis(self, schema_name: str, gpkg_file: str, gpkg_table_name: str, gpkg_to_db_table_name: str) -> None:
        """Copy the Geopackage table to the database using QGIS GDAL tool with the processing toolbox"""

        # Initialize the processing tool
        Processing.initialize()

        # The input file
        input_file: str = f"{gpkg_file}|layername={gpkg_table_name}"

        try:
            # Copy the GeoPackage table to PostGis database
            processing.run("gdal:importvectorintopostgisdatabasenewconnection",
                            {'INPUT': input_file,
                                'SHAPE_ENCODING':'',
                                'GTYPE':0,
                                'A_SRS':None,
                                'T_SRS':None,
                                'S_SRS':None,
                                'HOST': self.qgis_db_host,
                                'PORT': self.qgis_db_port,
                                'USER': self.qgis_db_user,
                                'DBNAME': self.qgis_db_name,
                                'PASSWORD': self.qgis_db_password,
                                'SCHEMA':schema_name,
                                'TABLE': gpkg_to_db_table_name,
                                'PK':'id',
                                'PRIMARY_KEY':'',
                                'GEOCOLUMN':'geom',  # TODO:`Check if 'geom` needs to be parameterized
                                'DIM':0,
                                'SIMPLIFY':'',
                                'SEGMENTIZE':'',
                                'SPAT':None,
                                'CLIP':False,
                                'FIELDS':[],
                                'WHERE':'',
                                'GT':'',
                                'OVERWRITE':False,
                                'APPEND':False,
                                'ADDFIELDS':False,
                                'LAUNDER': True,
                                'INDEX':False,
                                'SKIPFAILURES':False,
                                'PROMOTETOMULTI':False,
                                'PRECISION':True,
                                'OPTIONS':''
                            }
                        )

        except Exception as exc:
            raise UnableCopyGpkgTable(input_file, schema_name, gpkg_to_db_table_name) from exc

        # Get the list of layers from the PostGis database
        db_table_names = self.get_layers_from_db(schema_name)
        if gpkg_to_db_table_name in db_table_names:
            self.progress_marks.append(ProgressMarkTableAdded(datetime.now(), schema_name, gpkg_to_db_table_name))
        else:
            raise UnableCopyGpkgTable(input_file, schema_name, gpkg_to_db_table_name)

        return


    def get_layer_is_geopackage(self, layer) -> bool:
        """
        Helper function to check if the layer points to a geopackage.
        """

        # First of all, check if the data provider and layer type is valid
        if layer.dataProvider().isValid() and isinstance(layer, QgsVectorLayer):
            # Get the layer properties
            props = self.get_layer_properties(layer)

            # Return if there's a path and if the path ends with a geopackage file
            return 'path' in props and props['path'].endswith("gpkg")

        # Not a geopackage
        return False


    def get_layer_is_geopackage_in_same_folder(self, layer) -> bool:
        """
        Helper function to check if the layer points to a geopackage that's in the same folder as the project.
        """

        # First of all, check if geopackage
        if self.project and self.get_layer_is_geopackage(layer):
            # Get the layer properties
            props = self.get_layer_properties(layer)

            # Return if geopackage path is same folder as project
            return self.project.readPath("./").lower() == os.path.dirname(props['path']).lower()

        # Not a geopackage
        return False


    def get_layer_id_field_names(self, layer) -> list[str]:
        # For each index
        names: list[str] = []
        for i in layer.primaryKeyAttributes():
            names.append(layer.fields()[i].name())
        return names


    def get_layers_from_db(self, schema_name) -> list[tuple[Any, ...]]:
        """Get the name of the layers (table names) in the DB for a specific schema"""

        # Create a cursor
        db_conn: connection = self.qgis_db.open_conn()  # Open connection to the DB
        cur: cursor = db_conn.cursor()  # Get a cursor

        # Execute SQL query to fetch table names for the specified schema
        cur.execute(f"SELECT tablename FROM pg_catalog.pg_tables WHERE schemaname = '{schema_name}'")

        # Fetch all results
        table_names: list[tuple[Any, ...]] = cur.fetchall()

        # Extract a list of string from a list of tuples
        table_names = [table_name[0] for table_name in table_names]

        # Close the cursor and connection
        cur.close()

        self.progress_marks.append(ProgressMarkReadTablesDatabase(datetime.now(), schema_name))

        return table_names


    def get_layer_is_database(self, layer, valid_only: bool) -> bool:
        # First of all, check if the data provider and layer type is valid
        if isinstance(layer, QgsVectorLayer) and \
          (not valid_only or valid_only and layer.dataProvider().isValid()):
            # Get the layer properties
            props = self.get_layer_properties(layer)

            # Return if there's a path and if the path ends with a geopackage file
            return 'table' in props and 'schema' in props and props['schema']

        # Not
        return False


    def save_project_in_db(self) -> None:
        """
        Saves the project in the database
        """

        # If valid name
        if self.qgis_project_id:
            # Redirect
            self.save_project_in_db_as(self.qgis_project_id)

        else:
            raise ProjectNotInitialized("save_project_in_db")


    def save_project_in_db_as(self, project_id: str) -> bool:
        """
        Saves the project in the database with the given name
        """

        # If the project has been initialized
        if self.project:
            # Keep track
            self.progress_marks.append(ProgressMarkSavingProject(datetime.now(), project_id))

            # Generate the uri
            uri: str = self.qgis_db.gen_uri_project(project_id)

            # Save the QGIS project in database
            saved = self.project.write(uri)

            if saved:
                print(f">>The QGIS Project '{project_id}' has been saved in the database.")
                return True

            else:
                # Throws
                raise FailedSaveQgisProject(project_id)

        else:
            # Throws
            raise ProjectNotInitialized("save_project_in_db_as")


    def copy_project(self, copy_name: str) -> None:
        # If valid
        if self.qgis_db.schema:
            if self.project_exists_in_db(copy_name):
                self.delete_project_from_db_as(self.qgis_db.schema, copy_name)
            self.save_project_in_db_as(copy_name)

        else:
            raise DatabaseNotInitialized("copy_project")


    def delete_project_from_db(self) -> None:
        """
        Deletes the project from the database
        """

        # If valid
        if self.qgis_db.schema and self.qgis_project_id:
            # Redirect
            self.delete_project_from_db_as(self.qgis_db.schema, self.qgis_project_id)

        else:
            raise ProjectNotInitialized("delete_project_from_db")


    def delete_project_from_db_as(self, schema: str, project_id: str) -> bool:
        """
        Deletes the project from the database
        """

        # If the project has been initialized
        if self.project:
            # Keep track
            self.progress_marks.append(ProgressMarkDeletingProject(datetime.now(), project_id))

            # Generate the uri
            uri: str = self.qgis_db.gen_uri_project(project_id)

            # Get the storage
            storage = QgsApplication.projectStorageRegistry().projectStorageFromUri(uri)

            # If found
            if storage:
                # If the project exists
                if project_id in storage.listProjects(uri):
                    # Delete the QGIS project from database
                    deleted = storage.removeProject(uri)

                    if deleted:
                        print(f">>The QGIS Project '{project_id}' has been deleted.")
                        return True

                    else:
                        # Throws
                        raise FailedDeleteQgisProject(project_id)

                else:
                    # Throws
                    raise ProjectNotFoundFromDatabase(project_id, schema)

            else:
                # Throws
                raise StorageNotFound(project_id, uri)

        else:
            # Throws
            raise ProjectNotInitialized("delete_project_from_db_as")


    # def get_layer_styles(self, layer):

    #     print("yoyo")
    #     print(QgsProviderRegistry.instance().providerList())

    #     # Get the layer styles using the layer
    #     [count, style_ids, style_names, style_descs, error] = layer.listStylesInDatabase()
    #     print(f"--> 1) Styles using layer: {style_names}")

    #     # This is what we want, but we want to list the styles using the QgsProviderRegistry instead of from a layer.
    #     # So after reading the C++ code inside listStylesInDatabase we try to replicate it
    #     style_ids = []   #reset
    #     style_names = [] #reset
    #     style_descs = [] #reset
    #     error = ""       #reset
    #     QgsProviderRegistry.instance().listStyles(layer.dataProvider().name(),
    #                                               layer.dataProvider().dataSourceUri(),
    #                                               style_ids, style_names, style_descs, error)

    #     print(f"--> 2) Styles using provider registry: {style_names}")

    #     return style_names


    def layer_style_exists_in_db(self, layer, style_name: str) -> bool:
        """
        Gets if the layer style for the layer exists in the database
        """

        # Export the layer named style
        #documentNamedStyle = QDomDocument()
        #layer.exportNamedStyle(documentNamedStyle)

        # Export the layer SLD style
        #documentSLDStyle = QDomDocument()
        #layer.exportSldStyle(documentSLDStyle, "")

        # Generate the uri
        #uri_specific = self.qgis_db.gen_uri_data_source(self.qgis_db.schema, table_name, geom_type)

        # success = QgsProviderRegistry.instance().saveStyle(DATA_PROVIDER_KEY, uri_specific,
        #                                                    documentNamedStyle.toString(), documentSLDStyle.toString(),
        #                                                    style_name, f"Default style for {layer.name()}", "", True, "")

        # Fetch the styles
        [count, style_ids, style_names, style_descs, error] = layer.listStylesInDatabase()

        # Return if the style exists in the database
        return style_name in style_names


    def save_layer_style_in_database(self, layer, style_name: str) -> None:
        """
        Saves the layer style to Postgres DB
        """

        # Fetch the styles
        #[count, style_ids, style_names, style_descs, error] = layer.listStylesInDatabase()

        # Save it
        layer.saveStyleToDatabase(style_name, "", True, "")

        # Update the record in layer_styles to set the type
        # (I couldn't find a way to do it with PyQGIS SDK)
        self.qgis_db.save_layer_style_finalize(style_name, get_geometry_type_string(layer.geometryType()))

        # Print
        print(f">>Style '{style_name}' has been saved in the database")


    def delete_layer_style_from_db(self, layer, style_name: str) -> None:
        """
        Deletes the layer style from CDTK Postgres DB
        """

        # Fetch the styles
        [count, style_ids, style_names, style_descs, error] = layer.listStylesInDatabase()

        # Get the style id from the name (if exists)
        if style_name in style_names:
            # Delete the style (replacing it and we don't want the pop up window)
            layer.deleteStyleFromDatabase(style_ids[style_names.index(style_name)])
            print(f">>Style '{style_name}' has been deleted from the Database")

        else:
            print(f">>Style '{style_name}' not found in Database, skip")
            pass  # No need, style doesn't exist

