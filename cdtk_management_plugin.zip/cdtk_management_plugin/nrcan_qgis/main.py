"""
This is the CDTK PyQGIS launcher which offers methods to work with PyQGIS library in a stand-alone fashion (on the main thread due to a PyQGIS limitation!).
"""

# Core modules
import sys, os, getopt, json
from datetime import datetime
import cdtk_qgis, config, py_qgis as PY_QGIS
from lib.progress_marks import *
from lib.warnings import *
from lib.exceptions import *


# The PyQGIS instance which is closed automatically in the end of the __main__
py_qgis = cdtk_qgis.CdtkPyQgis("/usr")


def info_schema(schema: str):
    """
    Gets the information on the project
    """

    # Load the schema
    py_qgis.init_schema(schema)

    # Return the projects in the database for the initialized schema
    return py_qgis.get_projects_in_db()


def info_service(service_name: str, schema: str):
    """
    Gets the information on the project
    """

    # Load the schema and project
    py_qgis.init_schema(schema)
    py_qgis.init_project_from_db(service_name)

    # Build the validation results object
    return py_qgis.get_info_project()


def compare(project_file: str, schema: str):
    """
    Compares the provided project ('new') with the one stored in the database ('existing') (if any)
    """

    # Load the schema and project
    py_qgis.init_schema(schema)
    py_qgis.init_project_from_file(config.QGIS_PROJECTS_PATH(_read_param_proj_path(), project_file))

    # Build the validation results object
    res = {}
    res['new'] = py_qgis.get_info_project()

    existing = None
    if py_qgis.qgis_project_id and py_qgis.project_exists_in_db(py_qgis.qgis_project_id):
        # Load the project from the database
        py_qgis.init_project_from_db(py_qgis.qgis_project_id)
        existing = py_qgis.get_info_project()

    # Report the information from the existing project
    res['existing'] = existing

    # Done
    return res


def validate_all(operation: cdtk_qgis.OperationMode, control_file: dict, warnings: list):

    # The errors
    errors = []

    # For each service parameters, validate them all first
    val_results = []
    for sp in [control_file['ows_service_parameters']['english'], control_file['ows_service_parameters']['french']]:
        res = validate(operation, control_file, sp['project_filename'], control_file['department'], 2, warnings, errors)
        val_results.append(res)

    # Done comparing projects individually. Now compare the projects between themselves.
    validate_between(val_results, errors)

    # If any errors
    if len(errors):
        raise QGISAggregationException(errors)

    return val_results


def validate(operation: cdtk_qgis.OperationMode, control_file: dict, project_file: str, schema: str, nb_projects: int, warnings: list, errors: list):

    # Load the schema and project
    py_qgis.init_schema(schema)
    py_qgis.init_project_from_file(config.QGIS_PROJECTS_PATH(_read_param_proj_path(), project_file))

    # Validate the project
    return py_qgis.validate_project(operation, False, config.SUPPORTED_EPSG_CRS, nb_projects, warnings, errors)


def validate_between(val_results: list, errors: list):
    # Check for same number of layers in each project

    # If 2 projects to begin with (English/French)
    if len(val_results) == 2:
        # If different number of layers total
        if len(val_results[0]) != len(val_results[1]):
            errors.append(ProjectsDifferentLayersCount(len(val_results[0]), len(val_results[1])))
            return

        # Get the list of table names (the short names)
        table_names_en = [f['name_table'] for f in val_results[0]]

        # Get the list of table names (the short names)
        table_names_fr = [f['name_table'] for f in val_results[1]]

        # For each Englsh vector geopackage layer
        for layer_en in val_results[0]:
            # Check if the short name doesn't exist in the French project
            if not (layer_en['name_table'] in table_names_fr):
                errors.append(ProjectsShortNameNotFound(layer_en['name'], layer_en['name_table']))

        # For each French vector geopackage layer
        for layer_fr in val_results[1]:
            # Check if the short name doesn't exist in the English project
            if not (layer_fr['name_table'] in table_names_en):
                errors.append(ProjectsShortNameNotFound(layer_fr['name'], layer_fr['name_table']))


def publish(project_file: str, schema: str):
    """
    Publishers the project as a service
    """

    # Load the schema and project
    py_qgis.init_schema(schema)
    py_qgis.init_project_from_file(config.QGIS_PROJECTS_PATH(_read_param_proj_path(), project_file))

    # The warnings/errors
    warnings = []
    errors = []

    # Validate the project
    py_qgis.validate_project(False, config.SUPPORTED_EPSG_CRS, True, 1, warnings, errors)

    # If any errors
    if len(errors):
        raise QGISAggregationException(errors)

    # Normalize the project
    py_qgis.normalize_project()

    layers_saved = []
    try:
        # Save the styles in the database
        py_qgis.save_layer_styles_in_db(layers_saved)

        # Save the project in the database
        py_qgis.save_project_in_db()

    except Exception as err:
        # Something bad happened, revert any/all layer styles
        for l in layers_saved:
            py_qgis.delete_layer_style_from_db(l)
        raise

    # Return the layer status
    return py_qgis.get_info_project(admin_mode=False)


def oapi_delete_publish(control_file: dict):
    """
    Delete the non referenced tables of an OAPI publication
    """

    collections = control_file['oapi_service_parameters']['collections']

    # Connect to the database
    with py_qgis.qgis_db.open_conn() as conn:
        # Open a cursor
        with conn.cursor() as cur:
            # Loop over each collection
            for collection in collections:
                feature_postgres = collection['provider_feature_postgres']

                if feature_postgres and feature_postgres['feature_name_dict']['to_delete'] == 'True':
                    schema_name = feature_postgres['schema_name']
                    db_table_name = feature_postgres['feature_name_dict']['db_table_name']

                    # Remove the table
                    py_qgis.qgis_db.drop_table_go(cur, schema_name, db_table_name)
                    conn.commit()  # Commit the drop table
                    py_qgis.progress_marks.append(ProgressMarkTableDropped(datetime.now(), schema_name, db_table_name))

    return

def oapi_export_publish(control_file: dict):
    """
    Exports and publishes the OAPI feature service
    """

    collections = control_file['oapi_service_parameters']['collections']
    # Extract some information from the collections
    for collection in collections:
        feature_postgres = collection['provider_feature_postgres']
        if feature_postgres:
            schema_name = feature_postgres['schema_name']
            feature_type = feature_postgres['feature_name_dict']['type']

            if feature_type == "gpkg":

                # Extract someinformation
                gpkg_file = feature_postgres['feature_name_dict']['file_name']
                gpkg_table_name = feature_postgres['feature_name_dict']['table_name']

                # Transform the name of the gpkg tables into database table name
                db_table_name = feature_postgres['feature_name_dict']['db_table_name']

                # Get the list of layers from the PostGis database
                db_table_names = py_qgis.get_layers_from_db(schema_name)

                # Get the list of layers from the GeoPackage file
                gpkg_table_names = py_qgis.get_layers_from_gpkg(gpkg_file)

                # Verify the the control file table is in the GeoPackage file
                if gpkg_table_name not in gpkg_table_names:
                    raise TableMissingInGpkg(gpkg_table_name, gpkg_file)

                # Verify that the layer to copy are not in the db
                if db_table_name in db_table_names:
                    raise TableAlreadyExists(db_table_name)

                # Copy the table from the Geopackage file to the PostGis database
                py_qgis.copy_gpkg_tables_to_postgis(schema_name, gpkg_file, gpkg_table_name, db_table_name)

            else:
                pass
                # feature_postgres['feature_name_dict']['db_table_name'] = feature_postgres['feature_name_dict']['table_name']
                # Verify that the control file layers are in the db
                # _verify_layers_db()  # TODO: Add the  verification of the table in the database

    return control_file

def export_publish(project_file: str, schema: str):
    """
    Exports and publishes the project into the database
    """

    # Load the schema and project
    py_qgis.init_schema(schema)
    py_qgis.init_project_from_file(config.QGIS_PROJECTS_PATH(_read_param_proj_path(), project_file))

    # Normalize the project
    py_qgis.normalize_project()

    exported = []
    layers_saved = []
    try:
        # Exporting layers into database
        py_qgis.export_vector_layers_in_db(exported)

        # Update the data sources to point to the database
        py_qgis.set_layers_data_source()

        # Save the styles in the database
        py_qgis.save_layer_styles_in_db(layers_saved)

        # Save the project in the database
        py_qgis.save_project_in_db()

    except Exception:
        # Something bad happened, revert any/all layer styles and any/all exported tables
        for l in layers_saved:
            py_qgis.delete_layer_style_from_db(l)

        # Connect to the database
        with py_qgis.qgis_db.open_conn() as conn:
            # For each exported table
            for tn in exported:
                # Open a cursor
                with conn.cursor() as cur:
                    # Remove the table
                    py_qgis.remove_table_from_db(cur, tn)

            # Save
            conn.commit()
        raise

    # Return the layer status
    return py_qgis.get_info_project(admin_mode=True)


def export_republish(project_file: str, schema: str):
    """
    Exports and publishes the project into the database
    """

    exported = []
    layers_saved = []
    backup_layers= []
    try:
        # Read project id og
        project_id_og = os.path.basename(project_file).split(".")[0]

        # Backup the project and its layers
        backup_name, backup_layers = py_qgis.backup_project_layers(project_id_og, schema)

        # Load the schema and project
        py_qgis.init_schema(schema)
        py_qgis.init_project_from_file(config.QGIS_PROJECTS_PATH(_read_param_proj_path(), project_file))

        # Normalize the project
        py_qgis.normalize_project()

        # Exporting layers into database
        py_qgis.export_vector_layers_in_db(exported)

        # Update the data sources to point to the database
        py_qgis.set_layers_data_source()

        # Save the styles in the database
        py_qgis.save_layer_styles_in_db(layers_saved)

        # Save the project in the database
        py_qgis.save_project_in_db()

        # Updating was good, clear the backups
        py_qgis.backup_project_layers_clear(backup_name, backup_layers)

    except Exception:
        # Something bad happened!

        # Revert any/all layer styles
        for l in layers_saved:
            py_qgis.delete_layer_style_from_db(l)

        # Revert any/all exported tables
        for e in exported:
            py_qgis.db_quick_drop(py_qgis.qgis_db.schema, e)

        # Restore previous layer styles and data
        for l in backup_layers:
            restore_name = l[len(cdtk_qgis.BACKUP_PREFIX):]
            py_qgis.db_rename_layer_style(py_qgis.qgis_db.schema, l, restore_name)
            py_qgis.db_rename_and_recreate_index(py_qgis.qgis_db.schema, l, restore_name)

        # Reopen the original project as backed-up
        py_qgis.init_project_from_db(cdtk_qgis.BACKUP_PREFIX + project_id_og)
        # Restore it
        py_qgis.copy_project(project_id_og)
        # Delete the backup
        py_qgis.delete_project_from_db()

        # Keep raising..
        raise

    # Return the project information
    return py_qgis.get_info_project(admin_mode=True)


def delete_service(service_name: str, schema: str) -> None:
    """
    Deletes the project from the database
    """

    # Load the schema
    py_qgis.init_schema(schema)

    # Load the project from the database
    py_qgis.init_project_from_db(service_name)

    # Delete the styles from the database
    py_qgis.delete_layer_styles_from_db()

    # Delete the project from the database
    py_qgis.delete_project_from_db()


def delete_service_and_data(service_name: str, schema: str) -> None:
    """
    Deletes the project and the data from the database
    """

    # Load the schema
    py_qgis.init_schema(schema)

    # Load the project from the database
    py_qgis.init_project_from_db(service_name)

    # Delete the styles from the database
    py_qgis.delete_layer_styles_from_db()

    # Delete layers from database
    py_qgis.remove_layers_from_db()

    # Delete the project from the database
    py_qgis.delete_project_from_db()


def _read_param_proj_path() -> str:
    # Read
    return _read_param_mandatory("proj_path")


def _read_param_operation() -> str:
    # Read
    return _read_param_mandatory("operation")


def _read_param_file() -> str:
    # Read
    return _read_param_mandatory("file")


def _read_param_db_host() -> str:
    # Read
    return _read_param_mandatory("db_host")

def _read_param_db_port() -> int:
    # Read
    return int(_read_param_mandatory("db_port"))


def _read_param_db_name() -> str:
    # Read
    return _read_param_mandatory("db_name")


def _read_param_db_user() -> str:
    # Read
    return _read_param_mandatory("db_user")


def _read_param_db_pass() -> str:
    # Read
    return _read_param_mandatory("db_pass")


def _read_param_mandatory(param_name) -> str:
    opts, args = getopt.getopt(sys.argv[1:], "of", ["operation=", "file=", "proj_path=", "db_host=", "db_port=", "db_name=", "db_user=", "db_pass="])
    for opt, arg in opts:
        if opt in ("-" + param_name, "--" + param_name):
            return arg

    # Invalid param
    raise Exception(f"Parameter {param_name} invalid or not set")


def _read_param(param_name) -> str | None:
    opts, args = getopt.getopt(sys.argv[1:], "of", ["operation=", "file=", "proj_path=", "db_host=", "db_port=", "db_name=", "db_user=", "db_pass="])
    for opt, arg in opts:
        if opt in ("-" + param_name, "--" + param_name):
            return arg
    return None


def main():

    result = None
    warnings = []
    try:
        # Read the file
        file_data = {}
        with open(_read_param_file(), 'r') as outfile:
            file_data = json.load(outfile)

        # Depending on the operation
        return_code = 0
        if _read_param_operation() == "version":
            result = {
                'qgis_api': PY_QGIS.get_version().text(),
                'qgis_server': PY_QGIS.get_version().text(),
            }

        elif _read_param_operation() == "info_schema":
            # For each service parameters
            result = info_schema(file_data['schema'])

        elif _read_param_operation() == "info_service":
            # For each service parameters
            result = info_service(file_data['service_name'], file_data['schema'])

        elif _read_param_operation() == "compare":
            # For each service parameters
            result = []
            for sp in file_data['service_parameters']:
                res = compare(sp['in_project_filename'], sp['service_schema_name'])
                result.append(res)

        elif _read_param_operation() == "validate":
            # Validate
            result = validate_all(cdtk_qgis.OperationMode.VALIDATE, file_data, warnings)

        elif _read_param_operation() == "publish":
            # For each service parameters
            result = []
            for sp in file_data['service_parameters']:
                res = publish(sp['in_project_filename'], sp['service_schema_name'])
                result.append(res)

        elif _read_param_operation() == "export_publish":
            # Validate
            val_results = validate_all(cdtk_qgis.OperationMode.PUBLISH, file_data, warnings)

            # For each service parameters
            result = []

            serv_params = [file_data['ows_service_parameters']['english'], file_data['ows_service_parameters']['french']]
            for serv_param in serv_params:
                res = export_publish(serv_param['project_filename'], file_data['department'])
                result.append(res)

        elif _read_param_operation() == "export_republish":
            # Validate
            val_results = validate_all(cdtk_qgis.OperationMode.REPUBLISH, file_data, warnings)

            # For each service parameters
            result = []
            for sp in file_data['service_parameters']:
                res = export_republish(sp['in_project_filename'], sp['service_schema_name'])
                result.append(res)

        elif _read_param_operation() == "delete_service":
            # For each service parameters
            result = []
            for sp in file_data['service_parameters']:
                res = delete_service(sp['service_name'], sp['schema'])
                result.append(res)

        elif _read_param_operation() == "delete_service_and_data":
            # For each service parameters
            result = []
            serv_params = [file_data['ows_service_parameters']['english'], file_data['ows_service_parameters']['french']]
            for serv_param in serv_params:
                res = delete_service_and_data(os.path.basename(serv_param['project_filename']).split(".")[0], file_data['department'])
                result.append(res)

        elif _read_param_operation() == "oapi_export_publish":
            # For each service parameters
            # import web_pdb; web_pdb.set_trace()
            result = []
            res = oapi_export_publish(file_data)
            result.append(res)

        elif _read_param_operation() == "oapi_delete_publish":
            # For each service parameters
            result = []
            # import web_pdb; web_pdb.set_trace()
            oapi_delete_publish(file_data)

        else:
            raise Exception("Unknown operation: " + _read_param_operation())

        # If the resulting object is a list, transform to a dict so that it goes through the pipeline
        if isinstance(result, list):
            result = {
                'results': result
            }

        # Summary
        return_code = 0

        # Return the code
        return return_code

    except QGISApplicationException as err:
        # Marshall the exception to get through the pipeline.
        # Raising the exception so that it gets printed like an error in stderr.
        # This is using the same flow as any other exception that could have happened, on purpose.
        raise QGISAggregationException([err])

    except QGISAggregationException as err:
        # Already aggregated, let's go!
        raise

    finally:
        # Print the result in stdout to be able to retrieve and read it(!)
        print("Result: " + json.dumps({
            'result': result,
            'progress_marks': QGISProgressMark.list_progress_marks_as_list_dict(py_qgis.progress_marks),
            'warnings': QGISWarning.list_warn_as_list_dict(warnings)
            })
        )

        # Done
        py_qgis.close()


# If we're running in stand alone mode, run the application
if __name__ == '__main__':
    """
    Run!
    """

    py_qgis.init_database(_read_param_db_host(), _read_param_db_port(), _read_param_db_name(), _read_param_db_user(), _read_param_db_pass())
    exit(main())
