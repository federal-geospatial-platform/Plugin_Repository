"""
This is the CDTK PyQGIS launcher which offers methods to work with PyQGIS library in a stand-alone fashion (on the main thread due to a PyQGIS limitation!).
"""

# Core modules
import sys, os, getopt, json
from datetime import datetime
import xml.etree.ElementTree as ET

# Add the parent folder to the path so that the "nrcan_core" and "core" modules can be loaded
sys.path.append(os.path.dirname(sys.path[0]))

from nrcan_core import config as config_core
from core.lib.qgis_progress_marks import *
from core.lib.qgis_warnings import *
from core.lib.qgis_exceptions import *
from core.lib.logger import *
from nrcan_qgis.util import qgis_xml_tweak_layer_source

import cdtk_qgis, config, py_qgis as PY_QGIS

# The PyQGIS instance which is closed automatically in the end of the __main__
LOG.info("Instantiate PyQGIS...")
py_qgis = cdtk_qgis.CdtkPyQgis("/usr")


def info_schema(schema: str) -> list:
    """
    Gets the information on the project
    """

    # Return the projects in the database for the initialized schema
    return py_qgis.get_projects_in_db(schema)


def info_service(schema: str, service_name: str) -> dict:
    """
    Gets the information on the project
    """

    # Load the schema and project
    py_qgis.init_project_from_db(schema, service_name)

    # Build the validation results object
    return py_qgis.get_info_project()


def compare(project_file: str, schema: str) -> dict:
    """
    Compares the provided project ('new') with the one stored in the database ('existing') (if any)
    """

    # Load the schema and project
    py_qgis.init_project_from_file(config.QGIS_PROJECTS_PATH(_read_param_proj_path(), project_file))
    py_qgis.init_project_schema(schema)

    # Build the validation results object
    res: dict = {}
    res['new'] = py_qgis.get_info_project()

    existing = None
    if py_qgis.qgis_project_id and py_qgis.project_exists_in_db(schema, py_qgis.qgis_project_id):
        # Load the project from the database
        py_qgis.init_project_from_db(schema, py_qgis.qgis_project_id)
        existing = py_qgis.get_info_project()

    # Report the information from the existing project
    res['existing'] = existing

    # Done
    return res


def validate_all(operation: cdtk_qgis.OperationMode, control_file: dict, internal: bool,
                 wants_wcs: bool, wants_wfs: bool, warnings: list) -> list:

    # The errors
    errors: list = []

    # For each service parameters, validate them all first
    val_results: list = []
    for sp in [control_file['ows_service_parameters']['english'], control_file['ows_service_parameters']['french']]:
        res: dict = validate(operation, sp['project_filename'], internal,
                             control_file['department'], control_file['dataset_name'],
                             2, wants_wcs, wants_wfs, warnings, errors)
        val_results.append(res)

    # Done comparing projects individually. Now compare the projects between themselves.
    validate_between(val_results, errors)

    # If any errors
    if len(errors):
        raise QGISAggregationException(errors)

    return val_results


def validate(operation: cdtk_qgis.OperationMode, project_file: str, internal: bool, schema: str, dataset_name: str,
             nb_projects: int, wants_wcs: bool, wants_wfs: bool, warnings: list, errors: list) -> dict:

    # The project file path
    project_file_path: str = config.QGIS_PROJECTS_PATH(_read_param_proj_path(), project_file)

    # In external mode, the layers are probably disconnected, for security reasons and it's
    # likely using authcfg in the layers. There is an issue with authcfg and the existance of '' or not
    # GITHUB ISSUE: https://github.com/qgis/QGIS/issues/59384
    # This 'if' fixes the QGIS issue, before continuing with the project file
    if not internal:
        # Log
        LOG.debug("This project is external, make sure the authcfg configs (if any) are using apostrophes \"'\"")

        # Open the project as XML tree
        tree: ET.ElementTree = ET.parse(project_file_path)
        root: ET.Element | Any = tree.getroot()

        # For each layer
        for layer in root.findall(".//layer-tree-layer"):
            # Read the source
            source: str | None = layer.attrib.get('source')
            if source:
                source_final: str = qgis_xml_tweak_layer_source(source)
                layer.set('source', source_final)

        for datasource in root.findall(".//projectlayers/maplayer/datasource"):
            if datasource is not None and datasource.text:
                # Read as dict
                source_final = qgis_xml_tweak_layer_source(datasource.text)
                datasource.text = source_final

        # Save it back
        tree.write(project_file_path)

    # Load the schema and project
    py_qgis.init_dataset_name(dataset_name)
    py_qgis.init_project_from_file(project_file_path)
    py_qgis.init_project_schema(schema)

    # Validate the project
    val_res: dict = py_qgis.validate_project(operation, False, internal, config.SUPPORTED_EPSG_CRS,
                                             nb_projects, wants_wcs, wants_wfs, warnings, errors)

    # Save it back to drive, once validated, because layer connections may have changed in the case of external data
    py_qgis.save_project_on_disk(project_file_path)

    # Return validation result
    return val_res


def validate_between(val_results: list, errors: list) -> None:
    # Check for same number of layers in each project

    # If 2 projects to begin with (English/French)
    if len(val_results) == 2:
        # If different number of layers total
        if len(val_results[0]) != len(val_results[1]):
            errors.append(ProjectsDifferentLayersCount(len(val_results[0]), len(val_results[1])))
            return

        # Get all layers in both projects
        layers_1: list = val_results[0]['layers']
        layers_2: list = val_results[1]['layers']
        all_layers: list = []
        all_layers.extend(layers_1)
        all_layers.extend(layers_2)

        # For each layer in both projects
        layerNamesCheck: dict[str, str] = {}
        for layer_info in all_layers:
            # If the layer points to a geopackage source
            if 'is_geopackage' in layer_info and layer_info['is_geopackage']:
                # Get the source name as it would become in our database
                name_table: str = layer_info['name_table_db']
                gpkg_file: str = os.path.basename(layer_info['uri']['path'])

                # If the layer name was already processed once
                if name_table in layerNamesCheck:
                    # Careful, check if coming from different geopackage
                    if layerNamesCheck[name_table] != gpkg_file:
                        # Throws
                        raise ProjectUsingSameLayerNameDifferentGeopackages(layer_info['name_table'], layerNamesCheck[name_table], gpkg_file)

                # Append
                layerNamesCheck[name_table] = gpkg_file

        # Get the list of table names (the source names)
        table_names_en: list[str] = [f['name_table_db'] for f in layers_1]

        # Get the list of table names (the source names)
        table_names_fr: list[str] = [f['name_table_db'] for f in layers_2]

        # For each Englsh vector geopackage layer
        for layer_en in layers_1:
            # Check if the source name doesn't exist in the French project
            if not (layer_en['name_table_db'] in table_names_fr):
                errors.append(ProjectsSourceNameNotFound('en', layer_en['name'], layer_en['name_table']))

        # For each French vector geopackage layer
        for layer_fr in layers_2:
            # Check if the source name doesn't exist in the English project
            if not (layer_fr['name_table_db'] in table_names_en):
                errors.append(ProjectsSourceNameNotFound('fr', layer_fr['name'], layer_fr['name_table']))


# def publish(project_file: str, schema: str, dataset_name: str, internal: bool) -> dict:
#     """
#     Publishers the project as a service
#     """

#     # Load the schema and project
#     py_qgis.init_dataset_name(dataset_name)
#     py_qgis.init_project_from_file(config.QGIS_PROJECTS_PATH(_read_param_proj_path(), project_file))
#     py_qgis.init_project_schema(schema)

#     # The warnings/errors
#     warnings: list = []
#     errors: list = []

#     # Validate the project
#     py_qgis.validate_project(cdtk_qgis.OperationMode.PUBLISH, False, internal, config.SUPPORTED_EPSG_CRS, 1, warnings, errors)

#     # If any errors
#     if len(errors):
#         raise QGISAggregationException(errors)

#     # Normalize the project
#     py_qgis.normalize_project()

#     layers_saved: list[LayerStyle] = []
#     try:
#         # Save the styles in the database
#         py_qgis.save_layer_styles_in_db(layers_saved)

#         # Save the project in the database
#         py_qgis.save_project_in_db()

#     except Exception as err:
#         # Something bad happened, revert any/all layer styles
#         for l in layers_saved:
#             py_qgis.delete_layer_style_from_db(l.layer, l.style_name)
#         raise

#     # Return the layer status
#     return py_qgis.get_info_project(admin_mode=False)


def oapi_delete_publish(control_file: dict) -> None:
    """
    Delete the non referenced tables of an OAPI publication
    """

    collections = control_file['oapi_service_parameters']['collections']

    # If initialized
    if py_qgis.db_data:
        # Connect to the database
        with py_qgis.db_data.open_conn() as conn:
            # Open a cursor
            with conn.cursor() as cur:
                # Loop over each collection
                for collection_list in collections:
                    for collection in collection_list:
                        feature_postgres = collection['provider_feature_postgres']

                        if feature_postgres and feature_postgres['feature_name_dict']['to_delete'] == 'True':
                            schema_name = feature_postgres['schema_name']
                            db_table_name = feature_postgres['feature_name_dict']['db_table_name']

                            # Remove the table
                            py_qgis.db_data.drop_table_go(cur, schema_name, db_table_name)
                            py_qgis.progress_marks.append(ProgressMarkTableDropped(datetime.now(), schema_name, db_table_name))

            # Commit the drop tables
            conn.commit()


def oapi_export_publish(control_file: dict) -> dict:
    """
    Exports and publishes the OAPI feature service
    """

    collections: list = control_file['oapi_service_parameters']['collections']
    # Extract some information from the collections
    for collection_list in collections:
        for collection in collection_list:
            feature_postgres = collection['provider_feature_postgres']
            if feature_postgres:
                schema_name: str = feature_postgres['schema_name']
                feature_type: str = feature_postgres['feature_name_dict']['type']

                if feature_type == "gpkg":
                    # Extract some information
                    gpkg_file = feature_postgres['feature_name_dict']['file_name']
                    gpkg_table_name = feature_postgres['feature_name_dict']['table_name']

                    # Transform the name of the gpkg tables into database table name
                    db_table_name = feature_postgres['feature_name_dict']['db_table_name']

                    # Get the list of layers from the PostGis database
                    db_table_names = py_qgis.get_layers_from_db(schema_name)

                    # Get the list of layers from the GeoPackage file
                    gpkg_table_names = PY_QGIS.get_layers_from_gpkg(gpkg_file)

                    # Verify the the control file table is in the GeoPackage file
                    if gpkg_table_name.lower() not in [x.lower() for x in gpkg_table_names]:
                        raise TableMissingInGpkg(gpkg_table_name, gpkg_file)

                    # Verify that the layer to copy are not in the db
                    if db_table_name.lower() in db_table_names:
                        raise TableAlreadyExists(schema_name, db_table_name)

                    # Copy the table from the Geopackage file to the PostGis database
                    py_qgis.copy_gpkg_tables_to_postgis(config_core.DATA_IMPORT_PROCESS, schema_name, gpkg_file, gpkg_table_name, db_table_name,
                                                        feature_postgres['data_id_field'], config_core.DB_GEOM_FIELD)

                else:
                    # Verify that the data is in the database
                    if py_qgis.db_data and not py_qgis.db_data.table_exists(schema_name, feature_postgres['feature_name_dict']['db_table_name']):
                        raise TableMissingInDatabase(schema_name, feature_postgres['feature_name_dict']['db_table_name'])

    return control_file


def export_publish(project_file: str, schema: str, dataset_name: str, internal: bool, wants_wcs: bool, wants_wfs: bool) -> dict:
    """
    Exports and publishes the project into the database
    """

    # Log
    LOG.info(f"Publishing project '{project_file}'")

    # Load the schema and project
    py_qgis.init_dataset_name(dataset_name)
    py_qgis.init_project_from_file(config.QGIS_PROJECTS_PATH(_read_param_proj_path(), project_file))
    py_qgis.init_project_schema(schema)

    # Normalize the project
    py_qgis.normalize_project(wants_wcs, wants_wfs)

    exported: list = []
    layers_saved: list = []
    try:
        # If publishing internal (importing the data in our database)
        if internal:
            # Exporting layers into database
            py_qgis.export_vector_layers_in_db(config_core.DATA_IMPORT_PROCESS, schema, config_core.DB_PRIMARY_KEY_FIELD, config_core.DB_GEOM_FIELD, exported)

            # Update the data sources to point to the database
            py_qgis.set_layers_data_source(schema, config_core.DB_PRIMARY_KEY_FIELD, config_core.DB_GEOM_FIELD)

        # Save the styles in the database
        py_qgis.save_layer_styles_in_db(layers_saved)

        # Save it back to drive, to be able to compare with the DB copy in case
        #SOME_PATH: str = "C:\\TEMP"
        #py_qgis.save_project_on_disk(f'{SOME_PATH}\\{project_file}-DB-COPY.qgs')

        # Save the project in the database
        py_qgis.save_project_in_db()

    except Exception:
        # Something bad happened, revert any/all layer styles and any/all exported tables
        for l in layers_saved:
            py_qgis.delete_layer_style_from_db(l.layer, l.style_name)

        if py_qgis.db_data:
            for e in exported:
                py_qgis.db_quick_drop(schema, e)
        raise

    # Return the layer status
    return py_qgis.get_info_project(admin_mode=True)


def export_republish(project_file: str, schema: str, dataset_name: str, internal: bool, wants_wcs: bool, wants_wfs: bool) -> dict:
    """
    Exports and publishes the project into the database
    """

    # Log
    LOG.info(f"Republishing project '{project_file}'")

    # If external, not ready
    if not internal:
        raise NotImplementedError()

    exported: list = []
    layers_saved: list = []
    backup_layers: list = []
    project_id_og: str | None = None
    try:
        # Read project id og
        project_id_og = os.path.basename(project_file).split(".")[0]

        # Backup the project and its layers
        backup_name, backup_layers = py_qgis.backup_project_layers(project_id_og, schema, dataset_name, internal)

        # Load the schema and project
        py_qgis.init_dataset_name(dataset_name)
        py_qgis.init_project_from_file(config.QGIS_PROJECTS_PATH(_read_param_proj_path(), project_file))
        py_qgis.init_project_schema(schema)

        # Normalize the project
        py_qgis.normalize_project(wants_wcs, wants_wfs)

        # If publishing internal (importing the data in our database)
        if internal:
            # Exporting layers into database
            py_qgis.export_vector_layers_in_db(config_core.DATA_IMPORT_PROCESS, schema, config_core.DB_PRIMARY_KEY_FIELD, config_core.DB_GEOM_FIELD, exported)

            # Update the data sources to point to the database
            py_qgis.set_layers_data_source(schema, config_core.DB_PRIMARY_KEY_FIELD, config_core.DB_GEOM_FIELD)

        # Save the styles in the database
        py_qgis.save_layer_styles_in_db(layers_saved)

        # Save the project in the database
        py_qgis.save_project_in_db()

        # Updating was good, clear the backups
        py_qgis.backup_project_layers_clear(backup_name, backup_layers)

    except Exception:
        # Something bad happened!

        # Revert any/all layer styles
        for l in layers_saved:
            py_qgis.delete_layer_style_from_db(l.layer, l.style_name)

        if py_qgis.db_data:
            # Revert any/all exported tables
            for exp in exported:
                py_qgis.db_quick_drop(schema, exp)

            # Restore previous layer styles and data
            for l in backup_layers:
                restore_name = l[len(cdtk_qgis.BACKUP_PREFIX):]
                py_qgis.db_rename_layer_style(schema, l, restore_name)
                py_qgis.db_rename_and_recreate_index(schema, l, restore_name)

        if project_id_og:
            # Reopen the original project as backed-up
            py_qgis.init_project_from_db(schema, cdtk_qgis.BACKUP_PREFIX + project_id_og)
            # Restore it
            py_qgis.copy_project(project_id_og)
            # Delete the backup
            py_qgis.delete_project_from_db()

        # Keep raising..
        raise

    # Return the project information
    return py_qgis.get_info_project(admin_mode=True)


def delete_service(schema: str, service_name: str) -> None:
    """
    Deletes the project from the database
    """

    # Load the project from the database
    py_qgis.init_project_from_db(schema, service_name)

    # Delete the styles from the database
    py_qgis.delete_layer_styles_from_db()

    # Delete the project from the database
    py_qgis.delete_project_from_db()


def delete_service_and_data(schema: str, service_name: str, internal: bool) -> None:
    """
    Deletes the project and the data from the database
    """

    # Load the project from the database
    py_qgis.init_project_from_db(schema, service_name)

    # Delete the styles from the database
    py_qgis.delete_layer_styles_from_db()

    # If internal
    if internal:
        # Delete layers from database
        py_qgis.remove_layers_from_db()

    # Delete the project from the database
    py_qgis.delete_project_from_db()


def _read_param_proj_path() -> str:
    # Read
    return _read_param_mandatory("proj_path")


def _read_param_operation() -> str:
    # Read
    return _read_param_mandatory("operation")


def _read_param_file() -> str:
    # Read
    return _read_param_mandatory("file")


def _read_param_internal() -> bool:
    # Read
    return _read_param_mandatory("internal") == "True"


def _read_param_db_host_qgis() -> str:
    # Read
    return _read_param_mandatory("db_host_qgis")


def _read_param_db_port_qgis() -> int:
    # Read
    return int(_read_param_mandatory("db_port_qgis"))


def _read_param_db_name_qgis() -> str:
    # Read
    return _read_param_mandatory("db_name_qgis")


def _read_param_db_user_qgis() -> str:
    # Read
    return _read_param_mandatory("db_user_qgis")


def _read_param_db_pass_qgis() -> str:
    # Read
    return _read_param_mandatory("db_pass_qgis")


def _read_param_db_host_data() -> str:
    # Read
    return _read_param_mandatory("db_host_data")

def _read_param_db_port_data() -> int:
    # Read
    return int(_read_param_mandatory("db_port_data"))


def _read_param_db_name_data() -> str:
    # Read
    return _read_param_mandatory("db_name_data")


def _read_param_db_user_data() -> str:
    # Read
    return _read_param_mandatory("db_user_data")


def _read_param_db_pass_data() -> str:
    # Read
    return _read_param_mandatory("db_pass_data")


def _read_param_mandatory(param_name) -> str:
    opts, args = getopt.getopt(sys.argv[1:], "of", ["operation=", "file=", "proj_path=", "internal=",
                                                                                      "db_host_qgis=", "db_port_qgis=", "db_name_qgis=", "db_user_qgis=", "db_pass_qgis=",
                                                                                      "db_host_data=", "db_port_data=", "db_name_data=", "db_user_data=", "db_pass_data="])
    for opt, arg in opts:
        if opt in ("-" + param_name, "--" + param_name):
            return arg

    # Invalid param
    raise Exception(f"Parameter {param_name} invalid or not set")


def main():
    LOG.trace_func()

    result = None
    warnings = []
    try:
        # Read the file
        file_data = {}
        with open(_read_param_file(), 'r') as outfile:
            file_data = json.load(outfile)

        # Check if wants WCS and wants WFS
        wants_wcs: bool = False
        wants_wfs: bool = False
        if 'service_type' in file_data and (file_data['service_type']['OWS'] == "True" and 'ows_service_parameters' in file_data and 'ows_service_type' in file_data['ows_service_parameters']):
            wants_wcs = file_data['ows_service_parameters']['ows_service_type']['WCS'] == "True"
            wants_wfs = file_data['ows_service_parameters']['ows_service_type']['WFS'] == "True"

        # Depending on the operation
        return_code = 0
        if _read_param_operation() == "version":
            result = {
                'qgis_api': PY_QGIS.get_version().text()
            }

        elif _read_param_operation() == "info_schema":
            # For each service parameters
            result = info_schema(file_data['schema'])

        elif _read_param_operation() == "info_service":
            # For each service parameters
            result = info_service(file_data['schema'], file_data['service_name'])

        elif _read_param_operation() == "compare":
            # For each service parameters
            result = []
            for sp in file_data['service_parameters']:
                res = compare(sp['in_project_filename'], sp['service_schema_name'])
                result.append(res)

        elif _read_param_operation() == "validate":
            # Validate
            result = validate_all(cdtk_qgis.OperationMode.VALIDATE, file_data, _read_param_internal(), wants_wcs, wants_wfs, warnings)

        elif _read_param_operation() == "publish":
            pass  # Don't do anything anymore for now

            # # For each service parameters
            # result = []
            # for sp in file_data['service_parameters']:
            #     res = publish(sp['in_project_filename'], sp['service_schema_name'], file_data['dataset_name'], _read_param_internal())
            #     result.append(res)

        elif _read_param_operation() == "export_publish":
            # Validate
            val_results = validate_all(cdtk_qgis.OperationMode.PUBLISH, file_data, _read_param_internal(), wants_wcs, wants_wfs, warnings)

            # For each service parameters
            result = []

            serv_params = [file_data['ows_service_parameters']['english'], file_data['ows_service_parameters']['french']]
            for serv_param in serv_params:
                res = export_publish(serv_param['project_filename'], file_data['department'], file_data['dataset_name'],
                                     _read_param_internal(), wants_wcs, wants_wfs)
                result.append(res)

        elif _read_param_operation() == "export_republish":
            pass  # Don't do anything anymore for now
            # # Validate
            # val_results = validate_all(cdtk_qgis.OperationMode.REPUBLISH, file_data, _read_param_internal(), warnings)

            # # For each service parameters
            # result = []
            # for sp in file_data['service_parameters']:
            #     res = export_republish(sp['in_project_filename'], sp['service_schema_name'], file_data['dataset_name'], _read_param_internal())
            #     result.append(res)

        elif _read_param_operation() == "delete_service":
            # For each service parameters
            result = []
            res = delete_service(file_data['schema'], file_data['service_name'])
            result.append(res)

        elif _read_param_operation() == "delete_service_and_data":
            # For each service parameters
            result = []
            serv_params = [file_data['ows_service_parameters']['english'], file_data['ows_service_parameters']['french']]
            for serv_param in serv_params:
                res = delete_service_and_data(file_data['department'], os.path.basename(serv_param['project_filename']).split(".")[0], _read_param_internal())
                result.append(res)

        elif _read_param_operation() == "oapi_export_publish":
            # For each service parameters
            result = []
            res = oapi_export_publish(file_data)
            result.append(res)

        elif _read_param_operation() == "oapi_delete_publish":
            # For each service parameters
            result = []
            oapi_delete_publish(file_data)

        else:
            raise Exception("Unknown operation: " + _read_param_operation())

        # If the resulting object is a list, transform to a dict so that it goes through the pipeline
        if isinstance(result, list):
            result = {
                'results': result
            }

        # Summary
        return_code = 0

        # Return the code
        return return_code

    except QGISApplicationException as err:
        # Marshall the exception to get through the pipeline.
        # Raising the exception so that it gets printed like an error in stderr.
        # This is using the same flow as any other exception that could have happened, on purpose.
        raise QGISAggregationException([err])

    except QGISAggregationException as err:
        # Already aggregated, let's go!
        raise

    finally:
        # Print the result in stdout to be able to retrieve and read it(!)
        print("Result: " + json.dumps({
            'result': result,
            'progress_marks': QGISProgressMark.list_progress_marks_as_list_dict(py_qgis.progress_marks),
            'warnings': QGISWarning.list_warn_as_list_dict(warnings)
            })
        )

        # Done
        py_qgis.close()


# If we're running in stand alone mode, run the application
if __name__ == '__main__':
    """
    Run!
    """
    LOG.trace_func()

    # Initialize the connection to the database when working with QGIS projects
    py_qgis.init_database_qgis(_read_param_db_host_qgis(), _read_param_db_port_qgis(), _read_param_db_name_qgis(), _read_param_db_user_qgis(), _read_param_db_pass_qgis())

    # Initialize the connection to the database when working with data
    py_qgis.init_database_data(_read_param_db_host_data(), _read_param_db_port_data(), _read_param_db_name_data(), _read_param_db_user_data(), _read_param_db_pass_data())

    # Done
    exit(main())
