# If you are not inside a QGIS console you first need to import
# qgis and PyQt classes you will use in this script as shown below

# System imports
from enum import Enum
from collections import Counter
from datetime import datetime

# QGIS imports
from qgis.core import QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsVectorSimplifyMethod # type: ignore
from qgis.core import QgsVectorLayer, QgsRasterLayer, QgsVectorLayerExporter # type: ignore

# Application imports
import config, py_qgis as PY_QGIS
from lib.progress_marks import *
from lib.warnings import *
from lib.exceptions import *
from util import LAYER_NAME_MAX_LENGTH, format_oapi_table_name, _normalize_string, _validate_throws_or_append

# Constant
DATA_PROVIDER_KEY = "postgres"
BACKUP_PREFIX = "_"

class OperationMode(Enum):
    VALIDATE = 0
    PUBLISH = 1
    REPUBLISH = 2
    UNPUBLISH = 3


class CdtkPyQgis(PY_QGIS.PyQgis):
    """
    A CDTK PyQGIS management class
    """

    def __init__(self, qgis_install_path: str) -> None:
        """
        Constructor

        :param qgis_install_path: The path to QGIS install
        """
        super().__init__(qgis_install_path)

    def _format_table_name(self, layer: QgsVectorLayer) -> str:
        """
        Helper function to get the source name of the given vector layer.
        When a vector layer is given, the source name is the layer short name.
        """

        # The table name is based on the layer short name
        return format_oapi_table_name(self.qgis_project_id_short, layer.shortName())

    def _format_style_name(self, layer: QgsVectorLayer) -> str:
        """
        Helper function to format the style name based on the layer name
        """

        # Redirect
        return _normalize_string(format_oapi_table_name(self.qgis_project_id_short, layer.shortName()) + "_" + self.qgis_project_lang)

    def _format_geometry_index_name(self, table_name: str) -> str:
        """
        Helper function to format the geometry index based on the table name
        """

        return table_name + "_geom_idx"

    def _format_raster_name_source(self, path: str) -> str:
        """
        Helper function to format the name of a path for a raster layer
        """

        # If starts with /vsi
        if path.startswith("/vsicurl/"):
            return path[9:]
        return path

    def get_info_project(self, admin_mode: bool = False) -> dict:
        """
        Gets the information on a project
        """

        # If project is defined
        if self.project:
            # The results that will be returned
            return {
                'qgis_version': PY_QGIS.get_version().text(),
                'project_version': self.project.lastSaveVersion().text(),
                'project': self.qgis_project_id,
                'project_title': self.project.title(),
                'crs': self.get_crs(),
                'layers': self.get_layers_status(admin_mode)
            }

        raise ProjectNotInitialized("get_info_project")

    def get_layers_status(self, admin_mode: bool) -> list[dict]:
        """
        Gets a list of summary-dictionaries representing the layers in the project
        """

        # The layers to be returned
        layers: list[dict] = []

        # If the project has been initialized
        if self.project:
            # For each layer in the map
            for layer in self.get_layers_in_order():
                # Get the data provider
                data_prov = layer.dataProvider()

                # Decode the source
                source_data = self.get_layer_properties(layer)
                source_data_formatted: dict = {}
                for k in source_data:
                    if admin_mode or k.lower() != "password":
                        source_data_formatted[k] = str(source_data[k])

                # Get the metadata of the layer
                l_metadata = layer.metadata()

                # Write the keywords
                keys_list = []
                for k_list in l_metadata.keywords().values():
                    keys_list.extend(k_list)

                layer_extent = None
                layer_extent_4326 = None
                try:
                    # Get the layer extent
                    layer_extent = layer.extent()

                    # Reproject to 4326
                    geo2proj = QgsCoordinateTransform(layer.crs(), QgsCoordinateReferenceSystem(4326), self.project)
                    layer_extent_4326 = geo2proj.transform(layer_extent)

                except Exception as err:
                    # Error
                    raise LayerFailedToGetExtent(layer.name(), PY_QGIS._format_crs_epsg(layer.crs().authid()))

                # Grab layer info
                layer_info: dict = {
                    'is_valid': data_prov.isValid(),
                    'type': None,
                    'name': layer.name(),
                    'crs': PY_QGIS._format_crs_epsg(layer.crs().authid()),
                    'uri': source_data_formatted,
                    'abstract': l_metadata.abstract(),
                    'keywords': keys_list,
                    'extent': {
                        'xMinimum': layer_extent.xMinimum(),
                        'xMaximum': layer_extent.xMaximum(),
                        'yMinimum': layer_extent.yMinimum(),
                        'yMaximum': layer_extent.yMaximum()
                    },
                    'extent4326': {
                        'xMinimum': layer_extent_4326.xMinimum(),
                        'xMaximum': layer_extent_4326.xMaximum(),
                        'yMinimum': layer_extent_4326.yMinimum(),
                        'yMaximum': layer_extent_4326.yMaximum()
                    },
                    'temporal': {
                        'isActive': layer.temporalProperties().isActive(),
                        'begin': layer.temporalProperties().fixedTemporalRange().begin().toString("yyyy-MM-dd") if layer.temporalProperties().fixedTemporalRange().begin().isValid() else None,
                        'end': layer.temporalProperties().fixedTemporalRange().end().toString("yyyy-MM-dd") if layer.temporalProperties().fixedTemporalRange().end().isValid() else None
                    },
                    'styles': layer.styleManager().styles()
                }

                # Defaults
                layer_info['data_exists_in_database'] = False
                layer_info['style_exists_in_database'] = "no"
                layer_info['name_short'] = layer.shortName()

                # Validate the layer short name is valid
                layer_info['name_valid'] = "valid" if len(layer_info['name_short']) > 0 and len(layer_info['name_short']) <= LAYER_NAME_MAX_LENGTH else "invalid"

                # Get the table name (even useful for coverage, it becomes the collection id)
                table_name: str = self._format_table_name(layer)
                layer_info['name_table'] = table_name

                # If the layer data is valid, the layer is Vector type
                if data_prov.isValid() and isinstance(layer, QgsVectorLayer):
                    # Get layer id field
                    layer_info['type'] = "feature"
                    layer_info['is_geopackage'] = self.get_layer_is_geopackage(layer)
                    layer_info['is_geopackage_in_input'] = self.get_layer_is_geopackage_in_same_folder(layer)
                    layer_info['geom_type'] = PY_QGIS.get_geometry_type_string(layer.geometryType())
                    layer_info['fields'] = [i.name() for i in data_prov.fields()]
                    layer_info['fields_ids'] = self.get_layer_id_field_names(layer)
                    layer_info['feature_count'] = data_prov.featureCount()

                    # If data exists in the database
                    if self.qgis_db and self.qgis_db.table_exists(table_name):
                        layer_info['data_exists_in_database'] = True

                    # If the data points to a geopackage that was in the input package (it'll become a table in the database)
                    if layer_info['is_geopackage_in_input']:
                        # Check if the style already exists in the database
                        if self.layer_style_exists_in_db(layer, self._format_style_name(layer)):
                            # If publishing for the same service dataset
                            layer_info['style_exists_in_database'] = "invalid"

                    # Grab the layer id field names
                    layer_info['fields_id_valid'] = len(layer_info['fields_ids']) == 1

                    # Grab the layer styles
                    #[count, style_ids, style_names, style_descs, error] = layer.listStylesInDatabase()
                    #layer_info['styles'] = self.get_layer_styles(layer)

                # If the layer data is valid, the layer is Raster type
                if data_prov.isValid() and isinstance(layer, QgsRasterLayer):
                    layer_info['type'] = "coverage"
                    layer_info['units_per_pixel_x'] = layer.rasterUnitsPerPixelX()
                    layer_info['units_per_pixel_y'] = layer.rasterUnitsPerPixelY()

                # Append the layers info to the list
                layers.append(layer_info)

            # Return the layers info
            return layers

        else:
            # Throws
            raise ProjectNotInitialized("get_layers")

    def get_layers_in_order_only_export(self):
        """
        Helper function to get the layers pointing to a geopackage in order.
        """

        # Redirect
        layers = self.get_layers_in_order()

        # Filter
        return list(filter(lambda l: self.get_layer_is_geopackage_in_same_folder(l), layers))

    def validate_project(self, operation: OperationMode, admin_mode: bool, supported_crs: list, nb_projects: int, warnings: list, errors: list):
        """
        Gets if the project is valid for a publication
        """

        # Keep track
        self.progress_marks.append(ProgressMarkValidatingProjectExists(datetime.now(), self.qgis_project_id))

        # Get the project version
        project_version = self.project.lastSaveVersion()

        # Get the API QGIS Version
        qgis_api_version = PY_QGIS.get_version()

        # If our PyQGIS of the API is smaller than the version of the project
        if PY_QGIS.compare_version(qgis_api_version, project_version) < 0:
            _validate_throws_or_append(ProjectVersionGreaterThanAPI(self.qgis_project_id,
                                                                    project_version.text(),
                                                                    qgis_api_version.text()), errors)

        # TODO: Get the real QGIS Server Version
        qgis_server_version = PY_QGIS.get_version()

        # If our QGIS Server is smaller than the version of the project
        if PY_QGIS.compare_version(qgis_server_version, project_version) < 0:
            _validate_throws_or_append(ProjectVersionGreaterThanServer(self.qgis_project_id,
                                                                       project_version.text(),
                                                                       qgis_server_version.text()), errors)

        # If the project has no title
        if not self.project.title():
            _validate_throws_or_append(ProjectHasNoTitle(self.qgis_project_id), errors)

        # If the project already exists
        proj_exists = self.project_exists_in_db(self.qgis_project_id)
        if operation == OperationMode.PUBLISH and proj_exists:
            _validate_throws_or_append(ProjectAlreadyExists(self.qgis_project_id), errors)

        elif operation == OperationMode.REPUBLISH and not proj_exists:
            _validate_throws_or_append(ProjectNotFoundFromDatabase(self.qgis_project_id, self.qgis_db.schema), errors)

        # Keep track
        self.progress_marks.append(ProgressMarkValidatingProjectCRS(datetime.now()))

        # If the project crs is supported by CDTK
        if not int(self.get_crs()) in supported_crs:
            _validate_throws_or_append(UnsupportedCRS(self.get_crs()), errors)

        # Keep track
        self.progress_marks.append(ProgressMarkValidatingProjectLayersCRS(datetime.now()))

        # Get layer status
        layers_status = self.get_layers_status(admin_mode)

        # Get the valid/invalid layers
        layers_valid = list(filter(lambda l: l['is_valid'] and (l['type'] == "feature" or l['type'] == "coverage"), layers_status))
        layers_invalid = list(filter(lambda l: not l['is_valid'], layers_status))

        # If no valid layers
        if len(layers_valid) == 0:
            _validate_throws_or_append(ProjectNoValidLayers(self.qgis_project_id), errors)

        # If any invalid layers
        if len(layers_invalid):
            for l in layers_invalid:
                _validate_throws_or_append(LayerInvalid(self.qgis_project_id, l['name']), errors)

        # Get any layer having a different crs than the project
        layers_diff_crs = list(filter(lambda l: l['crs'] != self.get_crs(), layers_status))

        # If any
        if len(layers_diff_crs) > 0:
            # For each invalid layer
            for l in layers_diff_crs:
                _validate_throws_or_append(LayerUnsupportedCRS(l['name'], l['crs']), errors)

        # Get any layer having a invalid short names
        layers_invalid_name = list(filter(lambda l: 'name_valid' in l and l['name_valid'] != "valid", layers_status))

        # If any
        if len(layers_invalid_name) > 0:
            # For each invalid layer
            for l in layers_invalid_name:
                _validate_throws_or_append(LayerShortNameInvalid(l['name'], l['name_short']), errors)

        # Get any feature layer having bad field ids
        layers_bad_field_ids = list(filter(lambda l: l['type'] == "feature" and not l['fields_id_valid'], layers_status))

        # If any
        if len(layers_bad_field_ids) > 0:
            # For each invalid layer
            for l in layers_bad_field_ids:
                _validate_throws_or_append(LayerFieldIDInvalid(l['name']), errors)

       # Get the list of layers in geopackage or coverage
        layers_geop = list(filter(lambda l: l['type'] == "coverage" or (l['type'] == 'feature' and l['is_geopackage']), layers_status))

        # Get the list of table names (the short names)
        table_names = [f['name_table'] for f in layers_geop]

        # If any duplicates
        counts = Counter(table_names)
        counts_dict = dict(counts)
        for cd in counts_dict:
            if counts_dict[cd] > 1:
                _validate_throws_or_append(ProjectsShortNameDuplicated(self.qgis_project_id, cd), errors)

        # Get any source name that are invalid
        #sources_invalid = list(filter(lambda l: 'source_formatted_valid' in l and l['source_formatted_valid'] == "invalid", layers_status))

        ## If any sources are invalid
        #if len(sources_invalid) > 0:
        #    # For each invalid layer
        #    for layer_name in [l['name'] for l in sources_invalid]:
        #        _validate_throws_or_append(DataSourceInvalid(layer_name), errors)

        # If publishing
        if operation == OperationMode.PUBLISH:
            # If validating the english project or only one project being processed
            if self.qgis_project_lang == "en" or nb_projects == 1:
                # Keep track
                self.progress_marks.append(ProgressMarkValidatingDataAlreadyExists(datetime.now()))

                # Get any layer having pointing to data that already exists in the database
                layers_data_exist = list(filter(lambda l: 'data_exists_in_database' in l and l['data_exists_in_database'], layers_status))

                # If any
                if len(layers_data_exist) > 0:
                   # For each invalid layer
                   for layer_name in [l['name'] for l in layers_data_exist]:
                       _validate_throws_or_append(DataAlreadyExists(layer_name), errors)

            # Keep track
            self.progress_marks.append(ProgressMarkValidatingStylesAlreadyExists(datetime.now()))

            # Get any layer having their styles already in the database
            layers_styles_exist = list(filter(lambda l: 'style_exists_in_database' in l and l['style_exists_in_database'] == "invalid", layers_status))

            # If any
            if len(layers_styles_exist) > 0:
                # For each invalid layer
                for layer_name in [l['name'] for l in layers_styles_exist]:
                    _validate_throws_or_append(StyleAlreadyExists(layer_name), errors)

        # Return the layers status
        return layers_status

    def normalize_project(self):
        """
        Automatically normalizes the current project and its layers by filling in some metadata information based on other metadata information.
        """

        # Keep track
        self.progress_marks.append(ProgressMarkNormalizingProject(datetime.now()))

        # Make sure we're relative path and not absolute path
        self.project.writeEntryBool("Paths", "Absolute", False)

        # Activate the Service Capabilities
        self.project.writeEntry("WMSServiceCapabilities", "/", True)

        # Get the metadata
        p_metadata = self.project.metadata()

        # Insert a Short Name
        self.project.writeEntry("WMSRootName", "/", _normalize_string(p_metadata.title()))

        # Insert a Title
        self.project.writeEntry("WMSServiceTitle", "/", p_metadata.title())

        # If French
        organization_name = config.WMS_ORGANIZATION_NAME_EN
        if self.qgis_project_lang == "fr":
            organization_name = config.WMS_ORGANIZATION_NAME_FR

        # Insert the Organization
        self.project.writeEntry("WMSContactOrganization", "/", organization_name)

        # Online resource
        self.project.writeEntry("WMSOnlineResource", "/", config.WMS_ONLINE_RESOURCE)

        # E-mail
        self.project.writeEntry("WMSContactMail", "/", config.WMS_CONTACT_EMAIL)

        # Fees
        self.project.writeEntry("WMSFees", "/", config.WMS_FEES)

        # Access Contraints
        self.project.writeEntry("WMSAccessConstraints", "/", config.WMS_ACCESS_CONSTRAINTS)

        # Write the keywords
        keys_list = []
        for k_list in p_metadata.keywords().values():
            keys_list.extend(k_list)

        # Keywords
        self.project.writeEntry("WMSKeywordList", "/", keys_list)

        # CRS Restrictions
        self.project.writeEntry("WMSCrsList", "/", config.WMS_CRS_LIST)

        # Get FeatureInfo from settings
        self.project.writeEntry("WMSFeatureInfoUseAttributeFormSettings", "/", True)

        # Get the group layers
        group_layers = self.get_group_layers_all(False)

        # For each group layer
        for gl in group_layers:
            # Write the layer title
            gl.setCustomProperty("wmsShortName", _normalize_string(gl.name()))
            gl.setCustomProperty("wmsTitle", gl.name())

        # Get the layers that we're exporting
        vector_layers = self.get_layers_in_order_only_export()

        # Flag WFS layers in the list
        self.project.writeEntry("WFSLayers", "/", [layer.id() for layer in vector_layers])

        # Set trust layer metadata
        self.project.setTrustLayerMetadata(True)

        # Read the WMS Precision
        wms_precision = self.project.readEntry("WMSPrecision", "/")

        # For each vector layer
        for vl in vector_layers:
            # Write the layer precision
            self.project.writeEntry("WFSLayersPrecision", f"/{vl.id()}", wms_precision[0])

            ## Check the short name (not doing this anymore)
            #if not vl.shortName():
            #    vl.setShortName(_normalize_string(vl.name()))

            # Write the layer title
            vl.setTitle(vl.name())

            # Get the metadata of the layer
            l_metadata = vl.metadata()

            # Write the abstract
            vl.setAbstract(l_metadata.abstract())

            # Write the keywords
            keys_list = []
            for k_list in l_metadata.keywords().values():
                keys_list.extend(k_list)
            vl.setKeywordList(",".join(keys_list))

            # Write attribution title
            vl.setAttribution(organization_name)

            # Create the simplification method
            simp_method = QgsVectorSimplifyMethod()
            simp_method.setThreshold(1.05)
            simp_method.setSimplifyAlgorithm(0)
            simp_method.setForceLocalOptimization(False)
            vl.setSimplifyMethod(simp_method)

            # Toggle scale visibility and set min/max
            vl.setScaleBasedVisibility(True)
            vl.setMinimumScale(config.MINIMUM_SCALE)
            vl.setMaximumScale(config.MAXIMUM_SCALE)

    def export_vector_layers_in_db(self, exported: list):
        """
        Adds the layers to the database
        """

        # If the project has been initialized
        if self.project:
            # Keep track
            self.progress_marks.append(ProgressMarkExportingVectorLayers(datetime.now()))

            # For each layer in the map
            for layer in self.get_layers_in_order_only_export():
                # Get the table name
                table_name = self._format_table_name(layer)

                # Check if the table exists
                table_exists = self.qgis_db.table_exists(table_name)

                # If the layer doesn't already exist
                if not table_exists:
                    # Get layer Geometry Type
                    geom_type = layer.geometryType()

                    # Generate the uri
                    uri = self.qgis_db.gen_uri_export(self.qgis_db.schema, table_name, geom_type)

                    # Export the layer in database
                    error, message = QgsVectorLayerExporter.exportLayer(layer, uri, DATA_PROVIDER_KEY, layer.crs())

                    # If success
                    if error == 0:
                        # Keep track
                        self.progress_marks.append(ProgressMarkExportedVectorLayers(datetime.now(), layer.name()))
                        exported.append(table_name)

                        # Keep track
                        self.progress_marks.append(ProgressMarkCreatingSpatialIndex(datetime.now(), table_name))

                        # Connect to the database
                        with self.qgis_db.open_conn() as conn:
                            # Open a cursor
                            with conn.cursor() as cur:
                                # Building spatial index on it
                                self.qgis_db.create_spatial_index_go(cur, self.qgis_db.schema, table_name, self._format_geometry_index_name(table_name))

                            # Commit
                            conn.commit()

                        # Keep track
                        self.progress_marks.append(ProgressMarkCreatedSpatialIndex(datetime.now(), table_name))

                    else:
                        # If the message is a about export failed
                        if "Creation of data source" in message:
                            # Throws specific exception
                            raise ExportFailTableExists(layer.name(), table_name)

                        else:
                            raise FailedExportLayer(layer.name(), table_name, message)

                else:
                    # Table already exists. At this stage, it's possible and we just skip, it's been validated before
                    self.progress_marks.append(ProgressMarkExportedSkippedVectorLayers(datetime.now(), layer.name()))
                    pass

            # Done
            return True

        else:
            # Throws
            raise ProjectNotInitialized("export_layers_in_db")

    def backup_layers(self, exported: list):
        """
        Loops on every layer in the table of contents and when a layer points to data in the database, it creates a backup of the data
        """

        # If the project has been initialized
        if self.project:
            # Keep track
            self.progress_marks.append(ProgressMarkBackingUpVectorLayers(datetime.now()))

            # Connect to the database
            with self.qgis_db.open_conn() as conn:
                # Open a cursor
                with conn.cursor() as cur:
                    # For each layer in the map
                    for layer in self.get_layers_in_database(True):
                        # Get the table name
                        table_name_og = self._format_table_name(layer)
                        table_name_new = f"{BACKUP_PREFIX}{table_name_og}"

                        # If the backup already exist
                        if self.qgis_db.table_exists(table_name_new):
                            # Remove the table
                            self.qgis_db.drop_table_go(cur, self.qgis_db.schema, table_name_new)

                        # Drop index
                        self.qgis_db.drop_index_go(cur, self.qgis_db.schema, self._format_geometry_index_name(table_name_og))

                        # Rename the table
                        self.qgis_db.rename_table_go(cur, self.qgis_db.schema, table_name_og, table_name_new)

                        # Keep track
                        self.progress_marks.append(ProgressMarkCreatingSpatialIndex(datetime.now(), table_name_new))

                        # Recreate spatial index
                        self.qgis_db.create_spatial_index_go(cur, self.qgis_db.schema, table_name_new, self._format_geometry_index_name(table_name_new))

                        # Keep track
                        self.progress_marks.append(ProgressMarkCreatedSpatialIndex(datetime.now(), table_name_new))

                        # Rename
                        self.qgis_db.rename_layer_style_go(cur, self.qgis_db.schema, table_name_og, table_name_new)

                        # Keep track
                        exported.append(table_name_new)

                # Commit
                conn.commit()

            # Done
            return True

        else:
            # Throws
            raise ProjectNotInitialized("backup_layers")

    def db_rename_and_recreate_index(self, schema: str, table_name_og: str, table_name_new: str):
        """
        Utility function to quickly open an SQL connection and drop the table with the given name.
        """

        # Connect to the database
        with self.qgis_db.open_conn() as conn:
            # Open a cursor
            with conn.cursor() as cur:
                # Drop index
                self.qgis_db.drop_index_go(cur, schema, self._format_geometry_index_name(table_name_og))

                # Rename the table
                self.qgis_db.rename_table_go(cur, schema, table_name_og, table_name_new)

                # Keep track
                self.progress_marks.append(ProgressMarkCreatingSpatialIndex(datetime.now(), table_name_new))

                # Recreate spatial index
                self.qgis_db.create_spatial_index_go(cur, self.qgis_db.schema, table_name_new, self._format_geometry_index_name(table_name_new))

                # Keep track
                self.progress_marks.append(ProgressMarkCreatedSpatialIndex(datetime.now(), table_name_new))

            # Save
            conn.commit()

    def db_rename_layer_style(self, schema: str, table_name_og: str, table_name_new: str):
        """
        Utility function to quickly open an SQL connection and rename a layer style for a given table name.
        """

        # Connect to the database
        with self.qgis_db.open_conn() as conn:
            # Open a cursor
            with conn.cursor() as cur:
                # Rename
                self.qgis_db.rename_layer_style_go(cur, schema, table_name_og, table_name_new)

            # Save
            conn.commit()

    def db_quick_drop(self, schema: str, table_name: str):
        """
        Utility function to quickly open an SQL connection and drop the table with the given name.
        """

        # Connect to the database
        with self.qgis_db.open_conn() as conn:
            # Open a cursor
            with conn.cursor() as cur:
                # Remove the table
                self.qgis_db.drop_table_go(cur, schema, table_name)

            # Save
            conn.commit()

    def remove_layers_from_db(self):
        """
        Removes the layers from the database
        """

        # If the project has been initialized
        if self.project:
            # Keep track
            self.progress_marks.append(ProgressMarkDeletingVectorLayers(datetime.now()))

            # Connect to the database
            with self.qgis_db.open_conn() as conn:
                # Open a cursor
                with conn.cursor() as cur:
                    # For each layer in the map
                    for layer in self.get_layers_in_database(False):
                        # Remove the table
                        self.qgis_db.drop_table_go(cur, self.qgis_db.schema, self._format_table_name(layer))

                # Save
                conn.commit()

            # Done
            return True

        else:
            # Throws
            raise ProjectNotInitialized("remove_layers_from_db")

    def backup_project_layers(self, project_id: str, schema: str):
        """
        Backups the given project and all its layers which are pointing to data stored inside our database.
        When the backup is completed, the original QGIS project is deleted.
        """

        # Init the schema and the project in database
        self.init_schema(schema)
        self.init_project_from_db(project_id)

        # Backup the project
        backup_name = self.backup_project()

        # If English project
        backup_layer_names = []
        if self.qgis_project_lang == "en":
            # Backup the layers
            self.backup_layers(backup_layer_names)

        # Delete the original project
        self.delete_project_from_db()

        # Return the informations regarding the backup
        return [backup_name, backup_layer_names]

    def backup_project(self):
        """
        Backups a project by saving the project to another name prefixed by "_bck_".
        """

        # Make a backup of project
        backup_name = f"{BACKUP_PREFIX}{self.qgis_project_id}"
        self.copy_project(backup_name)
        return backup_name

    def backup_project_layers_clear(self, backup_name: str, backup_layer_names: list):
        """
        Clears the backuped project and the backed up data tables.
        This function is called when the update process completed succesfully and the backups aren't necessary anymore.
        """

        # Keep track
        self.progress_marks.append(ProgressMarkBackUpClearing(datetime.now()))

        # Delete the project
        self.delete_project_from_db_as(self.qgis_db.schema, backup_name)

        # Connect to the database
        with self.qgis_db.open_conn() as conn:
            # Open a cursor
            with conn.cursor() as cur:
                # For each table name
                for table_name in backup_layer_names:
                    # Delete the layer style
                    self.qgis_db.delete_layer_style_go(cur, self.qgis_db.schema, table_name)

                    # Remove the table
                    self.qgis_db.drop_table_go(cur, self.qgis_db.schema, table_name)

            # Commit
            conn.commit()

    def set_layers_data_source(self):
        """
        Sets Layer Data Source to new database location
        """

        # If the project has been initialized
        if self.project:
            # Keep track
            self.progress_marks.append(ProgressMarkChangingLayerDatasource(datetime.now()))

            # For each layer in the map
            for layer in self.get_layers_in_order_only_export():
                # Get layer geometry type
                geom_type = layer.geometryType()

                # Get the table name
                table_name = self._format_table_name(layer)

                # Generate the uri
                uri = self.qgis_db.gen_uri_data_source_srid(self.qgis_db.schema, table_name, geom_type, PY_QGIS._format_crs_epsg(layer.crs().authid()))

                # Go
                layer.setDataSource(uri, layer.name(), DATA_PROVIDER_KEY)

                # Print
                print(f">>The Layer '{layer.name()}' data source has been changed to '{table_name}' in the QGIS project file")

            # Done
            return True

        else:
            # Throws
            raise ProjectNotInitialized("set_layers_data_source")

    def save_layer_styles_in_db(self, layers_saved: list):
        """
        Saves layer style to CDTK Postgres DB
        """

        # If the project has been initialized
        if self.project:
            # Keep track
            self.progress_marks.append(ProgressMarkSavingStyles(datetime.now()))

            # For each layer in the map
            for layer in self.get_layers_in_database(True):
                # Get the style name
                style_name = self._format_style_name(layer)

                # Save it
                self.save_layer_style_in_database(layer, style_name)

                # Keep track
                layers_saved.append(layer)

        else:
            # Throws
            raise ProjectNotInitialized("save_layer_styles_in_db")


        ##################################
        # # OLD WAY
        # #style_id = layer.listStylesInDatabase()[1][styles.index(style_name)]
        # #layer.saveStyleToDatabase(style_name, "Default style for {}".format(layer.name()), True, "")

        # # Generate the uri
        # uri_generic = self.gen_uri_base()

        # # Fetch the styles in the database
        # style_ids = []
        # style_names = []
        # style_descs = []
        # error = ""
        # count = QgsProviderRegistry.instance().listStyles(DATA_PROVIDER_KEY, uri_generic, style_ids, style_names, style_descs, error)
        # print(str(len(style_ids)))
        # print(error)

        # # Fetch the styles
        # #[count, style_ids, style_names, style_descs, error] = layer.listStylesInDatabase()

        # # Depending if the style exists already or not
        # action = "added"
        # if style_name in style_names:
        #     action = "udpated"
        #     # Delete the style (replacing it and we don't want the pop up window)
        #     QgsProviderRegistry.instance().deleteStyleById(DATA_PROVIDER_KEY, uri_generic,
        #                                                    style_ids[style_names.index(style_name)], error)
        #######################

        #print(f">>Style '{style_name}' has been {action} in the CDTK Database")

        # Done
        return True

    def delete_layer_styles_from_db(self):
        """
        Saves layer style to CDTK Postgres DB
        """

        # If the project has been initialized
        if self.project:
            # Keep track
            self.progress_marks.append(ProgressMarkDeletingStyles(datetime.now()))

            # For each layer in the map
            for layer in self.get_layers_in_database(False):
                # Get the style name
                style_name = self._format_style_name(layer)

                # Delete it
                self.delete_layer_style_from_db(layer, style_name)

        else:
            # Throws
            raise ProjectNotInitialized("delete_layer_styles_from_db")



