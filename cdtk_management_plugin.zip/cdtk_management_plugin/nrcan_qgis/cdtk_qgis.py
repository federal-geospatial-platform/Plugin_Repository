# If you are not inside a QGIS console you first need to import
# qgis and PyQt classes you will use in this script as shown below

# System imports
from enum import Enum
from datetime import datetime

# QGIS imports
from qgis.core import QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsVectorSimplifyMethod # type: ignore
from qgis.core import QgsProjectMetadata, QgsLayerMetadata, QgsVectorLayer, QgsRasterLayer # type: ignore
from qgis.core import QgsDataSourceUri # type: ignore

# Application imports
import config, py_qgis as PY_QGIS
from core import util
from core.lib.logger import *
from core.lib.qgis_progress_marks import *
from core.lib.qgis_warnings import *
from core.lib.qgis_exceptions import *
from nrcan_qgis.lib.layer_style import LayerStyle

# Constant
DATA_PROVIDER_KEY = "postgres"
BACKUP_PREFIX = "_"

class OperationMode(Enum):
    VALIDATE = 0
    PUBLISH = 1
    REPUBLISH = 2
    UNPUBLISH = 3


class CdtkPyQgis(PY_QGIS.PyQgis):
    """
    A CDTK PyQGIS management class
    """

    def __init__(self, qgis_install_path: str) -> None:
        """
        Constructor

        :param qgis_install_path: The path to QGIS install
        """

        LOG.trace_func()

        super().__init__(qgis_install_path)
        self.dataset_name: str | None = None


    def init_dataset_name(self, dataset_name: str) -> None:
        """
        Initializes the dataset name
        """
        LOG.trace_func()

        self.dataset_name = dataset_name


    def get_layer_source_name_with_dataset_prefix(self, layer) -> str:
        # Get the source name as is
        table_name: str | None = PY_QGIS.get_layer_source_name(layer)

        # Format it with the dataset_name prefix
        return util.format_oapi_table_name(self.dataset_name or "", table_name or "")


    def _format_style_name(self, layer: QgsVectorLayer) -> str:
        """
        Helper function to format the style name based on the layer name
        """

        # If project initialized
        if self.qgis_project_id_short and self.qgis_project_lang:
            # Redirect
            return util.normalize_string(util.format_oapi_table_name(self.qgis_project_id_short, layer.shortName()) + "_" + self.qgis_project_lang)
        raise ProjectNotInitialized("_format_style_name")


    def _format_geometry_index_name(self, table_name: str) -> str:
        """
        Helper function to format the geometry index based on the table name
        """

        return table_name + "_geom_idx"


    def get_info_project(self, admin_mode: bool = False) -> dict:
        """
        Gets the information on a project
        """
        LOG.trace_func()

        # If project is defined
        if self.project:
            # The results that will be returned
            return {
                'qgis_version': PY_QGIS.get_version().text(),
                'project_version': self.project.lastSaveVersion().text(),
                'project': self.qgis_project_id,
                'project_title': self.project.title(),
                'crs': self.get_crs(),
                'layers': self.get_layers_status(admin_mode)
            }

        raise ProjectNotInitialized("get_info_project")


    def get_layers_status(self, admin_mode: bool) -> list[dict]:
        """
        Gets a list of summary-dictionaries representing the layers in the project
        """
        LOG.trace_func()

        # The layers to be returned
        layers: list[dict] = []

        # If the project has been initialized
        if self.project:
            # For each layer in the map
            for layer in self.get_layers_in_order(None):
                # Get the layer information status
                layer_info: dict = self.get_layer_status(layer, admin_mode)

                # Append the layers info to the list
                layers.append(layer_info)

            # Return the layers info
            return layers

        else:
            # Throws
            raise ProjectNotInitialized("get_layers")


    def get_layer_status(self, layer: Any, admin_mode: bool) -> dict:
        LOG.trace_func()

        # Get the data provider
        data_prov = layer.dataProvider()

        # Decode the source
        source_data: dict = PY_QGIS.get_layer_properties(layer)
        source_data_formatted: dict = {}
        for k in source_data:
            if admin_mode or k.lower() != "password":
                source_data_formatted[k] = str(source_data[k])

        # Get the metadata of the layer
        l_metadata = layer.metadata()

        # Write the keywords
        keys_list: list[str] = []
        for k_list in l_metadata.keywords().values():
            keys_list.extend(k_list)

        layer_extent = None
        layer_extent_4326 = None
        try:
            # Get the layer extent
            layer_extent = layer.extent()

            # Reproject to 4326
            geo2proj = QgsCoordinateTransform(layer.crs(), QgsCoordinateReferenceSystem(4326), self.project)
            layer_extent_4326 = geo2proj.transform(layer_extent)

        except Exception as err:
            # Error
            raise LayerFailedToGetExtent(layer.name(), PY_QGIS._format_crs_epsg(layer.crs().authid()))

        # Grab layer info
        layer_info: dict = {
            'is_valid': data_prov.isValid(),
            'type': layer.type(),
            'name': layer.name(),
            'crs': PY_QGIS._format_crs_epsg(layer.crs().authid()),
            'uri': source_data_formatted,
            'abstract': l_metadata.abstract(),
            'keywords': keys_list,
            'extent': {
                'xMinimum': layer_extent.xMinimum(),
                'xMaximum': layer_extent.xMaximum(),
                'yMinimum': layer_extent.yMinimum(),
                'yMaximum': layer_extent.yMaximum()
            },
            'extent4326': {
                'xMinimum': layer_extent_4326.xMinimum(),
                'xMaximum': layer_extent_4326.xMaximum(),
                'yMinimum': layer_extent_4326.yMinimum(),
                'yMaximum': layer_extent_4326.yMaximum()
            },
            'temporal': {
                'isActive': layer.temporalProperties().isActive(),
                'begin': layer.temporalProperties().fixedTemporalRange().begin().toString("yyyy-MM-dd") if layer.temporalProperties().fixedTemporalRange().begin().isValid() else None,
                'end': layer.temporalProperties().fixedTemporalRange().end().toString("yyyy-MM-dd") if layer.temporalProperties().fixedTemporalRange().end().isValid() else None
            },
            'styles': layer.styleManager().styles()
        }

        # Defaults
        layer_info['data_exists_in_database'] = False
        layer_info['style_exists_in_database'] = "no"
        #layer_info['name_short'] = layer.shortName()

        # Validate the layer short name is valid
        #layer_info['name_valid'] = "valid" if len(layer_info['name_short']) > 0 and len(layer_info['name_short']) <= LAYER_NAME_MAX_LENGTH else "invalid"

        # Get the schema name (even useful for coverage)
        layer_info['name_schema'] = PY_QGIS.get_layer_schema_name(layer) or ""

        # Get the table name (even useful for coverage)
        layer_info['name_table'] = PY_QGIS.get_layer_source_name(layer) or ""
        layer_info['name_table_db'] = self.get_layer_source_name_with_dataset_prefix(layer)

        # If the layer data is valid, the layer is Vector type
        if data_prov.isValid() and isinstance(layer, QgsVectorLayer):
            # Get layer id field
            layer_info['type'] = "feature"
            layer_info['is_geopackage'] = PY_QGIS.get_layer_is_geopackage(layer)
            layer_info['is_geopackage_in_input'] = self.get_layer_is_geopackage_in_same_folder(layer)
            layer_info['geom_type'] = PY_QGIS.get_geometry_type_string(layer.geometryType())
            layer_info['fields'] = [i.name() for i in data_prov.fields()]
            layer_info['fields_ids'] = self.get_layer_id_field_names(layer)
            layer_info['feature_count'] = data_prov.featureCount()

            # If data exists in the database
            if self.db_data and self.db_data.table_exists(layer_info['name_schema'], layer_info['name_table_db']):
                layer_info['data_exists_in_database'] = True

            # If the data points to a geopackage that was in the input package (it'll become a table in the database)
            if layer_info['is_geopackage_in_input']:
                # Check if the style already exists in the database
                if self.layer_style_exists_in_db(layer, self._format_style_name(layer)):
                    # If publishing for the same service dataset
                    layer_info['style_exists_in_database'] = "invalid"

            # Grab the layer id field names
            layer_info['fields_id_valid'] = len(layer_info['fields_ids']) == 1

            # Grab the layer styles
            #[count, style_ids, style_names, style_descs, error] = layer.listStylesInDatabase()
            #layer_info['styles'] = self.get_layer_styles(layer)

        # If the layer data is valid, the layer is Raster type
        if data_prov.isValid() and isinstance(layer, QgsRasterLayer):
            layer_info['type'] = "coverage"
            layer_info['units_per_pixel_x'] = layer.rasterUnitsPerPixelX()
            layer_info['units_per_pixel_y'] = layer.rasterUnitsPerPixelY()

        # Return the info
        return layer_info


    def get_layers_in_order_only_export(self) -> list:
        """
        Helper function to get the layers pointing to a geopackage in order.
        """
        LOG.trace_func()

        # Redirect
        return self.get_layers_in_order(lambda l: self.get_layer_is_geopackage_in_same_folder(l))


    def validate_project(self, operation: OperationMode, admin_mode: bool, internal: bool, supported_crs: list[int],
                         nb_projects: int, wants_wcs: bool, wants_wfs: bool, warnings: list, errors: list) -> dict:
        """
        Gets if the project is valid for a publication
        """
        LOG.trace_func()

        # If the project is initialized and project schema is set
        if self.qgis_project_id and self.project and self.db_qgis and self.qgis_project_schema:
            # Keep track
            self.progress_marks.append(ProgressMarkValidatingProjectExists(datetime.now(), self.qgis_project_id))

            # Get the project version
            project_version: PY_QGIS.QgsProjectVersion = self.project.lastSaveVersion()

            # Get the API QGIS Version
            qgis_api_version: PY_QGIS.QgsProjectVersion = PY_QGIS.get_version()

            # If our PyQGIS of the API is smaller than the version of the project
            if PY_QGIS.compare_version(qgis_api_version, project_version) < 0:
                util.validate_throws_or_append(ProjectVersionGreaterThanAPI(self.qgis_project_id,
                                                                            project_version.text(),
                                                                            qgis_api_version.text()), errors)

            # TODO: Get the real QGIS Server Version
            qgis_server_version: PY_QGIS.QgsProjectVersion = PY_QGIS.get_version()

            # If our QGIS Server is smaller than the version of the project
            if PY_QGIS.compare_version(qgis_server_version, project_version) < 0:
                util.validate_throws_or_append(ProjectVersionGreaterThanServer(self.qgis_project_id,
                                                                               project_version.text(),
                                                                               qgis_server_version.text()), errors)

            # If the project already exists
            proj_exists: bool = self.project_exists_in_db(self.qgis_project_schema, self.qgis_project_id)
            if operation == OperationMode.PUBLISH and proj_exists:
                util.validate_throws_or_append(ProjectAlreadyExists(self.qgis_project_id), errors)

            elif operation == OperationMode.REPUBLISH and not proj_exists:
                util.validate_throws_or_append(ProjectNotFoundFromDatabase(self.qgis_project_id, self.qgis_project_schema), errors)

            # In external mode, the layers are probably disconnected, for security reasons.
            # Make sure to connect them back to the database using the connection information from the secret
            if not internal:
                # Log
                LOG.debug("This project is external, make sure layers are connected to the external data source...")

                # For each layer
                for layer in self.get_layers_that_point_to_database(False):
                    # Log
                    LOG.debug(f"Processing layer '{layer.name()}'...")

                    # If all defined (should really be)
                    if self.db_host_data and self.db_port_data and self.db_user_data and self.db_password_data:
                        # Set the layer data source username and password
                        self.set_layer_data_source_host_user_pass(layer, self.db_host_data, self.db_port_data, self.db_user_data, self.db_password_data)

                        # Log
                        LOG.debug(f"Layer '{layer.name()}' connected to the external data source")

            # If the project has no title
            if not self.project.title():
                util.validate_throws_or_append(ProjectHasNoTitle(self.qgis_project_id), errors)

            # Keep track
            self.progress_marks.append(ProgressMarkValidatingProjectLayersCRS(datetime.now()))

            # Get layer status
            layers_status: list[dict] = self.get_layers_status(admin_mode)

            # Get the valid/invalid layers
            layers_valid = list(filter(lambda l: l['is_valid'] and (l['type'] == "feature" or l['type'] == "coverage"), layers_status))
            layers_invalid = list(filter(lambda l: not l['is_valid'], layers_status))

            # If no valid layers
            if len(layers_valid) == 0:
                util.validate_throws_or_append(ProjectNoValidLayers(self.qgis_project_id), errors)

            # For each invalid layer
            for l in layers_invalid:
                util.validate_throws_or_append(LayerInvalid(self.qgis_project_id, l['name']), errors)

            # Check if any layer in unsupported CRS
            layers_invalid_crs = list(filter(lambda l: int(l['crs']) not in supported_crs, layers_status))

            # For each layer with invalid crs
            for l in layers_invalid_crs:
                util.validate_throws_or_append(LayerUnsupportedCRS(l['name'], l['crs']), errors)

            # Check all layers have the same crs
            if len(layers_valid) > 0:
                first_crs = layers_valid[0]['crs']
                if not all(l['crs'] == first_crs for l in layers_valid):
                    util.validate_throws_or_append(LayerDifferentCRS(), errors)

            # if len(layers_diff_crs) > 0:
            #     # Check if it's an exception where the project is EPSG:3857 and the layers which aren't 3857 are all EPSG:4326
            #     project_in_3857: bool = self.get_crs() == "3857"
            #     layers_not_in_4326 = list(filter(lambda l: l['crs'] != "4326", layers_diff_crs))
            #     all_layers_in_4326: bool = len(layers_not_in_4326) == 0

            #     # It's an exception if the project is in 3857 and all layers which aren't 3857 are 4326
            #     exception_case: bool = project_in_3857 and all_layers_in_4326

            #     # If not an exception
            #     if not exception_case:
            #         # For each invalid layer
            #         for l in layers_diff_crs:
            #             validate_throws_or_append(LayerUnsupportedCRS(l['name'], l['crs']), errors)

            # # Get any layer having a invalid short names
            # layers_invalid_name = list(filter(lambda l: 'name_valid' in l and l['name_valid'] != "valid", layers_status))

            # # If any
            # if len(layers_invalid_name) > 0:
            #     # For each invalid layer
            #     for l in layers_invalid_name:
            #         validate_throws_or_append(LayerShortNameInvalid(l['name'], l['name_short']), errors)

            # Check if there is any WCS checked
            layer_wcs_ids, _ =  self.project.readListEntry("WCSLayers", "/")
            layer_wfs_ids, _ = self.project.readListEntry("WFSLayers", "/")

            # If the control file mentions about publishing WCS
            if wants_wcs:
                # If the list is empty, it's likely a mistake, raise error
                if len(layer_wcs_ids) == 0:
                    util.validate_throws_or_append(LayerNotMarkedForPublication('WCS'), errors)

            else:
                # If the list has ids, it's likely a mistake, raise error
                if len(layer_wcs_ids) > 0:
                    util.validate_throws_or_append(LayerMarkedForPublication('WCS', layer_wcs_ids), errors)

            # If the control file mentions about publishing WFS
            if wants_wfs:
                # Check if there is any WCS checked
                # If the list is empty, it's likely a mistake, raise error
                if len(layer_wfs_ids) == 0:
                    util.validate_throws_or_append(LayerNotMarkedForPublication('WFS'), errors)

            else:
                # If the list has ids, it's likely a mistake, raise error
                if len(layer_wfs_ids) > 0:
                    util.validate_throws_or_append(LayerMarkedForPublication('WFS', layer_wfs_ids), errors)

            # Get any feature layer having bad field ids
            layers_bad_field_ids = list(filter(lambda l: l['type'] == "feature" and not l['fields_id_valid'], layers_status))

            # If any
            if len(layers_bad_field_ids) > 0:
                # For each invalid layer
                for l in layers_bad_field_ids:
                    util.validate_throws_or_append(LayerFieldIDInvalid(l['name']), errors)

            # # Get the list of layers in geopackage or coverage
            # layers_geop = list(filter(lambda l: l['type'] == "coverage" or (l['type'] == 'feature' and l['is_geopackage']), layers_status))

            # # Get the list of table names (the short names)
            # table_names: list[str] = [f['name_table'] for f in layers_geop]

            # # If any duplicates
            # counts = Counter(table_names)
            # counts_dict = dict(counts)
            # for cd in counts_dict:
            #     if counts_dict[cd] > 1:
            #         validate_throws_or_append(ProjectsShortNameDuplicated(self.qgis_project_id, cd), errors)

            # Get any source name that are invalid
            #sources_invalid = list(filter(lambda l: 'source_formatted_valid' in l and l['source_formatted_valid'] == "invalid", layers_status))

            ## If any sources are invalid
            #if len(sources_invalid) > 0:
            #    # For each invalid layer
            #    for layer_name in [l['name'] for l in sources_invalid]:
            #        validate_throws_or_append(DataSourceInvalid(layer_name), errors)

            # If publishing
            if operation == OperationMode.PUBLISH:
                # If running with data going in our database
                if internal:
                    # If validating the english project or only one project being processed
                    if self.qgis_project_lang == "en" or nb_projects == 1:
                        # Keep track
                        self.progress_marks.append(ProgressMarkValidatingDataAlreadyExists(datetime.now()))

                        # Get any layer having pointing to data that already exists in the database
                        layers_data_exist = list(filter(lambda l: 'data_exists_in_database' in l and l['data_exists_in_database'], layers_status))

                        # If any
                        if len(layers_data_exist) > 0:
                            # For each invalid layer
                            for layer_name in [l['name'] for l in layers_data_exist]:
                                util.validate_throws_or_append(DataAlreadyExists(layer_name), errors)

                # Keep track
                self.progress_marks.append(ProgressMarkValidatingStylesAlreadyExists(datetime.now()))

                # Get any layer having their styles already in the database
                layers_styles_exist = list(filter(lambda l: 'style_exists_in_database' in l and l['style_exists_in_database'] == "invalid", layers_status))

                # If any
                if len(layers_styles_exist) > 0:
                    # For each invalid layer
                    for layer_name in [l['name'] for l in layers_styles_exist]:
                        util.validate_throws_or_append(StyleAlreadyExists(layer_name), errors)

            # Return the layers status
            return {
                'project_id': self.qgis_project_id,
                'crs': self.get_crs(),
                'qgis_version': project_version.text(),
                'layers': layers_status
            }

        # No info possible
        return {}


    def normalize_project(self, wants_wcs: bool, wants_wfs: bool) -> None:
        """
        Automatically normalizes the current project and its layers by filling in some metadata information based on other metadata information.
        """
        LOG.trace_func()

        # If the project is initialized
        if self.project:
            # Log
            LOG.info(f"Normalizing project...")

            # Keep track
            self.progress_marks.append(ProgressMarkNormalizingProject(datetime.now()))

            # Make sure we're relative path and not absolute path
            self.project.writeEntryBool("Paths", "Absolute", False)

            # Activate the Service Capabilities
            self.project.writeEntry("WMSServiceCapabilities", "/", True)

            # Get the metadata
            p_metadata: QgsProjectMetadata = self.project.metadata()

            # Insert a Short Name
            self.project.writeEntry("WMSRootName", "/", util.normalize_string(p_metadata.title()))

            # Insert a Title
            self.project.writeEntry("WMSServiceTitle", "/", p_metadata.title())

            # If French
            organization_name = config.WMS_ORGANIZATION_NAME_EN
            if self.qgis_project_lang == "fr":
                organization_name = config.WMS_ORGANIZATION_NAME_FR

            # Insert the Organization
            self.project.writeEntry("WMSContactOrganization", "/", organization_name)

            # Online resource
            self.project.writeEntry("WMSOnlineResource", "/", config.WMS_ONLINE_RESOURCE)

            # E-mail
            self.project.writeEntry("WMSContactMail", "/", config.WMS_CONTACT_EMAIL)

            # Fees
            self.project.writeEntry("WMSFees", "/", config.WMS_FEES)

            # Access Contraints
            self.project.writeEntry("WMSAccessConstraints", "/", config.WMS_ACCESS_CONSTRAINTS)

            # Write the keywords
            keys_list = []
            for k_list in p_metadata.keywords().values():
                keys_list.extend(k_list)

            # Keywords
            self.project.writeEntry("WMSKeywordList", "/", keys_list)

            # CRS Restrictions
            self.project.writeEntry("WMSCrsList", "/", config.WMS_CRS_LIST)

            # Get FeatureInfo from settings
            self.project.writeEntry("WMSFeatureInfoUseAttributeFormSettings", "/", True)

            # Get the group layers
            group_layers: list = self.get_group_layers_all()

            # For each group layer
            for gl in group_layers:
                # Write the layer title
                gl.setCustomProperty("wmsShortName", util.normalize_string(gl.name()))
                gl.setCustomProperty("wmsTitle", gl.name())

            # Get the vector layers
            exp_vec_layers = self.get_layers_vector()

            # If we don't want any WCS
            if not wants_wcs:
                # Make sure none are checked
                self.project.writeEntry("WCSLayers", "/", [])

            # If we don't want any WFS
            if not wants_wfs:
                # Make sure none are checked
                self.project.writeEntry("WFSLayers", "/", [])

            # Flag WFS layers in the list for publication
            #self.project.writeEntry("WFSLayers", "/", [layer.id() for layer in exp_wfs_layers])

            # Get the WCS compatible layers (rasters and some vectors)
            #raster_layers: list = self.get_layers_wcs_compatible()

            # Flag WCS layers in the list for publication
            #self.project.writeEntry("WCSLayers", "/", [layer.id() for layer in raster_layers])

            # Set trust layer metadata
            self.project.setTrustLayerMetadata(True)

            # Read the WMS Precision
            wms_precision = self.project.readEntry("WMSPrecision", "/")

            # For each vector layer to publish
            for vl in exp_vec_layers:
                # Log
                LOG.debug(f"Normalizing layer '{vl.name()}'...")

                # Write the layer precision
                self.project.writeEntry("WFSLayersPrecision", f"/{vl.id()}", wms_precision[0])

                ## Check the short name (not doing this anymore)
                #if not vl.shortName():
                #    vl.setShortName(normalize_string(vl.name()))

                # Write the layer title
                vl.setTitle(vl.name())

                # Get the metadata of the layer
                l_metadata: QgsLayerMetadata = vl.metadata()

                # Write the abstract
                vl.setAbstract(l_metadata.abstract())

                # Write the keywords
                keys_list: list = []
                for k_list in l_metadata.keywords().values():
                    keys_list.extend(k_list)
                vl.setKeywordList(",".join(keys_list))

                # Write attribution title
                vl.setAttribution(organization_name)

                # Create the simplification method
                simp_method = QgsVectorSimplifyMethod()
                simp_method.setThreshold(1.05)
                simp_method.setSimplifyAlgorithm(QgsVectorSimplifyMethod.Distance)
                simp_method.setForceLocalOptimization(False)
                vl.setSimplifyMethod(simp_method)

                # If the scale visibility is not set, set it to custom min/max
                if not vl.hasScaleBasedVisibility():
                    # Toggle scale visibility and set min/max
                    vl.setScaleBasedVisibility(True)
                    vl.setMinimumScale(config.MINIMUM_SCALE)
                    vl.setMaximumScale(config.MAXIMUM_SCALE)


    def export_vector_layers_in_db(self, data_import_process: str, schema: str, pk_key: str, geom_key: str, exported: list) -> bool:
        """
        Adds the layers to the database
        """
        LOG.trace_func()

        # If the project has been initialized
        if self.project and self.db_data:
            # Keep track
            self.progress_marks.append(ProgressMarkExportingVectorLayers(datetime.now()))

            # Get all layers to be exported
            layers: list = self.get_layers_in_order_only_export()

            # For each layer in the map
            for layer in layers:
                # Log
                LOG.info(f"Checking to export data referenced by layer '{layer.name()}'...")

                # Tweak the table name with the dataset name
                table_name: str = self.get_layer_source_name_with_dataset_prefix(layer)

                # Check if the table exists
                table_exists: bool = self.db_data.table_exists(schema, table_name)

                # If the layer doesn't already exist
                if not table_exists:
                    # Get the layer status information
                    layer_info: dict = self.get_layer_status(layer, True)

                    # If the source is in a geopackage
                    if layer_info['is_geopackage']:
                        # Copy the table from the Geopackage file to the PostGis database
                        self.copy_gpkg_tables_to_postgis(data_import_process, schema, layer_info['uri']['path'], layer_info['uri']['layerName'], table_name, pk_key, geom_key)

                        # Add to the export list
                        exported.append(table_name)

                    else:
                        # Source isn't geopackage
                        self.progress_marks.append(ProgressMarkExportedSkippedVectorLayersNotGeopackage(datetime.now(), layer.name()))

                else:
                    # Table already exists. At this stage, it's possible and we just skip, it's been validated before
                    self.progress_marks.append(ProgressMarkExportedSkippedVectorLayersAlreadyExists(datetime.now(), layer.name()))

            # Done
            return True

        else:
            # Throws
            raise ProjectNotInitialized("export_vector_layers_in_db")


    def backup_layers(self, exported: list[str]) -> bool:
        """
        Loops on every layer in the table of contents and when a layer points to data in the database, it creates a backup of the data
        """
        LOG.trace_func()

        # If the project has been initialized
        if self.project and self.db_qgis and self.db_data:
            # Keep track
            self.progress_marks.append(ProgressMarkBackingUpVectorLayers(datetime.now()))

            # Connect to the database
            with self.db_data.open_conn() as conn:
                # Open a cursor
                with conn.cursor() as cur:
                    # For each layer in the map that points to a database
                    for layer in self.get_layers_that_point_to_database(True):
                        # Get the schema name
                        schema_name: str = PY_QGIS.get_layer_schema_name(layer) or ""

                        # Get the table name
                        table_name_og: str = PY_QGIS.get_layer_source_name(layer) or ""
                        table_name_new: str = f"{BACKUP_PREFIX}{table_name_og}"

                        # If the backup already exist
                        if self.db_data.table_exists(schema_name, table_name_new):
                            # Remove the table
                            self.db_data.drop_table_go(cur, schema_name, table_name_new)

                        # Drop index
                        self.db_data.drop_index_go(cur, schema_name, self._format_geometry_index_name(table_name_og))

                        # Rename the table
                        self.db_data.rename_table_go(cur, schema_name, table_name_og, table_name_new)

                        # Keep track
                        self.progress_marks.append(ProgressMarkCreatingSpatialIndex(datetime.now(), table_name_new))

                        # Recreate spatial index
                        self.db_data.create_spatial_index_go(cur, schema_name, table_name_new, self._format_geometry_index_name(table_name_new))

                        # Keep track
                        self.progress_marks.append(ProgressMarkCreatedSpatialIndex(datetime.now(), table_name_new))

                        # Rename
                        self.db_qgis.rename_layer_style_go(cur, schema_name, table_name_og, table_name_new)

                        # Keep track
                        exported.append(table_name_new)

                # Commit
                conn.commit()

            # Done
            return True

        else:
            # Throws
            raise ProjectNotInitialized("backup_layers")


    def db_rename_and_recreate_index(self, schema: str, table_name_og: str, table_name_new: str) -> None:
        """
        Utility function to quickly open an SQL connection and drop the table with the given name.
        """
        LOG.trace_func()

        # If schema initialized
        if self.db_data:
            # Connect to the database
            with self.db_data.open_conn() as conn:
                # Open a cursor
                with conn.cursor() as cur:
                    # Drop index
                    self.db_data.drop_index_go(cur, schema, self._format_geometry_index_name(table_name_og))

                    # Rename the table
                    self.db_data.rename_table_go(cur, schema, table_name_og, table_name_new)

                    # Keep track
                    self.progress_marks.append(ProgressMarkCreatingSpatialIndex(datetime.now(), table_name_new))

                    # Recreate spatial index
                    self.db_data.create_spatial_index_go(cur, schema, table_name_new, self._format_geometry_index_name(table_name_new))

                    # Keep track
                    self.progress_marks.append(ProgressMarkCreatedSpatialIndex(datetime.now(), table_name_new))

                # Save
                conn.commit()


    def db_rename_layer_style(self, schema: str, table_name_og: str, table_name_new: str) -> None:
        """
        Utility function to quickly open an SQL connection and rename a layer style for a given table name.
        """
        LOG.trace_func()

        # If initialized
        if self.db_qgis:
            # Connect to the database
            with self.db_qgis.open_conn() as conn:
                # Open a cursor
                with conn.cursor() as cur:
                    # Rename
                    self.db_qgis.rename_layer_style_go(cur, schema, table_name_og, table_name_new)

                # Save
                conn.commit()

        else:
            # Throws
            raise ProjectNotInitialized("db_rename_layer_style")


    def db_quick_drop(self, schema: str, table_name: str) -> None:
        """
        Utility function to quickly open an SQL connection and drop the table with the given name.
        """
        LOG.trace_func()

        # If initialized
        if self.db_data:
            # Connect to the database
            with self.db_data.open_conn() as conn:
                # Open a cursor
                with conn.cursor() as cur:
                    # Remove the table
                    self.db_data.drop_table_go(cur, schema, table_name)

                # Save
                conn.commit()

        else:
            # Throws
            raise ProjectNotInitialized("db_quick_drop")


    def remove_layers_from_db(self) -> bool:
        """
        Removes the layers from the database
        """
        LOG.trace_func()

        # If the project has been initialized
        if self.db_data:
            # Keep track
            self.progress_marks.append(ProgressMarkDeletingVectorLayers(datetime.now()))

            # Connect to the database
            with self.db_data.open_conn() as conn:
                # Open a cursor
                with conn.cursor() as cur:
                    # For each layer in the map that points to a database
                    for layer in self.get_layers_that_point_to_database(False):
                        # Get the layer schema name
                        schema_name: str | None = PY_QGIS.get_layer_schema_name(layer)

                        # Get the layer source name
                        table_name: str | None = PY_QGIS.get_layer_source_name(layer)

                        # If found
                        if schema_name and table_name:
                            # Remove the table
                            self.db_data.drop_table_go(cur, schema_name, table_name)

                # Save
                conn.commit()

            # Done
            return True

        else:
            # Throws
            raise ProjectNotInitialized("remove_layers_from_db")


    def backup_project_layers(self, project_id: str, schema: str, dataset_name: str, internal: bool) -> list:
        """
        Backups the given project and all its layers which are pointing to data stored inside our database.
        When the backup is completed, the original QGIS project is deleted.
        """
        LOG.trace_func()

        # Init the schema and the project in database
        self.init_dataset_name(dataset_name)
        self.init_project_from_db(schema, project_id)

        # Backup the project
        backup_name: str = self.backup_project()

        # If internal
        backup_layer_names: list[str] = []
        if internal:
            # If English project
            if self.qgis_project_lang == "en":
                # Backup the layers
                self.backup_layers(backup_layer_names)

        # Delete the original project
        self.delete_project_from_db()

        # Return the informations regarding the backup
        return [backup_name, backup_layer_names]


    def backup_project(self) -> str:
        """
        Backups a project by saving the project to another name prefixed by "_bck_".
        """
        LOG.trace_func()

        # Make a backup of project
        backup_name: str = f"{BACKUP_PREFIX}{self.qgis_project_id}"
        self.copy_project(backup_name)
        return backup_name


    def backup_project_layers_clear(self, backup_name: str, backup_layer_names: list) -> None:
        """
        Clears the backuped project and the backed up data tables.
        This function is called when the update process completed succesfully and the backups aren't necessary anymore.
        """
        LOG.trace_func()

        # If schema initialized
        if self.db_qgis and self.db_data and self.qgis_project_schema:
            # Keep track
            self.progress_marks.append(ProgressMarkBackUpClearing(datetime.now()))

            # Delete the project
            self.delete_project_from_db_as(backup_name)

            # Connect to the databasses
            with self.db_qgis.open_conn() as conn_qgis:
                with self.db_data.open_conn() as conn_data:
                    # For each table name
                    for table_name in backup_layer_names:
                        # Open a cursor
                        with conn_qgis.cursor() as cur:
                            # Delete the layer style
                            self.db_qgis.delete_layer_style_go(cur, self.qgis_project_schema, table_name)

                        # Open a cursor
                        with conn_data.cursor() as cur:
                            # Remove the table
                            self.db_data.drop_table_go(cur, self.qgis_project_schema, table_name)

                    # Commit
                    conn_data.commit()

                # Commit
                conn_qgis.commit()

        else:
            # Throws
            raise ProjectNotInitialized("backup_project_layers_clear")


    def set_layers_data_source(self, schema: str, pk_key: str, geom_key: str) -> bool:
        """
        Sets Layer Data Source to new database location
        """
        LOG.trace_func()

        # If the project has been initialized
        if self.project and self.db_data:
            # Log
            LOG.debug("Saving layers data sources...")

            # Keep track
            self.progress_marks.append(ProgressMarkChangingLayerDatasource(datetime.now()))

            # For each layer in the map
            for layer in self.get_layers_in_order_only_export():
                # Set the schema name in output
                schema_name: str = schema

                # Get the table name, we use a prefix on our tables
                table_name = self.get_layer_source_name_with_dataset_prefix(layer)

                # Redirect
                self.set_layer_data_source(layer, schema_name, table_name, pk_key, geom_key)


            # Log
            LOG.debug("Layer data sources saved.")

            # Done
            return True

        else:
            # Throws
            raise ProjectNotInitialized("set_layers_data_source")


    def set_layer_data_source(self, layer: Any, schema_name: str, table_name: str, pk_key: str,
                              geometry_column: str, keep_filter: bool = True, keep_visibility_scales: bool = True) -> None:
        """
        Sets the source of the layer to the given schema name and table name according to the db_data connection parameters
        """
        LOG.trace_func()

        # If initialized
        if self.db_data:
            # Store the current filter if any (because when setting a data source, the filter gets removed)
            current_filter: str = layer.subsetString()

            # Store the current sql-filter if any (because when setting a data source, the filter gets removed)
            current_sql_filter: str = (QgsDataSourceUri(layer.dataProvider().dataSourceUri())).sql()

            # Store the current visibility scales
            min_scale = layer.minimumScale()
            max_scale = layer.maximumScale()

            # Generate the uri
            uri: str = self.db_data.gen_uri_data_source_srid(schema_name, table_name, pk_key, geometry_column,
                                                             layer.geometryType(), PY_QGIS._format_crs_epsg(layer.crs().authid()))

            # If keep filter
            if keep_filter:
                # If SQL-Filter
                if current_sql_filter:
                    uri = f"{uri} sql={current_sql_filter}"

            # Go
            layer.setDataSource(uri, layer.name(), DATA_PROVIDER_KEY)

            # If keep filter
            if keep_filter:
                # If Filter
                if current_filter:
                    # Reapply the filter
                    layer.setSubsetString(current_filter)

            # If keep visibility scales
            if keep_visibility_scales:
                # Reapply the visibility scales
                layer.setMinimumScale(min_scale)
                layer.setMaximumScale(max_scale)


    def set_layer_data_source_host_user_pass(self, layer: Any, host: str, port: int, username: str, password: str) -> None:
        # Get the data provider
        data_prov = layer.dataProvider()

        # Get the original data source uri
        data_source = data_prov.dataSourceUri()

        # Get the Uri object
        data_source_uri = QgsDataSourceUri(data_source)

        # Set the username and password
        data_source_uri.setAuthConfigId('')  # TODO: Check - '' or None?
        data_source_uri.setParam('host', host)
        data_source_uri.setParam('port', str(port))
        data_source_uri.setUsername(username)
        data_source_uri.setPassword(password)

        # Set the new URI on the layer
        layer.setDataSource(data_source_uri.uri(), layer.name(), layer.providerType())


    def save_layer_styles_in_db(self, layers_saved: list[LayerStyle]) -> bool:
        """
        Saves layer style to CDTK Postgres DB
        """
        LOG.trace_func()

        # If the project has been initialized
        if self.project:
            # Keep track
            self.progress_marks.append(ProgressMarkSavingStyles(datetime.now()))

            # For each layer in the map that points to a database
            for layer in self.get_layers_that_point_to_database(True):
                # Get the style name
                style_name: str = self._format_style_name(layer)

                # Save it
                self.save_layer_style_in_database(layer, style_name)

                # Keep track
                layers_saved.append(LayerStyle(layer, style_name))

        else:
            # Throws
            raise ProjectNotInitialized("save_layer_styles_in_db")


        ##################################
        # # OLD WAY
        # #style_id = layer.listStylesInDatabase()[1][styles.index(style_name)]
        # #layer.saveStyleToDatabase(style_name, "Default style for {}".format(layer.name()), True, "")

        # # Generate the uri
        # uri_generic = self.gen_uri_base()

        # # Fetch the styles in the database
        # style_ids = []
        # style_names = []
        # style_descs = []
        # error = ""
        # count = QgsProviderRegistry.instance().listStyles(DATA_PROVIDER_KEY, uri_generic, style_ids, style_names, style_descs, error)
        # print(str(len(style_ids)))
        # print(error)

        # # Fetch the styles
        # #[count, style_ids, style_names, style_descs, error] = layer.listStylesInDatabase()

        # # Depending if the style exists already or not
        # action = "added"
        # if style_name in style_names:
        #     action = "udpated"
        #     # Delete the style (replacing it and we don't want the pop up window)
        #     QgsProviderRegistry.instance().deleteStyleById(DATA_PROVIDER_KEY, uri_generic,
        #                                                    style_ids[style_names.index(style_name)], error)
        #######################

        #print(f">>Style '{style_name}' has been {action} in the CDTK Database")

        # Done
        return True


    def delete_layer_styles_from_db(self) -> None:
        """
        Deletes layer style to CDTK Postgres DB
        """
        LOG.trace_func()

        # If the project has been initialized
        if self.project:
            # Keep track
            self.progress_marks.append(ProgressMarkDeletingStyles(datetime.now()))

            # For each layer in the map that points to a database
            for layer in self.get_layers_that_point_to_database(False):
                # Get the style name
                style_name: str = self._format_style_name(layer)

                # Delete it
                self.delete_layer_style_from_db(layer, style_name)

        else:
            # Throws
            raise ProjectNotInitialized("delete_layer_styles_from_db")



