# CDTK Publication QGIS Core
- `db` folder contains classes to communicate with the PostgreSQL database for any PyQGIS related functionalities that require additional database processing
- `lib` folder contains low-level library classes such as exceptions
- `main.py` entry point to execute PyQGIS processing which is being executed on the main thread. This is the bridge between threads so that PyQGIS API runs on the main thread, a PyQGIS library limitation.
- `py_qgis.py` contains core functions to work with the PyQGIS library. This class could be shared with other applications as it doesn't contain CDTK Publication related business logic.
- `cdtk_qgis.py` inherits from `py_qgis.py` to add CDTK Publication related business logic on top of the core PyQGIS class.
