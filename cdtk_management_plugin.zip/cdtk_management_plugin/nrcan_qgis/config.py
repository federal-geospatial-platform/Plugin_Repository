"""
This module stores all configurations used by this application.
"""

import os

SUPPORTED_EPSG_CRS = [3857, 3978, 3979, 4269, 4617]
WMS_CRS_LIST = ["EPSG:3857", "EPSG:3978", "EPSG:3979", "EPSG:4269", "EPSG:4326", "EPSG:4617"]
WMS_ORGANIZATION_NAME_EN = "Government of Canada"
WMS_ORGANIZATION_NAME_FR = "Gouvernement du Canada"
WMS_ONLINE_RESOURCE = "https://www.geo.ca/"
WMS_CONTACT_EMAIL = "geo@nrcan-rncan.gc.ca"
WMS_FEES = "No Conditions Apply"
WMS_ACCESS_CONSTRAINTS = "License"
MINIMUM_SCALE = 50000000
MAXIMUM_SCALE = 0


def QGIS_PROJECTS_PATH(proj_path: str, filename: str):
    if filename and len(filename) > 0:
        return os.path.join(proj_path, filename)
    return proj_path
