"""
This module offers application progress marks indicators.
"""

from __future__ import annotations
from datetime import datetime
import importlib
from dateutil import parser
from .exceptions import *


class QGISProgressMark(object):
    """Base class for Progress Markers"""
    def __init__(self, date) -> None:
        self.date: datetime = date

    def as_dict(self) -> dict[str, Any]:
        raise QGISApplicationException(f"as_dict() is not implemented for this progress mark {type(self)}")

    def line_header(self) -> str:
        return f"{self.date.strftime('%Y-%m-%d %H:%M')} - "

    @staticmethod
    def list_progress_marks_as_list_dict(pm_list: list) -> list[dict[str, Any]]:
        if pm_list and len(pm_list):
            return [QGISProgressMark.serialize(e) for e in pm_list]
        return []

    @staticmethod
    def list_dict_as_list_progress_marks(pm_list: list) -> list[Any]:
        if pm_list and len(pm_list):
            return [QGISProgressMark.deserialize(e) for e in pm_list]
        return []

    @staticmethod
    def serialize(progress_mark) -> dict[str, Any]:
        return {
            'type': type(progress_mark).__name__,
            'content': progress_mark.as_dict()
        }

    @staticmethod
    def deserialize(progress_mark: dict) -> Any:
        the_progress_mark_class = getattr(importlib.import_module("nrcan_qgis.lib.progress_marks"), progress_mark['type'])
        return the_progress_mark_class.from_dict(progress_mark['content'])


class ProgressMarkGeneric(QGISProgressMark):
    """Progress Marker when validating if the project crs is valid."""
    def __init__(self, date, message: str) -> None:
        super().__init__(date)
        self.message: str = message

    def as_dict(self) -> dict[str, Any]:
        return {'date': self.date.isoformat(), 'message': self.message}

    @staticmethod
    def from_dict(pm_dict: dict) -> ProgressMarkGeneric:
        return ProgressMarkGeneric(parser.parse(pm_dict['date']), pm_dict['message'])

    def __str__(self) -> str:
        return f"{self.line_header()}{self.message}"


class ProgressMarkInitialized(ProgressMarkGeneric):
    """Progress Marker when QGIS has been initialized."""
    def __init__(self, date, qgis_version: str) -> None:
        super().__init__(date, f"Initialized PyQGIS. Running on version {qgis_version}")
        self.qgis_version: str = qgis_version

    def as_dict(self) -> dict[str, Any]:
        return {'date': self.date.isoformat(), 'qgis_version': self.qgis_version}

    @staticmethod
    def from_dict(pm_dict: dict) -> ProgressMarkInitialized:
        return ProgressMarkInitialized(parser.parse(pm_dict['date']), pm_dict['qgis_version'])


class ProgressMarkInitializedDatabase(ProgressMarkGeneric):
    """Progress Marker when database has been initialized."""
    def __init__(self, date, db_host: str, db_name: str) -> None:
        super().__init__(date, f"Initialized Database {db_name} at {db_host}")
        self.db_host: str = db_host
        self.db_name: str = db_name

    def as_dict(self) -> dict[str, Any]:
        return {'date': self.date.isoformat(), 'db_host': self.db_host, 'db_name': self.db_name}

    @staticmethod
    def from_dict(pm_dict: dict) -> ProgressMarkInitializedDatabase:
        return ProgressMarkInitializedDatabase(parser.parse(pm_dict['date']), pm_dict['db_host'], pm_dict['db_name'])


class ProgressMarkInitializingProjectFromFile(ProgressMarkGeneric):
    """Progress Marker when database has been initialized."""
    def __init__(self, date, project_file: str) -> None:
        super().__init__(date, f"Initializing Project from file {project_file}")
        self.project_file = project_file

    def as_dict(self) -> dict[str, Any]:
        return {'date': self.date.isoformat(), 'project_file': self.project_file}

    @staticmethod
    def from_dict(pm_dict: dict) -> ProgressMarkInitializingProjectFromFile:
        return ProgressMarkInitializingProjectFromFile(parser.parse(pm_dict['date']), pm_dict['project_file'])


class ProgressMarkInitializingProjectFromDatabase(ProgressMarkGeneric):
    """Progress Marker when database has been initialized."""
    def __init__(self, date, project_id: str) -> None:
        super().__init__(date, f"Initializing Project from database {project_id}")
        self.project_id: str = project_id

    def as_dict(self) -> dict[str, Any]:
        return {'date': self.date.isoformat(), 'project_id': self.project_id}

    @staticmethod
    def from_dict(pm_dict: dict) -> ProgressMarkInitializingProjectFromDatabase:
        return ProgressMarkInitializingProjectFromDatabase(parser.parse(pm_dict['date']), pm_dict['project_id'])


class ProgressMarkInitializedProject(ProgressMarkGeneric):
    """Progress Marker when database has been initialized."""
    def __init__(self, date) -> None:
        super().__init__(date, "--- Project initialized ---")

    @staticmethod
    def from_dict(pm_dict: dict) -> ProgressMarkInitializedProject:
        return ProgressMarkInitializedProject(parser.parse(pm_dict['date']))


class ProgressMarkInitializedSchema(ProgressMarkGeneric):
    """Progress Marker when schema has been initialized."""
    def __init__(self, date, schema: str) -> None:
        super().__init__(date, f"Initialized Schema {schema}")
        self.schema: str = schema

    def as_dict(self) -> dict[str, Any]:
        return {'date': self.date.isoformat(), 'schema': self.schema}

    @staticmethod
    def from_dict(pm_dict: dict) -> ProgressMarkInitializedSchema:
        return ProgressMarkInitializedSchema(parser.parse(pm_dict['date']), pm_dict['schema'])


class ProgressMarkValidatingProjectExists(ProgressMarkGeneric):
    """Progress Marker when validating if the project exists."""
    def __init__(self, date, project_id: str) -> None:
        super().__init__(date, f"Validating project exists {project_id}")
        self.project_id: str = project_id

    def as_dict(self) -> dict[str, Any]:
        return {'date': self.date.isoformat(), 'project_id': self.project_id}

    @staticmethod
    def from_dict(pm_dict: dict) -> ProgressMarkValidatingProjectExists:
        return ProgressMarkValidatingProjectExists(parser.parse(pm_dict['date']), pm_dict['project_id'])


class ProgressMarkValidatingProjectCRS(ProgressMarkGeneric):
    """Progress Marker when changing the layer data source."""
    def __init__(self, date) -> None:
        super().__init__(date, "Validating the project CRS")

    @staticmethod
    def from_dict(pm_dict: dict) -> ProgressMarkValidatingProjectCRS:
        return ProgressMarkValidatingProjectCRS(parser.parse(pm_dict['date']))


class ProgressMarkValidatingProjectLayersCRS(ProgressMarkGeneric):
    """Progress Marker when changing the layer data source."""
    def __init__(self, date) -> None:
        super().__init__(date, "Validating the project layers CRS")

    @staticmethod
    def from_dict(pm_dict: dict) -> ProgressMarkValidatingProjectLayersCRS:
        return ProgressMarkValidatingProjectLayersCRS(parser.parse(pm_dict['date']))


class ProgressMarkValidatingDataAlreadyExists(ProgressMarkGeneric):
    """Progress Marker when changing the layer data source."""
    def __init__(self, date) -> None:
        super().__init__(date, "Validating that the data doesn't already exist in the database")

    @staticmethod
    def from_dict(pm_dict: dict) -> ProgressMarkValidatingDataAlreadyExists:
        return ProgressMarkValidatingDataAlreadyExists(parser.parse(pm_dict['date']))


class ProgressMarkValidatingStylesAlreadyExists(ProgressMarkGeneric):
    """Progress Marker when changing the layer data source."""
    def __init__(self, date) -> None:
        super().__init__(date, "Validating that the styles don't already exist in the database")

    @staticmethod
    def from_dict(pm_dict: dict) -> ProgressMarkValidatingStylesAlreadyExists:
        return ProgressMarkValidatingStylesAlreadyExists(parser.parse(pm_dict['date']))


class ProgressMarkSavingStyles(ProgressMarkGeneric):
    """Progress Marker when saving layer styles."""
    def __init__(self, date) -> None:
        super().__init__(date, "Saving layer styles in the database")

    @staticmethod
    def from_dict(pm_dict: dict) -> ProgressMarkSavingStyles:
        return ProgressMarkSavingStyles(parser.parse(pm_dict['date']))


class ProgressMarkDeletingStyles(ProgressMarkGeneric):
    """Progress Marker when saving layer styles."""
    def __init__(self, date) -> None:
        super().__init__(date, "Deleting layer styles from the database")

    @staticmethod
    def from_dict(pm_dict: dict) -> ProgressMarkDeletingStyles:
        return ProgressMarkDeletingStyles(parser.parse(pm_dict['date']))


class ProgressMarkSavingProject(ProgressMarkGeneric):
    """Progress Marker when saving a project."""
    def __init__(self, date, project_id: str) -> None:
        super().__init__(date, f"Saving project '{project_id}' in the database")
        self.project_id: str = project_id

    def as_dict(self) -> dict[str, Any]:
        return {'date': self.date.isoformat(), 'project_id': self.project_id}

    @staticmethod
    def from_dict(pm_dict: dict) -> ProgressMarkSavingProject:
        return ProgressMarkSavingProject(parser.parse(pm_dict['date']), pm_dict['project_id'])


class ProgressMarkDeletingProject(ProgressMarkGeneric):
    """Progress Marker when deleting a project."""
    def __init__(self, date, project_id: str) -> None:
        super().__init__(date, f"Deleting project '{project_id}' from the database")
        self.project_id: str = project_id

    def as_dict(self) -> dict[str, Any]:
        return {'date': self.date.isoformat(), 'project_id': self.project_id}

    @staticmethod
    def from_dict(pm_dict: dict) -> ProgressMarkDeletingProject:
        return ProgressMarkDeletingProject(parser.parse(pm_dict['date']), pm_dict['project_id'])


class ProgressMarkBackingUpVectorLayers(ProgressMarkGeneric):
    """Progress Marker when saving a project."""
    def __init__(self, date) -> None:
        super().__init__(date, "Backing up layers in the database..")

    @staticmethod
    def from_dict(pm_dict: dict) -> ProgressMarkBackingUpVectorLayers:
        return ProgressMarkBackingUpVectorLayers(parser.parse(pm_dict['date']))


class ProgressMarkBackedUpVectorLayers(ProgressMarkGeneric):
    """Progress Marker when saving a project."""
    def __init__(self, date, layer_name: str) -> None:
        super().__init__(date, f"The Layer {layer_name} has been backed up in the database")
        self.layer_name: str = layer_name

    def as_dict(self) -> dict[str, Any]:
        return {'date': self.date.isoformat(), 'layer_name': self.layer_name}

    @staticmethod
    def from_dict(pm_dict: dict) -> ProgressMarkBackedUpVectorLayers:
        return ProgressMarkBackedUpVectorLayers(parser.parse(pm_dict['date']), pm_dict['layer_name'])


class ProgressMarkBackUpClearing(ProgressMarkGeneric):
    """Progress Marker when saving a project."""
    def __init__(self, date) -> None:
        super().__init__(date, "Clearing the backup information from database..")

    @staticmethod
    def from_dict(pm_dict: dict) -> ProgressMarkBackUpClearing:
        return ProgressMarkBackUpClearing(parser.parse(pm_dict['date']))


class ProgressMarkExportingVectorLayers(ProgressMarkGeneric):
    """Progress Marker when exporting vector layers."""
    def __init__(self, date) -> None:
        super().__init__(date, "Exporting vector layers into the database..")

    @staticmethod
    def from_dict(pm_dict: dict) -> ProgressMarkExportingVectorLayers:
        return ProgressMarkExportingVectorLayers(parser.parse(pm_dict['date']))


class ProgressMarkExportedVectorLayers(ProgressMarkGeneric):
    """Progress Marker when exporting vector layers."""
    def __init__(self, date, layer_name: str) -> None:
        super().__init__(date, f"The Layer {layer_name} has been exported in the database")
        self.layer_name: str = layer_name

    def as_dict(self) -> dict[str, Any]:
        return {'date': self.date.isoformat(), 'layer_name': self.layer_name}

    @staticmethod
    def from_dict(pm_dict: dict) -> ProgressMarkExportedVectorLayers:
        return ProgressMarkExportedVectorLayers(parser.parse(pm_dict['date']), pm_dict['layer_name'])


class ProgressMarkExportedSkippedVectorLayers(ProgressMarkGeneric):
    """Progress Marker when exporting vector layers."""
    def __init__(self, date, layer_name: str) -> None:
        super().__init__(date, f"The Layer {layer_name} has been skipped for exportation")
        self.layer_name: str = layer_name

    def as_dict(self) -> dict[str, Any]:
        return {'date': self.date.isoformat(), 'layer_name': self.layer_name}

    @staticmethod
    def from_dict(pm_dict: dict) -> ProgressMarkExportedSkippedVectorLayers:
        return ProgressMarkExportedSkippedVectorLayers(parser.parse(pm_dict['date']), pm_dict['layer_name'])


class ProgressMarkNormalizingProject(ProgressMarkGeneric):
    """Progress Marker when exporting vector layers."""
    def __init__(self, date) -> None:
        super().__init__(date, "Normalizing project for NRCan")

    @staticmethod
    def from_dict(pm_dict: dict) -> ProgressMarkNormalizingProject:
        return ProgressMarkNormalizingProject(parser.parse(pm_dict['date']))


class ProgressMarkDeletingVectorLayers(ProgressMarkGeneric):
    """Progress Marker when deleting vector layers."""
    def __init__(self, date) -> None:
        super().__init__(date, "Deleting vector layers from the database")

    @staticmethod
    def from_dict(pm_dict: dict) -> ProgressMarkDeletingVectorLayers:
        return ProgressMarkDeletingVectorLayers(parser.parse(pm_dict['date']))


class ProgressMarkChangingLayerDatasource(ProgressMarkGeneric):
    """Progress Marker when changing the layer data source."""
    def __init__(self, date) -> None:
        super().__init__(date, "Changing layer data source")

    @staticmethod
    def from_dict(pm_dict: dict) -> ProgressMarkChangingLayerDatasource:
        return ProgressMarkChangingLayerDatasource(parser.parse(pm_dict['date']))


class ProgressMarkCreatingSpatialIndex(ProgressMarkGeneric):
    """Progress Marker when changing the layer data source."""
    def __init__(self, date, table_name: str) -> None:
        super().__init__(date, f"Creating spatial index on table {table_name}")
        self.table_name: str = table_name

    def as_dict(self) -> dict[str, Any]:
        return {'date': self.date.isoformat(), 'table_name': self.table_name}

    @staticmethod
    def from_dict(pm_dict: dict) -> ProgressMarkCreatingSpatialIndex:
        return ProgressMarkCreatingSpatialIndex(parser.parse(pm_dict['date']), pm_dict['table_name'])


class ProgressMarkCreatedSpatialIndex(ProgressMarkGeneric):
    """Progress Marker when changing the layer data source."""
    def __init__(self, date, table_name: str) -> None:
        super().__init__(date, f"Created spatial index on table {table_name}")
        self.table_name: str = table_name

    def as_dict(self)-> dict[str, Any]:
        return {'date': self.date.isoformat(), 'table_name': self.table_name}

    @staticmethod
    def from_dict(pm_dict: dict) -> ProgressMarkCreatedSpatialIndex:
        return ProgressMarkCreatedSpatialIndex(parser.parse(pm_dict['date']), pm_dict['table_name'])


class ProgressMarkTableDropped(ProgressMarkGeneric):
    """Progress Marker when dropping table."""
    def __init__(self, date, schema_name: str, db_table_name: str) -> None:
        super().__init__(date, f"The following table was droppped: '{schema_name}'.'{db_table_name}'")
        self.schema_name: str = schema_name
        self.db_table_name: str = db_table_name

    def as_dict(self) -> dict[str, Any]:
        return {
            'date': self.date.isoformat(),
            'schema_name': self.schema_name,
            'db_table_name': self.db_table_name
        }

    @staticmethod
    def from_dict(pm_dict: dict) -> ProgressMarkTableDropped:
        return ProgressMarkTableDropped(parser.parse(pm_dict['date']), pm_dict['schema_name'], pm_dict['db_table_name'])


class ProgressMarkReadTablesGpkg(ProgressMarkGeneric):
    """Progress Marker when reading tables from a GeoPackage."""
    def __init__(self, date, gpkg_file: str) -> None:
        super().__init__(date, f"Table names read from geopackage: {gpkg_file}")
        self.gpkg_file: str = gpkg_file

    def as_dict(self) -> dict[str, Any]:
        return {
            'date': self.date.isoformat(),
            'gpkg_file': self.gpkg_file
        }

    @staticmethod
    def from_dict(pm_dict: dict) -> ProgressMarkReadTablesGpkg:
        return ProgressMarkReadTablesGpkg(parser.parse(pm_dict['date']), pm_dict['gpkg_file'])


class ProgressMarkTableAdded(ProgressMarkGeneric):
    """Progress Mark when adding a tablein the database."""
    def __init__(self, date, schema_name:str, db_table_name:str) -> None:
        super().__init__(date, f"The following table was added: '{schema_name}'.'{db_table_name}'")
        self.schema_name: str = schema_name
        self.db_table_name: str = db_table_name

    def as_dict(self) -> dict[str, Any]:
        return {
            'date': self.date.isoformat(),
            'schema_name': self.schema_name,
            'db_table_name': self.db_table_name
        }

    @staticmethod
    def from_dict(pm_dict: dict) -> ProgressMarkTableAdded:
        return ProgressMarkTableAdded(parser.parse(pm_dict['date']), pm_dict['schema_name'], pm_dict['db_table_name'])


class ProgressMarkReadTablesDatabase(ProgressMarkGeneric):
    """Progress Marker when reading tables from a database."""
    def __init__(self, date, schema_name:str) -> None:
        super().__init__(date, f"Table names read from database for schema: {schema_name}")
        self.schema_name: str = schema_name

    def as_dict(self) -> dict[str, Any]:
        return {
            'date': self.date.isoformat(),
            'schema_name': self.schema_name
        }

    @staticmethod
    def from_dict(pm_dict: dict) -> ProgressMarkReadTablesDatabase:
        return ProgressMarkReadTablesDatabase(parser.parse(pm_dict['date']), pm_dict['schema_name'])
