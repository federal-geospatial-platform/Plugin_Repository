from typing import Any


class LayerStyle(object):
     """
     Simple Layer Style class to associate a layer with a style name
     """

     def __init__(self, layer: Any, style_name: str) -> None:
          self.layer = layer
          self.style_name = style_name

