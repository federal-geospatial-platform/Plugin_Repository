"""
This module offers application progress marks indicators.
"""

from __future__ import annotations
import importlib
from datetime import datetime
from .exceptions import *


class QGISWarning(object):
    """Base class for Progress Markers"""
    def __init__(self, date: datetime) -> None:
        self.date: datetime = date

    def as_dict(self) -> dict[str, Any]:
        raise QGISApplicationException(f"as_dict() is not implemented for this warning {type(self)}")

    @staticmethod
    def list_warn_as_list_dict(warn_list: list) -> list[dict[str, Any]]:
        if warn_list and len(warn_list):
            return [QGISWarning.serialize(w) for w in warn_list]
        return []

    @staticmethod
    def list_dict_as_list_warn(warn_list: list) -> list[Any]:
        if warn_list and len(warn_list):
            return [QGISWarning.deserialize(w) for w in warn_list]
        return []

    @staticmethod
    def serialize(warn) -> dict[str, Any]:
        return {
            'type': type(warn).__name__,
            'warning': warn.as_dict()
        }

    @staticmethod
    def deserialize(ex: dict) -> Any:
        the_warning_class = getattr(importlib.import_module("nrcan_qgis.lib.warnings"), ex['type'])
        return the_warning_class.from_dict(ex['warning'])


# class LayerInvalidWarning(QGISWarning):
#     """Warning when a layer is invalid in a project."""
#     def __init__(self, project_id: str, layer_name: str):
#         super(QGISWarning, self)
#         self.project_id = project_id
#         self.layer_name = layer_name

#     def as_dict(self):
#         return {'project_id': self.project_id, 'layer_name': self.layer_name}

#     def from_dict(warn_dict: dict):
#         return LayerInvalidWarning(warn_dict['project_id'], warn_dict['layer_name'])

#     def __str__(self):
#         return f"The Layer '{self.layer_name}' in project '{self.project_id}' was invalid."

