def qgis_xml_tweak_layer_source(text: str) -> str:
    """
    Reads a layer source connection string and changes the authcfg to the
    provided username and password.
    """

    # Read as dict
    source_dict: dict = string_of_keyvaluepairs_to_dict(text)

    # If there is a authcfg
    if 'authcfg' in source_dict:
        value_og: str = source_dict['authcfg']
        value: str = value_og
        if not value_og.startswith('\''):
            value = f"'{value_og}'"

        # Return tweaked
        return text.replace(f"authcfg={value_og} ", f"authcfg={value} ")

    # As is
    return text


def string_of_keyvaluepairs_to_dict(text: str) -> dict:
    """
    Converts a string to a key/value dictionary.
    """

    result_dict: dict = {}
    for item in text.split():
        if "=" in item and item.count('=') == 1:
            key, value = item.split("=")
            result_dict[key] = value
    return result_dict

