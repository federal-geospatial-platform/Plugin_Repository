from typing import Any
import jwt.algorithms
import requests, jwt
import hashlib, base64, secrets

class MSAuth:
    """
    Class to handle Microsoft-based authentication for OAuth2 flows in Azure AD.
    Provides methods to obtain authorization URLs and tokens.
    """

    MICROSOFT_PUBLIC_KEYS_URL: str = "https://login.microsoftonline.com/common/discovery/v2.0/keys"

    def __init__(self, client_id: str, authority: str) -> None:
        """
        Initialize the MSAuth object with required details.

        :param client_id: The client ID of the registered Azure AD application.
        :param client_secret: The client secret for the application.
        :param authority: The authority URL (Azure AD endpoint).
        """

        self.client_id: str = client_id
        self.authority: str = authority
        self.authority_v2: str = f"{authority}/v2.0"
        self.authority_authorize: str = f"{authority}/oauth2/v2.0/authorize"
        self.authority_token: str = f"{authority}/oauth2/v2.0/token"


    def get_auth_request_url(self, redirect_uri: str, scopes: list[str], code_challenge: str) -> str:
        """
        Generate an authorization request URL for OAuth2 authentication with PKCE.

        :param redirect_uri: The redirect URI registered in Azure AD.
        :param scopes: List of permissions required.
        :param code_challenge: The PKCE code challenge.
        :return: The generated authorization URL.
        """

        # Return the url
        return f"{self.authority_authorize}?client_id={self.client_id}&response_type=code&redirect_uri={redirect_uri}&scope={str.join(' ', scopes)}&code_challenge={code_challenge}&code_challenge_method=S256"


    def acquire_token(self, client_secret: str, redirect_uri: str, scopes: list[str], code_received: str, code_verifier: str) -> dict:
        """
        Acquire the OAuth2 token after the authorization code is received.

        :param redirect_uri: The redirect URI where the user was redirected after login.
        :param scopes: List of permissions required.
        :param code_received: The authorization code received from the redirect.
        :return: The token response as a dictionary.
        """

        # Set payload
        payload = {
            'grant_type': 'authorization_code',
            'client_secret': client_secret, # For an Azure Web application, this is still required at the time of writing this, even if we implement PKCE pattern :(
            'client_id': self.client_id,
            'scope': str.join(' ', scopes),
            'redirect_uri': redirect_uri,
            'code': code_received,
            'code_verifier': code_verifier
        }

        # Acquire the token using the received authorization code, manually
        return requests.post(self.authority_token, data=payload).json()


    def decode_id_token(self, id_token: str) -> dict:
        """
        Verifies and decodes Microsoft's ID token to extract claims.
        """

        # Get JWT header to find the key ID (kid)
        unverified_header = jwt.get_unverified_header(id_token)

        # Fetch Microsoft's public signing keys
        jwks = requests.get(MSAuth.MICROSOFT_PUBLIC_KEYS_URL).json()
        key = next((k for k in jwks['keys'] if k['kid'] == unverified_header['kid']), None)

        # If found
        if key:
            # Convert JWK to RSA public key
            public_key: Any = jwt.algorithms.RSAAlgorithm.from_jwk(key)

            # Decode the token using the correct public key
            return jwt.decode(id_token, public_key, algorithms=['RS256'], audience=self.client_id, issuer=f"{self.authority_v2}")

        else:
            raise Exception("Failed to decode token")


    @staticmethod
    def generate_code_verifier() -> str:
        """
        Generate a high-entropy code verifier for use in PKCE.

        :return: The generated code verifier string.
        """
        # Use secrets to generate a secure random string (URL-safe base64)
        return secrets.token_urlsafe(64)


    @staticmethod
    def generate_code_challenge(verifier: str) -> str:
        """
        Generate the code challenge from a given code verifier using SHA256 and base64 encoding.

        :param verifier: The code verifier to generate the challenge from.
        :return: The base64-url encoded code challenge string.
        """
        # Hash the verifier using SHA256
        digest: bytes = hashlib.sha256(verifier.encode('utf-8')).digest()

        # Base64-url encode the hash and strip trailing '=' padding
        return base64.urlsafe_b64encode(digest).decode('utf-8').rstrip("=")
