# -*- coding: utf-8 -*-


class ToolTips:
    """Class to manage the tool tips for the CDTK Publication API plugin for QGIS."""

    tp = {
            "workspace_dir": {
                'en': "The workspace where the data to process is stored.",
                'fr': "L'espace de travail où les données à traiter sont stockées."},
            "authentication": {
                'en': "The QGIS authentication credentials to use to connect to the CDTK server.",
                'fr': "La code d'authentification QGIS à utiliser pour se connecter au serveur CDTK."},
            "operation": {
                'en': "The operation to perform on the ControlFile.json file.",
                'fr': "L'opération à effectuer sur le fichier ControlFile.json."},
            "validate": {
                'en': "Only validate the ControlFile.json file (no database writing done).",
                'fr': "Seulement valider le fichier ControlFile.json (pas d'inscription dans la base de données)."},
            "email": {
                'en': "The email adress of the publisher (must be already registered in the registry).",
                'fr': "L'adresse courriel du publicateur (doit être déjà enregistrée dans le registre)."},
            "organization": {
                'en': "Choose the English organization acronym to which the dataset will be related." +
                      "must be already registered in the registry).",
                'fr': "Choisir l'acronyme anglais de l'organisation à laquelle le jeu de données sera lié " +
                      "(doit être déjà enregistré dans le registre)."},
            "meta_id": {
                "en": "The metadata UUID from the FGP catalog. This UUID can be found under 'File Identifier' in the " +
                      "'Additional Information' section of the FGP metadata page.",
                "fr": "Le UUID des métadonnées du catalogue PGF. Ce UUID se trouve sous 'Identifiant du fichier' " +
                      "dans la section 'Informations supplémentaires' de la page de métadonnées PGF."},
            "dataset_name": {
                'en': "A significant name for the dataset that will be used to create the web services name. " +
                      "Use only alphanumerical characters, dashes and underscores (no spaces, no special or " +
                      "accentuated characters).",
                'fr': "Un nom significatif pour le jeu de données qui sera utilisé pour créer le nom des services web. " +
                      "N'utilisez que des caractères alphanumériques, des tirets et des traits de soulignement " +
                      "(pas d'espaces, ni de caractères spéciaux ou accentués)."},
            'ows_service': {
                'en': "Toggle switch to indicate if an OWS service is present (if selected, the OWS Service tab will enable).",
                'fr': "Interrupteur pour indiquer si un service OWS est présent (si sélectionné, l'onglet Service " +
                      "OWS sera activé)."},
            'down_service': {
                'en': "Toggle switch to indicate if a download service is present (if selected, the Download Service " +
                      "tab will enable).",
                'fr': "Interrupteur pour indiquer si un service de téléchargement est présent (si sélectionné, l'onglet " +
                      "Service de téléchargement sera activé)."},
            'oapi_service': {
                'en': "Toggle switch to indicate if an OAPI service is present (if selected, the OAPI Service tab will enable).",
                'fr': "Interrupteur pour indiquer si un service OAPI est présent (si sélectionné, l'onglet " +
                      "Service OAPI sera activé)."},
            'data_type': {
                'en': 'The data type determines the type of service to be published.',
                'fr': 'Le type de données détermine le type de service à publier.'},
            'service_type': {
                'en': "If your project contains only vector data, it can be hosted as a WMS, WFS or both. If it's " +
                      "only raster data, it can be hosted as a WMS, WCS or both. If your project contains both vector " +
                      "and raster data, it will be hosted has a WMS.",
                'fr': "Si votre projet ne contient que des données vectorielles, il peut être hébergé en tant que " +
                      "WMS, WFS ou les deux. S'il contient que des données matricielles, il peut être hébergé en " +
                      "tant que WMS, WCS ou les deux. Si votre projet contient des données vectorielles et des " +
                      "données matricielles, il sera hébergé en tant que WMS."},
            'service_visibility': {
                'en': "The web services can be either available to the general public or restricted to " +
                      "the Canadian government network.",
                'fr': "Les services web peuvent être soit accessibles au grand public, soit limités " +
                      "au réseau du gouvernement canadien."},
            'server_type': {
                'en': "The current CDTK only offers QGIS servers. This cells is reserved for future " +
                      "developments (i.e. MapServer).",
                'fr': "Le CDTK actuel ne propose que des serveurs QGIS. Cette cellule est réservée pour " +
                      "les développements futurs (c.-à-d. MapServer)."},
            'server_id': {
                'en': "This information is not necessary if you want to use the default server assigned to " +
                      "your organization in the CDTK Registry. If you want to use another server, register it " +
                      "in the registry (contact the CDTK Administrator) and enter the ID here. Choosing a server " +
                      "manually will override the Service visibily setting.",
                'fr': "Cette information n'est pas nécessaire si vous utilisez le serveur par défaut assigné " +
                      "à votre organisation. Si vous souhaitez utiliser un autre serveur, enregistrez-le dans " +
                      "le registre (contactez l'administrateur CODC) et entrez l'ID ici. Choisir manuellement un " +
                      "serveur supplantera le paramètre de visibilité du service."},
            'vector_datastore_id': {
                'en': "Datastore for vector layers. This information is not required if you are using " +
                      "the default datastore assigned to your organization. If you wish to use another " +
                      "datastore, register it (contact your CDTK administrator) and enter the ID here. ",
                'fr': "Entrepôt de données pour les couches vectorielles. Cette information n'est pas " +
                      "nécessaire si vous utilisez l'entrepôt de données par défaut assigné à votre " +
                      "organisation. Si vous souhaitez utiliser un autre entrepôt de données, enregistrez-le "
                      "dans le registre (contactez l'administrateur CODC) et entrez l'ID ici."},
            'raster _datastore_id': {
                'en': "Datastore for raster layers. This information is not required if you are using the " +
                      "default datastore assigned to your organization. If you wish to use another datastore, " +
                      "register it (contact your CDTK administrator) and enter the ID here.",
                'fr': "Entrepôt de données pour les couches matricielles. Cette information n'est pas nécessaire " +
                      "si vous utilisez l'entrepôt de données par défaut assigné à votre organisation. " +
                      "Si vous souhaitez utiliser un autre entrepôt de données, enregistrez-le dans le " +
                      "registre (contactez l'administrateur CODC) et entrez l'ID ici. "},
            'qgis_project': {
                'en': "The QGIS project (.qgs) file name must be the same for both languages and appended " +
                      "with '_en. in English or '_fr' in French. Please include the .qgs extension. " +
                      "The .qgz extension is not supported.",
                'fr': "Le nom du fichier de projet QGIS (.qgs) doit être le même pour les deux langues et " +
                      "suivi de '_en' en anglais ou '_fr' en français. Veuillez inclure l'extension .qgs. " +
                      "L'extension .qgz n'est pas supportée."},
            'service_name': {
                'en': "The service name is created automatically based on the Dataset Name in the Generic Parameters.",
                'fr': "Le nom du service est créé automatiquement en fonction du nom du jeu de données dans les " +
                      "paramètres génériques."},
            'service_folder_name': {
                'en': "The name of the subfolder where the service will be deployed in the Datastore. " +
                      "This parameter is automatically imported from the Generic Parameters.",
                'fr': "Le nom du sous-dossier dans lequel le service sera déployé dans le Datastore. " +
                      "Ce paramètre est automatiquement importé des paramètres génériques."},
            'folder_name': {
                'en': "Enter the name of the main folder in which all of your downloadable files will be uploaded. " +
                      "Therefore, the download folder in your input package MUST be named after the value inserted in " +
                      "this field (case sensitive) and compressed in ZIP format.",
                'fr': "Entrez le nom du dossier principal dans lequel tous vos fichiers téléchargeables seront téléversés. " +
                      "Par conséquent, le dossier de téléchargement dans votre paquet d'entrée DOIT être nommé d'après la " +
                      "valeur insérée dans ce champ (sensible à la casse) et compressé au format ZIP."},
            'core_subject': {
                'en': "Please select the most relevant Core Subject Term for your dataset. The Core Subject Term (extracted " +
                      "from the government of Canada Core Subject Thesaurus) will be used on the FTP site as the name of the " +
                      "folder in which your download package will be uploaded, after the FTP domain and your organization acronym.",
                'fr': "Veuillez sélectionner un sujet de base pertinent pour votre jeu de données. Le sujet de base " +
                      "(extrait du Thésaurus des sujets de base du gouvernement du Canada) sera utilisé sur le site " +
                      "FTP comme nom du dossier dans lequel votre paquet de téléchargement sera téléversé, après le " +
                      "domaine FTP et l'acronyme de votre organisation."},
            'down_file_visibility': {
                'en': "The files can be either available to the general public or restricted to the Canadian " +
                      "government network. If nothing is selected, the default value is 'General public'.",
                'fr': "Les fichiers peuvent être soit accessibles au grand public, soit limités au réseau du " +
                      "gouvernement canadien. Si aucune valeur n'est sélectionnée, la valeur par défaut est 'Grand public'."},
            'down_server_id': {
                'en': "If you wish to use a specific FTP server, enter the ID here (contact the CDTK administrator " +
                      "to create one), otherwise the default FTP server assigned to your organization in the CDTK " +
                      "registry will be used. Manually selecting a FTP server will override the service visibility setting.",
                'fr': "Si vous souhaitez utiliser un serveur FTP spécifique, entrez l'ID ici (contactez l'administrateur " +
                      "CODC pour en créer un), sinon, le serveur FTP par défaut assigné à votre organisation dans " +
                      "le registre CODC sera utilisé. Choisir manuellement un serveur supplantera le paramètre " +
                      "de visibilité du service."},
            'datastore_id': {
                'en': "If you wish to use a specific datastore, enter the ID here (contact the CDTK administrator " +
                      "to create one), otherwise the default datastore assigned to your organization in the CDTK  " +
                      "registry will be used.",
                'fr': "Si vous souhaitez utiliser un entrepôt de données spécifique, entrez l'ID ici (contactez " +
                      "l'administrateur CODC pour en créer un), sinon, l'entrepôt de données par défaut assigné à " +
                      "votre organisation dans le registre CODC sera utilisé."},
            'oapi_data_type': {
                'en': "The data type determines the type of service to be published. Changing the Data Type will " +
                      "clear all added collections.",
                'fr': "Le type de données déterminera le type service qui sera publié. Changer le type de données " +
                      "supprimera toutes les collections ajoutées."},
            'oapi_service_type': {
                'en': "For vector collections, you can publish an OGC API - Features service. For raster " +
                      "collections, you can publish an OGC API - Coverage service. Both data types can be " +
                      "published as an OGC API - Maps service, but a WMS service is required to do so.",
                'fr': "Pour les collections vectorielles, vous pouvez publier un service OGC API - Features. " +
                      "Pour les collections raster, vous pouvez publier un service OGC API - Coverage. Les deux " +
                      "types de données peuvent être publiés en tant que service OGC API - Maps, mais un servic " +
                      "WMS est nécessaire pour ce faire."},
            'oapi_service_visibility': {
                'en': "The web services can be either available to the general public or restricted to " +
                      "the Canadian government network. If nothing is selected, the default value " +
                      "is 'General public'.",
                'fr': "Les services web peuvent être soit accessibles au grand public, soit limités au " +
                      "réseau du gouvernement canadien. Si aucune valeur n'est sélectionnée, la valeur par " +
                      "défaut est 'Grand public'."},
            'oapi_server_id': {
                'en': "Leave this cell blank to use the default server for your organization, otherwise, " +
                      "you can enter a specific server ID. Choosing a server manually will override the " +
                      "Service visibily setting.",
                'fr': "Laissez cette cellule vide pour utiliser le serveur par défaut de votre organisation, " +
                      "sinon vous pouvez saisir un ID de serveur spécifique. Choisir manuellement un serveur " +
                      "supplantera le paramètre de visibilité du service."},
            'oapi_server_type': {
                'en': "The current CDTK only offers pygeoapi servers. This cell is reserved for future developments.",
                'fr': "Le CDTK actuel ne propose que des serveurs pygeoapi. Cette cellule est réservée " +
                      "pour les développements futurs."},
            'datastore': {
                'en': "For vector data, you can either use the CDTK Datastores or a custom PostGIS datastore. " +
                      "If you use the CDTK datastore, please specify if you provide a Geopackage or if the data is " +
                      "already published in the datastore. For raster data, you can either use Geobase's Datacube " +
                      "or a custom datastore.",
                'fr': "Pour les données vectorielles, vous pouvez utiliser les dépôts de données du CODC ou un dépôt " +
                      "PostGIS personnalisé.  Si vous utilisez le dépôt de données du CODC, veuillez préciser si vous " +
                      "fournissez un Géopackage ou si les données sont déjà publiées dans le dépôt de données du CODC. " +
                      "Pour les données matricielles, vous pouvez utiliser le cube de données de Géobase ou un dépôt " +
                      "de données personnalisé."},
            'oapi_datastore_id': {
                'en': "Leave this cell blank to use the default datastore for your organization, otherwise, " +
                      "you can enter a specific datastore ID. If you are using a custom datastore, please " +
                      "contact the support team to setup a new connection.",
                'fr': "Laissez cette cellule vide pour utiliser le dépôt de données par défaut de votre " +
                      "organisation, sinon vous pouvez saisir un ID de dépôt de données spécifique. Si " +
                      "vous utilisez un dépôt de données personnalisé, veuillez contacter l'équipe d'assistance " +
                      "pour créer une nouvelle connexion."},
            'wms_facade': {
                'en': "If checked, a WMS facade provider will be created for the CDTK API.",
                'fr': "Si coché, un fournisseur de façade WMS sera créé pour l'API CDTK."},
            'raster_io': {
                'en': "If checked, a Raster IO provider will be created for the CDTK API.",
                'fr': "Si coché, un fournisseur Raster IO sera créé pour l'API CDTK."},
            'postgres_sql': {
                'en': "If checked, a PostgreSQL provider will be created for the CDTK API.",
                'fr': "Si coché, un fournisseur PostgreSQL sera créé pour l'API CDTK."},
            'oapi_add': {
                'en': "Add a new item in the collection list.",
                'fr': "Ajouter un nouvel élément dans la liste des collections"},
            'oapi_modifiy': {
                'en': "Modify the selected item in the collection list",
                'fr': "M"},
            'oapi_delete': {
                'en': "Delete the selected item in the collection list",
                'fr': "Supprimer l'élément sélectionné dans la liste des collections"},
            'oapi_duplicate': {
                'en': "Duplicate the selected item in the collection list",
                'fr': "Dupliquer l'élément sélectionné dans la liste des collections"},
            'tager_layer_name': {
                'en': "If you want to name your collection differently than the Feature Class name, enter the " +
                      "target collection name, otherwise it will keep the Feature Class name.",
                'fr': "Si vous publiez des données dans un dépôt de données du CODC et que vous fournissez un " +
                      "Géopackage, veuillez saisir le nom du Geopackage. Si vous utilisez un dépôt personnalisé ou " +
                      "si vos données sont déjà publiées dans le CODC, veuillez saisir le nom du schéma dans lequel " +
                      "vos données sont enregistrées."},
            'spatial_reference': {
                'en': "Enter the EPGS code of your data's Coordinate Reference System (example: 3978).",
                'fr': "Saisissez le code EPGS du système de référence des coordonnées de vos données (exemple : 3978)."},
            'temporal_extent_begin': {
                'en': "Enter the start date of your dataset's time range.",
                'fr': "Saisissez la date de début de l'étendue temporelle de votre jeu de données."},
            'temporal_extent_end': {
                'en': "Enter the end date of your dataset's time range. Leave blank for ongoing data.",
                'fr': "Saisissez la date de fin de l'étendue temporelle de votre jeu de données. Laisser en " +
                      "blanc pour les données en continu."},
            'northern': {
                'en': "Northern extent of the dataset in decimal degrees.",
                'fr': "Point le plus au nord du jeu de données en degrés décimaux."},
            'eastern': {
                'en': "Eastern extent of the dataset in decimal degrees.",
                'fr': "Point le plus à l'est du jeu de données en degrés décimaux."},
            'southern': {
                'en': "Southern extent of the dataset in decimal degrees.",
                'fr': "Point le plus au sud du jeu de données en degrés décimaux."},
            'western': {
                'en': "Western extent of the dataset in decimal degrees.",
                'fr': "Point le plus à l'ouest du jeu de données en degrés décimaux."},
            'oapi_title': {
                'en': "Enter title of the collection in both official languages.",
                'fr': "Saisissez le nom de la collection dans les deux langues officielles."},
            'oapi_description': {
                'en': "Enter the description of the collection in both official languages.",
                'fr': "Saisissez la description de la collection dans les deux langues officielles."},
            'oapi_keywords': {
                'en': "Enter a comma-separated list of keywords in both official languages for this collection. " +
                      "Example: keyword1,keyword2,keyword3",
                'fr': "Saisissez une liste de mots-clés séparés par des virgules dans les deux langues officielles " +
                      "pour cette collection. Exemple: mot-clé1,mot-clé2,mot-clé3"},
            'geopackage_name': {
                'en': "If you publish data to a CDTK datastore and provide a Geopackage, please enter the name of " +
                      "the Geopackage. If you use a custom datastore or your data is already published to the CDTK, " +
                      "please enter the schema name where your data is saved.",
                'fr': "Si vous publiez des données dans un dépôt de données du CODC et que vous fournissez un " +
                      "Géopackage, veuillez saisir le nom du Geopackage."},
            'schema_name': {
                'en': "If you use a custom datastore or your data is already published to the CDTK, please enter the " +
                      "schema name where your data is saved",
                'fr': "Si vous utilisez un dépôt personnalisé ou si vos données sont déjà publiées dans le CODC, veuillez " +
                      "saisir le nom du schéma dans lequel vos données sont enregistrées."},
            'feature_class_name': {
                'en': "If you provide data in a Geopackage (GPKG), enter the name of the vector feature class name. " +
                      "If you use data from an existing data source, enter the layer name from the database.",
                'fr': "Si vous fournissez des données dans un Géopackage (GPKG), entrez le nom de la classe " +
                      "d'entités vectorielles. Si vous utilisez des données provenant d'une source de données existante, " +
                      "saisissez le nom de la couche de la base de données."},
            'data_queryables': {
                'en': "If you want to restrict data filtering to specific attributes, specify a comma-separated list of " +
                      "queryable attribute names. If nothing is specified, all attributes will be queryable.",
                'fr': "Pour restreindre le filtrage des données à certains attributs, indiquez les attributs interrogeables " +
                      "séparés par des virgules. Si rien n'est spécifié, tous les attributs seront interrogeables."},
            'data_id_field': {
                'en': "In a GeoPackage (GPKG), the default field name for the feature identifier is 'fid'. If your " +
                      "GeoPackage uses another unique identifier field, enter it here.",
                'fr': "Dans un GeoPackage (GPKG), le nom de champ par défaut pour l'identifiant de l'entité est 'fid'. " +
                      "Si votre GeoPackage utilise un autre champ d'identifiant unique, saisissez-le ici."},
            'data_geometry_field': {
                'en': "In a GeoPackage (GPKG), the default  field used to store the geometry is 'geom'. " +
                      "If your GeoPackage uses another field for the geometry, enter it here.",
                'fr': "Dans un GeoPackage (GPKG), le champ par défaut utilisé pour stocker la géométrie " +
                      "est 'geom'.Si votre GeoPackage utilise un autre champ pour la géométrie, saisissez-le ici."},
            'raster_folder_name': {
                'en': "Enter the folder name containing the raster items you want to add as a collection. " +
                      "Example: https://datacube-prod-data-public.s3.ca-central-1.amazonaws.com/  " +
                      "<span style='color:red;'><b>store/elevation/cdem-cdsm/cdem</b></span>/cdem-canada-dem.tif",
                'fr': "Saisissez le nom du dossier contenant les items raster que vous souhaitez ajouter en  " +
                      "tant que collection. Exemple : https://datacube-prod-data-public.s3.ca-central-1.amazonaws.com/ " +
                      "<span style='color:red;'><b>store/elevation/cdem-cdsm/cdem/</b></span>cdem-canada-dem.tif"},
            'item_name': {
                'en': "Enter the name of the raster item with its extension you want to add as a collection.  " + "Example: " +
                      "https://datacube-prod-data-public.s3.ca-central-1.amazonaws.com/store/elevation/cdem-cdsm/cdem/ " +
                      "<span style='color:red;'><b>cdem-canada-dem.tif</b></span>",
                'fr': "Saisissez le nom de l'élément matriciel avec son extension que vous souhaitez ajouter en tant que collection.  " +
                      "Exemple : https://datacube-prod-data-public.s3.ca-central-1.amazonaws.com/store/elevation/cdem-cdsm/cdem/ " +
                      "<span style='color:red;'><b>cdem-canada-dem.tif</b></span>"},
            'wms_style_name': {
                'en': "If you want to use a specific symbology from the WMS Layer, enter its name here," +
                      "otherwise the default style will be used.""",
                'fr': "Si vous souhaitez utiliser une symbologie spécifique de la couche WMS, saisissez son " +
                      "nom ici, sinon le style par défaut sera utilisé."},
            'wms_layer_name': {
                'en': "Enter the name of the layer in your WMS Service that matches this collection.",
                'fr': "Entrez le nom de la couche de votre service WMS qui correspond à cette collection."},
            'wms_service_url': {
                'en': "Enter the URL of the underlying WMS Service for your OGC API - Maps.",
                'fr': "Saisissez l'URL du service WMS sous-jacent pour votre API OGC - Maps."}

    }

    tab = {
            'generic_parameters': {
                'en': 'Generic parameters',
                'fr': 'Paramètres génériques'},
            'ows_service': {
                'en': 'OWS service',
                'fr': 'Service OWS'},
            'download_service': {
                'en': 'Download service',
                'fr': 'Service de téléchargement'},
            'oapi_service': {
                'en': 'OAPI service',
                'fr': 'Service OAPI'},
            'log': {
                'en': 'Log',
                'fr': 'Journal'},
            'advanced': {
                'en': 'Advanced',
                'fr': 'Avancé'},
            'common_info': {
                  'en': 'Common information',
                  'fr': 'Information commune'},
            'collection_info': {
                  'en': 'Collection information',
                  'fr': 'Information des collections'},
      }

    buttons = {
            'open_ctl_file_file': {
                'en': 'Open control file',
                'fr': 'Ouvrir fichier contrôle'},
            'save_ctl_file': {
                'en': 'Save control file',
                'fr': 'Sauver fichier contrôle'},
            'process_operation': {
                'en': 'Process operation',
                'fr': 'Exécuter opération'},
            'reset_session': {
                'en': 'Reset session',
                'fr': 'Initialiser session'},
            'add_collection': {
                  'en': 'Add',
                  'fr': 'Ajouter'},
            'modify_collection': {
                  'en': 'Modify',
                  'fr': 'Modifier'},
            'delete_collection': {
                  'en': 'Delete',
                  'fr': 'Détruire'},
            'duplicate_collection': {
                  'en': 'Duplicate',
                  'fr': 'Dupliquer'},
      }

    group_box = {
            'configuration': {
                'en': 'Configuration',
                'fr': 'Configuration'},
            'generic_information': {
                'en': 'Generic Information',
                'fr': 'Information générique'},
            'service_to_process': {
                'en': 'Service(s) to process',
                'fr': 'Service(s) à traiter'},
            'provider_type': {
                  'en': 'Provider type',
                  'fr': 'Type de fournisseur'},
            'collection_list': {
                  'en': 'Collection list',
                  'fr': 'Liste des collections'},
            'collection_edit': {
                  'en': 'Collection edit',
                  'fr': 'Édition d\'une collection'},
            'collection_extent': {
                  'en': 'Collection extent',
                  'fr': 'Étendue de la collection'},
            'postgre_sql_provider': {
                  'en': 'PostgreSQL provider',
                  'fr': 'Fournisseur PostgreSQL'},
            'raster_io_provider': {
                  'en': 'Raster IO provider',
                  'fr': 'Fournisseur Raster IO'},
            'wms_facade_provider': {
                  'en': 'WMS Facade provider',
                  'fr': 'Fournisseur WMS Facade'},
      }

    labels = {
            'workspace': {
                'en': 'Workspace:',
                'fr': 'Espace de travail:'},
            'authentication': {
                'en': 'Authentication:',
                'fr': 'Identification:'},
            'operation': {
                'en': 'Operation:',
                'fr': 'Opération:'},
            'validate': {
                  'en': 'Validate',
                  'fr': 'Valider'},
            'email_address': {
                  'en': 'Email address:',
                  'fr': 'Adresse courriel:'},
            'organization_acronym': {
                  'en': "Organization acronym:",
                  'fr': "Acronyme de l'organisation:"},
            'meta_record_id': {
                  'en': 'Metadata record ID:',
                  'fr': 'ID des métadonnées:'},
            'dataset_name': {
                  'en': 'Dataset name:',
                  'fr': 'Nom du jeu de données:'},
            'ows_service': {
                  'en': 'OGC web services (OWS):',
                  'fr': 'Services web OGC (OWS):'},
            'down_service': {
                  'en': 'Download service:',
                  'fr': 'Service de téléchargement:'},
            'oapi_service': {
                  'en': 'OGC API service (OAPI):',
                  'fr': 'Service OGC API (OAPI):'},
            'data_type': {
                  'en': 'Data type:',
                  'fr': 'Type de données:'},
            'service_type': {
                  'en': 'Service type:',
                  'fr': 'Type de service:'},
            'service_visibility': {
                  'en': 'Service visibility:',
                  'fr': 'Visibilité du service:'},
            'server_type': {
                  'en': 'Server type:',
                  'fr': 'Type de serveur:'},
            'server_id': {
                  'en': 'Server ID:',
                  'fr': 'ID du serveur:'},
            'vector_datastore_id': {
                  'en': 'Vector datastore ID:',
                  'fr': 'ID du dépot de vectorielles:'},
            'raster_datastore_id': {
                  'en': 'Raster datastore ID:',
                  'fr': 'ID du dépot de matricielles:'},
            'project_file_name': {
                  'en': 'QGIS Project file name:',
                  'fr': 'Nom du fichier QGIS:'},
            'service_name': {
                  'en': 'Service name:',
                  'fr': 'Nom du service:'},
            'service_folder_name': {
                  'en': 'Service folder name:',
                  'fr': 'Nom du dossier:'},
            'english': {
                  'en': 'English',
                  'fr': 'Anglais'},
            'french': {
                  'en': 'French',
                  'fr': 'Français'},
            'download_folder_name': {
                  'en': 'Download folder name:',
                  'fr': 'Dossier de téléchargement:'},
            'core_subject_term': {
                  'en': 'Core subject term:',
                  'fr': 'Sujet de base:'},
            'down_service_visibility': {
                  'en': 'Service visibility:',
                  'fr': 'Visibilité du service:'},
            'down_server_id': {
                  'en': 'Server ID:',
                  'fr': 'ID du serveur:'},
            'datastore_id': {
                  'en': 'Datastore ID:',
                  'fr': 'ID du dépot de données:'},
            'oapi_data_type': {
                  'en': 'Data type:',
                  'fr': 'Type de données:'},
            'oapi_service_type': {
                  'en': 'Service type:',
                  'fr': 'Type de service:'},
            'oapi_server_type': {
                  'en': 'Server type:',
                  'fr': 'Type de serveur:'},
            'oapi_service_visibility': {
                  'en': 'Service visibility:',
                  'fr': 'Visibilité du service:'},
            'oapi_server_id': {
                  'en': 'Server ID:',
                  'fr': 'ID du serveur:'},
            'oapi_datastore': {
                  'en': 'Datastore:',
                  'fr': 'Dépôt de données:'},
            'oapi_datastore_id': {
                  'en': 'Datastore ID:',
                  'fr': 'ID du dépôt de données:'},
            'oapi_wms_facade': {
                  'en': 'WMS Facade provider',
                  'fr': 'Fournisseur WMS Facade'},
            'oapi_raster_io': {
                  'en': 'Raster IO provider',
                  'fr': 'Fournisseur Raster IO'},
            'oapi_postgres_sql': {
                  'en': 'PostgreSQL provider',
                  'fr': 'Fournisseur PostgreSQL'},
            'oapi_north': {
                  'en': 'North',
                  'fr': 'Nord'},
            'oapi_east': {
                  'en': 'East',
                  'fr': 'Est'},
            'oapi_south': {
                  'en': 'South',
                  'fr': 'Sud'},
            'oapi_west': {
                  'en': 'West',
                  'fr': 'Ouest'},
            'oapi_collection_name': {
                  'en': 'Collection name:',
                  'fr': 'Nom de la collection:'},
            'oapi_spatial_reference': {
                  'en': 'Spatial reference:',
                  'fr': 'Référence spatiale:'},
            'oapi_temporal_extent_begin': {
                  'en': 'Start date:',
                  'fr': 'Date de début:'},
            'oapi_temporal_extent_end': {
                  'en': 'End date:',
                  'fr': 'Date de fin:'},
            'oapi_end_date_optional': {
                  'en': 'Optional',
                  'fr': 'Optionnelle'},
            'oapi_title': {
                  'en': 'Title:',
                  'fr': 'Titre:'},
            'oapi_description': {
                  'en': 'Description:',
                  'fr': 'Description:'},
            'oapi_keywords': {
                  'en': 'Keywords:',
                  'fr': 'Mots-clés:'},
            'oapi_language_en': {
                  'en': 'English',
                  'fr': 'Anglais'},
            'oapi_language_fr': {
                  'en': 'French',
                  'fr': 'Français'},
            'oapi_geopackage_name': {
                  'en': 'Geopackage name:',
                  'fr': 'Nom du Geopackage:'},
            'oapi_schema_name': {
                  'en': 'Schema name:',
                  'fr': 'Nom du schéma:'},
            'oapi_feature_class_name': {
                  'en': 'Feature class name:',
                  'fr': 'Nom de la classe:'},
            'oapi_data_queryables': {
                  'en': 'Data queryables:',
                  'fr': 'Champs requêtables:'},
            'oapi_data_id_field': {
                  'en': 'Data ID field:',
                  'fr': 'Champ ID:'},
            'oapi_data_geometry_field': {
                  'en': 'Data geometry field:',
                  'fr': 'Champ géométrie:'},
            'oapi_folder_name': {
                  'en': 'Folder name:',
                  'fr': 'Nom du dossier:'},
            'oapi_item_name': {
                  'en': 'Item name:',
                  'fr': 'Nom de l\'item:'},
            'oapi_wms_style_name': {
                  'en': 'WMS style name:',
                  'fr': 'Nom du style WMS:'},
            'oapi_wms_layer_name': {
                  'en': 'WMS layer name:',
                  'fr': 'Nom de la couche:'},
            'oapi_wms_service_url': {
                  'en': 'WMS service URL:',
                  'fr': 'URL du service:'},
            'adv_processing_environment': {
                  'en': 'Processing environment:',
                  'fr': 'Environnement d\'exécution:'},
            'adv_plugin_version': {
                  'en': 'Plugin version:',
                  'fr': 'Version du plugin:'},
            'adv_language': {
                  'en': 'Language:',
                  'fr': 'Langue:'},
            'cdtk_documentation': {
                  'en': 'Link to CDTK documentation',
                  'fr': 'Lien vers la documentation du CDTK'},
      }

    @staticmethod
    def tool_tips(ui: object, lang: str) -> None:
        """Initialize the ToolTips class."""

        # Loop over each item of the tool tips dictionary to add <br> at the end to enable line break
        for key, value in ToolTips.tp.items():
            value['en'] += '<br>'
            value['fr'] += '<br>'
            ToolTips.tp[key] = value

#        ui.setToolTip('')
        ToolTips.tool_tips_tab_gen(ui, lang)
        ToolTips.tool_tips_tab_ows(ui, lang)
        ToolTips.tool_tips_tab_down(ui, lang)
        ToolTips.tool_tips_tab_oapi(ui, lang)
        ui.setStyleSheet("""
            QToolTip {
                font-size: 10pt;  /* Change font size */
                padding: 3px;    /* Add padding */
                border: 1px solid black;  /* Add border */
                background-color: white; /* Change background color */
                max-width: 400px; /* Set maximum width */
                    }
        """)

        ToolTips.set_labels(ui, lang)

    @staticmethod
    def tool_tips_tab_gen(ui: object, lang: str) -> None:
        """Generate the tool tips for the general tab."""

        ui.workspace_dir_file_widget.setToolTip(ToolTips.tp['workspace_dir'][lang])
        ui.authentication_authe_config.setToolTip(ToolTips.tp['authentication'][lang])
        ui.operation_combo_box.setToolTip(ToolTips.tp['operation'][lang])
        ui.validate_check_box.setToolTip(ToolTips.tp['validate'][lang])
        ui.email_line_edit.setToolTip(ToolTips.tp['email'][lang])
        ui.organization_combo_box.setToolTip(ToolTips.tp['organization'][lang])
        ui.meta_id_line_edit.setToolTip(ToolTips.tp['meta_id'][lang])
        ui.dataset_name_line_edit.setToolTip(ToolTips.tp['dataset_name'][lang])
        ui.ows_combo_box.setToolTip(ToolTips.tp['ows_service'][lang])
        ui.download_combo_box.setToolTip(ToolTips.tp['down_service'][lang])
        ui.oapi_combo_box.setToolTip(ToolTips.tp['oapi_service'][lang])

    @staticmethod
    def tool_tips_tab_ows(ui: object, lang: str) -> None:
        """Generate the tool tips for the OWS Service tab."""

        ui.data_type_combo_box.setToolTip(ToolTips.tp['data_type'][lang])
        ui.service_type_combo_box.setToolTip(ToolTips.tp['service_type'][lang])
        ui.service_visibility_combo_box.setToolTip(ToolTips.tp['service_visibility'][lang])
        ui.server_type_line_edit.setToolTip(ToolTips.tp['server_type'][lang])
        ui.ows_server_id_line_edit.setToolTip(ToolTips.tp['server_id'][lang])
        ui.vector_datastore_id_line_edit.setToolTip(ToolTips.tp['vector_datastore_id'][lang])
        ui.raster_datastore_id_line_edit.setToolTip(ToolTips.tp['raster _datastore_id'][lang])
        ui.qgis_project_en_line_edit.setToolTip(ToolTips.tp['qgis_project'][lang])
        ui.qgis_project_en_line_edit.setToolTip(ToolTips.tp['qgis_project'][lang])
        ui.qgis_project_fr_line_edit.setToolTip(ToolTips.tp['qgis_project'][lang])
        ui.service_name_en_line_edit.setToolTip(ToolTips.tp['service_name'][lang])
        ui.service_name_fr_line_edit.setToolTip(ToolTips.tp['service_name'][lang])
        ui.service_name_en_line_edit.setToolTip(ToolTips.tp['service_folder_name'][lang])
        ui.service_name_fr_line_edit.setToolTip(ToolTips.tp['service_folder_name'][lang])

    @staticmethod
    def tool_tips_tab_down(ui: object, lang: str) -> None:
        """Generate the tool tips for the Download Service tab."""
        ui.folder_name_line_edit.setToolTip(ToolTips.tp['folder_name'][lang])
        ui.core_subject_combo_box.setToolTip(ToolTips.tp['core_subject'][lang])
        ui.down_server_visibility_combo_box.setToolTip(ToolTips.tp['down_file_visibility'][lang])
        ui.down_server_id_line_edit.setToolTip(ToolTips.tp['down_server_id'][lang])
        ui.datastore_id_line_edit.setToolTip(ToolTips.tp['datastore_id'][lang])

    @staticmethod
    def tool_tips_tab_oapi(ui: object, lang: str) -> None:
        """Generate the tool tips for the OAPI Service tab."""
        #  TODO: Le tool tip pour le oapi_data_type_combo_box ne fonctionne pas
        ui.oapi_data_type_combo_box.setToolTip(ToolTips.tp['oapi_data_type'][lang])
        ui.oapi_service_type_combo_box.setToolTip(ToolTips.tp['oapi_service_type'][lang])
        ui.oapi_service_visibility_combo_box.setToolTip(ToolTips.tp['oapi_service_visibility'][lang])
        ui.oapi_server_id_line_edit.setToolTip(ToolTips.tp['oapi_server_id'][lang])
        ui.oapi_server_type_line_edit.setToolTip(ToolTips.tp['oapi_server_type'][lang])
        ui.datastore_combo_box.setToolTip(ToolTips.tp['datastore'][lang])
        ui.oapi_datastore_id_line_edit.setToolTip(ToolTips.tp['oapi_datastore_id'][lang])
        ui.wms_facade_check_box.setToolTip(ToolTips.tp['wms_facade'][lang])
        ui.raster_io_check_box.setToolTip(ToolTips.tp['raster_io'][lang])
        ui.postgres_sql_check_box.setToolTip(ToolTips.tp['postgres_sql'][lang])
        ui.add_push_button.setToolTip(ToolTips.tp['oapi_add'][lang])
        ui.modify_push_button.setToolTip(ToolTips.tp['oapi_modifiy'][lang])
        ui.delete_push_button.setToolTip(ToolTips.tp['oapi_delete'][lang])
        ui.duplicate_push_button.setToolTip(ToolTips.tp['oapi_duplicate'][lang])
        ui.collection_name_line_edit.setToolTip(ToolTips.tp['tager_layer_name'][lang])
        ui.spatial_reference_line_edit.setToolTip(ToolTips.tp['spatial_reference'][lang])
        ui.temporal_begin_date.setToolTip(ToolTips.tp['temporal_extent_begin'][lang])
        ui.temporal_end_date.setToolTip(ToolTips.tp['temporal_extent_end'][lang])
        ui.north_line_edit.setToolTip(ToolTips.tp['northern'][lang])
        ui.south_line_edit.setToolTip(ToolTips.tp['southern'][lang])
        ui.east_line_edit.setToolTip(ToolTips.tp['eastern'][lang])
        ui.west_line_edit.setToolTip(ToolTips.tp['western'][lang])
        ui.title_en_line_edit.setToolTip(ToolTips.tp['oapi_title'][lang])
        ui.title_fr_line_edit.setToolTip(ToolTips.tp['oapi_title'][lang])
        ui.description_en_text_edit.setToolTip(ToolTips.tp['oapi_description'][lang])
        ui.description_fr_text_edit.setToolTip(ToolTips.tp['oapi_description'][lang])
        ui.keywords_en_line_edit.setToolTip(ToolTips.tp['oapi_keywords'][lang])
        ui.keywords_fr_line_edit.setToolTip(ToolTips.tp['oapi_keywords'][lang])
        ui.geopackage_name_line_edit.setToolTip(ToolTips.tp['geopackage_name'][lang])
        ui.schema_name_line_edit.setToolTip(ToolTips.tp['schema_name'][lang])
        ui.feature_class_name_line_edit.setToolTip(ToolTips.tp['feature_class_name'][lang])
        ui.data_queryables_line_edit.setToolTip(ToolTips.tp['data_queryables'][lang])
        ui.data_id_field_line_edit.setToolTip(ToolTips.tp['data_id_field'][lang])
        ui.data_geometry_field_line_edit.setToolTip(ToolTips.tp['data_geometry_field'][lang])
        ui.raster_folder_name_line_edit.setToolTip(ToolTips.tp['raster_folder_name'][lang])
        ui.item_name_line_edit.setToolTip(ToolTips.tp['item_name'][lang])
        ui.wms_style_name_line_edit.setToolTip(ToolTips.tp['wms_style_name'][lang])
        ui.wms_layer_name_line_edit.setToolTip(ToolTips.tp['wms_layer_name'][lang])
        ui.wms_service_url_line_edit.setToolTip(ToolTips.tp['wms_service_url'][lang])

    @staticmethod
    def set_labels(ui: object, lang: str) -> None:
        """Generate the tool tips for the OAPI Service tab."""

        # Tab labels
        ui.cdtk_main_panel.setTabText(0, ToolTips.tab['generic_parameters'][lang])
        ui.cdtk_main_panel.setTabText(1, ToolTips.tab['ows_service'][lang])
        ui.cdtk_main_panel.setTabText(2, ToolTips.tab['download_service'][lang])
        ui.cdtk_main_panel.setTabText(3, ToolTips.tab['oapi_service'][lang])
        ui.cdtk_main_panel.setTabText(4, ToolTips.tab['log'][lang])
        ui.cdtk_main_panel.setTabText(5, ToolTips.tab['advanced'][lang])
        ui.oapi_sub_panel.setTabText(0, ToolTips.tab['common_info'][lang])
        ui.oapi_sub_panel.setTabText(1, ToolTips.tab['collection_info'][lang])

        # Push button labels
        ui.open_ctl_file_push_button.setText(ToolTips.buttons['open_ctl_file_file'][lang])
        ui.save_ctl_file_push_button.setText(ToolTips.buttons['save_ctl_file'][lang])
        ui.process_operation_push_button.setText(ToolTips.buttons['process_operation'][lang])
        ui.reset_session_push_button.setText(ToolTips.buttons['reset_session'][lang])

        # Group box labels
        ui.configuration_group_box.setTitle(ToolTips.group_box['configuration'][lang])
        ui.gen_info_group_box.setTitle(ToolTips.group_box['generic_information'][lang])
        ui.services_group_box.setTitle(ToolTips.group_box['service_to_process'][lang])

        # Generic Parameters Tab labels
        ui.workspace_lbl.setText(ToolTips.labels['workspace'][lang])
        ui.authentication_lbl.setText(ToolTips.labels['authentication'][lang])
        ui.operation_lbl.setText(ToolTips.labels['operation'][lang])
        ui.validate_check_box.setText(ToolTips.labels['validate'][lang])
        ui.email_address_lbl.setText(ToolTips.labels['email_address'][lang])
        ui.organization_acronym_lbl.setText(ToolTips.labels['organization_acronym'][lang])
        ui.metadata_id_lbl.setText(ToolTips.labels['meta_record_id'][lang])
        ui.dataset_name_lbl.setText(ToolTips.labels['dataset_name'][lang])
        ui.ows_service_lbl.setText(ToolTips.labels['ows_service'][lang])
        ui.down_service_lbl.setText(ToolTips.labels['down_service'][lang])
        ui.oapi_service_lbl.setText(ToolTips.labels['oapi_service'][lang])

        # OWS Tab labels
        ui.data_type_lbl.setText(ToolTips.labels['data_type'][lang])
        ui.service_type_lbl.setText(ToolTips.labels['service_type'][lang])
        ui.service_visibility_lbl.setText(ToolTips.labels['service_visibility'][lang])
        ui.server_type_lbl.setText(ToolTips.labels['server_type'][lang])
        ui.server_id_lbl.setText(ToolTips.labels['server_id'][lang])
        ui.vector_datastore_id_lbl.setText(ToolTips.labels['vector_datastore_id'][lang])
        ui.raster_datastore_id_lbl.setText(ToolTips.labels['raster_datastore_id'][lang])
        ui.project_file_name_lbl.setText(ToolTips.labels['project_file_name'][lang])
        ui.service_name_lbl.setText(ToolTips.labels['service_name'][lang])
        ui.service_folder_name_lbl.setText(ToolTips.labels['service_folder_name'][lang])
        ui.english_lbl.setText(ToolTips.labels['english'][lang])
        ui.french_lbl.setText(ToolTips.labels['french'][lang])

        # Download Tab labels
        ui.download_folder_name_lbl.setText(ToolTips.labels['download_folder_name'][lang])
        ui.core_subject_term_lbl.setText(ToolTips.labels['core_subject_term'][lang])
        ui.down_service_visibility_lbl.setText(ToolTips.labels['down_service_visibility'][lang])
        ui.down_server_id_lbl.setText(ToolTips.labels['down_server_id'][lang])
        ui.datastore_id_lbl.setText(ToolTips.labels['datastore_id'][lang])

        # Common OAPI Tab labels
        ui.oapi_data_type_lbl.setText(ToolTips.labels['oapi_data_type'][lang])
        ui.oapi_service_type_lbl.setText(ToolTips.labels['oapi_service_type'][lang])
        ui.oapi_server_type_lbl.setText(ToolTips.labels['oapi_server_type'][lang])
        ui.oapi_service_visibility_lbl.setText(ToolTips.labels['oapi_service_visibility'][lang])
        ui.oapi_server_id_lbl.setText(ToolTips.labels['oapi_server_id'][lang])
        ui.oapi_datastore_lbl.setText(ToolTips.labels['oapi_datastore'][lang])
        ui.oapi_datastore_id_lbl.setText(ToolTips.labels['oapi_datastore_id'][lang])
        ui.wms_facade_check_box.setText(ToolTips.labels['oapi_wms_facade'][lang])
        ui.raster_io_check_box.setText(ToolTips.labels['oapi_raster_io'][lang])
        ui.postgres_sql_check_box.setText(ToolTips.labels['oapi_postgres_sql'][lang])
        ui.provider_type_group_box.setTitle(ToolTips.group_box['provider_type'][lang])

        # Collection Info tab
        ui.collection_list_group_box.setTitle(ToolTips.group_box['collection_list'][lang])
        ui.collection_edit_group_box.setTitle(ToolTips.group_box['collection_edit'][lang])
        ui.collection_extent_group_box.setTitle(ToolTips.group_box['collection_extent'][lang])
        ui.postgre_sql_group_box.setTitle(ToolTips.group_box['postgre_sql_provider'][lang])
        ui.raster_io_group_box.setTitle(ToolTips.group_box['raster_io_provider'][lang])
        ui.wms_facade_group_box.setTitle(ToolTips.group_box['wms_facade_provider'][lang])
        ui.add_push_button.setText(ToolTips.buttons['add_collection'][lang])
        ui.modify_push_button.setText(ToolTips.buttons['modify_collection'][lang])
        ui.delete_push_button.setText(ToolTips.buttons['delete_collection'][lang])
        ui.duplicate_push_button.setText(ToolTips.buttons['duplicate_collection'][lang])
        ui.north_lbl.setText(ToolTips.labels['oapi_north'][lang])
        ui.east_lbl.setText(ToolTips.labels['oapi_east'][lang])
        ui.south_lbl.setText(ToolTips.labels['oapi_south'][lang])
        ui.west_lbl.setText(ToolTips.labels['oapi_west'][lang])
        ui.collection_name_lbl.setText(ToolTips.labels['oapi_collection_name'][lang])
        ui.spatial_reference_lbl.setText(ToolTips.labels['oapi_spatial_reference'][lang])
        ui.temporal_begin_lbl.setText(ToolTips.labels['oapi_temporal_extent_begin'][lang])
        ui.temporal_end_lbl.setText(ToolTips.labels['oapi_temporal_extent_end'][lang])
        ui.temporal_end_optional_check_box.setText(ToolTips.labels['oapi_end_date_optional'][lang])
        ui.title_lbl.setText(ToolTips.labels['oapi_title'][lang])
        ui.description_lbl.setText(ToolTips.labels['oapi_description'][lang])
        ui.keywords_lbl.setText(ToolTips.labels['oapi_keywords'][lang])
        ui.language_en_lbl.setText(ToolTips.labels['oapi_language_en'][lang])
        ui.language_fr_lbl.setText(ToolTips.labels['oapi_language_fr'][lang])
        ui.geopackage_name_lbl.setText(ToolTips.labels['oapi_geopackage_name'][lang])
        ui.schema_name_lbl.setText(ToolTips.labels['oapi_schema_name'][lang])
        ui.feature_class_name_lbl.setText(ToolTips.labels['oapi_feature_class_name'][lang])
        ui.data_queryables_lbl.setText(ToolTips.labels['oapi_data_queryables'][lang])
        ui.data_id_field_lbl.setText(ToolTips.labels['oapi_data_id_field'][lang])
        ui.data_geometry_field_lbl.setText(ToolTips.labels['oapi_data_geometry_field'][lang])
        ui.folder_name_lbl.setText(ToolTips.labels['oapi_folder_name'][lang])
        ui.item_name_lbl.setText(ToolTips.labels['oapi_item_name'][lang])
        ui.wms_style_name_lbl.setText(ToolTips.labels['oapi_wms_style_name'][lang])
        ui.wms_layer_name_lbl.setText(ToolTips.labels['oapi_wms_layer_name'][lang])
        ui.wms_service_url_lbl.setText(ToolTips.labels['oapi_wms_service_url'][lang])
        ui.adv_processing_environment_lbl.setText(ToolTips.labels['adv_processing_environment'][lang])
        ui.adv_plugin_version_lbl.setText(ToolTips.labels['adv_plugin_version'][lang])
        ui.adv_language_lbl.setText(ToolTips.labels['adv_language'][lang])
        hyperlink = ui.params.cdtk_documentation
        ui.cdtk_documentation_lbl.setText(f'<a href={hyperlink} style="color:blue;">{ToolTips.labels['cdtk_documentation'][lang]}</a>')
        ui.cdtk_documentation_lbl.setOpenExternalLinks(True)
        
