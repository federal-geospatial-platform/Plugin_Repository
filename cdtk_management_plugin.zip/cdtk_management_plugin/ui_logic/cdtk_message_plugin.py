from typing import Union

from ..nrcan_core.core.cdtk_message import CDTKMessage
from ..nrcan_core.lib.exceptions import UserMessageException
from ..nrcan_core.lib.progress_marks import ProgressMark
from ..nrcan_core.core.util import combine_progress_marks_for_response


class CDTKMessagePlugin(CDTKMessage):
    """
    Manages the messages related to the Plugin
    """

    def __init__(self, log_text_edit) -> None:
        """Constructor"""

        self.log_text_edit = log_text_edit
        super().__init__()  # Call the parent class

    def _log_message(self, english: str, french: str, message_status: str) -> None:
        """Print the message in the Log tab"""

        english = message_status + " - " + english
        french = message_status + " - " + french
        current_pm = [ProgressMark(english, french)]
        english, french = combine_progress_marks_for_response(current_pm)
        current_text = self.log_text_edit.toPlainText()
        current_text = current_text + english + '\n'
        self.log_text_edit.setPlainText(current_text)

    def reset_messages(self) -> None:
        """Reset all the messages"""

        self.progress_marks: list = []
        self.warnings: list = []
        self.errors: list = []
    
    def add_progress(self, english: str, french: str) -> None:
        """Keeps track"""

        super().add_progress(english, french)
        self._log_message(english, french, 'Information')


    def add_error(self, english: str, french: str, internal_error: Union[BaseException, None] = None) -> None:
        """Adds an exception error"""

        super().add_error(english, french, internal_error)
        self._log_message(english, french, 'Error')

    def add_warning(self, english: str, french: str, internal_error: Union[BaseException, None] = None) -> None:
        """Print a warning in the log tab"""

        super().add_error(english, french, internal_error)
        self._log_message(english, french, 'Warning')
