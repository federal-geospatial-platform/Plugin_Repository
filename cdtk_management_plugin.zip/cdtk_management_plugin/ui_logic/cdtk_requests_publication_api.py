"""Docstring"""

from requests import Response
from ..nrcan_core.requests.cdtk_request import CDTKRequest
from ..nrcan_core.lib.cdtk_message import CDTKMessage


class CDTKRequestPublicationAPI(CDTKRequest):
    """Helper class to perform requests to the CDTK Registry API"""

    def __init__(self, message: CDTKMessage, access_token: str, url_publication: str) -> None:
        """Constructor"""

        # Call parent
        super().__init__(url_publication, message)

        # Set the token ID
        self.access_token = access_token

    def get_user_email(self) -> dict | None:
        # Extract the email of the user
        return self.getOrNone('/cdtk_registry_my_publisher_email')

    def get_user_departments(self) -> dict | None:
        # Extract the departments accessible for the user
        return self.getOrNone('/cdtk_registry_departments')

    def get_user_servers(self) -> dict | None:
        # Extract the email of the user
        return self.getOrNone('/cdtk_registry_servers')

    def publish_operation(self, zip_file: str) -> dict:
        # Format the process operation payload
        payload = {}
        files = {'zip_file': open(zip_file, 'rb')}

        # Call put 204
        return self.put_gen('/publish', payload, files=files)

    def validate_operation(self, zip_file: str, operation: str) -> dict:
        # Format the process operation payload
        data = {"operation": operation}
        files = {'zip_file': open(zip_file, 'rb')}

        # Call put 204
        return self.post_gen('/validate', files=files, data=data)

    def unpublish_operation(self, zip_file: str) -> None | dict:
        # Format the process operation payload
        files = {'zip_file': open(zip_file, 'rb')}

        # Call put 204
        return self.delete_gen('/unpublish', files=files)

    def post_gen(self, url_endpoint: str, payload: dict | None = None, files: str | None = None, data: dict | None = None) -> None:
        # Call generic put with no response code check and no raise on error
        res: Response | None = self._post(url_endpoint, payload, [], False, files=files, data=data)

        return res  # type: ignore

    def put_gen(self, url_endpoint: str, payload: dict = {}, files: str | None = None) -> None:
        # Call generic put with no response code check and no raise on error
        res: Response | None = self._put(url_endpoint, payload, [], False, files)

        return res  # type: ignore

    def delete_gen(self, url_endpoint: str, files: str | None = None) -> None:
        # Call generic put with no response code check and no raise on error
        payload = None
        filter_res_code = []
        res: Response | None = self._delete(url_endpoint, payload, filter_res_code, False, files)

        return res  # type: ignore

