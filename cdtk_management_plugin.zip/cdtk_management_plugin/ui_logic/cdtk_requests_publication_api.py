"""Docstring"""

from ..nrcan_core.core.cdtk_request import CDTKRequest


class CDTKRequestPublicationAPI(CDTKRequest):
    """Helper class to perform requests to the CDTK Registry API"""

    def __init__(self, message, username: str, password: str, url_publication) -> None:
        """Constructor"""

        # Call parent
        super().__init__(url_publication, message)

        # Set an access code for the CDTK Registry API
        self.is_valid = self._init_access_token(username, password)

    def _init_access_token(self, username: str, password: str) -> None:
        """Sets an access token using the supplied credentials"""

        payload = {
            'username': username,
            'password': password
        }

        # Call post
        content: dict | None = self.postOrNone("/login", payload)

        # If found
        if content:
            # Set the token value
            self.access_token = content['access_token']

    def get_user_email(self) -> dict | None:
        # Extract the email of the user
        return self.getOrNone("/cdtk_registry_my_publisher_email")

    def get_user_departments(self) -> dict | None:
        # Extract the departments accessible for the user
        return self.getOrNone("/cdtk_registry_departments")

    def get_user_servers(self) -> dict | None:
        # Extract the email of the user
        return self.getOrNone("/cdtk_registry_servers")

    def publish_operation(self, zip_file: str) -> dict:
        # Format the process operation payload
        payload = {}
        files = {'zip_file': open(zip_file, 'rb')}

        # Call put 204
        return self.put_gen("/publish", payload, files=files)

    def unpublish_operation(self, zip_file: str) -> None | dict:
        # Format the process operation payload
        files = {'zip_file': open(zip_file, 'rb')}

        # Call put 204
        return self.delete_gen("/unpublish", files=files)
