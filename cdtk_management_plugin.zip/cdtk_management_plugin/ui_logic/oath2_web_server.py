import http.server
import json
import requests
import socketserver
import traceback
import urllib.parse
import sys


# Step 1: Define the OAuth2 callback handler
class OAuthRequestHandler(http.server.BaseHTTPRequestHandler):

#   def log_message(self, format, *args):
#        # Redirect logs to sys.stdout instead of sys.stderr
#        sys.stdout.write("%s - - [%s] %s\n" %
#                         (self.client_address[0],
#                          self.log_date_time_string(),
#                          format % args))

    def do_GET(self):

        # Parse the query parameters from the URL
        parsed_url = urllib.parse.urlparse(self.path)
        query_params = urllib.parse.parse_qs(parsed_url.query)
        request_path = self.path
        print(f"Parsed url: {parsed_url}")
        print(f"Request_path: {request_path}")
        print(f"Query params: {query_params}")

        # Look for the 'code' in the query string
        if 'code' in query_params:
            auth_code = query_params['code'][0]
            print(f"Authorization Code#1: {auth_code}")

            # Step 2: Exchange the authorization code for an access token
            token_data = {
                'grant_type': 'authorization_code',
                'code': auth_code,
                'code_verifier': code_verifier,
                'client_id': client_id,
                'redirect_uri': redirect_uri,
                'scope': 'openid profile email'
            }

            # Send the request to get the access token without a client secret
            try:
                response = requests.post(token_url_azure, data=token_data)

                # Log the full response to help debug
                print("Token request response status code:", response.status_code)
                print("Token request response body:", response.text)
                print("Token request response headers:", response.headers)

                if response.status_code == 200:
                    token_info = response.json()
                    id_token = token_info.get('id_token')
                    if id_token:
                        print(f"ID Token: {id_token}")

                        # Good, Azure gave us a token, now convert it to a Publication API token
                        token_data = {
                            'microsoft_token': id_token,
                            'client_id': client_id,
                        }

                        headers = {'Content-Type': 'application/json'}

                        response = requests.post(token_url, data=json.dumps(token_data), headers=headers)

                        if response.status_code == 200:
                            token_info = response.json()
                            # Print the token ID to the stdout so the parent process can read it
                            print(f"token_id={token_info['access_token']}")
                            self.send_response(200)
                            self.send_header('Content-type', 'text/html')
                            self.end_headers()
                            self.wfile.write(b"Authentication successful! You can close this window.")
                            sys.exit(0)  # We have the token exit from the infinite loop

                    else:
                        self.send_error(400, 'Access Token not found.')
                else:
                    self.send_error(400, f"Failed to exchange code for token: {response.text}")

            except requests.exceptions.RequestException as e:
                # Handle connection errors
                #print(f"Error during token request: {e}")
                self.send_error(500, f"Internal Server Error: {e}")
                #sys.exit(0)  # Exit from the infinite loop

            except Exception as e:
                stack_trace = traceback.format_exc()
                print (stack_trace)
                sys.exit(0)  # Exit from the infinite loop

        else:
            self.send_error(400, "Authorization code not found in URL.")


# Step 3: Create a simple HTTP server
def run_server():
    try:
        handler = OAuthRequestHandler
        httpd = socketserver.TCPServer((host, port), handler)
        print(f"Oauth2 web server started at http://{host}:{port}")
        httpd.serve_forever()
    except OSError as e:
        if e.errno == 10048:
            headers = {'X-Message': 'testing server'}
            params = {
                      'Test_Web_Server': []
                     }
            response = requests.post(redirect_uri, headers=headers, params=params, timeout=1)
            print (f"Status code: {response.status_code}")
            if response.status_code == 200:
                print ("OK Server is already up")
            else:
                raise ApplicationError("Unknown application running on port xxx")
        else:
            raise ApplicationError("Unable to start the web server")
    except Exception as e:
        stack_trace = traceback.format_exc()
        print(stack_trace)


# Run the server
if __name__ == '__main__':
    params_string = sys.argv[1]
    # Read the serialized string from stdin
    params = json.loads(params_string)

    # Etract the content of the dictionary
    host = params['host']
    port = params['port']
    code_verifier = params['code_verifier']
    client_id = params['client_id']
    redirect_uri = params['redirect_uri']
    token_url_azure = params['token_url_azure']
    token_url = params['token_url']

    # Start the web server
    run_server()
