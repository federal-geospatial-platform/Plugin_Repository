# This folder contains the CDTK Publication API.

#### The source-code at this level is for the api high-level management. Most of the code redirects to logic implemented in the `nrcan_core`
