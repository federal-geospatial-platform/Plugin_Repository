"""
This module stores all configurations used by this application.
"""

try:
    from .lib import aws
except:
    pass

# If the environment is local
IS_LOCAL: bool = True
USER_LOCAL: str = 'daniel-pilon' # This config is only used when debugging. It does not exist for other environments.

# Determine if setting allow-origin for CORS
USE_CORS: bool = True

# Running port
PORT_API: int = 5031
#PORT_WEB: int = 5030

# AWS Secret Manager
try:
    AWS_SECRET_VALUE: dict = aws.get_secret("ca-central-1", "secretsmanager", "cdtk-api-publication-dev")
except:
    AWS_SECRET_VALUE: dict = {}
    AWS_SECRET_VALUE['WEB'] = {}
    AWS_SECRET_VALUE['WEB']['TOKEN_API'] = None

# CDTK Admin URL for internal communication
CDTK_ADMIN_URL: str = "http://localhost:5021/api"

# Clip Zip Ship Admin URL for internal communication
CZS_ADMIN_URL: str = "http://localhost:5001/api"

# PyGeoAPI URL for internal communication
PYGEOAPI_URL: str = "http://localhost:5000/reload_resources"

# FTP Root
FTP_ROOT: str = "https://ftp-staging.services.geo.ca"

# ECS
ECS_IAM_ROLE: str = "arn:aws:iam::862867296240:role/qgis-ecs-ddr-access-staging"
ECS_CLUSTER: str = "arn:aws:ecs:ca-central-1:862867296240:cluster/qgis-stage-micro-service-cluster"
ECS_SERVICE: str = "qgis-stage-micro-service"

# Email configs
EMAIL_ADMIN_CONTENT: list[str] = [] # Ignored when running local (in config_env)
EMAIL_TIMEOUT: int = 5

# QGIS configs
QGIS_JOBS_PATH: str = "..\\jobs"
QGIS_IN_PACKAGES_PATH: str = "..\\in_packs"
QGIS_PROJECTS_PATH: str = "..\\data"
QGIS_PYTHON_PATH: str = "nrcan_qgis"
