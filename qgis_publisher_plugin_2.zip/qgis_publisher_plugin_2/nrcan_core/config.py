"""
This module stores all configurations used by this application.
"""

import os
import getpass
from nrcan_core import config_env


# Determine if using Connexion API.
# Connexion is essentially useful for the Swagger UI and define the spec first.
USING_CONNEXION_API: bool = True

# Security token variables
#TOKEN_COOKIE_NAME = "web_token"
#TOKEN_KEY_WEB = config_env.AWS_SECRET_VALUE['WEB']['TOKEN_WEB']
TOKEN_KEY_API = config_env.AWS_SECRET_VALUE['WEB']['TOKEN_API']
TOKEN_EXP_MINUTES: int = 480
TOKEN_REFRESH_EXP_MINUTES: int = 1440

# Collection max areas by type of layer
COLL_MAX_AREA_POINT: int = 100000000 # Basically unlimited
COLL_MAX_AREA_POLYLINE: int = 2000000 # In km2
COLL_MAX_AREA_POLYGON: int = 400000 # In km2
COLL_MAX_AREA_RASTER_RES_0: int = 1000 # Highest resolution, in km2
COLL_MAX_AREA_RASTER_RES_6: int = 10000 # High resolution, in km2
COLL_MAX_AREA_RASTER_RES_16: int = 100000 # Medium resolution, in km2
COLL_MAX_AREA_RASTER_RES_30: int = 1000000 # Low resolution, in km2

# Roles
ROLE_LEVEL_ADMIN: int = 100
ROLE_LEVEL_USER: int = 1
ROLES: dict[str, int] = {
    'ADMIN': ROLE_LEVEL_ADMIN,
    'USER': ROLE_LEVEL_USER
}

DB_TABLE_USERS: dict[str, str] = {
    'TABLE_NAME': "users",
    'FIELD_ID': "id",
    'FIELD_LDAP_KEY': "ldap_key",
    'FIELD_ROLE': "role"
}

DB_TABLE_TOKEN_BLACKLIST: dict[str, str] = {
    'TABLE_NAME': "users_token_blacklist",
    'FIELD_ID': "id",
    'FIELD_JTI_UID': "jti_uid",
    'FIELD_EXP_DATE': "exp_date"
}

# Define AWS region
AWS_REGION_NAME: str = "ca-central-1"

def QGIS_JOBS_PATH(filename: str) -> str:
    if filename and len(filename) > 0:
        return os.path.join(config_env.QGIS_JOBS_PATH, filename)
    return config_env.QGIS_JOBS_PATH


def QGIS_PROJECTS_PATH(filename: str) -> str:
    if filename and len(filename) > 0:
        return os.path.join(config_env.QGIS_PROJECTS_PATH, filename)
    return config_env.QGIS_PROJECTS_PATH


def QGIS_IN_PACKAGES_PATH(filename: str) -> str:
    if filename and len(filename) > 0:
        return os.path.join(config_env.QGIS_IN_PACKAGES_PATH, filename)
    return config_env.QGIS_IN_PACKAGES_PATH


def QGIS_PYTHON_PATH(filename: str) -> str:
    return os.path.join(config_env.QGIS_PYTHON_PATH, filename)


def EMAIL_USER(email: str) -> str:
    if config_env.IS_LOCAL:
        # Build the email address with the local user name
        user_name = getpass.getuser()
        return f"{user_name}@nrcan-rncan.gc.ca"
    return email
