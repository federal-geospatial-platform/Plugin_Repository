"""This module handles the NRCan business logic to work with the CDTK API."""

# Python imports
import traceback
from werkzeug.datastructures import FileStorage

# Application modules import
from nrcan_core.core import auth, util, cdtk_email
from nrcan_core.core.cdtk_message import CDTKMessage
from nrcan_core.core.cdtk_request_registry_api import CDTKRequestRegistryAPI
from nrcan_core.core.control_file import ControlFile
from nrcan_core.core.zip_file import ZipFile
from nrcan_core.lib.exceptions import *
from nrcan_qgis.lib.progress_marks import *
from nrcan_qgis.lib.warnings import *
from nrcan_qgis.lib.exceptions import *
from nrcan_core.services.abstract_service import AbstractService
from nrcan_core.services.download_service import DownloadService
from nrcan_core.services.oapi_service import OapiService
from nrcan_core.services.ows_service import OwsService
from nrcan_core.core.pyqgis_runner import run_pyqgis


def get_cdtk_my_email() -> str | None:
    """
    Fetches the email of the currently logged in user based on the Publisher table
    """

    # Instantiate the request and message classes
    cdtk_request = CDTKRequestRegistryAPI(CDTKMessage())

    # Get current user
    cur_user: auth.User | None = auth.current_user()

    # If valid
    if cur_user:
        # Get the current user email
        return cdtk_request.get_cdtk_email_by_ad_user_name(cur_user.id)

    # Not found
    return None


def get_cdtk_my_departments() -> list:
    """
    Fetches the CDTK Departments of the currently logged in user based on the Publisher table
    """

    # Instantiate the request and message classes
    cdtk_request = CDTKRequestRegistryAPI(CDTKMessage())

    # Get current user
    cur_user: auth.User | None = auth.current_user()

    # If valid
    if cur_user:
        # Get the current user email
        email: str | None = cdtk_request.get_cdtk_email_by_ad_user_name(cur_user.id)

        # If found
        if email:
            # Get the departments
            return cdtk_request.get_departments_by_publisher(email)

    # Empty list
    return []


def get_cdtk_my_servers() -> list:
    """
    Fetches the CDTK Servers of the currently logged in user based on the Publisher table
    """

    # Instantiate the request and message classes
    cdtk_request = CDTKRequestRegistryAPI(CDTKMessage())

    # Get current user
    cur_user: auth.User | None = auth.current_user()

    # If valid
    if cur_user:
        # Get the current user email
        email: str | None = cdtk_request.get_cdtk_email_by_ad_user_name(cur_user.id)

        # If found
        if email:
            # Get the servers
            return cdtk_request.get_servers_by_publisher(email)

    # Empty list
    return []


def get_cdtk_my_downloads() -> list:
    """
    Fetches the CDTK Downloads of the currently logged in user based on the Publisher table
    """

    # Instantiate the request and message classes
    cdtk_request = CDTKRequestRegistryAPI(CDTKMessage())

    # Get current user
    cur_user: auth.User | None = auth.current_user()

    # If valid
    if cur_user:
        # Get the current user email
        email: str | None = cdtk_request.get_cdtk_email_by_ad_user_name(cur_user.id)

        # If found
        if email:
            # Get the downloads
            return cdtk_request.get_downloads_by_publisher(email)

    # Empty list
    return []


def get_cdtk_dataset(metadata_id: str) -> dict:
    # Instantiate the request and message classes
    cdtk_request = CDTKRequestRegistryAPI(CDTKMessage())

    # Get the datasets associated with the metadata id
    dataset_info: dict | None = cdtk_request.get_dataset(metadata_id)

    # If found
    if dataset_info:
        # Read the dataset id
        dataset_id: str = dataset_info['dataset_id']

        # Get the map services associated with the dataset
        data_pub_infos: list[dict] = cdtk_request.get_data_publication_by_dataset(dataset_id)

        # Only return metadata_id, download_folder_name, core_subject_term and thumbnail_image_file
        return {
            'dataset': dataset_info,
            'data_publications': data_pub_infos
        }

    else:
        # Not found
        raise NotFoundException()


def get_versions() -> dict:
    """
    Fetches the QGIS Versions used by the Publication API
    """

    # Run PyQGIS to read and compare the project file
    pyqgis_version = run_pyqgis("version", {}, "cdtk-postgis-datastore-dev", None)  # TODO: Fix the hardcoded secret

    # Get the versions
    return pyqgis_version


def info_schema(payload: dict) -> dict:
    """
    Gets the service names published under the given schema
    """

    # Start the messager
    message = CDTKMessage()

    # Run PyQGIS to read and validate the project file
    res = run_pyqgis("info_schema", payload, "cdtk-postgis-datastore-dev", message)  # TODO: Fix the hardcoded secret

    # If only 1 exception and it's a SchemaNotFound
    if len(message.errors) == 1 and isinstance(message.errors[0], SchemaNotFound):
        raise NotFoundException()

    # If any errors, raise
    message.if_errors_raise()

    # Return the result
    return res


def info_service(payload: dict) -> dict:
    """
    Gets the information on a particular service
    """

    # Start the messager
    message = CDTKMessage()

    # Run PyQGIS to read and validate the project file
    res = run_pyqgis("info_service", payload, "cdtk-postgis-datastore-dev", message)  # TODO: Fix the hardcoded secret

    # If only 1 exception and it's a ProjectNotFound
    if len(message.errors) == 1 and isinstance(message.errors[0], ProjectNotFoundFromDatabase):
        raise NotFoundException()

    # If any errors, raise
    message.if_errors_raise()

    # Return the result
    return res


def manage_publication(operation: str, zip_file_io: FileStorage, send_email: bool = True) -> bool:
    """
    Manages a publication operation
    """

    def _process_service(cdtk_service: AbstractService) -> None:
        """
        Processes the service and extract the html text
        """

        # Process the service as speciied in the control file
        cdtk_service.process_service()

        # Raise an error if an error was found
        cdtk_service.message.if_errors_raise()

        # Build the html answer
        html_service_en, html_service_fr = cdtk_service.get_html_services_list()
        html_services['english'] += html_service_en
        html_services['french'] += html_service_fr


    def _get_publisher_name() -> str:
        """
        Gets the publisher name by finding the first not None publisher name.
        If all the publisher name are None return None
        """

        p_name: str = "Unknown"
        if ows_service and ows_service.publisher_name is not None:
            p_name = ows_service.publisher_name
        elif download_service and download_service.publisher_name is not None:
            p_name = download_service.publisher_name
        return p_name


    def _set_datasource_id() -> None:
        """
        Assigns the source dataset_id to all target_services
        """

        if ows_service and ows_service.is_service_present():
            # The source service is present assign the dataset id
            for target_service in [download_service, oapi_service]:
                target_service.dataset_id = ows_service.dataset_id


    # START of the publication management
    # Instantiate the message class
    message = CDTKMessage()
    zip_res = None
    control_file_obj = None

    # The services
    services: list[AbstractService] = []
    ows_service = None
    download_service = None
    oapi_service = None

    # Init variables
    html_services: dict[str, str] = {}
    html_services['english'] = ""  # List of services in French
    html_services['french'] = ""  # List of services in english

    try:
        try:
            # Keep track
            message.add_progress("Service started for 'manage_publication'",
                                 "Service démarré pour 'manage_publication'")

            # Load the zip file
            zip_res = ZipFile(zip_file_io, message)

            # Load the control file
            control_file_obj = ControlFile(zip_res.control_file_str, message)
            valid: bool = control_file_obj.validate_content()

            # Instantiate the services and add to the list
            ows_service = OwsService(control_file_obj)
            download_service = DownloadService(control_file_obj)
            oapi_service = OapiService(control_file_obj)
            services.extend([ows_service, download_service, oapi_service])

            # Validate the operation coherence between API and control file
            if valid and operation != control_file_obj.get_operation():
                err_str: str = f"'{operation}' versus '{control_file_obj.get_operation()}'"
                message.add_error(f"Inconsistencies between the operation requested by the API call and the operation of the control file: {err_str}",
                                  f"Incohérence entre l'opération demandée par la requête de l'API et le contenu du fichier de contrôle: {err_str}")

            # Raise an error if an error was set during control file validation
            message.if_errors_raise()

            # Validate each service
            for service in services:
                service.validate_service()

            # Raise an error if the validation of one of the services failed
            message.if_errors_raise()

            # If all services are valid process the requested operation for each service
            for service in services:
                # Main processing call
                _process_service(service)
                # Reset datasource_id if needed
                _set_datasource_id()

            # Keep track
            message.add_progress("Done!", "Terminé!")

            # Done
            return True

        except Exception as err:
            # Extract the detail of the error
            message.set_stack(traceback.format_exc())

            # If a UserMessageException
            if isinstance(err, UserMessageException):
                # If has an internal error
                if err.internal_error is not None:
                    message.set_big_error(err.internal_error)
            else:
                # Internal error. Not a UserMessage one.
                message.set_big_error(err)

            # There was a major error call the rollback of each service
            for service in services:
                service.rollback_service()

            # Keep raising
            raise

    finally:
        # Print out the progress and errors if any
        _print_out(message)

        if zip_res:
            # Clean up
            zip_res.clean_up_directory()

        # If sending email (default mode)
        if send_email and control_file_obj:
            # Send emails when this endpoint has processed
            cdtk_email.send_emails(operation, control_file_obj.get_email(), _get_publisher_name(), message, html_services)


def _print_out(message: CDTKMessage) -> None:
    """
    Prints out what has happened.
    """

    # Read the progress marks
    [english, french] = util.combine_progress_marks_for_response(message.progress_marks)

    # Get the user error message if any
    user_error: UserMessageException | None = message.get_user_message()

    print()
    print()
    print("---------------------- PRINT OUT ----------------------")
    print()
    if message.big_error and not user_error:
        print("Here's the big error:")
        print(str(message.big_error))
        print()
        print("----------------------")
        print()

    if user_error:
        print("Here's the error message sent to the user:")
        print(user_error.message)
        print()

    print("Here's what's happened:")
    print(english)
    print()
    print("----------------------")
    print()
    if user_error:
        print("Voici le message d'erreur envoyé à l'utilisateur:")
        print(user_error.message_fr)
        print()

    print("Voici ce qui est arrivé:")
    print(french)
    print()
