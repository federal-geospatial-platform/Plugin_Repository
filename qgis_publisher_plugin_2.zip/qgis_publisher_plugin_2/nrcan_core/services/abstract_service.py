from abc import ABC, abstractmethod

from nrcan_core.core.cdtk_message import CDTKMessage
from nrcan_core.core.control_file import ControlFile
from nrcan_core.core.cdtk_request_registry_api import CDTKRequestRegistryAPI
from nrcan_core.lib.exceptions import *


class AbstractService(ABC):
    """Abstract class from which all the published services of derived"""

    # Use __slots__ to disable dynamic attribute creation in order to control them at the class level
    __slots__: list[str] = ['control_file', 'message', 'cdtk_request', 'department_info',
                            'publisher_info', 'publisher_name', 'dataset_id',
                            'publication_started', 'publication_ended', 'registry_started', 'registry_ended']


    def __init__(self, control_file: ControlFile) -> None:
        """Constructor"""

        self.control_file: ControlFile = control_file  # The control file
        self.message: CDTKMessage = control_file.message  # Message object that contains: progress marks, warnings and errors
        self.cdtk_request = CDTKRequestRegistryAPI(self.message)
        self.department_info: dict | None = None  # Dictionary containg the department information, only populated once validated
        self.publisher_info: dict | None = None  # Dictionary containg the publisher information, only populated once validated
        self.publisher_name: str | None = None  # Name of the publisher associated with the email, only populated once validated
        self.dataset_id: str | None = None  # Dataset id
        self.publication_started: bool = False  # Flag indicating if the process started in the CDTK Publication
        self.publication_ended: bool = False  # Flag indicating if the process ended in the CDTK Publication
        self.registry_started: bool = False  # Flag indicating if the process started in the CDTK Registry
        self.registry_ended: bool = False  # Flag indicating if the process ended in the CDTK Registry


    def get_service_name(self) -> str:
        """
        Gets the service name for this class
        """

        # Return the service name
        return self.__class__.__name__


    def validate_service(self) -> bool:
        """
        Validates a service. All the control file must be validated to allow to push the service.
        (publish, unpublish or update) to go without errors.
        """

        # Redirect to overridable method
        return self.on_validate_service()


    def process_service(self) -> None:
        """
        Processes the validated service in the registry and publication databases.
        """

        # If service is present
        if self.is_service_present():
            # Redirect to overridable method
            return self.on_process_service(self.control_file.get_operation())

        # Nothing to process
        return None


    def get_html_services_list(self) -> tuple[str, str]:
        """
        Extracts a an html report which summerizes the work done.
        """

        # If service is present
        if self.is_service_present():
            # Redirect to overridable method
            return self.on_get_html_services_list(self.control_file.get_operation())

        # Default
        return ("", "")


    def rollback_service(self) -> None:
        """
        Rollbacks the service process.
        """

        # Start rollback process
        if self.is_service_present():
            # Track progress
            self.message.add_progress(f"Rollback process activated for {self.get_service_name()}",
                                      f"Processus de retour en arrière activé pour {self.get_service_name()}")

            # Redirect to overridable method
            self.on_rollback_service(self.control_file.get_operation())

            # Track progress
            self.message.add_progress(f"Rollback process terminated for {self.get_service_name()}",
                                      f"Processus de retour en arrière terminé pour {self.get_service_name()}")


    @abstractmethod
    def on_validate_service(self) -> bool:
        """
        Overridable method to perform service validation.
        This function performs generic validations.
        """

        # Start by normalizing the control file for the service
        self.on_normalize_control_file()

        # Get access token to CDTK registry
        self.message.add_progress("Testing communication with CDTK Registry.",
                                  "Test du canal de communication avec le Registre CDTK.")

        # Validate the department exists
        dept_info: dict | None = self._validate_department_exists(self.control_file.get_department())
        if dept_info:
            self.department_info = dept_info

        # Validate the publisher exists
        pub_name: str | None = self._validate_publisher_exists_and_department(self.control_file.get_email(), self.control_file.get_department())
        if pub_name:
            self.publisher_name = pub_name

        # Validate the dataset exists for this department
        self._validate_dataset_department(self.control_file.get_metadata_uuid(), self.control_file.get_department())

        return True


    @abstractmethod
    def on_validate_server_type(self, server_type: str) -> bool:
        """
        Overridable method to return True or False depending if the server information is valid for the service.
        """

        # Default not implemented (has to be implemented by child class)
        raise NotImplementedError()


    @abstractmethod
    def on_normalize_control_file(self) -> None:
        """
        Overridable method to normalize a section in the control file. This function performs generic normalizations.
        """

        self.control_file.normalize_common_section()
        return


    @abstractmethod
    def is_service_present(self) -> bool:
        """
        Overridable method to return True or False depending if the service is present in the control file.
        """

        # Default false
        return False

    @abstractmethod
    def on_process_service(self, operation: str) -> None:
        """
        Must-override method to process a service.
        """

        # Default not implemented (has to be implemented by child class)
        raise NotImplementedError()


    @abstractmethod
    def on_get_html_services_list(self, operation: str) -> tuple[str, str]:
        """
        Overridable method to build an html report which summerizes the work done.
        """

        # Default
        return ("", "")


    @abstractmethod
    def on_rollback_service(self, operation: str) -> None:
        """
        Must-override method called when the service needs to rollback cleanly all the transactions
        done in the registry and publication databases.
        """

        # Default not implemented (has to be implemented by child class)
        raise NotImplementedError()


    def _validate_department_exists(self, dept_acrn_en: str) -> dict | None:
        """
        Validates if the department exists.
        """

        # Get the department info
        dept_info: dict | None = self.cdtk_request.get_department(dept_acrn_en)

        # If found
        if dept_info:
            return dept_info

        else:
            # Not found
            self.message.add_error(f"The department with the English TBS acronym {dept_acrn_en} does not exists in the CDTK Registry",
                                   f"Le département dont l'acronyme anglais du TBS est {dept_acrn_en} n'existe pas dans le registre du CDTK")

        return None


    def _validate_publisher_exists_and_department(self, email: str, dept_acrn_en: str) -> str | None:
        """
        Validates if the publisher has permissions to perform an operation on that department.
        """

        # Get the publisher information
        pub_info: dict | None = self.cdtk_request.get_publisher(email)

        # If the publisher exists
        if pub_info:
            # Keep it
            self.publisher_info = pub_info

            # Check if the publisher is linked to the department
            depts_for_publisher: list[dict] = self.cdtk_request.get_departments_by_publisher(email)

            # If exists
            if dept_acrn_en.lower() in [x['tbs_dept_acrn_en'].lower() for x in depts_for_publisher]:
                # Return the publisher full name
                return self.publisher_info['name']

            else:
                self.message.add_error(f"Publisher with email {email} is not allowed to publish for department for department: {dept_acrn_en}",
                                       f"L'éditeur avec le email {email} n'est pas autorisé à publier pour le ministère: {dept_acrn_en}")

        else:
            # Not found
            self.message.add_error(f"The publisher {email} couldn't be validated",
                                   f"L'éditeur {email} n'a pu être validé")

        return None


    def _validate_dataset_department(self, metadata_uuid: str, dept_acrn_en: str) -> None:
        """
        Validates that the dataset department correspond to the department in the conttrol file.
        """

        # Get the dataset information
        dataset_info: dict | None = self.cdtk_request.get_dataset(metadata_uuid)

        # If found the dataset
        if dataset_info:
            # Get the department id for the dataset
            dept_id: str = dataset_info['department_id']

            # Get the dataset id which will be returned if all goes well
            dataset_id: str = dataset_info['dataset_id']

            # Get the department by department id
            departments: list[dict] = self.cdtk_request.get_departments_by_dept_id(dept_id)

            # If found
            if len(departments) == 1:
                # If the department of the existing metadata uuid is the same as the department in the control file
                if departments[0]['tbs_dept_acrn_en'].lower() == dept_acrn_en.lower():
                    self.dataset_id = dataset_id

                else:
                    self.message.add_error(f"Dataset with metadata uuid {metadata_uuid} already exist in the CDTK registry and is associated to another department than requested",
                                           f"Le jeu de données associé à la métadonnée {metadata_uuid} existe déjà dans le registre du CDTK et est associé à un autre ministère que celui demandé")

            else:
                self.message.add_error(f"Dataset with metadata {metadata_uuid} couldn't be validated with the department information",
                                       f"Le jeu de données avec metadonnée {metadata_uuid} n'a pu être validé avec les informations des ministères")

        else:
            # Dataset with metadata doesn't exist, it'll be created, fine
            # Keep track
            self.dataset_id = "CREATE_IT"
            self.message.add_progress(f"A new record will be created in the dataset table with {metadata_uuid} as value for the metadata_id field",
                                      f"Un nouvel enregistrement sera créé dans la table dataset avec {metadata_uuid} comme valeur pour le champ metadata_id")


    def _validate_server_id_exists(self, server_id: str) -> dict | None:
        """
        Validates if the server id exist and if the server type is well associaqted with the service name.
        """

        # Get the server id content
        server_info: dict | None = self.cdtk_request.get_server(server_id)

        # If found
        if server_info:
            # Get the server type
            server_type: str = server_info['server_type']

            # Validate the server type is valid for the name of the service
            if not self.on_validate_server_type(server_type):
                # Not valid
                self.message.add_error(f"Combination of service name: {self.get_service_name()} and server type: {server_type} is invalid.",
                                       f"La combinaison de service name: {self.get_service_name()} and de server type: {server_type} est invalide.")

        else:
            # Server info not found
            self.message.add_error(f"Server ID: {server_id} does not exist in the CDTK Registry.",
                                   f"Le serveur avec l'identifiant: {server_id} n'existe pas dans le registre du CDTK.")

        return server_info


    def _validate_datastore_id_exists(self, datastore_id: str) -> dict | None:
        """
        Extracts the requested datastore ID. Once extracted the field 'hosting' is added to determine if
        the datastore is 'INTERNAL' or 'EXTERNAL'.
        """

        # Get the datastore info
        datastore_info: dict | None = self.cdtk_request.get_datastore(datastore_id)

        # If found
        if datastore_info:
            # Check if special hosting attribute is there
            if not 'hosting' in datastore_info:
                self.message.add_error(f"The 'datastore_type' key is invalid: {datastore_info['datastore_type']} (ID: {datastore_id})'",
                                       f"La clé 'datastore_type' est invalide: {datastore_info['datastore_type']} (ID: {datastore_id})'",)

        else:
            # Not found
            self.message.add_error(f"The datastore with ID: {datastore_id} does not exist in the CDTK Registry",
                                   f"Le site de téléchargement avec l'identifiant: {datastore_id} n'existe pas dans le registre du CDTK")

        return datastore_info
