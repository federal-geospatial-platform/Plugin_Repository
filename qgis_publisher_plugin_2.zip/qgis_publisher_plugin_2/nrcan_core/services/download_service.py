import os
import zipfile

from nrcan_core.core.control_file import ControlFile
from nrcan_core import config
from nrcan_core.core.cdtk_s3_bucket import CDTKS3Bucket
from nrcan_core.services.abstract_service import AbstractService
from nrcan_core.lib import aws
from nrcan_core.lib.exceptions import *


class DownloadService(AbstractService):
    """
    Download Services are accessible through the FTP download (S3 bucket) that are manged by the CDTK
    """

    # Use __slots__ to disable dynamic attribute creation in order to control them at the class level
    __slots__: list[str] = ['server_id_info', 'datastore_info', 'cdtk_s3_bucket']


    def __init__(self, control_file: ControlFile) -> None:
        """Constructor"""

        AbstractService.__init__(self, control_file)
        self.server_id_info: dict | None = None  # Dictionary containing the server information
        self.datastore_info: dict | None = None  # Dictionary containing the dastore information
        self.cdtk_s3_bucket: CDTKS3Bucket | None = None  # Object to access the AWS S3 Bucket


    def is_service_present(self) -> bool:
        """Returns True if a Download service is present in the control file."""

        return self.control_file.has_service_type_download()


    def on_normalize_control_file(self):
        """
        Overrides the way the normalization of the control file is done for a DownloadService
        """

        AbstractService.on_normalize_control_file(self)
        self.control_file.normalize_download_section()


    def on_validate_service(self) -> bool:
        """
        Overrides the way the validation is performed for a DownloadService.
        """

        # Checck if there is a service to validate
        if not self.is_service_present():
            # Nothing to validate
            return True

        # Call parent class for generic validation
        AbstractService.on_validate_service(self)

        # Now that it's valid, we can get the operation
        operation: str = self.control_file.get_operation()

        # Validate the server ID
        # If the server_id isn't set, use the department default server id
        if self.department_info and self.control_file.get_download_server_id() == "":
            self.control_file.set_download_server_id(self.department_info['default_download_server_id'].upper())

        # Extract server information
        self.server_id_info = self._validate_server_id_exists(self.control_file.get_download_server_id())

        # Validate datastore id
        if self.department_info and self.control_file.get_download_datastore_id() == "":
            self.control_file.set_download_datastore_id(self.department_info['default_download_datastore_id'].upper())

        # Extract datastore information
        self.datastore_info = self._validate_datastore_id_exists(self.control_file.get_download_datastore_id())

        # NOTE: To be consistent with the other services (and because we need the self.datastore_info attribute for Publish and Unpublish (not just Publish)?),
        # that's why the validations happen for all operations

        # Depending on the operation
        if operation == "Publish":
            # Validate the service name is not already published
            self._validate_download_service_satus(operation)

            # Validate the folder is not present in the AWS S3 bucket
            self._validate_folder_s3_bucket_status(operation)

            # Validate the content of the zip file
            self._validate_zipfile_content()

        elif operation == "Unpublish":
            # Validate that the service names and dataset are related

             # Validate the download service is published
            self._validate_download_service_satus(operation)

            # Validate the folder is present in the AWS S3 bucket
            if not self.message.if_errors():  # Cannot validate if there are some errors
                self._validate_folder_s3_bucket_status(operation)

        elif operation == "Update":
            # No supplemental validation to be done
            pass

        else:
            # Invalid call
            raise ApplicationException("Invalid operation code in DownloadService.on_validate_service function")

        # Add a progress mark
        if self.message.if_errors():
            self.message.add_progress("The Download service is invalid.", "Le service de téléchargement est invalide.")
            is_valid = False
        else:
            self.message.add_progress("The Download service is valid.", "Le service de téléchargement est valide.")
            is_valid = True

        return is_valid


    def on_validate_server_type(self, server_type: str) -> bool:
        """
        Overrides validation of a server type for the service.
        """

        # Return if the server type is valid
        return server_type.split("_")[0] == "Download"


    def on_process_service(self, operation: str) -> None:
        """
        Overrides the processing of the given operation by the service.
        """

        # Depending on the operation
        if operation == "Publish":
            # Save files in the AWS S3 bucket
            self._save_download_package()

            # Save download information in the CDTK refistry
            self._save_in_cdtk_registry()

        elif operation == "Unpublish":
            # Delete the folder in the AWS S3 bucket
            self._delete_download_package()

            # Delete the download service in the CDTK registry
            self._delete_in_cdtk_registry()


    def on_rollback_service(self, operation: str) -> None:
        """
        Overrides the rollback mecanism for a Download Service.
        """

        # If publish operation
        if operation == "Publish":
            # Rollbacking a Publish
            self._rollback_publish()

        else:
            # Can't rollback that operation
            self.message.add_progress(f"No rollback is possible for service {self.get_service_name()} and operation: {operation}.",
                                      f"Aucun rollback de possible pour le service {self.get_service_name()} et l'opération: {operation}.")


    def on_get_html_services_list(self, operation: str) -> tuple[str, str]:
        """
        Overrides the html report which summerizes the list of accessible Download services.
        """

        folder_name: str = self.control_file.get_download_folder_name()
        core_subject_term: str = self.control_file.get_download_core_subject_term()

        # Loop over each service name to build the server list
        service_list: str = ""
        if operation in ["Publish", "Update"]:
            # Get the Download info
            download_info: dict | None = self.cdtk_request.get_download(core_subject_term, folder_name)

            # If found
            if download_info:
                service_url: str = download_info['download_url']
                service_list = f"<li>{folder_name}: <a href=\'{service_url}'>{service_url}</a></li>"

            else:
                # Not found
                service_list = f"<li>{folder_name}: <i>Error reading the service URL / Erreur lors de la lecture du service URL</i></li>"

        else:
            service_list = f"<li>{folder_name}</li>"

        html_content_en: str = ""
        html_content_fr: str = ""
        if operation == 'Publish':
            html_content_en = html_content_en + "Your publication request for download services proceeded successfully.<br/><br/>"
            html_content_fr = html_content_fr + "Votre requête de publication de service de téléchargment a été exécutée avec succès.<br/><br/>"
            html_content_en = html_content_en + f"Here are the links of the published download services:<ul>{service_list}</ul><br/>"
            html_content_fr = html_content_fr + f"Voici les liens des services de téléchargement publiés:<ul>{service_list}</ul>"

        elif operation == 'Update':
            html_content_en = html_content_en + "Your update request for download services proceeded successfully.<br/><br/>"
            html_content_fr = html_content_fr + "Votre requête de mise-à-jour des services de téléchargement a été exécutée avec succès.<br/><br/>"
            html_content_en = html_content_en + f"Voici les liens des services de téléchargement mis-à-jour:<ul>{service_list}</ul>"
            html_content_fr = html_content_fr + f"Here are the links of the updated download services:<ul>{service_list}</ul><br/>"

        else:
            html_content_en = html_content_en + "Your unpublication request for download services proceeded successfully.<br/><br/>"
            html_content_fr = html_content_fr + "Votre requête de dépublication des services de téléchargement a été exécutée avec succès.<br/><br/>"
            html_content_en = html_content_en + f"Here are the unpublished download services:<ul>{service_list}</ul><br/>"
            html_content_fr = html_content_fr + f"Voici les services de téléchargement dépubliés:<ul>{service_list}</ul>"

        return (html_content_en, html_content_fr)


    def _save_in_cdtk_registry(self) -> None:
        """
        Saves the information of the control file in the CDTK registry.
        """

        # Keep track
        self.message.add_progress("Saving Download services in CDTK Registry.",
                                  "Sauvegarde des services de téléchargement dans le Registre CDTK.")

        # If not enough information
        if not (self.server_id_info and self.datastore_info):
            # Invalid call
            raise ApplicationException("Missing information to save in the CDTK Registry in _save_in_cdtk_registry")

        # Flag
        self.registry_started = True

        # If the dataset must be created
        if self.dataset_id == "CREATE_IT":
            # Save the dataset in the CDTK registry
            dataset_info: dict = self.cdtk_request.put_dataset(self.control_file.get_dataset_name(),
                                                               self.control_file.get_department(),
                                                               self.control_file.get_metadata_uuid())

            # Only 201 stustus code is returned
            self.dataset_id = dataset_info['dataset_id']

        # Save a data_publication in the cdtk registry
        # Note: Casting the dataset_id to str, because it'll be defined, not None by this point. Saving a warning.
        data_pub_info: dict = self.cdtk_request.put_data_publication("Download",
                                                                     self.server_id_info['server_id'],
                                                                     str(self.dataset_id),
                                                                     self.control_file.get_email())

        # Save the Download published data in the cdtk registry
        self.cdtk_request.put_downloads(data_pub_info['data_publication_id'],
                                        self.datastore_info['datastore_id'],
                                        self.control_file.get_download_core_subject_term(),
                                        self.control_file.get_download_folder_name())

        # Flag
        self.registry_ended = True


    def _save_download_package(self) -> None:
        """
        Saves the unzip content of the zip file in the AWS S3 bucket.
        """

        # Keep track
        self.message.add_progress("Extracting and saving download package to FTP",
                                "Extraction et sauvegarde du paquet de téléchargement dans le FTP")

        # If not enough information
        if not (self.cdtk_s3_bucket and self.cdtk_s3_bucket.owner_username and self.cdtk_s3_bucket.download_root_subpath):
            # Invalid call
            raise ApplicationException("Missing information to save in S3 in _save_download_package")

        # Flag
        self.publication_started = True

        # Get S3 path
        s3_path_prefix: str = self.cdtk_s3_bucket.get_download_path(False, None)

        # Set the destination folder and zip file path
        folder_name: str = self.control_file.get_download_folder_name()
        dest_path: str = config.QGIS_PROJECTS_PATH(folder_name)

        # If the folder doesn't exist, create it
        if not os.path.exists(dest_path):
            os.makedirs(dest_path)

        # Extract the zip content in the folder
        zip_path: str = dest_path + ".zip"
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            for info in zip_ref.infolist():
                # Extract the file
                zip_ref.extract(info, dest_path)

        # Upload the folder to S3
        aws.upload_bucket_folder(dest_path, self.cdtk_s3_bucket.owner_username,
                                 self.cdtk_s3_bucket.download_root_subpath, s3_path_prefix)

        # Keep track
        self.message.add_progress(f"Download package saved to {s3_path_prefix}/{folder_name}",
                                  f"Paquet de téléchargement sauvegardé dans {s3_path_prefix}/{folder_name}")

        # Flag
        self.publication_ended = True


    def _delete_download_package(self) -> None:
        """
        Deletes the content of the folder name in the AWS S3 bucket.
        """

        # Keep track
        self.message.add_progress("Delete content of the download package in the AWS S3 bucket (FTP)",
                                  "Destruction du paquet de téléchargement dans le le S3 bucket de AWS (FTP)")

        # If not enough information
        if not (self.cdtk_s3_bucket and self.cdtk_s3_bucket.owner_username and self.cdtk_s3_bucket.download_root_subpath):
            # Invalid call
            raise ApplicationException("Missing information to delete in S3 in _delete_download_package")

        try:
            # Get S3 path
            s3_path_prefix: str = self.cdtk_s3_bucket.get_download_path(False, None)
            folder_name: str = self.control_file.get_download_folder_name()

            # Delete the folder in S3
            aws.delete_bucket_folder(folder_name, self.cdtk_s3_bucket.owner_username, self.cdtk_s3_bucket.download_root_subpath, s3_path_prefix)

            # Keep track
            self.message.add_progress(f"Download package deleted to {s3_path_prefix}/{folder_name}",
                                      f"Paquet de téléchargement détruit dans {s3_path_prefix}/{folder_name}")

        except Exception as err:
            # Failed saving download package, unregister from CDTK and unpublish everything
            self.message.add_error_raise("Error when deleting download package.",
                                         "Erreur lors de la suppression du paquet de téléchargement.",
                                         err)


    def _rollback_publish(self) -> None:
        """
        Rollbacks a publish operation
        """

        # If flagged
        if self.publication_started:
            cdtk_type = "S3 Bucket"
            if self.publication_ended:
                # Can safely start the rollback
                try:
                    self.message.add_progress(f"Rollback started for {cdtk_type}.", f"Retour en arrière démarré pour le {cdtk_type}.")
                    self._delete_download_package()
                    self.message.add_progress(f"Rollback terminated for {cdtk_type}.", f"Retour en arrière terminé pour le {cdtk_type}.")
                except Exception:
                    self.message.add_progress(f"Rollback error for {cdtk_type}. Manual operation will have to take place",
                                              f"Retour en arrière en erreur pour le {cdtk_type}. Des mesures manuelles devront être prises")

            else:
                # Cannot start safely the rollback process
                self.message.add_progress(f"The publication in the {cdtk_type} failed in the middle of the process.",
                                          f"La publication dans le {cdtk_type} a arrêtée avant la fin.")
                self.message.add_progress(f"It is impossible to rollback. Manual operation will have to take place in the {cdtk_type}",
                                          f"Il est imposssible de faire un retour en arrière. Des mesures manuelles devront être prises dans le {cdtk_type}.")

        if self.registry_started:
            cdtk_type = "CDTK Registry"
            if self.registry_ended:
                # Can safely start the rollback of the CDTK Registry
                try:
                    self.message.add_progress(f"Rollback started for {cdtk_type}.", f"Retour en arrière démarré pour le {cdtk_type}.")
                    self._delete_in_cdtk_registry()
                    self.message.add_progress(f"Rollback terminated for {cdtk_type}.", f"Retour en arrière terminé pour le {cdtk_type}.")
                except Exception:
                    self.message.add_progress(f"Rollback error for {cdtk_type}. Manual operation will have to take place",
                                              f"Retour en arrière en erreur pour le {cdtk_type}. Des mesures manuelles devront être prises")
            else:
                # Cannot start safely the rollback process
                self.message.add_progress(f"The publication in the {cdtk_type} failed in the middle of the process.",
                                          f"La publication dans le {cdtk_type} a arrêtée avant la fin.")
                self.message.add_progress(f"It is impossible to rollback. Manual operation will have to take place in the {cdtk_type}",
                                          f"Il est imposssible de faire un retour en arrière. Des mesures manuelles devront être prises dans le {cdtk_type}.")


    def _validate_zipfile_content(self) -> None:
        """
        This method validates that the zip file:
          - contains a least one non directory file
          - root directory is the same as the folder name
        """

        # Set the destination folder and zip file path
        nbr_data_file: int = 0
        valid_root_folder: bool = False
        root_folder: str = self.control_file.get_download_folder_name()
        dest_path: str = config.QGIS_PROJECTS_PATH(root_folder)
        root_folder: str = root_folder + "/"

        # Loop over the content of the zip file to test the condition
        zip_path: str = dest_path + ".zip"
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            for info in zip_ref.infolist():
                if info.is_dir():
                    if info.filename == root_folder:
                        valid_root_folder = True
                else:
                    nbr_data_file += 1

        if nbr_data_file == 0:
            # The zip file should contains at least one data file (Warning)
            self.message.add_warning(f"The zip file: {zip_path} should contain at least one data file.",
                                     f"Le fichier zip: {zip_path} devrait contenir au moins un fichier de données.")

        if not valid_root_folder:
             self.message.add_error(f"The directory: {root_folder} is not present in the zip file: {zip_path}",
                                    f"Le répertoire: {root_folder} n'est pas présent dans le fichier zip: {zip_path}")

        return


    def _delete_in_cdtk_registry(self) -> None:
        """
        Deletes the download service in the CDTK registry.
        The delete service takes care of deleting and cleaning all the CDTK tables.
        """

        # Keep track
        self.message.add_progress("Deleting Download services in CDTK Registry.",
                                  "Destruction des services de téléchargement dans le Registre CDTK.")

        try:
            # Delete the French and English services.
            # The delete takes care of cleaning the following tables: download_service, data_publication and dataset
            folder_name: str = self.control_file.get_download_folder_name()
            core_subject_term: str = self.control_file.get_download_core_subject_term()

            # Call delete service
            deleted: bool = self.cdtk_request.delete_downloads(core_subject_term, folder_name)

            # If failed to delete in the registry
            if not deleted:
                self.message.add_error_raise(f"Failed to delete the Download service: {core_subject_term}/{folder_name} in the CDTK Registry.",
                                             f"Erreur lors de la destruction du service de téléchargement: {core_subject_term}/{folder_name} dans le Registre CDTK.")

            return

        except Exception as err:
            # Keep track
            self.message.add_progress("Failed deleting in CDTK Registry, no reverting.",
                                      "Échec lors de la destruction dans le Registre CDTK, pas de retour arrière.")

            # Keep raising err
            raise err


    def _validate_download_service_satus(self, operation: str) -> None:
        """
        Validates the status of the download service.
        If the download service exist and the operation is Publish ==> Add an error
        If the download service does not exist and the operation is Unublish or Update ==> Add an error
        """

        folder_name: str = self.control_file.get_download_folder_name()
        core_subject_term: str = self.control_file.get_download_core_subject_term()

        # Get the download information
        download_info: dict | None = self.cdtk_request.get_download(core_subject_term, folder_name)

        # If found
        if download_info:
            if operation in ["Update", "Unpublish"]:
                # Extract the datastore information link to the datastore_id
                datastore_id: str = download_info['datastore_id']

                # Get the datastore information
                datastore_info: dict | None = self.cdtk_request.get_datastore(datastore_id)

                # If found
                if datastore_info:
                    # Keep it
                    self.datastore_info = datastore_info

                else:
                    # Not found
                    self.message.add_error(f"The datastore information associated with the download information couldn't be retrieved.",
                                           f"L'information sur le data store associé au service de téléchargement n'a pas être obtenu.")
            else:
                self.message.add_error(f"The download service: {core_subject_term}/{folder_name} exists. Cannot publish it.",
                                       f"Le service de téléchargement existe: {core_subject_term}/{folder_name}. Impossible de le publier.")

        else:
            # Not found
            if operation in ["Publish"]:
                pass  # We can update it

            else:
                self.message.add_error(f"The download service: {core_subject_term}/{folder_name} is not published. Cannot update/unpublish it.",
                                       f"Le service de téléchargement n'est pas publié: {core_subject_term}/{folder_name}. Impossible de le mettre à jour/dépublier.")

        return


    def _validate_folder_s3_bucket_status(self, operation: str) -> None:
        """
        Validates if the folder is present in the S3 Bucket
        If the download folder exist in AWS and the operation is Publish ==> Add an error
        If the download folder does not exist and the operation is Unublish or Update ==> Add only a warning
        """

        # Check if the s3 path exists already
        s3_path_found, s3_path_prefix = self.check_s3_path_exists()

        # If publishing and s3 path was already existing
        if operation == "Publish" and s3_path_found:
            # Add an error there is a file to publish
            self.message.add_error(f"The download package folder: {s3_path_prefix} is already published on the server.",
                                   f"Le paquet de téléchargement: {s3_path_prefix} est déjà publié sur le serveur.")

        # If updating/unpublishing and s3 path was not already existing
        if operation in ["Unpublish", "Update"] and not s3_path_found:
            # We should have found files but no one was found
            self.message.add_warning(f"The s3 folder: {s3_path_prefix} contains no file.",
                                     f"Le dossier s3: {s3_path_prefix} ne contient pas de fichier.")


    def check_s3_path_exists(self) -> list:
        """
        Checks if the S3 path exists
        """

        # If not enough information
        if not (self.department_info and self.datastore_info):
            # Invalid call
            raise ApplicationException("Missing information to check in S3 in check_s3_path_exists")

        dept_acr_en: str = self.department_info['tbs_dept_acrn_en']
        dept_acr_fr: str = self.department_info['tbs_dept_acrn_fr']
        secret_name: str = self.datastore_info['connection_string']
        folder_name: str = self.control_file.get_download_folder_name()
        core_subject_term: str = self.control_file.get_download_core_subject_term()

        self.cdtk_s3_bucket = CDTKS3Bucket(dept_acr_en, dept_acr_fr, core_subject_term, folder_name, secret_name, self.message)

        # Get S3 path prefix
        s3_path_prefix: str = self.cdtk_s3_bucket.get_download_path(True, None)

        # Get list of objects in bucket on the s3 path prefix
        res: dict = self.cdtk_s3_bucket.list_bucket(s3_path_prefix)

        # For each object bucket key in S3
        object_found = False
        for b_key in [x.key for x in res]:
            # Validate that it doesn't already exist in S3
            if not object_found and b_key.startswith(s3_path_prefix):
                object_found = True

        # Return if found
        return [object_found, s3_path_prefix]
