from typing import Any
from nrcan_core.core.control_file import ControlFile
from nrcan_core.services.abstract_service import AbstractService
from nrcan_core.core.pyqgis_runner import run_pyqgis
from nrcan_core.lib.exceptions import *


class OwsService(AbstractService):
    """OWS service include WMS, WFS and WCS service that are managed by the CDTK"""

    # Use __slots__ to disable dynamic attribute creation in order to control them at the class level
    __slots__: list[str] = ['raster_datastore_info', 'vector_datastore_info', 'server_id_info', 'qgis_project_info']


    def __init__(self, control_file: ControlFile) -> None:
        """Constructor"""

        AbstractService.__init__(self, control_file)
        self.server_id_info: dict | None = None  # Dictionary containing the server information
        self.raster_datastore_info: dict | None = None  # Dictionary containing the raster dastore information
        self.vector_datastore_info: dict | None = None  # Dictionary containing the vector dastore information
        self.qgis_project_info: dict | None = None  # Dictionary containing the qgis project information


    def is_service_present(self) -> bool:
        """Returns True if an OWS service is present in the control file"""

        return self.control_file.has_service_type_ows()


    def on_normalize_control_file(self) -> None:
        """
        Overrides the way the normalization of the control file is done for a OWSService
        """

        AbstractService.on_normalize_control_file(self)
        self.control_file.normalize_ows_section()


    def on_validate_service(self) -> bool:
        """
        Overrides the way the validation is performed for a OWSService.
        """

        # Check if there is something to validate
        if not self.is_service_present():
            # Nothing to validate and let's assume the validation is True
            return True

        # Call parent class for generic validation
        AbstractService.on_validate_service(self)

        # Now that it's valid, we can get the operation
        operation: str = self.control_file.get_operation()

        # Validate the server ID, use the department default value when not set
        ows_service_parameters: dict = self.control_file.get_ows_service_parameters()
        if self.department_info and ows_service_parameters['server_id'] == "":
            ows_service_parameters['server_id'] = self.department_info['default_ows_server_id'].upper()

        self.server_id_info = self._validate_server_id_exists(ows_service_parameters['server_id'])

        # Validate raster datastore id, use the department default value when not set
        if self.department_info and ows_service_parameters['raster_datastore_id'] == "":
            ows_service_parameters['raster_datastore_id'] = self.department_info['default_raster_datastore_id'].upper()

        self.raster_datastore_info = self._validate_datastore_id_exists(ows_service_parameters['raster_datastore_id'])

        # Validate vector datastore id, use the department default value when not set
        if self.department_info and ows_service_parameters['vector_datastore_id'] == "":
            ows_service_parameters['vector_datastore_id'] = self.department_info['default_vector_datastore_id'].upper()

        # Keep the vector datastore info
        self.vector_datastore_info = self._validate_datastore_id_exists(ows_service_parameters['vector_datastore_id'])

        # NOTE: We need the self.vector_datastore_info attribute for Publish and Unpublish (not just Publish),
        # that's why the validations happen for all operations

        # Depending on the operation
        if operation == "Publish":
            # Validate the service name is not already published
            self._validate_service_name_not_exists()

        elif operation == "Unpublish":
            # Validate that the service names and dataset are related
            self._validate_service_name_dataset_exists()

        elif operation == "Update":
            # No supplemental validation to be done
            pass

        else:
            raise ApplicationException("Invalid operation code in OwsService.on_validate_service function")

        # Add a progress mark
        if self.message.if_errors():
            self.message.add_progress("The OWS service is invalid.", "Le service OWS est invalide.")
            is_valid = False
        else:
            self.message.add_progress("The OWS service is valid.", "Le service OWS est valide.")
            is_valid = True

        return is_valid


    def on_validate_server_type(self, server_type: str) -> bool:
        """
        Overrides validation of a server type for the service.
        """

        # Return if the server type is valid
        return server_type.split("_")[0] == "OWS"


    def on_process_service(self, operation: str) -> None:
        """
        Overrides the processing of the given operation by the service.
        """

        # If not enough information
        if not (self.vector_datastore_info):
            # Invalid call
            raise ApplicationException("Missing information to process service in OAPI service in on_process_service")

        # Depending on the operation
        if operation == "Publish":
            # Flag
            self.publication_started = True

            # Execute
            self.qgis_project_info = run_pyqgis("export_publish", self.control_file.inner_dict, self.vector_datastore_info['connection_string'], self.message)

            # Unflag
            self.publication_ended = True

            try:
                # Save in registry
                self._save_in_cdtk_registry()
            except Exception as err:
                self.message.add_error_raise("An error has occured when writing in the CDTK Registry",
                                             "Une erreur est survenue durant l'écriture dans le CDTK Registry",
                                             err)

        elif operation == "Unpublish":
            try:
                # Delete from registry
                self._delete_in_cdtk_registry()
            except Exception as err:
                self.message.add_error_raise("An error has occured when deleting in the CDTK Registry",
                                             "Une erreur est survenue durant la suppresion dans le CDTK Registry",
                                             err)

            # Flag
            self.publication_started = True

            # Execute
            self.qgis_project_info = run_pyqgis("delete_service_and_data", self.control_file.inner_dict, self.vector_datastore_info['connection_string'], self.message)

            # Unflag
            self.publication_ended = True


    def on_rollback_service(self, operation: str) -> None:
        """
        Overrides the rollback mecanism for an OWS Service.
        """

        # If publish operation
        if operation == "Publish":
            # Rollbacking a Publish
            self._rollback_publish()

        else:
            # Can't rollback that operation
            self.message.add_progress(f"No rollback is possible for service {self.get_service_name()} and operation: {operation}.",
                                      f"Aucun rollback de possible pour le service {self.get_service_name()} et l'opération: {operation}.")


    def on_get_html_services_list(self, operation: str) -> tuple[str, str]:
        """
        Overrides the html report which summerizes the list of accessible OWS services.
        """

        sp: dict = self.control_file.get_ows_service_parameters()
        ows_service_type: dict = self.control_file.get_ows_service_parameters_ows_service_type()

        # Get the service names
        service_names: list[tuple[str, str]] = [('english', sp['english']['service_name']), ('french', sp['french']['service_name'])]

        # Loop over each service name to build the server list
        services_list_en: str = ""
        services_list_fr: str = ""
        for language, service_name in service_names:
            for service_type in ["WMS", "WCS", "WFS"]:
                if ows_service_type[service_type] == "True":
                    text_html: str = ""
                    if operation in ["Publish", "Update"]:
                        # Get the OWS service
                        ows_service: dict | None = self.cdtk_request.get_ows_service(service_name, service_type)

                        # If found
                        if ows_service:
                            service_url: str = ows_service['service_url']
                            text_html = f"<li>{service_type}: <a href=\'{service_url}'>{service_url}</a></li>"

                        else:
                            # Not found
                            text_html = f"<li>{service_type}: {service_name}: <i>Error reading the service URL / Erreur lors de la lecture du service URL</i></li>"

                    else:
                        # Unpublish service
                        text_html = f"<li>{service_type}: {service_name}</li>"

                    if language == 'english':
                        services_list_en = services_list_en + text_html

                    else:
                        services_list_fr = services_list_fr + text_html

        html_content_en: str = ""
        html_content_fr: str = ""
        if operation == 'Publish':
            html_content_en = html_content_en + "Your publication request for OWS services proceeded successfully.<br/><br/>"
            html_content_fr = html_content_fr + "Votre requête de publication de services OWS a été exécutée avec succès.<br/><br/>"
            html_content_en = html_content_en + f"Here are the links of the published OWS services:<ul>{services_list_en}</ul><br/>"
            html_content_fr = html_content_fr + f"Voici les liens des services OWS publiés:<ul>{services_list_fr}</ul>"

        elif operation == 'Update':
            html_content_en = html_content_en + "Your update request for OWS services proceeded successfully.<br/><br/>"
            html_content_fr = html_content_fr + "Votre requête de mise-à-jour de services OWS a été exécutée avec succès.<br/><br/>"
            html_content_en = html_content_en + f"Voici les liens des services OWS mis-à-jour:<ul>{services_list_en}</ul>"
            html_content_fr = html_content_fr + f"Here are the links of the updated OWS services:<ul>{services_list_fr}</ul><br/>"

        else:
            html_content_en = html_content_en + "Your unpublication request for OWS services proceeded successfully.<br/><br/>"
            html_content_fr = html_content_fr + "Votre requête de dépublication de services OWS a été exécutée avec succès.<br/><br/>"
            html_content_en = html_content_en + f"Here are the unpublished services:<ul>{services_list_en}</ul><br/>"
            html_content_fr = html_content_fr + f"Voici les services dépubliés:<ul>{services_list_fr}</ul>"

        return (html_content_en, html_content_fr)


    def _save_in_cdtk_registry(self) -> None:
        """Saves the service in the CDTK Registry"""

        def _set_datasources() -> None:

            # If not enough information
            if not (self.qgis_project_info):
                # Invalid call
                raise ApplicationException("Missing information to set datasources in _set_datasources in _save_in_cdtk_registry")

            qgis_project_layers: list[dict] = self.qgis_project_info['results'][0]['layers']
            for qgis_project_layer in qgis_project_layers:
                datasource: dict = {}

                # If coverage type
                if qgis_project_layer['type'] == 'coverage':
                    # If not enough information
                    if not (self.raster_datastore_info):
                        # Invalid call
                        raise ApplicationException("Missing information to set datasources for coverage type in _set_datasources in _save_in_cdtk_registry")

                    # Set data from the datacube
                    address: str = qgis_project_layer['uri']['path']  # Extract the address of the datacube address
                    parts: list[str] = address.split('/')  # Split the parts
                    path: str = '/'.join(parts[5:len(parts)-1])  # Reconstruct the path
                    name: str =  parts[-1]  # Extract the name
                    datasource['name'] = name
                    datasource['path'] = path
                    datasource['datastore_id'] = self.raster_datastore_info['datastore_id']

                else:
                    # If not enough information
                    if not (self.vector_datastore_info):
                        # Invalid call
                        raise ApplicationException("Missing information to set datasources for vector type in _set_datasources in _save_in_cdtk_registry")

                    # Set data from the Postgres database
                    datasource['name'] = qgis_project_layer['name_table']
                    datasource['path'] = self.control_file.get_department()
                    datasource['datastore_id'] = self.vector_datastore_info['datastore_id']

                # Add the datasource
                datasources.append(datasource)

        # Keep track
        self.message.add_progress("Saving OWS services in CDTK Registry.",
                                  "Sauvegarde des services OWS dans le Registre CDTK.")

        # If not enough information
        if not (self.server_id_info and self.dataset_id):
            # Invalid call
            raise ApplicationException("Missing information to save in CDTK Registry in _save_in_cdtk_registry")

        # Flag
        self.registry_started = True

        server_id: str = self.server_id_info['server_id']
        service_type: str = "OWS"
        datasources: list[dict] = []
        ows_services: list[str] = []

        # If the dataset must be created
        if self.dataset_id == "CREATE_IT":
            # Save the dataset in the CDTK registry
            dataset_info: dict = self.cdtk_request.put_dataset(self.control_file.get_dataset_name(), self.control_file.get_department(), self.control_file.get_metadata_uuid())

            # Only 201 stustus code is returned
            self.dataset_id = dataset_info['dataset_id']

        # Save each datasource in the CDTK registry
        _set_datasources()
        for datasource in datasources:
            # Save in the datasource registry
            datasource_info: dict = self.cdtk_request.put_datasource(datasource['datastore_id'], datasource['name'], datasource['path'])

            # Only status code 201 is returned
            # Get the datasource_id
            datasource_id: str = datasource_info['datasource_id']

            # Keep the datasource_id for the next operation
            datasource[datasource['name']] = datasource_id

        # Create the list of OWS services to publish
        for ows_service in ["WMS", "WFS", "WCS"]:
            if self.control_file.get_ows_service_parameters_ows_service_type()[ows_service] == "True":
                ows_services.append(ows_service)

        # Process separatly each ows service
        for ows_service in ows_services:
            # Save a data_publication in the cdtk registry
            # Note: Casting the dataset_id to str, because it'll be defined, not None by this point. Saving a warning.
            data_pub_info: dict = self.cdtk_request.put_data_publication(service_type,
                                                                         server_id,
                                                                         str(self.dataset_id),
                                                                         self.control_file.get_email())

            # Only status code 201 is returned
            data_publication_id: str = data_pub_info['data_publication_id']

            sp: dict = self.control_file.get_ows_service_parameters()
            for datasource in datasources:
                for language in ["english", "french"]:
                    # Save the OWS published data in the cdtk registry
                    self.cdtk_request.put_ows_service(sp[language]['service_name'], ows_service,
                                                      data_publication_id, datasource[datasource['name']],
                                                      sp[language]['project_filename'], language)

        # Flag
        self.registry_ended = True


    def _delete_in_cdtk_registry(self) -> None:
        """
        Deletes the service from the CDTK Registry
        """

        # Keep track
        self.message.add_progress("Deleting OWS services in CDTK Registry.",
                                  "Destruction des services OWS dans le Registre CDTK.")

        try:
            # Delete the French and English services.
            # NOTE: The French service name gets deleted automatically by deleting the English one. That code is handled elsewhere.
            # The delete takes care of cleaning the following tables: datasource, ows_service, data_publication and dataset
            service_name: str = self.control_file.get_ows_service_parameters_english_service_name()

            # Delete the French and English services.
            deleted: bool = self.cdtk_request.delete_ows_service(service_name)

            # If failed to save in the registry
            if not deleted:
                self.message.add_error_raise(f"Failed to delete the OSW service: {service_name} in the CDTK Registry.",
                                             f"Erreur lors de la destruction du service OWS: {service_name} dans le Registre CDTK.")

            return

        except Exception as err:
            # Keep track
            self.message.add_progress("Failed deleting in CDTK Registry, no reverting.",
                                      "Échec lors de la destruction dans le Registre CDTK, pas de retour arrière.")

            # Keep raising err
            raise err


    def _rollback_publish(self) -> None:
        """
        Rollbacks a publish operation
        """

        # If flagged
        if self.publication_started:
            cdtk_type = "CDTK Publication"
            if self.publication_ended:
                # If not enough information
                if not (self.vector_datastore_info):
                    # Invalid call
                    raise ApplicationException("Missing information to rollback in OWS service in _rollback_publish")

                # Can safely start the rollback
                try:
                    self.message.add_progress(f"Rollback started for {cdtk_type}.", f"Retour en arrière démarré pour le {cdtk_type}.")
                    self.qgis_project_info = run_pyqgis("delete_service_and_data", self.control_file.inner_dict,
                                                        self.vector_datastore_info['connection_string'], self.message)
                    self.message.add_progress(f"Rollback terminated for {cdtk_type}.", f"Retour en arrière terminé pour le {cdtk_type}.")
                except Exception:
                    self.message.add_progress(f"Rollback error for {cdtk_type}. Manual operation will have to take place",
                                              f"Retour en arrière en erreur pour le {cdtk_type}. Des mesures manuelles devront être prises")

            else:
                # Cannot start safely the rollback process
                self.message.add_progress(f"The publication in the {cdtk_type} failed in the middle of the process.",
                                          f"La publication dans le {cdtk_type} a arrêtée avant la fin.")
                self.message.add_progress(f"It is impossible to rollback. Manual operation will have to take place in the {cdtk_type}",
                                          f"Il est imposssible de faire un retour en arrière. Des mesures manuelles devront être prises dans le {cdtk_type}.")

        if self.registry_started:
            cdtk_type = "CDTK Registry"
            if self.registry_ended:
                # Can safely start the rollback of the CDTK Registry
                try:
                    self.message.add_progress(f"Rollback started for {cdtk_type}.", f"Retour en arrière démarré pour le {cdtk_type}.")
                    self._delete_in_cdtk_registry()
                    self.message.add_progress(f"Rollback terminated for {cdtk_type}.", f"Retour en arrière terminé pour le {cdtk_type}.")

                except Exception:
                    self.message.add_progress(f"Rollback error for {cdtk_type}. Manual operation will have to take place",
                                              f"Retour en arrière en erreur pour le {cdtk_type}. Des mesures manuelles devront être prises")
            else:
                # Cannot start safely the rollback process
                self.message.add_progress(f"The publication in the {cdtk_type} failed in the middle of the process.",
                                          f"La publication dans le {cdtk_type} a arrêtée avant la fin.")
                self.message.add_progress(f"It is impossible to rollback. Manual operation will have to take place in the {cdtk_type}",
                                          f"Il est imposssible de faire un retour en arrière. Des mesures manuelles devront être prises dans le {cdtk_type}.")


    def _validate_service_name_dataset_exists(self) -> None:
        """Validates the following information and raise errors if not
          - Both service name exists
          - Both service name have the same publication id
          - The publication id is link to the dataset id in the control file"""

        service_name_en: str = self.control_file.get_ows_service_parameters_english_service_name()
        service_name_fr: str = self.control_file.get_ows_service_parameters_french_service_name()
        publication_ids: list[str] = []

        # For both service names (en/fr)
        for service_name in [service_name_en, service_name_fr]:
            # Get the OWS services
            ows_services: list[dict] = self.cdtk_request.get_ows_services(service_name)

            # If found
            if len(ows_services) > 0:
                publication_ids.append(ows_services[0]['data_publication_id'])

            else:
                self.message.add_error(f"The service name {service_name} is not published in the CDTK Registry",
                                       f"Le service nommé {service_name} n'est pas publié dans le registre du CDTK")

        # Validate that each data publication have an entry in data_publication table
        for publication_id in publication_ids:
            # Get the data publication info
            data_publication_info: dict | None = self.cdtk_request.get_data_publication(publication_id)

            # If found
            if data_publication_info:
                target_dataset_id: str = data_publication_info['dataset_id']

                # Validate that the dataset ID is the same as the one in the control file
                if target_dataset_id != self.dataset_id:
                    self.message.add_error(f"The service name to delete {service_name_en} is not linked to the metadata uuid in the control file.",
                                           f"Le service nommé à détruire {service_name_en} n'est pas lié à la métadonnée_uuid dans le fichier de contrôle.")

            else:
                # Not found
                self.message.add_error(f"Unable to find data_publication_id {publication_ids[0]}",
                                       f"data_publication_id {publication_ids[0]} introuvable")

        return


    def _validate_service_name_not_exists(self) -> None:
        """Validates that the service names are not published as OWS services"""

        service_name_en: str = self.control_file.get_ows_service_parameters_english_service_name()
        service_name_fr: str = self.control_file.get_ows_service_parameters_french_service_name()

        # Loop on both service names
        for service_name in [service_name_en, service_name_fr]:
            self._validate_service_name_not_exists_check(service_name)


    def _validate_service_name_not_exists_check(self, service_name: str) -> None:
        """Validates that the service name are not published as OWS services"""

        # If the service name exists
        if self.check_service_name_exists(service_name):
            # Service name already published
            self.message.add_error(f"The service name {service_name} is already published in the CDTK Registry.",
                                   f"Le service nommé {service_name} est déjà publié dans le registre du CDTK.")


    def check_service_name_exists(self, service_name: str) -> bool:
        """Queries the CDTK Registry to check if the service name exists"""

        # Get the OWS services
        ows_services: list[dict] = self.cdtk_request.get_ows_services(service_name)

        # True if service name exists
        return len(ows_services) > 0
