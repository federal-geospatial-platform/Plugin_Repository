from nrcan_core.core.control_file import ControlFile
from nrcan_core.services.abstract_service import AbstractService
from nrcan_core.core.pyqgis_runner import run_pyqgis
from nrcan_core.lib.exceptions import *


class OapiService(AbstractService):
    """OAPI services include WMSFacade, coverage and feature services that are managed by the CDTK"""

    # Use __slots__ to disable dynamic attribute creation in order to control them at the class level
    __slots__: list[str] = ['infos', 'postgres_datastore_info', 'qgis_project_info']


    def __init__(self, control_file: ControlFile) -> None:
        """Constructor"""

        AbstractService.__init__(self, control_file)
        self.infos: list = []  # List of dictionary of the information needed for the publication of each collection
        self.postgres_datastore_info: dict | None = None # Reference to the collection datastore for provider postgres
        self.qgis_project_info: dict | None = None


    def is_service_present(self) -> bool:
        """Returns True if an OAPI service is present in the control file"""

        return self.control_file.has_service_type_oapi()


    def on_normalize_control_file(self) -> None:
        """
        Overrides the way the normalization of the control file is done for a OAPIService
        """

        AbstractService.on_normalize_control_file(self)
        self.control_file.normalize_oapi_section()


    def on_validate_service(self) -> bool:
        """
        Overrides the way the validation is performed for a OAPIService.
        """

        # Check if there is something to validate
        if not self.is_service_present():
            # Nothing to validate and let's assume the validation is True
            return True

        # Call parent class for generic validation
        AbstractService.on_validate_service(self)

        # Now that it's valid, we can get the operation
        operation: str = self.control_file.get_operation()

        # For each collection
        for collection in self.control_file.get_oapi_service_parameters_collections():
            # Validate the server ID
            # If the server_id isn't set, use the department default server id
            if self.department_info and collection['server_id'] == "":
                collection['server_id'] = self.department_info['default_oapi_server_id']

            info: dict = {}
            info['server_info'] = self._validate_server_id_exists(collection['server_id'])

            # Validate datastore id
            if self.department_info and collection['datastore_id'] == "":
                if collection['provider_type'] == 'feature':
                    # Exract default vector datastore id
                    collection['datastore_id'] = self.department_info['default_vector_datastore_id']
                elif collection['provider_type'] == 'coverage':
                    # Exract default raster datastore id
                    collection['datastore_id'] = self.department_info['default_raster_datastore_id']
                else:
                    # For the provider_type map the datastore ID is not used
                    collection['datastore_id'] = self.department_info['default_vector_datastore_id']

            info['datastore_info'] = self._validate_datastore_id_exists(collection['datastore_id'])
            if collection['provider_type'] == 'feature':
                # Keep a reference to the datastore; needed for calling the py_qgis module
                if self.postgres_datastore_info is None:
                    # All the provider of type 'feature' have the same datastore id
                    self.postgres_datastore_info = info['datastore_info']

            # NOTE: We need the self.postgres_datastore_info attribute for Publish and Unpublish (not just Publish),
            # that's why the validations happen for all operations

            if operation == "Publish":
                # Validate the service name is not already published
                self._validate_collection_name(operation, collection)

                self._validate_datastore_hosting(collection, info)

                self.infos.append(info)

            elif operation == "Unpublish":
                # Validate that the service names and dataset are related
                self._validate_collection_name(operation, collection)

            elif operation == "Update":
                # No supplemental validation to be done
                pass

            else:
                raise ApplicationException("Invalid operation code in OapiService.on_validate_service function")

        # Add a progress mark
        if self.message.if_errors():
            self.message.add_progress("The OAPI service is invalid.", "Le service OAPI est invalide.")
            is_valid = False
        else:
            self.message.add_progress("The OAPI service is valid.", "Le service OAPI est valide.")
            is_valid = True

        return is_valid


    def _validate_datastore_hosting(self, collection, info) -> None:
        """
        Validates the hosting (internal/external) of the datastore.
        It's forbidden to upload to an external datastore
        """

        # If not enough information
        if not (self.publisher_info):
            # Invalid call
            raise ApplicationException("Missing information to validate in OAPI service in _validate_datastore_hosting")

        if collection['provider_feature_postgres']:
            feature_postgres = collection['provider_feature_postgres']
            feature_postgres['feature_name_dict']['hosting'] = info['datastore_info']['hosting']
            if feature_postgres['feature_name_dict']['type'] == 'gpkg':
                # Validate if internal or external datastore
                if info['datastore_info']['hosting'] == 'EXTERNAL':
                    self.message.add_error(f"Cannot upload a GeoPackage table to the external datastore: {info['datastore_id']['datastore_id']}",
                                            f"Impossible de téléverser un GeoPackage dans le datastore externe: {info['datastore_id']['datastore_id']}")
                # Validate the schema name
                if feature_postgres['schema_name'] != self.control_file.get_department():
                    # When the schema is different the publisher must be admin
                    if not self.publisher_info['admin']:
                        self.message.add_error("OAPI Feature: Publisher must be admin in order to publish under another department name.",
                                                "OAPI feature: L'éditeur doit-être admin pour publier au nom d'un autre ministère.")


    def on_validate_server_type(self, server_type: str) -> bool:
        """
        Overrides validation of a server type for the service.
        """

        # Return if the server type is valid
        return server_type.split("_")[0] == "OAPI"


    def on_process_service(self, operation: str) -> None:
        """
        Overrides the processing of the given operation by the service.
        """

        # If not enough information
        if not (self.postgres_datastore_info):
            # Invalid call
            raise ApplicationException("Missing information to process service in OAPI service in on_process_service")

        # Depending on the operation
        if operation == "Publish":
            # Flag
            self.publication_started = True

            # Execute
            self.qgis_project_info = run_pyqgis("oapi_export_publish", self.control_file.inner_dict, self.postgres_datastore_info['connection_string'], self.message)
            # self.control_file = self.qgis_project_info['results'][0]  # Extract from the updated control_file  # Commenting this as it doesn't seem right

            # Unflag
            self.publication_ended = True

            try:
                # Save in registry
                self._save_in_cdtk_registry()
            except Exception as err:
                self.message.add_error_raise("An error has occured when writing in the CDTK Publication.",
                                             "Une erreur est survenue durant l'écriture dans le CDTK Registry.",
                                             err)

        elif operation == "Unpublish":
            try:
                # Delete from registry
                self._delete_in_cdtk_registry()
            except Exception as err:
                self.message.add_error_raise("An error has occured when deleting in the CDTK Publication",
                                             "Une erreur est survenue durant la suppresion dans le CDTK Registry",
                                             err)

            # Flag
            self.publication_started = True

            # Execute
            self.qgis_project_info = run_pyqgis("oapi_delete_publish", self.control_file.inner_dict, self.postgres_datastore_info['connection_string'], self.message)

            # Unflag
            self.publication_ended = True


    def on_rollback_service(self, operation: str) -> None:
        """
        Overrides the rollback mecanism for an OAPI Service.
        """

        # If publish operation
        if operation == "Publish":
            # Rollbacking a Publish
            self._rollback_publish()

        else:
            # Can't rollback that operation
            self.message.add_progress(f"No rollback is possible for service {self.get_service_name()} and operation: {operation}.",
                                      f"Aucun rollback de possible pour le service {self.get_service_name()} et l'opération: {operation}.")


    def on_get_html_services_list(self, operation: str) -> tuple[str, str]:
        """
        Overrides the html report which summerizes the list of accessible OAPI services.
        """

        # Loop over each service name to build the server list
        services_list: str = ""
        text_html: str = ""
        for collection in self.control_file.get_oapi_service_parameters_collections():
            if operation in ["Publish", "Update"]:

                collection_name: str = collection['collection_name']
                service_type: str = self._get_service_type(collection['provider_type'])

                # Get the OAPI service
                oapi_service: dict | None = self.cdtk_request.get_oapi_service(collection_name, service_type)

                # If found
                if oapi_service:
                    collection_url: str = oapi_service['collection_url']
                    text_html = f"<li>{service_type}: <a href=\'{collection_url}'>{collection_url}</a></li>"

                else:
                    # Not found
                    text_html = f"<li>{service_type}: {collection_name}: <i>Error reading the service URL / Erreur lors de la lecture du service URL</i></li>"

                services_list = services_list + text_html
            else:
                # Unpublish
                text_html = f"<li>{collection['provider_name']}: {collection['collection_name']}</li>"
                services_list = services_list + text_html

        html_content_en: str = ""
        html_content_fr: str = ""
        if operation == 'Publish':
            html_content_en = html_content_en + "Your publication request for OAPI services proceeded successfully.<br/><br/>"
            html_content_fr = html_content_fr + "Votre requête de publication de services OAPI a été exécutée avec succès.<br/><br/>"
            if services_list:
                html_content_en = html_content_en + f"Here are the links of the published OAPI services:<ul>{services_list}</ul><br/>"
                html_content_fr = html_content_fr + f"Voici les liens des services OAPI publiés:<ul>{services_list}</ul>"

        elif operation == 'Update':
            html_content_en = html_content_en + "Your update request for OAPI services proceeded successfully.<br/><br/>"
            html_content_fr = html_content_fr + "Votre requête de mise-à-jour de services OAPI a été exécutée avec succès.<br/><br/>"
            if services_list:
                html_content_en = html_content_en + f"Voici les liens des services OAPI mis-à-jour:<ul>{services_list}</ul>"
                html_content_fr = html_content_fr + f"Here are the links of the updated OAPI services:<ul>{services_list}</ul><br/>"

        else:
            # Unpublish
            html_content_en = html_content_en + "Your unpublication request for OAPI services proceeded successfully.<br/><br/>"
            html_content_fr = html_content_fr + "Votre requête de dépublication de services OAPI a été exécutée avec succès.<br/><br/>"
            if services_list:
                html_content_en = html_content_en + f"Here are the unpublished OAPI services:<ul>{services_list}</ul><br/>"
                html_content_fr = html_content_fr + f"Voici les services OAPI dépubliés:<ul>{services_list}</ul>"

        return (html_content_en, html_content_fr)


    def _save_in_cdtk_registry(self) -> None:
        """Save the OAPI service the CDTK registry"""

        # Flag
        self.registry_started = True

        # Keep track
        self.message.add_progress("Saving OAPI services in CDTK Registry.",
                                  "Sauvegarde des services OAPI dans le Registre CDTK.")

        # If the dataset must be created
        if self.dataset_id == "CREATE_IT":
            # Save the dataset in the CDTK registry
            dataset_info: dict = self.cdtk_request.put_dataset(self.control_file.get_dataset_name(),
                                                               self.control_file.get_department(),
                                                               self.control_file.get_metadata_uuid())

            # Only 201 stustus code is returned
            self.dataset_id = dataset_info['dataset_id']

        # Save each OAPI collection in the CDTK registry
        for info, collection in zip(self.infos, self.control_file.get_oapi_service_parameters_collections()):
            # Extract some information
            datastore_id: str = collection['datastore_id']

            # Set some values
            datasource_name: str = ""
            datasource_path: str = ""
            if collection['provider_type'] == 'map':
                service_type = "OAPIM"
                datasource_name = "OAPIM_WMSFacade::" + collection['provider_map_wmsfacade']['options_layer']
                datasource_path = collection['provider_map_wmsfacade']['wms_service_url']
                collection['provider_coverage_rasterio'] = {}
                collection['provider_feature_postgres'] = {}

            elif collection['provider_type'] == 'coverage':
                service_type = "OAPIC"
                datasource_name = collection['provider_coverage_rasterio']['item_name']
                datasource_path = collection['provider_coverage_rasterio']['folder_path']
                collection['provider_map_wmsfacade'] = {}
                collection['provider_feature_postgres'] = {}

            else:
                # Feature
                service_type = "OAPIF"
                datasource_name = collection['provider_feature_postgres']['feature_name_dict']['db_table_name']
                datasource_path = collection['provider_feature_postgres']['schema_name']
                collection['provider_map_wmsfacade'] = {}
                collection['provider_coverage_rasterio'] = {}

            # Save the data_publication in the cdtk registry
            # Note: Casting the dataset_id to str, because it'll be defined, not None by this point. Saving a warning.
            data_pub_info: dict = self.cdtk_request.put_data_publication('OAPI',
                                                                         info['server_info']['server_id'],
                                                                         str(self.dataset_id),
                                                                         self.control_file.get_email())
            data_publication_id: str = data_pub_info['data_publication_id']

            # Save in the datasource in the cdtk registry
            datasource_info: dict = self.cdtk_request.put_datasource(datastore_id, datasource_name, datasource_path)
            datasource_id: str = datasource_info['datasource_id']

            # Save the OAPI published data in the cdtk registry
            self.cdtk_request.put_oapi_service(collection['collection_name'], data_publication_id, datasource_id,
                                               collection['group_name'], collection['provider_name'], collection['provider_type'],
                                               service_type, collection['collection_metadata'],
                                               collection['provider_map_wmsfacade'], collection['provider_feature_postgres'],
                                               collection['provider_coverage_rasterio'])

        # Flag
        self.registry_ended = True

        return


    def _get_service_type(self, provider_type: str) -> str:
        """
        Extracts the service type from the provider type
        """

        if provider_type == "map":
            provider_type = "OAPIM"
        elif provider_type == "feature":
            provider_type = "OAPIF"
        else:
            provider_type = "OAPIC"

        return provider_type


    def _delete_in_cdtk_registry(self) -> None:
        """
        Deletes each OAPI collection in the CDTK registry
        """

        def _extract_datasource_id(collection_name: str, service_type: str) -> dict:
            """
            Extracts a copy of the datasource_id content
            """

            datasource = None
            if service_type == 'OAPIF':
                # Fetch the OAPI service
                oapi_services: dict | None = self.cdtk_request.get_oapi_service(collection_name, service_type)

                # If found
                if oapi_services:
                    # Fetch the datasource
                    datasource: dict | None = self.cdtk_request.get_datasource(oapi_services['datasource_id'])

                    # If not found
                    if not datasource:
                        # OAPI datasource couldn't be found
                        self.message.add_error_raise("Couldn't find the data source for the OAPIF service to delete.",
                                                     "La source de données pour le service OAPIF à supprimer est introuvable.")

                else:
                    # OAPI service couldn't be found
                    self.message.add_error_raise("Couldn't find the OAPIF service to delete.",
                                                 "Le service OAPIF à supprimer est introuvable.")

            # By logic, here, the datasource is set
            if datasource:
                return datasource

            # Unreachable code, because when it's not found, an exception has been raised
            raise ApplicationException("Unreachable code by logic")


        def _update_tables_to_delete(collection: dict, datasource: dict) -> None:
            """
            For OAPIF service check if the data source was deleted.
            If the datasource was internal than it mus be added to the table to delete
            """

            if service_type == "OAPIF":
                # Flag
                collection['provider_feature_postgres']['feature_name_dict']['to_delete'] = 'False'

                # Get the datasource
                datasource_info: dict | None = self.cdtk_request.get_datasource(datasource['datasource_id'])

                # If not found
                if not datasource_info:
                    # Get the datastore info then
                    datastore_info: dict | None = self.cdtk_request.get_datastore(datasource['datastore_id'])

                    # If the datastore link to the datasource is INTERNAL we must delete it
                    if datastore_info and datastore_info['hosting'] == 'INTERNAL':
                        # The datasource was deleted and INTERNAL; need to add a table to delete
                        collection['provider_feature_postgres']['feature_name_dict']['to_delete'] = 'True'
                        collection['provider_feature_postgres']['feature_name_dict']['db_table_name'] = datasource['datasource_name']

            else:
                # No table to delete for the other service type
                pass

            return

        # Keep track
        self.message.add_progress("Deleting OAPI services in CDTK Registry.",
                                  "Destruction des services OAPI dans le Registre CDTK.")

        try:
            # Loop over each collection and delete it.
            for collection in self.control_file.get_oapi_service_parameters_collections():
                collection_name: str = collection['collection_name']
                service_type: str = self._get_service_type(collection['provider_type'])

                # Keep a reference to the datasource_id
                datasource: dict = _extract_datasource_id(collection_name, service_type)

                # The delete takes care of cleaning the following tables: datasource, oapi_service, data_publication and dataset
                deleted: bool = self.cdtk_request.delete_oapi_service(collection_name, service_type)

                # If failed to save in the registry
                if not deleted:
                    self.message.add_error_raise(f"Failed to delete the OAPI service: {service_type}: {collection_name} in the CDTK Registry.",
                                                 f"Erreur lors de la destruction du service OAPI: {service_type}: {collection_name} dans le Registre CDTK.")

                _update_tables_to_delete(collection, datasource)

            # Delete the tables in the Publication registry
            if self.postgres_datastore_info is not None:
                self.qgis_project_info = run_pyqgis("oapi_delete_publish", self.control_file.inner_dict, self.postgres_datastore_info['connection_string'], self.message)

            return

        except Exception as err:
            # Keep track
            self.message.add_progress("Failed deleting in CDTK Registry, no reverting.",
                                      "Échec lors de la destruction dans le Registre CDTK, pas de retour arrière.")

            # Keep raising err
            raise err


    def _rollback_publish(self) -> None:
        """
        Rollbacks a publish operation
        """

        # If flagged
        if self.publication_started:
            cdtk_type = "CDTK Publication"
            if self.publication_ended:
                # If not enough information
                if not (self.postgres_datastore_info):
                    # Invalid call
                    raise ApplicationException("Missing information to rollback in OAPI service in _rollback_publish")

                # Can safely start the rollback
                try:
                    self.message.add_progress(f"Rollback started for {cdtk_type}.", f"Retour en arrière démarré pour le {cdtk_type}.")
                    self.qgis_project_info = run_pyqgis("oapi_delete_publish", self.control_file.inner_dict,
                                                        self.postgres_datastore_info['connection_string'], self.message)
                    self.message.add_progress(f"Rollback terminated for {cdtk_type}.", f"Retour en arrière terminé pour le {cdtk_type}.")
                except Exception:
                    self.message.add_progress(f"Rollback error for {cdtk_type}. Manual operation will have to take place",
                                              f"Retour en arrière en erreur pour le {cdtk_type}. Des mesures manuelles devront être prises")

            else:
                # Cannot start safely the rollback process
                self.message.add_progress(f"The publication in the {cdtk_type} failed in the middle of the process.",
                                          f"La publication dans le {cdtk_type} a arrêtée avant la fin.")
                self.message.add_progress(f"It is impossible to rollback. Manual operation will have to take place in the {cdtk_type}",
                                          f"Il est imposssible de faire un retour en arrière. Des mesures manuelles devront être prises dans le {cdtk_type}.")

        if self.registry_started:
            cdtk_type = "CDTK Registry"
            if self.registry_ended:
                # Can safely start the rollback of the CDTK Registry
                try:
                    self.message.add_progress(f"Rollback started for {cdtk_type}.", f"Retour en arrière démarré pour le {cdtk_type}.")
                    self._delete_in_cdtk_registry()
                    self.message.add_progress(f"Rollback terminated for {cdtk_type}.", f"Retour en arrière terminé pour le {cdtk_type}.")
                except Exception:
                    self.message.add_progress(f"Rollback error for {cdtk_type}. Manual operation will have to take place",
                                              f"Retour en arrière en erreur pour le {cdtk_type}. Des mesures manuelles devront être prises")

            else:
                # Cannot start safely the rollback process
                self.message.add_progress(f"The publication in the {cdtk_type} failed in the middle of the process.",
                                          f"La publication dans le {cdtk_type} a arrêtée avant la fin.")
                self.message.add_progress(f"It is impossible to rollback. Manual operation will have to take place in the {cdtk_type}.",
                                          f"Il est imposssible de faire un retour en arrière. Des mesures manuelles devront être prises dans le {cdtk_type}.")


    def _validate_service_name_dataset_exists(self) -> None:
        """Validates the following information and raise errors if not
              - Both service name exists
              - Both service name have the same publication id
              - The publication id is link to the dataset id in the control file"""

        service_name_en: str = self.control_file.get_ows_service_parameters_english_service_name()
        service_name_fr: str = self.control_file.get_ows_service_parameters_french_service_name()
        publication_ids: list[str] = []

        # For both service names (en/fr)
        for service_name in [service_name_en, service_name_fr]:
            # Get the OWS services
            ows_services: list[dict] = self.cdtk_request.get_ows_services(service_name)

            # If found
            if len(ows_services) > 0:
                publication_ids.append(ows_services[0]['data_publication_id'])

            else:
                # Not found
                self.message.add_error(f"The service_name {service_name} is not published in the CDTK Registry.",
                                        f"Le service nommé {service_name} n'est pas publié dans le registre du CDTK.")

        # Validate that each data publication have an entry in data_publication table
        for publication_id in publication_ids:
            # Get the data publication info
            data_publication_info: dict | None = self.cdtk_request.get_data_publication(publication_id)

            # If found
            if data_publication_info:
                target_dataset_id: str = data_publication_info['dataset_id']

                # Validate that the dataset ID is the same as the one in the control file
                if target_dataset_id != self.dataset_id:
                    self.message.add_error(f"The service name to delete {service_name_en} is not linked to the metadata uuid in the control file.",
                                           f"Le service nommé à détruire {service_name_en} n'est pas lié à la métadonnée uuid dans le fichier de contrôle.")

            else:
                # Not found
                self.message.add_error(f"Unable to find data_publication_id {publication_ids[0]}",
                                       f"data_publication_id {publication_ids[0]} introuvable")

        return


    def _validate_collection_name(self, operation: str, collection: dict) -> None:
        """Validates that the collection name for a OAPI services
              - If the operation is Publish the collection name/collection type must not exist; otherwise ==> Error
              - If the operation is Unpublish or Update the collection name/collection type must not exist; otherwise ==> Error
        """

        collection_name: str = collection['collection_name']
        provider_type: str = self._get_service_type(collection['provider_type'])

        # Get the OAPI service
        oapi_service_info: dict | None = self.cdtk_request.get_oapi_service(collection_name, provider_type)

        # If found
        if oapi_service_info:
            if operation in ["Publish"]:
                self.message.add_error(f"The collection: {collection_name} is already published in the CDTK Registry for the provider_type: {provider_type}",
                                       f"La collection: {collection_name} est déjà publié dans le registre CDTK pour le provider_type: {provider_type}")

        else:
            # Not found
            if operation in ["Unpublish", "Update"]:
                self.message.add_error(f"The collection: {collection_name} is not published in the CDTK Registry for the provider_type {provider_type}",
                                       f"La collection: {collection_name} n'est pas publié dans le registre CDTK pour le provider_type {provider_type}")

        return

