"""
This module stores all configurations used by this application.
"""

from nrcan_core.lib import aws

# If the environment is local
IS_LOCAL: bool = False

# Determine if setting allow-origin for CORS
USE_CORS: bool = True

# Running port
PORT_API: int = 5031
#PORT_WEB: int = 5030

# AWS Secret Manager
AWS_SECRET_VALUE: dict = aws.get_secret("ca-central-1", "secretsmanager", "cdtk-api-publication-dev")

# CDTK Admin URL for internal communication
CDTK_ADMIN_URL: str = "http://10.68.132.188:5021/api"

# Clip Zip Ship Admin URL for internal communication
CZS_ADMIN_URL: str = "http://10.68.132.188:5001/api"

# PyGeoAPI URL for internal communication
PYGEOAPI_URL: str = "http://10.68.132.188:5000/reload_resources"

# FTP Root
FTP_ROOT: str = "https://ftp-dev.services.geo.ca"

# ECS
ECS_IAM_ROLE: str = "arn:aws:iam::817170115702:role/qgis-ecs-ddr-access-dev"
ECS_CLUSTER: str = "arn:aws:ecs:ca-central-1:817170115702:cluster/qgis-dev-micro-service-cluster"
ECS_SERVICE: str = "qgis-dev-micro-service"

# Email configs
EMAIL_ADMIN_CONTENT: list[str] = ["geodiscoverydatadissemination-diffusiondesdonneesgeodecouverte@nrcan-rncan.gc.ca", "alexandre.roy@nrcan-rncan.gc.ca", "daniel.pilon@nrcan-rncan.gc.ca", "geoffroy.houle@nrcan-rncan.gc.ca"]
EMAIL_TIMEOUT: int = 5

# QGIS configs
QGIS_JOBS_PATH: str = "..\\jobs"
QGIS_IN_PACKAGES_PATH: str = "..\\in_packs"
QGIS_PROJECTS_PATH: str = "..\\data"
QGIS_PYTHON_PATH: str = "nrcan_qgis"
