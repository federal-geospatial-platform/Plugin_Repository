import os
from ..lib.exceptions import UserMessageException
from ..lib.progress_marks import *
from ..lib.progress_marks import *


def get_download_path(control_file: dict, with_package_name: bool, with_prefix ) -> str:
    path: str = "pub/" + \
           control_file['process_parameters']['department_info']['download_root_subpath'] + "/" + \
           control_file['generic_parameters']['core_subject_term']

    if with_package_name:
        if with_prefix and len(with_prefix) > 0:
            path = path + "/" + with_prefix + control_file['generic_parameters']['download_package_name']
        else:
            path = path + "/" + control_file['generic_parameters']['download_package_name']

    return path.replace("//", "/")


def combine_progress_marks_for_response(progress_marks: list, *, prefix: str = "", suffix: str = os.linesep) -> list[str]:
    """
    Loops on the progress marks and create 2 messages (English/French) which encompases all messages.
    """

    # For each progress mark
    msg_english_total: str = ""
    msg_french_total: str = ""
    for pm in progress_marks:
        [msg_english, msg_french] = _combine_progress_marks_for_response_read_pm(pm)
        msg_english_total = msg_english_total + prefix + msg_english + suffix
        msg_french_total = msg_french_total + prefix + msg_french + suffix
    msg_english_total = msg_english_total.strip(os.linesep)
    msg_french_total = msg_french_total.strip(os.linesep)

    return [msg_english_total, msg_french_total]


def combine_warnings_for_response(warnings: list, *, prefix: str = "", suffix: str = os.linesep) -> list[str]:
    """
    Loops on the progress marks and create 2 messages (English/French) which encompases all messages.
    """

    # For each progress mark
    msg_english_total: str = ""
    msg_french_total: str = ""
    for warn in warnings:
        [msg_english, msg_french] = combine_warnings_for_response_read_warn(warn)
        msg_english_total = msg_english_total + prefix + msg_english + suffix
        msg_french_total = msg_french_total + prefix + msg_french + suffix
    msg_english_total = msg_english_total.strip(os.linesep)
    msg_french_total = msg_french_total.strip(os.linesep)

    return [msg_english_total, msg_french_total]



def combine_exceptions_for_response(exceptions: list, *, admin: bool = False, prefix: str = "", suffix: str = os.linesep) -> UserMessageException:
    """
    Loops on the exceptions and create a single UserMessageException which encompases all messages.
    """

    # For each exception
    msg_english_total: str = ""
    msg_french_total: str = ""
    internal_error: BaseException | None = None
    for e in exceptions:
        [msg_english, msg_french] = _combine_exceptions_for_response_read_exception(e, admin)
        msg_english_total = msg_english_total + prefix + msg_english + suffix
        msg_french_total = msg_french_total + prefix + msg_french + suffix
        if internal_error is None and isinstance(e, UserMessageException) and e.internal_error is not None:
            internal_error = e.internal_error
    msg_english_total = msg_english_total.strip(os.linesep)
    msg_french_total = msg_french_total.strip(os.linesep)

    return UserMessageException(500, msg_english_total, msg_french_total, internal_error)


def _combine_exceptions_for_response_read_exception(e, admin: bool = False) -> list[str]:
    """
    """

    if isinstance(e, UserMessageException):
        return [e.message, e.message_fr]

    elif isinstance(e, SchemaNotFound):
        return [str(e),  # QGIS English message works fine
                f"Le schéma '{e.schema}' n'existe pas dans le dépôt de données QGIS."]

    elif isinstance(e, ProjectVersionGreaterThanAPI):
        return [str(e),  # QGIS English message works fine
                f"La version du project '{e.project_name}' est '{e.version_project}' qui est plus grande que la version QGIS de notre API '{e.version_pyqgis}'"]

    elif isinstance(e, ProjectVersionGreaterThanServer):
        return [str(e),  # QGIS English message works fine
                f"La version du project '{e.project_name}' est '{e.version_project}' qui est plus grande que la version sur notre server QGIS '{e.version_server}'"]

    elif isinstance(e, ProjectHasNoTitle):
        return [str(e),  # QGIS English message works fine
                f"Le projet '{e.project_name}' n'a pas de titre."]

    elif isinstance(e, ProjectAlreadyExists):
        return [f"The project '{e.project_name}' already exists in the QGIS data store. Use CDTK_Update to update an existing project.",
                f"Le projet '{e.project_name}' existe déjà dans le dépôt de données QGIS. Utiliser plutôt CDTK_Update pour mettre à jour un projet existant."]

    elif isinstance(e, ProjectsDifferentLayersCount):
        return [str(e),  # QGIS English message works fine
                f"Les projets ont un nombre différent de couches; {e.project_1_count} vs {e.project_2_count}"]

    elif isinstance(e, ProjectsShortNameNotFound):
        return [str(e),  # QGIS English message works fine
                f"Le layer '{e.layer_name}' a un nom court '{e.layer_short_name}' qui n'a pas d'équivalance dans le projet de l'autre langue."]

    elif isinstance(e, ProjectsShortNameDuplicated):
        return [str(e),  # QGIS English message works fine
                f"Le nom court '{e.layer_short_name}' apparaît plus d'une fois dans le projet '{e.project_id}'."]

    elif isinstance(e, DataSourceInvalid):
        return [f"The layer '{e.layer_name}' has an invalid source (name is too long?)",
                f"La couche '{e.layer_name}' a un nom de source invalide (nom trop long?)"]

    elif isinstance(e, DataAlreadyExists):
        return [f"The layer '{e.layer_name}' already exists in the QGIS data store. Use CDTK_Update to update an existing layer.",
                f"La couche '{e.layer_name}' existe déjà dans le dépôt de données QGIS. Utiliser plutôt CDTK_Update pour mettre à jour une couche existante."]

    elif isinstance(e, LayerExistsInBothProjects):
        return [f"The layer '{e.layer_name}' exists in both QGIS projects.",
                f"La couche '{e.layer_name}' existe dans les 2 projets QGIS."]

    elif isinstance(e, StyleAlreadyExists):
        return [f"The style for the layer '{e.layer_name}' already exists in the QGIS data store. Use CDTK_Update to update an existing style.",
                f"Le style pour la couche '{e.layer_name}' existe déjà dans le dépôt de données QGIS. Utiliser plutôt CDTK_Update pour mettre à jour un style existant."]

    elif isinstance(e, UnsupportedCRS):
        return [str(e),  # QGIS English message works fine
                f"Le projet utilise une projection crs non supportée: {e.crs}"]

    elif isinstance(e, LayerInvalid):
        return [str(e),  # English message works fine
                f"La couche '{e.layer_name}' dans le projet '{e.project_id}' était invalide."]

    elif isinstance(e, LayerUnsupportedCRS):
        return [str(e),  # QGIS English message works fine
                f"Le crs '{e.crs}' de la couche '{e.layer_name}' est différente du crs du projet"]

    elif isinstance(e, LayerShortNameInvalid):
        return [str(e),  # QGIS English message works fine
                f"Le nom court '{e.layer_short_name}' de la couche '{e.layer_name}' est invalide."]

    elif isinstance(e, LayerFieldIDInvalid):
        return [str(e),  # QGIS English message works fine
                f"La couche '{e.layer_name}' n'a pas de champ unique qui identifie l'unicité des enregistrement."]

    elif isinstance(e, LayerFailedToGetExtent):
        return [str(e),  # QGIS English message works fine
                f"Échec lors du calcul de l'étendu pour la couche '{e.layer_name}' avec crs '{e.crs}'."]

    elif isinstance(e, ProjectNotFoundFromDatabase):
        return [str(e),  # QGIS English message works fine
                f"Le projet '{e.project_name}' n'existe pas dans le dépôt de données QGIS sous le schéma '{e.schema}'."]

    elif isinstance(e, ProjectNoValidLayers):
        return [str(e),  # QGIS English message works fine
                f"Le projet '{e.project_name}' a aucune couche valide."]

    elif isinstance(e, TableMissingInGpkg):
        return [str(e),  # QGIS English message works fine
                f"La table suivante: {e.table_name} n'est pas présente dans le fichier geopackage: {e.gpkg_file}"]

    elif isinstance(e, TableAlreadyExists):
        return [str(e),  # QGIS English message works fine
                f"La table suivante: '{e.table_name}' existe déjà dans la base de données."]

    elif isinstance(e, UnableCopyGpkgTable):
        return [str(e),  # QGIS English message works fine
                f"Impossible de copier la table de: {e.input_file} dans '{e.schema_name}'.'{e.db_table_name}"]

    elif isinstance(e, UnableAccessGpkg):
        return [str(e),  # QGIS English message works fine
                f"Impossible d'ouvrir ou d'accéder au fichier GeoPackage: {e.gpkg_file}."]

    elif isinstance(e, FailedExportLayer):
        return [str(e),  # QGIS English message works fine
                f"Erreur lors de l'exportation de la couche {e.layer_name} avec la table {e.table_name}: {e.message}."]

    elif isinstance(e, FailedSaveQgisProject):
        return [str(e),  # QGIS English message works fine
                f"Erreur lors de l'écriture du project QGIS '{e.project_id}' dans la base de données."]

    elif isinstance(e, FailedDeleteQgisProject):
        return [str(e),  # QGIS English message works fine
                f"Erreur lors de la destruction du project QGIS '{e.project_id}' dans la base de données."]


    # If admin
    if admin:
        return [str(e), str(e)]

    # Default
    return ["A fatal error happened", "Une erreur fatale est survenue"]


def _combine_progress_marks_for_response_read_pm(pm) -> list[str]:
    """
    """

    if isinstance(pm, ProgressMark):
        return [f"{pm.date.strftime('%Y-%m-%d %H:%M')} - {pm.message}",
                f"{pm.date.strftime('%Y-%m-%d %H:%M')} - {pm.message_fr}"]

    elif isinstance(pm, QGISProgressMark):
        if isinstance(pm, ProgressMarkInitialized):
            return [str(pm),  # English message works fine
                    f"{pm.date.strftime('%Y-%m-%d %H:%M')} - PyQGIS initialisé. Version active {pm.qgis_version}"]

        elif isinstance(pm, ProgressMarkInitializedDatabase):
            return [str(pm),  # English message works fine
                    f"{pm.date.strftime('%Y-%m-%d %H:%M')} - Base de données initialisée {pm.db_name} à {pm.db_host}"]

        elif isinstance(pm, ProgressMarkInitializedSchema):
            return [str(pm),  # English message works fine
                    f"{pm.date.strftime('%Y-%m-%d %H:%M')} - Schéma initialisé {pm.schema}"]

        elif isinstance(pm, ProgressMarkInitializingProjectFromFile):
            return [str(pm),  # English message works fine
                    f"{pm.date.strftime('%Y-%m-%d %H:%M')} - Initialisation du projet à partir du fichier {pm.project_file}"]

        elif isinstance(pm, ProgressMarkInitializingProjectFromDatabase):
            return [str(pm),  # English message works fine
                    f"{pm.date.strftime('%Y-%m-%d %H:%M')} - Initialisation du projet à partir de la base de données {pm.project_id}"]

        elif isinstance(pm, ProgressMarkInitializedProject):
            return [str(pm),  # English message works fine
                    f"{pm.date.strftime('%Y-%m-%d %H:%M')} - --- Projet initialisé ---"]

        elif isinstance(pm, ProgressMarkValidatingProjectCRS):
            return [str(pm),
                    f"{pm.date.strftime('%Y-%m-%d %H:%M')} - Validation du CRS du projet"]

        elif isinstance(pm, ProgressMarkValidatingProjectLayersCRS):
            return [str(pm),
                    f"{pm.date.strftime('%Y-%m-%d %H:%M')} - Validation du CRS des couches"]

        elif isinstance(pm, ProgressMarkValidatingDataAlreadyExists):
            return [str(pm),
                    f"{pm.date.strftime('%Y-%m-%d %H:%M')} - Validation que les données n'existent pas déjà dans la base de données"]

        elif isinstance(pm, ProgressMarkValidatingStylesAlreadyExists):
            return [str(pm),
                    f"{pm.date.strftime('%Y-%m-%d %H:%M')} - Validation que les styles n'existent pas déjà dans la base de données"]

        elif isinstance(pm, ProgressMarkSavingStyles):
            return [str(pm),
                    f"{pm.date.strftime('%Y-%m-%d %H:%M')} - Sauvegarde des styles pour les couches en question dans la base de données"]

        elif isinstance(pm, ProgressMarkDeletingStyles):
            return [str(pm),
                    f"{pm.date.strftime('%Y-%m-%d %H:%M')} - Suppression des styles pour les couches en question de la base de données"]

        elif isinstance(pm, ProgressMarkSavingProject):
            return [str(pm),
                    f"{pm.date.strftime('%Y-%m-%d %H:%M')} - Sauvegarde du projet '{pm.project_id}' dans la base de données"]

        elif isinstance(pm, ProgressMarkDeletingProject):
            return [str(pm),
                    f"{pm.date.strftime('%Y-%m-%d %H:%M')} - Suppression du projet '{pm.project_id}' de la base de données"]

        elif isinstance(pm, ProgressMarkExportingVectorLayers):
            return [str(pm),
                    f"{pm.date.strftime('%Y-%m-%d %H:%M')} - Exportation des couches vectorielles dans la base de données.."]

        elif isinstance(pm, ProgressMarkExportedSkippedVectorLayers):
            return [str(pm),
                    f"{pm.date.strftime('%Y-%m-%d %H:%M')} - Exportation de la couche {pm.layer_name} ignorée"]

        elif isinstance(pm, ProgressMarkBackingUpVectorLayers):
            return [str(pm),
                    f"{pm.date.strftime('%Y-%m-%d %H:%M')} - Copie de secours en cours.."]

        elif isinstance(pm, ProgressMarkBackedUpVectorLayers):
            return [str(pm),
                    f"{pm.date.strftime('%Y-%m-%d %H:%M')} - Copie de secours de la couche {pm.layer_name} terminée"]

        elif isinstance(pm, ProgressMarkBackUpClearing):
            return [str(pm),
                    f"{pm.date.strftime('%Y-%m-%d %H:%M')} - Nettoyage des copies de secours dans la base de données.."]

        elif isinstance(pm, ProgressMarkCreatingSpatialIndex):
            return [str(pm),
                    f"{pm.date.strftime('%Y-%m-%d %H:%M')} - Création de l'index spatial sur la table {pm.table_name}"]

        elif isinstance(pm, ProgressMarkCreatedSpatialIndex):
            return [str(pm),
                    f"{pm.date.strftime('%Y-%m-%d %H:%M')} - Index spatial créé sur la table {pm.table_name}"]

        elif isinstance(pm, ProgressMarkDeletingVectorLayers):
            return [str(pm),
                    f"{pm.date.strftime('%Y-%m-%d %H:%M')} - Suppression des couches vectorielles de la base de données"]

        elif isinstance(pm, ProgressMarkChangingLayerDatasource):
            return [str(pm),
                    f"{pm.date.strftime('%Y-%m-%d %H:%M')} - Changement des sources de données dans les couches"]

        elif isinstance(pm, ProgressMarkTableDropped):
            return [str(pm),
                    f"{pm.date.strftime('%Y-%m-%d %H:%M')} - Destruction de la table suivante: '{pm.schema_name}'.'{pm.db_table_name}'"]

        elif isinstance(pm, ProgressMarkReadTablesGpkg):
            return [str(pm),
                    f"{pm.date.strftime('%Y-%m-%d %H:%M')} - Lecture des tables dans le fichier geopackage: {pm.gpkg_file}"]

        elif isinstance(pm, ProgressMarkTableAdded):
            return [str(pm),
                    f"{pm.date.strftime('%Y-%m-%d %H:%M')} - Ajout de la table suivante: '{pm.schema_name}'.'{pm.db_table_name}'"]

        elif isinstance(pm, ProgressMarkReadTablesDatabase):
            return [str(pm),
                    f"{pm.date.strftime('%Y-%m-%d %H:%M')} - Lecture des tables de la base de données pour le schéma: {pm.schema_name}"]

    # Default
    return [str(pm), str(pm)]


def combine_warnings_for_response_read_warn(warning) -> list[str]:
    # Depending on the warning message

    # Default
    return [str(warning), str(warning)]
