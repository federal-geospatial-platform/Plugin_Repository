"""Docstring"""

import json
import re
from typing import Any
from uuid import UUID
from nrcan_core.core.cdtk_message import CDTKMessage
from nrcan_core import config, config_env
from nrcan_qgis import util

class ControlFile(object):
    """Reads and validates the structure and the content of a JSON control file."""

    TRUE_FALSE: list[str] = ["True", "False"]


    def __init__(self, ctl_file_str: str , message: CDTKMessage) -> None:
        """Constructor"""

        self.ctl_file_str: str = ctl_file_str
        self.message: CDTKMessage = message
        self.inner_dict: dict[str, Any] = {}


    def validate_content(self) -> bool:
        """Validates the structure and the schema of the JSON file"""

        try:
            self._validate_json_structure()
            self._validate_json_schema()
            self.message.add_progress("JSON Control File is valid.", "Le fichier de contrôle JSON est valide.")
            return True

        except UserWarning:
            self.message.add_error("JSON Control File is invalid.", "Le fichier de contrôle JSON est invalide.")
        return False


    def get_email(self) -> str:
        return self.inner_dict['email']


    def set_email(self, value: str) -> None:
        self.inner_dict['email'] = value


    def get_department(self) -> str:
        return self.inner_dict['department']


    def set_department(self, value: str) -> None:
        self.inner_dict['department'] = value


    def get_dataset_name(self) -> str:
        return self.inner_dict['dataset_name']


    def get_metadata_uuid(self) -> str:
        return self.inner_dict['metadata_uuid']


    def set_metadata_uuid(self, value: str) -> None:
        self.inner_dict['metadata_uuid'] = value


    def has_service_type(self) -> bool:
        return 'service_type' in self.inner_dict


    def get_service_type(self) -> dict[str, str]:
        return self.inner_dict['service_type']


    def has_download(self) -> bool:
        return 'download' in self.inner_dict


    def get_download(self) -> dict:
        return self.inner_dict['download']


    def get_download_server_id(self) -> str:
        return self.get_download()['server_id']


    def set_download_server_id(self, value: str) -> None:
        self.inner_dict['download']['server_id'] = value


    def get_download_datastore_id(self) -> str:
        return self.get_download()['datastore_id']


    def set_download_datastore_id(self, value: str) -> None:
        self.inner_dict['download']['datastore_id'] = value


    def get_download_folder_name(self) -> str:
        return self.get_download()['folder_name']


    def get_download_core_subject_term(self) -> str:
        return self.get_download()['core_subject_term']


    def has_ows_service_parameters(self) -> bool:
        return 'ows_service_parameters' in self.inner_dict


    def get_ows_service_parameters(self) -> dict:
        return self.inner_dict['ows_service_parameters']


    def get_ows_service_parameters_ows_service_type(self) -> dict:
        return self.get_ows_service_parameters()['ows_service_type']


    def get_ows_service_parameters_server_id(self) -> str:
        return self.get_ows_service_parameters()['server_id']


    def set_ows_service_parameters_server_id(self, value: str) -> None:
        self.inner_dict['ows_service_parameters']['server_id'] = value


    def get_ows_service_parameters_vector_datastore_id(self) -> str:
        return self.get_ows_service_parameters()['vector_datastore_id']


    def set_ows_service_parameters_vector_datastore_id(self, value: str) -> None:
        self.inner_dict['ows_service_parameters']['vector_datastore_id'] = value


    def get_ows_service_parameters_raster_datastore_id(self) -> str:
        return self.get_ows_service_parameters()['raster_datastore_id']


    def set_ows_service_parameters_raster_datastore_id(self, value: str) -> None:
        self.inner_dict['ows_service_parameters']['raster_datastore_id'] = value


    def get_ows_service_parameters_english(self) -> dict:
        return self.get_ows_service_parameters()['english']


    def get_ows_service_parameters_english_service_name(self) -> str:
        return self.get_ows_service_parameters_english()['service_name']


    def get_ows_service_parameters_french(self) -> dict:
        return self.get_ows_service_parameters()['french']


    def get_ows_service_parameters_french_service_name(self) -> str:
        return self.get_ows_service_parameters_french()['service_name']


    def has_oapi_service_parameters(self) -> bool:
        return 'oapi_service_parameters' in self.inner_dict


    def get_oapi_service_parameters(self) -> dict:
        return self.inner_dict['oapi_service_parameters']


    def get_oapi_service_parameters_collections(self) -> dict:
        return self.get_oapi_service_parameters()['collections']


    def has_service_type_ows(self) -> bool:
        return self.has_service_type() and \
               'OWS' in self.get_service_type() and \
               self.get_service_type()['OWS'] == "True"


    def has_service_type_oapi(self) -> bool:
        return self.has_service_type() and \
               'OAPI' in self.get_service_type() and \
               self.get_service_type()['OAPI'] == "True"


    def has_service_type_download(self) -> bool:
        return self.has_service_type() and \
               'Download' in self.get_service_type() and \
               self.get_service_type()['Download'] == "True"


    def _validate_json_structure(self) -> None:
        """Validates that the structure of the JSON file is valid"""

        try:
            self.inner_dict = json.loads(self.ctl_file_str)
        except ValueError as err:
            self.message.add_error_raise(f"Invalid JSON ControlFile structure: {str(err)}",  # We do want the exception string to be shown to the user here
                                         f"La structure du JSON ControlFile est invalide: {str(err)}")  # We do want the exception string to be shown to the user here


    def _validate_key(self, dict_holder, key, key_type: Any=str, empty_value=True):
        """Validates the presence of a key and set error message if missing"""

        ret_code = True
        if key in dict_holder:
            # Validate the type of the value
            if key_type is not None and type(dict_holder[key]) != key_type:
                self.message.add_error(f"In the JSON ControlFile, the value type of the key: {key} is not good.",
                                       f"Dans le JSON ControlFile le type de la valeur pour la clé: {key} est erronné.")
                ret_code = False

            # Validate empty value
            if not empty_value:
                if not dict_holder[key]:  # Test if empty
                    self.message.add_error(f"In the JSON ControlFile, the value of the key: {key} cannot be empty.",
                                           f"Dans le JSON ControlFile la valeur pour la clé: {key} ne peut pas être vide.")
                    ret_code = False
        else:
            self.message.add_error(f"In the JSON ControlFile the following key is missing: {key}",
                                   f"Dans le JSON ControlFile la clé suivante est absente: {key}")
            ret_code = False

        return ret_code


    def _validate_value_domain(self, holder, key, domain_values) -> None:
        """Validates the domain of a key in the control file"""

        if holder[key] not in domain_values:
            self.message.add_error(f"In the JSON ControlFile the key: {key}, must contain one of the following value: {str(domain_values)}",
                                   f"Dans le JSON ControlFile la clé: {key}, doit contenir une des valeurs suivantes: {str(domain_values)}")


    def _validate_list(self, section_list, list_sub_type) -> None:
        """Validates that the section is a list and the type of each item in the list"""

        msg_en = f'In the JSON ControlFile the content type of the list is invalid: {str(section_list)}'
        msg_fr = f'Dans le JSON ControlFile le type du contenu de la liste est invalide: {str(section_list)}'
        for item in section_list:
            if list_sub_type == float:
                try:
                    item = float(item)
                except Exception as err:
                    self.message.add_error(msg_en, msg_fr, err)
                    break
            if type(item) != list_sub_type:
                self.message.add_error(msg_en, msg_fr)
                break


    def _validate_schema_main_values(self) -> None:
        """Validates the operation mode value"""

        # Validate the email address
        regex = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,7}\b'
        if not re.fullmatch(regex, self.get_email()):
            self.message.add_error(f"In the JSON ControlFile the email address: {self.get_email()} is invalid.",
                                   f"Dans le JSON ControlFile l'adresse courriel: {self.get_email()} est invalide.")

        # Validate the metadata UUID
        try:
            UUID(self.get_metadata_uuid())
        except ValueError:
            self.message.add_error(f"In the JSON ControlFile the metadata_uuid: {self.get_email()} is invalid.",
                                   f"Dans le JSON ControlFile le metadata_uuid: {self.get_metadata_uuid()} est invalide.")

        return


    def _validate_service_type_combination(self) -> None:
        """Validates the combination of service_type"""

        service_type: dict[str, str] = self.get_service_type()
        ows: str = service_type['OWS']
        oapi: str = service_type['OAPI']
        download: str = service_type['Download']

        if ows == "False" and oapi == "False" and download == "False":
            self.message.add_error("In the JSON ControlFile at least one 'service_type' must be set to 'True'",
                                   "Dans le JSON ControlFile au moins un 'service_type' doit-être à 'True'")

        return


    def _validate_schema_main(self) -> None:
        """Validates the main section of the json control file"""

        self._validate_key(self.inner_dict, 'department', empty_value=False)
        self._validate_key(self.inner_dict, 'email', empty_value=False)
        self._validate_key(self.inner_dict, 'dataset_name')
        self._validate_key(self.inner_dict, 'metadata_uuid', empty_value=False)
        self._validate_key(self.inner_dict, 'service_type', dict, empty_value=False)

        if self.message.if_errors():
            raise UserWarning   # Exit on error

        # Validate section: service_type
        service_type: dict[str, str] = self.get_service_type()
        self._validate_key(service_type, 'Download')
        self._validate_key(service_type, 'OWS')
        self._validate_key(service_type, 'OAPI')

        if self.message.if_errors():
            raise UserWarning   # Exit on error

        # Validate domain value of service_type
        self._validate_value_domain(service_type, 'Download', ControlFile.TRUE_FALSE)
        self._validate_value_domain(service_type, 'OWS', ControlFile.TRUE_FALSE)
        self._validate_value_domain(service_type, 'OAPI', ControlFile.TRUE_FALSE)

        # validate service_type combination
        self._validate_service_type_combination()

        if self.message.if_errors():
            raise UserWarning   # Exit on error

        # Validate domain value of the main section
        self._validate_schema_main_values()


    def _validate_schema_download(self) -> None:
        """Validates the download section"""

        download = self.get_download()
        self._validate_key(download, 'server_id')
        self._validate_key(download, 'datastore_id')
        self._validate_key(download, 'folder_name', empty_value=False)
        self._validate_key(download, 'core_subject_term', empty_value=False)

        return


    def _validate_ows_service_type_combination(self) -> None:
        """Validates the permutation of type services; the three allowed combination are: WMS / WMS and WFS / WCS"""

        wms = self.get_ows_service_parameters_ows_service_type()['WMS']
        wfs = self.get_ows_service_parameters_ows_service_type()['WFS']
        wcs = self.get_ows_service_parameters_ows_service_type()['WCS']

        if (wms == "False"  and wfs == "False" and wcs == "False") or \
           (wms == "False"  and wfs == "True"  and wcs == "True") or \
           (wms == "True"   and wfs == "True"  and wcs == "True"):
            # Invalid combination of services
            self.message.add_error(f"Invalid OWS service type combination: [WMS: {wms}, WFS: {wfs}, WCS: {wcs}]",
                                   f"Combinaison invalide de type de services OWS: [WMS: {wms}, WFS: {wfs}, WCS: {wcs}]")
        else:
            # Valid combination
            pass

        return


    def _validate_schema_ows_service(self) -> None:
        """Validates the ows_service section"""

        ows_service = self.get_ows_service_parameters()
        self._validate_key(ows_service, 'server_id')
        self._validate_key(ows_service, 'vector_datastore_id')
        self._validate_key(ows_service, 'raster_datastore_id')
        self._validate_key(ows_service, 'ows_service_type', dict, empty_value=False)
        self._validate_key(ows_service, 'english', dict, empty_value=False)
        self._validate_key(ows_service, 'french', dict, empty_value=False)

        if self.message.if_errors():
            raise UserWarning   # Exit on error

        # Validate ows service_type section
        ows_service_type = ows_service['ows_service_type']
        self._validate_value_domain(ows_service_type, 'WMS', ControlFile.TRUE_FALSE)
        self._validate_value_domain(ows_service_type, 'WFS', ControlFile.TRUE_FALSE)
        self._validate_value_domain(ows_service_type, 'WCS', ControlFile.TRUE_FALSE)

        # Validate the combination of OWS service type
        self._validate_ows_service_type_combination()

        # Validate the french english section
        for language in (ows_service['english'], ows_service['french']):
            self._validate_key(language, 'project_filename', empty_value=False)
            self._validate_key(language, 'service_name', empty_value=False)


    def _validate_provider_wms_facade(self, service_type: str, collection: dict) -> None:
        """
        Tests the section wms_provider_facade.
        The section can be missing or the section can contain an empty dictionary
        or the section can have all the key values.
        """

        if 'provider_map_wmsfacade' in collection:
            if self._validate_key(collection, 'provider_map_wmsfacade', dict):
                wms_facade = collection['provider_map_wmsfacade']
                if service_type == "True":
                    # Validate content
                    if wms_facade:
                        # Dictionary is not empty
                        self._validate_key(wms_facade, 'format_name')
                        self._validate_key(wms_facade, 'format_mimetype')
                        self._validate_key(wms_facade, 'options_layer')
                        self._validate_key(wms_facade, 'options_style')
                        self._validate_key(wms_facade, 'wms_service_url')
                else:
                    wms_facade = {}
        else:
            collection['provider_map_wmsfacade'] = {}

        return


    def _validate_provider_coverage(self, service_type: str, collection: dict) -> None:
        """
        Tests the section provider_feature_coverage.
        The section can be missing or the section can contain an empty dictionary
        or the section can have all the key values.
        """

        if 'provider_coverage_rasterio' in collection:
            if self._validate_key(collection, 'provider_coverage_rasterio', dict):
                coverage = collection['provider_coverage_rasterio']
                if service_type == "True":
                    # Validate content
                    if coverage:
                        # Dictionary is not empty
                        self._validate_key(coverage, 'folder_path')
                        self._validate_key(coverage, 'item_name')
                        self._validate_key(coverage, 'format_name')
                        self._validate_key(coverage, 'format_mimetype')
                coverage = {}
        else:
            collection['provider_coverage_rasterio'] = {}

        return


    def _validate_feature_name(self, provider_feature) -> None:
        """
        Validates the feature name value. Two templates are possible
          - gpkg::file_name.gpkg|layer_name
          - postgis::table_name
        """

        feature_name = provider_feature['feature_name']
        provider_feature['feature_name_dict'] = None
        feature_name_dict: dict | None = None

        types: list[str] = feature_name.split("::")
        if len(types) == 2:
            if types[0] == "gpkg":
                values: list[str] = types[1].split("|")
                if len(values) == 2:
                    if values[0].lower().endswith(".gpkg"):
                        gpkg_file: str = config.QGIS_PROJECTS_PATH(values[0])  # Adjust gpkg file path
                        feature_name_dict = {}
                        feature_name_dict['type'] = types[0]
                        feature_name_dict['file_name'] = gpkg_file
                        feature_name_dict['table_name'] = values[1]
                        feature_name_dict['db_table_name'] = util.format_oapi_table_name(self.get_dataset_name(), values[1])

                    else:
                        # The file name must end with "gpkg"
                        self.message.add_error(f"Feature name has an invalid geopackage name: {values[0]}",
                                               f"Le feature name possède un nom de geopackage invalide: {values[0]}")
                else:
                    # Must have 2 and only 2 parts
                    self.message.add_error(f"Invalid 'feature name': {feature_name}.",
                                           f"Invalide 'feature name': {feature_name}.")
            elif types[0] == "postgis":
                feature_name_dict = {}
                feature_name_dict['type'] = types[0]
                feature_name_dict['file_name'] = None
                feature_name_dict['table_name'] = types[1]
                feature_name_dict['db_table_name'] = util.format_oapi_table_name(self.get_dataset_name(), types[1])

            else:
                # A type must be "gpkg" or "postgis"
                self.message.add_error(f"Invalid 'feature name': {types[0]}. Must be: 'gpkg::' or 'postgis::'",
                                       f"'feature name': {types[0]} invalide. Doit-être: 'gpkg::' or 'postgis::'")
        else:
            # A type must have exactly 2 parts
            self.message.add_error(f"Invalid 'feature name': {types[0]}.",
                                   f"'feature name': {types[0]} invalide.")

        provider_feature['feature_name_dict'] = feature_name_dict

        return


    def _validate_provider_feature(self, service_type: str, collection: dict) -> None:
        """
        Tests the section provider_feature_postgres
        The section can be missing or the section can contain an empty dictionary
        or the section can have all the key values
        """

        if 'provider_feature_postgres' in collection:
            if self._validate_key(collection, 'provider_feature_postgres', dict):
                feature = collection['provider_feature_postgres']
                if service_type == "True":
                    # Validate content
                    if feature:
                        # Dictionary is not empty
                        self._validate_key(feature, 'data_queryables', list)
                        self._validate_list(feature['data_queryables'], str)
                        self._validate_key(feature, 'feature_name')
                        self._validate_key(feature, 'schema_name')
                        self._validate_key(feature, 'data_id_field')
                        self._validate_key(feature, 'data_geom_field')
                        self._validate_feature_name(feature)
                else:
                    coverage = {}
        else:
            collection['provider_feature_postgres'] = {}

        return


    def _validate_schema_oapi_service(self) -> None:
        """Validates the oapi_service section"""


        def _validate_oapi_service_type_combination() -> None:
            """
            Validates the permutation of type services; the three allowed combination are: WMS / WMS and WFS / WCS
            """

            oapim = oapi_service_type['OAPIM']
            oapif = oapi_service_type['OAPIF']
            oapic = oapi_service_type['OAPIC']

            if (oapim == "False" and oapif == "False" and oapic == "False") or \
               (oapim == "False" and oapif == "True"  and oapic == "True") or \
               (oapim == "True"  and oapif == "True"  and oapic == "True"):
                # Invalid combination of services
                self.message.add_error(f"Invalid service type combination:[OAPIM: {oapim}, OAPIF: {oapif}, OAPIC: {oapic}]",
                                       f"Combinaison invalide de type de services:[OAPIM: {oapim}, OAPIF: {oapif}, OAPIC: {oapic}]")
            else:
                # Valid combination
                pass

            return


        def  _validate_provider_combination() -> None:
            """
            Validates the domain and the combination of the provider
            """

            # Validate domain values of provider_name
            self._validate_value_domain(collection, 'provider_name', ["WMSFacade", "rasterio", "PostgreSQL"])

            # Validate domain values of provider type
            self._validate_value_domain(collection, 'provider_type', ["feature", "coverage", "map"])

            # Validate combination of provider_name anf provider_type
            if collection['provider_name'] == "PostgreSQL" and collection['provider_type'] == "feature":
                valid = True
            elif collection['provider_name'] == "rasterio" and collection['provider_type'] == "coverage":
                valid = True
            elif collection['provider_name'] == "WMSFacade" and collection['provider_type'] == "map":
                valid = True
            else:
                valid = False

            if not valid:
                self.message.add_error("The combination of the fields 'provider_name' and 'provider_type' is invalid.",
                                       "La combinaison des champs 'provider_name' et 'provider_type' est invalide.")

            return

        oapi_services = self.get_oapi_service_parameters()
        self._validate_key(oapi_services, 'oapi_service_type', dict)
        self._validate_key(oapi_services, 'collections', list)

        if self.message.if_errors():
            raise UserWarning   # Exit on error

        oapi_service_type = oapi_services['oapi_service_type']
        self._validate_key(oapi_service_type, 'OAPIM', empty_value=False)
        self._validate_key(oapi_service_type, 'OAPIF', empty_value=False)
        self._validate_key(oapi_service_type, 'OAPIC', empty_value=False)

        if self.message.if_errors():
            raise UserWarning   # Exit on error

        # Validate the domain of the OAPI service type
        self._validate_value_domain(oapi_service_type, 'OAPIM', ControlFile.TRUE_FALSE)
        self._validate_value_domain(oapi_service_type, 'OAPIF', ControlFile.TRUE_FALSE)
        self._validate_value_domain(oapi_service_type, 'OAPIC', ControlFile.TRUE_FALSE)

        # Validate if the combination of service type is valid
        _validate_oapi_service_type_combination()

        if self.message.if_errors():
            raise UserWarning   # Exit on error

        # Validate the content of each collection
        for collection in oapi_services['collections']:
            if type(collection) == dict:
                self._validate_key(collection, 'collection_name', empty_value=False)
                self._validate_key(collection, 'group_name')
                self._validate_key(collection, 'datastore_id')
                self._validate_key(collection, 'server_id')
                self._validate_key(collection, 'provider_name', empty_value=False)
                self._validate_key(collection, 'provider_type', empty_value=False)
                self._validate_key(collection, 'collection_metadata', dict)

                if self.message.if_errors():
                    raise UserWarning   # Exit on error

                col_metadata = collection['collection_metadata']
                self._validate_key(col_metadata, 'collection_description_en')
                self._validate_key(col_metadata, 'collection_description_fr')
                self._validate_key(col_metadata, 'collection_keywords_en', list)
                self._validate_key(col_metadata, 'collection_keywords_fr', list)
                self._validate_key(col_metadata, 'collection_title_en')
                self._validate_key(col_metadata, 'collection_title_fr')
                self._validate_key(col_metadata, 'collection_crs')
                self._validate_key(col_metadata, 'extents_spatial_bbox', list)
                self._validate_key(col_metadata, 'extents_spatial_crs')
                self._validate_key(col_metadata, 'extents_temporal_begin')
                self._validate_key(col_metadata, 'extents_temporal_end')

                if self.message.if_errors():
                    raise UserWarning   # Exit on error

                self._validate_list(col_metadata['collection_keywords_en'], str)
                self._validate_list(col_metadata['collection_keywords_fr'], str)
                self._validate_list(col_metadata['extents_spatial_bbox'], float)

                # Validate the domain and the combination of provider
                _validate_provider_combination()

                self._validate_provider_wms_facade(oapi_service_type['OAPIM'], collection)
                self._validate_provider_feature(oapi_service_type['OAPIF'], collection)
                self._validate_provider_coverage(oapi_service_type['OAPIC'], collection)

        # Validate that each collection as one and only one provider (facade, rasterio pr postgess) and the provider match
        # with the provider_type
        provider_lst = (('OAPIC', 'provider_coverage_rasterio' ), \
                        ('OAPIM', 'provider_map_wmsfacade'), \
                        ('OAPIF', 'provider_feature_postgres'))
        for collection in oapi_services['collections']:
            # Validate each provider
            nbr_provider = 0
            for oapi, provider in provider_lst:
                # Only if the collection has specified that specific provider
                if len(collection[provider]) >= 1:
                    # Check if the specific collection provider is indeed True in the oapi service type
                    if oapi_service_type[oapi] == "True":
                        # Increment
                        nbr_provider += 1

                    else:
                        # The collection is using a provider which is False in the oapi service type
                        self.message.add_error(f"Incoherence between service_type: {oapi} and provider {provider}.",
                                               f"Incohérence entre service_type: {oapi} et provider: {provider}.")


            if nbr_provider > 1:
                # Error one and only one provider per collection
                self.message.add_error(f"Each collection must have one and only one provider. Error in collection: {collection['collection_name']}.",
                                       f"Chaque collection doit avoir un et un seul provider. Erreur pour la collection: {collection['collection_name']}.")

        # For the provider_type "feature" validate that the datastore_id and schema_name is always the same
        datastore_id = None
        schema_name = None
        for collection in oapi_services['collections']:
            if collection['provider_type'] == 'feature':
                if datastore_id is None:
                    datastore_id = collection['datastore_id']
                    schema_name = collection['provider_feature_postgres']['schema_name']
                else:
                    if datastore_id != collection['datastore_id']:
                        self.message.add_error("For the 'provider_type': 'feature', all the collection must have the same 'datastore_id'.",
                                               "Pour un 'provider_type': 'feature', toute la collection doit avoir le même 'datastore_id'.")

                    if schema_name != collection['provider_feature_postgres']['schema_name']:
                        self.message.add_error("For the 'provider_type': 'feature', all the collection must have the same 'schema_name'.",
                                               "Pour un 'provider_type': 'feature', toute la collection doit avoir le même 'schema_name'.")

        return


    def _validate_json_schema(self) -> None:
        """Validates the schema of the json file"""

        if self.message.if_errors():
            raise UserWarning   # Exit on error

        self._validate_schema_main()

        if self.message.if_errors():
            raise UserWarning   # Exit on error

        service_type: dict[str, str] = self.get_service_type()

        if service_type['Download'] == "True":
            if self._validate_key(self.inner_dict, 'download', dict):
                self._validate_schema_download()

        if service_type['OWS'] == "True":
            if self._validate_key(self.inner_dict, 'ows_service_parameters', dict):
                self._validate_schema_ows_service()

        if service_type['OAPI'] == "True":
            if self._validate_key(self.inner_dict, 'oapi_service_parameters', dict):
                self._validate_schema_oapi_service()

        if self.message.if_errors():
            raise UserWarning  # Exit on on error

        return


    def normalize_common_section(self) -> None:
        """
        Normalizes the common section of the control file.
        """

        # Make sure the department is written in lowercase
        self.set_department(self.get_department().lower())

        # Make sure the email is lowercase
        self.set_email(self.get_email().lower())

        # Make sure the UUID is in lower case (UUID are case insensitive)
        self.set_metadata_uuid(self.get_metadata_uuid().lower())


    def normalize_download_section(self) -> None:
        """
        Normalizes the download section of the control file.
        """

        # Make sure download section exists
        if self.has_download():
            # Make sure the server and datastore are in upper case
            self.set_download_server_id(self.get_download_server_id().upper())
            self.set_download_datastore_id(self.get_download_datastore_id().upper())


    def normalize_ows_section(self) -> None:
        """
        Normalizes the ows section of the control file.
        """

        # Make sure the section exists
        if self.has_ows_service_parameters():
            # Normalization specific to OWS services
            ows_service_params: dict = self.get_ows_service_parameters()

            # Make sure the server and datastore are in upper case
            self.set_ows_service_parameters_server_id(self.get_ows_service_parameters_server_id().upper())
            self.set_ows_service_parameters_vector_datastore_id(self.get_ows_service_parameters_vector_datastore_id().upper())
            self.set_ows_service_parameters_raster_datastore_id(self.get_ows_service_parameters_raster_datastore_id().upper())


    def normalize_oapi_section(self) -> None:
        """
        Normalizes the oapi section of the control file.
        """

        # Make sure the section exists
        if self.has_oapi_service_parameters():
            # Continue with normalization specific to OAPI services
            for collection in self.get_oapi_service_parameters_collections():
                # Loop over each collection to normalize some key/value
                collection['server_id'] = collection['server_id'].upper()
                collection['datastore_id'] = collection['datastore_id'].upper()
