"""
This module handles Users management logic (create User, read User permissions, etc).
"""

# Imports
# 3rd party imports

# Application modules
from nrcan_core.db.entity.user import DBUser
from nrcan_core.db import db_conn
from nrcan_core.lib.exceptions import *


def get_users() -> list[DBUser]:
    """
    Gets a list of users in the system.
    """

    return db_conn.query_users()


def create_user(ldap_key: str, admin_flag: bool) -> None:
    """
    Verifies if the user doesn't already exist and adds it in the database.

    :param ldap_key: The ldap_key of the User to create
    :raises UserMessageException: Raised when the user already existed or no ldap_key was defined.
    """

    # Validate the ldap_key is set
    if ldap_key:
        # Trim it
        ldap_key = ldap_key.strip()

        # Get the user by this ldap_key
        user: DBUser | None = db_conn.query_user(ldap_key)

        # If no user
        if user is None:
            # Add the User in the database
            db_conn.add_user(ldap_key, admin_flag)

        else:
            raise UserMessageException(500,
                                       "This user already exists.",
                                       "Cet utilisateur existe déjà.")

    else:
        raise UserMessageException(400,
                                   "Username undefined.",
                                   "Aucun nom d'utilisateur défini.")


def delete_user(ldap_key: str) -> None:
    """
    Verifies if the user exists and deletes it from the database.

    :param ldap_key: The ldap_key of the User to delete
    :raises UserMessageException: Raised when the username doesn't exist or no username was defined.
    """

    # Validate the username is set
    if ldap_key:
        # Trim it
        ldap_key = ldap_key.strip()

        # Get the user by this ldap_key
        user: DBUser | None = db_conn.query_user(ldap_key)

        # If user exists
        if user is not None:
            # Delete the user in the database
            db_conn.delete_user(ldap_key)

        else:
            raise UserMessageException(404,
                                       "This user couldn't be found.",
                                       "Cet utilisateur n'existe pas.")

    else:
        raise UserMessageException(400,
                                   "Username undefined.",
                                   "Aucun nom d'utilisateur défini.")
