from typing import Union

from ..nrcan_core.core.cdtk_message import CDTKMessage
from ..nrcan_core.lib.exceptions import UserMessageException
from ..nrcan_core.lib.progress_marks import ProgressMark
from ..nrcan_core.core.util import combine_progress_marks_for_response


class CDTKMessagePlugin(CDTKMessage):
    """
    Manages the messages related to the Plugin
    """

    def __init__(self, log_text_edit) -> None:
        """Constructor"""

        self.log_text_edit = log_text_edit
        super().__init__()  # Call the parent class


    # def get_user_message(self) -> Union[UserMessageException, None]:
    #     """Gets a UserMessagseException based on all the gathered errors"""

    #     if self.if_errors():
    #         return util.combine_exceptions_for_response(self.errors)
    #     return None


    # def get_last_internal_error(self) -> Union[BaseException, None]:
    #     """Gets the last internal error"""

    #     if self.if_errors() and isinstance(self.errors[-1], UserMessageException) and self.errors[-1].internal_error is not None:
    #         return self.errors[-1].internal_error
    #     return None


    # def set_stack(self, stack_trace: str) -> None:
    #     """Sets the stack list"""

    #     self.stack_trace = stack_trace


    # def set_big_error(self, big_error: BaseException) -> None:
    #     """Sets the big error"""

    #     self.big_error = big_error


    def _log_message(self, english: str, french: str, message_status: str) -> None:
        """Print the message in the Log tab"""

        english = message_status + " - " + english
        french = message_status + " - " + french
        current_pm = [ProgressMark(english, french)]
        english, french = combine_progress_marks_for_response(current_pm)
        current_text = self.log_text_edit.toPlainText()
        current_text = current_text + english + '\n'
        self.log_text_edit.setPlainText(current_text)


    def add_progress(self, english: str, french: str) -> None:
        """Keeps track"""

        super().add_progress(english, french)
        self._log_message(english, french, 'Information')


    def add_error(self, english: str, french: str, internal_error: Union[BaseException, None] = None) -> None:
        """Adds an exception error"""

        super().add_error(english, french, internal_error)
        self._log_message(english, french, 'Error')


    # def add_error_exception(self, exception: UserMessageException) -> None:
    #     """Adds an exception error"""

    #     self.errors.append(exception)


    # def add_error_raise(self, english: str, french: str, internal_error: Union[BaseException, None] = None) -> None:
    #     """Adds an error and raise the exceptions"""

    #     if internal_error is None:
    #         internal_error = self.get_last_internal_error()
    #     self.add_error(english, french, internal_error)
    #     self.if_errors_raise()


    def add_warning(self, english: str, french: str, internal_error: Union[BaseException, None] = None) -> None:
        """Print a warning in the log tab"""

        super().add_error(english, french, internal_error)
        self._log_message(english, french, 'Warning')


    # def if_errors(self) -> bool:
    #     """Returns True if errors are logged; False otherwise"""

    #     return len(self.errors) != 0


    # def if_errors_mark(self, english: str, french: str) -> None:
    #     """If errors, add a marker with the information"""

    #     if self.if_errors():
    #         self.add_progress(english, french)


    # def if_errors_raise(self) -> None:
    #     """If errors, raise an abort exception"""

    #     if self.if_errors():
    #         raise util.combine_exceptions_for_response(self.errors)
