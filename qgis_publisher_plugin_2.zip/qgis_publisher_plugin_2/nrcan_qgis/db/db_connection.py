"""
This module offers functions to query and manage a Postgresql database.
"""

# 3rd party imports
import psycopg2
import psycopg2.extras
from psycopg2 import sql
import urllib.parse
from lib.exceptions import *


def _gen_uri_base(host: str, port: int, db_name: str, user: str, password: str, ssl_mode: str):
    """
    Helper function to generate a base uri for a database connection for PyQGIS
    """
    return f"host='{host}' port={str(port)} dbname='{db_name}' user='{user}' password='{password}' sslmode={ssl_mode} "


class PyDB(object):
    """
    Class representing a Database connection.
    """

    def __init__(self, host, port, dbname, user, password):
        """Constructor"""

        self.host = host
        self.port = port
        self.dbname = dbname
        self.user = user
        self.password = password


    def open_conn(self):
        """
        Connects to the database.

        :returns: A :class:`~psycopg2` connection
        """

        # Connects and returns the connection
        return psycopg2.connect(host=self.host, port=self.port, dbname=self.dbname, user=self.user, password=self.password, sslmode="allow")


    def init_schema(self, schema: str):
        """
        Initializes the database schema for the functions in this class
        that require a database schema.

        :param schema: The database schema
        """

        # Init the schema
        self.schema = None

        # Validate the schema exists in the database
        with self.open_conn() as conn:
            # Open a cursor
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                str_query = "SELECT * FROM {table} WHERE UPPER(schema_name) LIKE UPPER(%s);"

                # Query in the database
                query = sql.SQL(str_query).format(table=sql.Identifier("information_schema","schemata"))

                # Execute cursor and fetch
                cur.execute(query, (schema,))
                res = cur.fetchone()
                if res:
                    # Read the schema as-is from the database, because this is case sensitive!
                    self.schema = res['schema_name']
                    return True

                else:
                    self.schema = None
                    raise SchemaNotFound(schema)


    def gen_uri_base(self):
        return _gen_uri_base(self.host, self.port, self.dbname, self.user, self.password, "allow")


    def gen_uri_export(self, schema: str, table: str, type: str):
        """
        Helper function to generate a base uri for a table in a database connection in PyQGIS
        """

        # Redirect
        uri = self.gen_uri_base()
        return uri + f" table=\"{schema}\".\"{table}\" (geom) key='fid' type={type} "


    def gen_uri_data_source(self, schema: str, table: str, type: str):
        """
        Helper function to generate a base uri for a table with a srid in a database connection in PyQGIS
        """

        # Redirect
        uri = self.gen_uri_export(schema, table, type)
        return uri + f" checkPrimaryKeyUnicity='{1}' estimatedmetadata=true "


    def gen_uri_data_source_srid(self, schema, table, type, srid):
        """
        Helper function to generate a base uri for a table with a srid in a database connection in PyQGIS
        """

        # Redirect
        uri = self.gen_uri_data_source(schema, table, type)
        return uri + f" srid={srid} "


    def gen_uri_storage_schema(self):
        """
        Helper function to generate a base uri for the storage in PyQGIS
        """

        return f"postgresql://{urllib.parse.quote(self.user)}:{urllib.parse.quote(self.password)}@{self.host}:{self.port}?dbname={self.dbname}&schema={self.schema}"


    def gen_uri_project(self, qgis_project_id: str):
        """
        Helper function to generate a base uri for a PyQGIS project stored within the storage in PyQGIS
        """

        return f"{self.gen_uri_storage_schema()}&project={qgis_project_id}"



    def table_exists(self, table_name: str):
        """
        Utility function to check if a table exists in the database.
        """

        # Connect to the database
        with self.open_conn() as conn:
            # Open a cursor
            with conn.cursor() as cur:
                # Query in the database
                query = sql.SQL("SELECT * FROM {table};").format(
                    table=sql.Identifier(self.schema, table_name))

                exists = False
                try:
                    # Execute cursor
                    cur.execute(query)
                    exists = True

                except Exception as err:
                    pass

                return exists


    def save_layer_style_finalize(self, style_name: str, type_str: str):
        """
        Utility function to quickly open an SQL connection and drop the table with the given name.
        """

        # Connect to the database
        with self.open_conn() as conn:
            # Open a cursor
            with conn.cursor() as cur:
                # The update query
                str_query = """UPDATE {layer_styles_table}
                               SET type = %s
                               WHERE stylename = %s;
                            """

                # Query in the database
                query = sql.SQL(str_query).format(
                    layer_styles_table=sql.Identifier("public", "layer_styles"))

                # Execute cursor
                res = cur.execute(query, (type_str, style_name,))

            # Commit
            conn.commit()



    def rename_table_go(self, cur, schema: str, table_name_og: str, table_name_new: str):
        """
        Drops a table from the database by running the "ALTER TABLE RENAME TO ..." SQL command.
        """

        # The drop query
        str_query = "ALTER TABLE {table_og} RENAME TO {table_new};"

        # Query in the database
        query = sql.SQL(str_query).format(
            table_og=sql.Identifier(schema, table_name_og),
            table_new=sql.Identifier(table_name_new))

        # Execute cursor
        #print(f"RENAMING TABLE FROM {table_og} TO {table_new}")
        cur.execute(query)


    def drop_table_go(self, cur, schema: str, table_name: str):
        """
        Drops a table from the database by running the "DROP TABLE IF EXISTS ..." SQL command.
        """

        # The drop query
        str_query = "DROP TABLE IF EXISTS {table};"

        # Query in the database
        query = sql.SQL(str_query).format(
            table=sql.Identifier(schema, table_name))

        # Execute cursor
        #print(f"DROPPING TABLE {table_name}")
        cur.execute(query)


    def create_spatial_index_go(self, cur, schema: str, table_name: str, index_name: str):
        """
        Creates a spatial index on the given table by running the "CREATE INDEX ... USING GIST(geom)" SQL command.
        """

        # The drop query
        str_query = "CREATE INDEX {index_name} ON {table_name} USING GIST(geom);"

        # Query in the database
        query = sql.SQL(str_query).format(
            index_name=sql.Identifier(index_name),
            table_name=sql.Identifier(schema, table_name))

        # Execute cursor
        cur.execute(query)


    def drop_index_go(self, cur, schema: str, index_name: str):
        """
        Drops an index from the database by running the "DROP INDEX IF EXISTS ..." SQL command.
        """

        # Drop the index so the new table can use it
        str_query = "DROP INDEX IF EXISTS {index_name};"

        # Query in the database
        query = sql.SQL(str_query).format(
            index_name=sql.Identifier(schema, index_name))

        # Execute cursor
        cur.execute(query)


    def rename_layer_style_go(self, cur, schema: str, table_name_og: str, table_name_new: str):
        # The update query
        str_query = """UPDATE {layer_styles_table}
                       SET f_table_name = %s
                       WHERE f_table_schema = %s AND f_table_name = %s;
                    """

        # Query in the database
        query = sql.SQL(str_query).format(
            layer_styles_table=sql.Identifier("public", "layer_styles"))

        # Execute cursor
        res = cur.execute(query, (table_name_new, schema, table_name_og,))


    def delete_layer_style_go(self, cur, schema: str, table_name: str):
        """
        Utility function to delete a layer style for a given table name.
        """

        # The update query
        str_query = """DELETE FROM {layer_styles_table}
                       WHERE f_table_schema = %s AND f_table_name = %s;
                    """

        # Query in the database
        query = sql.SQL(str_query).format(
            layer_styles_table=sql.Identifier("public", "layer_styles"))

        # Execute cursor
        res = cur.execute(query, (schema, table_name,))

