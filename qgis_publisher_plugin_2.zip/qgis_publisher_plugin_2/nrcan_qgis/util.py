import unicodedata

from .lib.exceptions import QGISApplicationException


LAYER_NAME_MAX_LENGTH = 45


def format_oapi_table_name(group_name: str, gpkg_table_name: str):
    """
    Helper function to get the oapi table name from a group name and a geopackage table name.
    """

    # The table name is based on the layer short name
    return _normalize_string(group_name[:15] + "__" + gpkg_table_name[:LAYER_NAME_MAX_LENGTH])


def _normalize_string(the_string: str):
    """
    Helper function to format the layer name to a name with " " replaced by "_"
    """

    if the_string:
        return _strip_accents(the_string.lower().replace(" ", "_"))
    return the_string


def _strip_accents(text: str):
    """
    Strip accents from input String.

    :param text: The input string.
    :type text: String.

    :returns: The processed String.
    :rtype: String.
    """
    try:
        text = str(text, 'utf-8')
    except (TypeError, NameError): # unicode is a default on python 3
        pass
    text = unicodedata.normalize('NFD', text)
    text = text.encode('ascii', 'ignore')
    text = text.decode("utf-8")
    return str(text)


def _validate_throws_or_append(exception: QGISApplicationException, errors: list):
    """
    Utility function to either raise the provided exception or compile it in the provided errors list (when defined).
    This is to allow a process to compile a series of errors before actually stopping everything.
    """

    # If we have provided a list, append the exception to it, otherwise, throw it immediately
    if errors != None:
        # Append to the list
        errors.append(exception)

    else:
        # Throw it
        raise exception
