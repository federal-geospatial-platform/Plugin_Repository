CREATE USER "cdtk_sys_pub_admin_dev" LOGIN NOSUPERUSER INHERIT NOCREATEDB NOCREATEROLE NOREPLICATION PASSWORD 'admin';
CREATE DATABASE cdtk_publication
        WITH OWNER = "cdtk_sys_pub_admin_dev"
                TEMPLATE = template0
                ENCODING = 'UTF8'
                TABLESPACE = pg_default
                LC_COLLATE = 'C.UTF-8'
                LC_CTYPE = 'C.UTF-8'
                CONNECTION LIMIT = -1;

GRANT ALL PRIVILEGES ON DATABASE "cdtk_publication" TO "cdtk_sys_pub_admin_dev";

\connect cdtk_publication

