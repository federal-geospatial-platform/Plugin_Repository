--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3
-- Dumped by pg_dump version 16.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: users; Type: TABLE DATA; Schema: qgis_sys; Owner: cdtk_sys_pub_admin_dev
--

COPY qgis_sys.users (id, role, email, usage) FROM stdin;
2	100	daniel.pilon@NRCan-RNCan.gc.ca	User
4	100	martin.mimeault@NRCan-RNCan.gc.ca	User
42	2	some-test-email@email.com	User
5	100	melissa.coursol@NRCan-RNCan.gc.ca	User
6	100	mark.lague@NRCan-RNCan.gc.ca	User
7	100	charles.fortin@NRCan-RNCan.gc.ca	User
8	100	71d17990-bcb0-4346-86a4-4b509ddf1bb3	API Registry
9	100	f646686d-1c57-449f-abc6-d587aa093d01	API Publication Web
3	100	alexandre.roy@NRCan-RNCan.gc.ca	User
18	100	steven.poulin@nrcan-rncan.gc.ca	User
1	100	geoffroy.houle@nrcan-rncan.gc.ca	User
\.


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: qgis_sys; Owner: cdtk_sys_pub_admin_dev
--

SELECT pg_catalog.setval('qgis_sys.users_id_seq', 42, true);


--
-- PostgreSQL database dump complete
--

