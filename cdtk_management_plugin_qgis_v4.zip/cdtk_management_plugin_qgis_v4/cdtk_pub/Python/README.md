# Python solution overview
- `api` folder contains source-code relative to the `CDTK Publication OpenAPI`.
- `nrcan_core` folder contains core source-code used by `CDTK Publication OpenAPI`.
- `nrcan_qgis` folder contains utility source-code using the PyQGIS library.
- `docs` folder contains templates for the automatic Sphinx documentation.
- `Dockerfile_api` file contains all configuration to create a Docker image for the deployment of the `CDTK Publication OpenAPI`.
- `GEN_DOC.bat` is a Windows-executable shortcut running commands to rebuild the Sphinx documentation, built on Readthedocs, for the `CDTK Publication OpenAPI`.

1. Install a Conda manager such as [Anaconda3](https://docs.anaconda.com/anaconda/install/windows/) or [Miniconda](https://docs.conda.io/projects/miniconda/en/latest/)
2. Git Clone https://github.com/federal-geospatial-platform/cdtk_publication.git in a workspace folder of your choice
3. Navigate to the `Python` folder and create a Python environment for the solution by running `conda create --name env-cdtk_publication python=3.11.5`
4. Activate the environment by running `conda activate env-cdtk_publication`
5. Install pip `conda install pip`
6. Install dependencies running `pip install -r "api\requirements.txt"`
8. You are now ready to `python main.py` the api application!

## CDTK Publication OpenAPI
Navigate to the [`api`](https://github.com/federal-geospatial-platform/cdtk_publication/tree/main/Python/api) folder to get documentation on the `CDTK Publication OpenAPI`.

## Deployment of the solution using Docker image
1. Package the source code to a blank deployment folder. You can run:
   - `robocopy C:\{YOUR_PATH}\cdtk_publication\Python C:\{RELEASE_PATH} /MIR /DST /NP /NDL /R:5 /XA:S /XD "__pycache__" "docs"  /XF "config_*.py"`

2. Package the correct config file based on the environment to deploy to. You can run:
   - To deploy in DEV: `xcopy C:\{YOUR_PATH}\cdtk_publication\Python\nrcan_core\config_dev.py C:\{RELEASE_PATH}\nrcan_core\config_env.py`
   - To deploy in PROD: `xcopy C:\{YOUR_PATH}\cdtk_publication\Python\nrcan_core\config_prd.py C:\{RELEASE_PATH}\nrcan_core\config_env.py`
   - *The current `nrcan_core\config_env.py` file in GIT is for developpers*

3. Deploying the API:
   - Create the Docker image using the provided Docker file (e.g. on Windows):
     - `docker build -f C:\{RELEASE_PATH}\Dockerfile_api -t nrcan-ddr-publication-api .`
     - `docker save nrcan-ddr-publication-api -o C:\{DOCKER_IMAGES}\nrcan-ddr-publication-api`

   - Load the Docker image on port 5031 (e.g. on Linux):
     - `sudo docker load -i nrcan-ddr-publication-api`
     - `sudo docker run -d -p 5031:5031 --restart always --name nrcan-ddr-publication-api nrcan-ddr-publication-api`
 
4. You now have the API server running, listening on port 5031, and powered by [Gunicorn](https://gunicorn.org/).
