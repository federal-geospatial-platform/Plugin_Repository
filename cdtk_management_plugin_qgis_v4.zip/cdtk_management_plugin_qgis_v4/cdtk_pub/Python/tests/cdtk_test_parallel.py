"""This file contains the code to test the cdtk_publisher """
import sys, os
import concurrent.futures
from nrcan_core.lib.exceptions import *
from nrcan_core.cdtk_publisher import info_schema


# Add working directory to get access to 'nrcan_core' module which is higher than tests folder
sys.path.insert(1, os.getcwd())

WORKERS: int = 20

def execute_task() -> dict:
    print("Executing task")
    return info_schema('nrcan')


with concurrent.futures.ThreadPoolExecutor(max_workers = WORKERS) as executor:
    # Start the workers
    futures: list[concurrent.futures.Future] = [executor.submit(execute_task) for _ in range(WORKERS)]

    # Wait for the all tasks to complete
    for future in concurrent.futures.as_completed(futures):
        # If the execute function returned a result, process it
        fres = future.result()  # This raises any exceptions from the tasks
        print(f"Result: {fres}")
