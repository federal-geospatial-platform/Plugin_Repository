from qgis.core import QgsApplication, QgsProject, QgsLayerTreeLayer

SOMEPATH = "C:\\Users\\alexandre.roy\\Desktop"

def get_all_layers(root) -> list:
    results: list = []

    def get_all_layers_rec(node, results) -> None:
        if isinstance(node, QgsLayerTreeLayer):
            layer = node.layer()
            results.append(layer)

        elif node.nodeType() == node.NodeGroup:
            for child in node.children():
                get_all_layers_rec(child, results)

    get_all_layers_rec(root, results)
    return results

def check_layers_source_and_validity(layers):
    for layer in layers:
        data_provider = layer.dataProvider()
        print(f"Layer {layer.name()} | provider type: {layer.providerType()} | datasource: {data_provider.dataSourceUri()} | Valid?: {data_provider.isValid()}")

# Init
qgis_app_reference = QgsApplication([], False)
qgis_app_reference.initQgis()
project: QgsProject | None = QgsProject.instance()

# If instance found
if project:
    # Open the project which has layer with authcfg=some_valid_auth
    project.read(f"{SOMEPATH}\\test_auth_1.qgs")

    # Get the layers
    layers: list = get_all_layers(project.layerTreeRoot())

    # This prints an array with one None value, like this: [None] ## PROBLEM #1
    print(layers)

    # Can't check the layers source, because of the None object
    # check_layers_source_and_validity(layers)

    # Open the project which has layer with authcfg='some_valid_auth' (with apostrophes)
    project.read(f"{SOMEPATH}\\test_auth_2.qgs")

    # Get the layers
    layers: list = get_all_layers(project.layerTreeRoot())

    # This prints an array with the correct layer object in it
    print(layers)

    # This prints the layer source information correctly, but the isValid() call returns False ## PROBLEM #2
    check_layers_source_and_validity(layers)
