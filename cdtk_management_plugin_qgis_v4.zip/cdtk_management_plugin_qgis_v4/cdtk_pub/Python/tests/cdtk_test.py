"""This file contains the code to test the CDTK Publication"""
import os, sys
from typing import Callable, Optional
from werkzeug.datastructures import FileStorage
from nrcan_core import secret, config_env

# CONSTANTS, the CDTK_ZIP_ROOT will point to a DATA folder in your working directory
CDTK_ZIP_ROOT: str = os.path.join(os.path.dirname(os.getcwd()), "DATA")
AWS_SECRET_S3: str = "cdtk-sftp-datastore-1"

# Add working directory to get access to 'nrcan_core' module which is higher than tests folder
#sys.path.insert(1, os.getcwd())
sys.path.append(os.path.dirname(os.path.dirname(sys.path[0])))


# Init the log
from core.lib.logger import get_log, init_log
init_log(config_env.LOG_NAME, config_env.LOG_FILE, config_env.LOG_LEVEL_FILE, config_env.LOG_LEVEL_CONSOLE)

from nrcan_core.cdtk_publisher import manage_publication
from nrcan_core.lib.exceptions import *
from nrcan_core.lib.zip_file import ZipFile
from nrcan_core.lib.cdtk_message import CDTKMessage
from nrcan_core.lib.control_file import ControlFile
from nrcan_core.lib.cdtk_s3_bucket import CDTKS3Bucket
from nrcan_core.requests.cdtk_request_registry_api import CDTKRequestRegistryAPI
from nrcan_core.services.ows_service import OwsService
from nrcan_core.services.download_service import DownloadService

# Get the log
LOG = get_log(config_env.LOG_NAME)


def test_messages() -> None:
    # Create a message class
    msg = CDTKMessage()

    assert len(msg.progress_marks) == 0
    assert len(msg.warnings) == 0
    assert len(msg.errors) == 0

    ENG_PROG = "English progress"
    FRE_PROG = "French progress"
    msg.add_progress(ENG_PROG, FRE_PROG)
    assert len(msg.progress_marks) == 1
    assert len(msg.warnings) == 0
    assert len(msg.errors) == 0
    assert msg.progress_marks[0].message == ENG_PROG
    assert msg.progress_marks[0].message_fr == FRE_PROG

    ENG_WARN = "English warning"
    FRE_WARN = "French warning"
    msg.add_warning(ENG_WARN, FRE_WARN)
    assert len(msg.progress_marks) == 1
    assert len(msg.warnings) == 1
    assert len(msg.errors) == 0
    assert msg.warnings[0].message == ENG_WARN
    assert msg.warnings[0].message_fr == FRE_WARN

    ENG_ERR = "English error"
    FRE_ERR = "French error"
    msg.add_error(ENG_ERR, FRE_ERR)
    assert len(msg.progress_marks) == 1
    assert len(msg.warnings) == 1
    assert len(msg.errors) == 1

    if isinstance(msg.errors[0], UserMessageException):
        assert msg.errors[0].message == ENG_ERR
        assert msg.errors[0].message_fr == FRE_ERR


def test_registry_api_conn() -> None:
    print('########################################################################')
    print('TESTING CDTK REGISTRY API CONNECTION')
    print('########################################################################')

    # Create a request class attempting to connecto the CDTK Registry API at the same time
    # Instantiate the request and message classes
    cdtk_request = CDTKRequestRegistryAPI(secret.get_secret_api_registry_api_key(), CDTKMessage())
    assert cdtk_request

    # Try a call
    pubs: list = cdtk_request.get_publishers()
    assert pubs


def test_s3_bucket_conn() -> None:
    print('########################################################################')
    print('TESTING S3 BUCKET CONNECTION')
    print('########################################################################')

    # Connect to S3
    s3bucket = CDTKS3Bucket(secret.AWS_REGION_NAME, "", "", "", "", AWS_SECRET_S3, CDTKMessage())
    assert s3bucket

    # List info in bucket
    info: dict = s3bucket.list_bucket()
    assert info
    # for b_key in [x.key for x in info]:
    #     print(b_key)


def test_special_cases() -> None:
    # Try to publish a zip without control file
    execute_test("Publish", "SPC_OWS_no_control_file.zip", False,
                 lambda response: _assert_exception_message(response, "does not contain a JSON control file"))

    # Try to publish a zip with a folder
    execute_test("Publish", "SPC_OWS_with_folders.zip", False,
                 lambda response: _assert_exception_message(response, "Folders in the input package"))

    # Try to publish a zip with a bad control file
    execute_test("Publish", "SPC_OWS_bad_control_file_2.zip", False,
                 lambda response: _assert_exception_message(response, ["JSON Control File is invalid",
                                                                       "ControlFile the following key is missing: service_type"]))

    # Try to publish a zip with a bad control file
    execute_test("Publish", "SPC_OWS_bad_control_file_3.zip", False,
                 lambda response: _assert_exception_message(response, ["JSON Control File is invalid",
                                                                       "ControlFile the following key is missing: oapi_service_parameter"]))

    # Try to publish a zip with a bad control file
    execute_test("Publish", "SPC_OWS_bad_control_file_4.zip", False,
                 lambda response: _assert_exception_message(response, ["JSON Control File is invalid",
                                                                       "ControlFile the following key is missing: ows_service_parameters"]))

    # Try to publish with invalid naming convention for service vs filename
    execute_test("Publish", "SPC_project_bad_service_name.zip", False,
                 lambda response: _assert_exception_message(response, "must be the same as the project filename"))

    # Try to publish with a wrong department
    execute_test("Publish", "SPC_OWS_wrong_dep.zip", False,
                 lambda response: _assert_exception_message(response, ["The department with the English TBS acronym",
                                                                       "does not exists in the CDTK Registry",
                                                                       "Publisher with email",
                                                                       "is not allowed to publish for department"]))

    # Try to publish a bad OAPI combination
    execute_test("Publish", "SPC_OAPI_bad_combination.zip", False,
                 lambda response: _assert_exception_message(response, ["Incoherence between service_typ"]))

    # Try to publish a badly named zip package in the package
    execute_test("Publish", "SPC_Down_bad_zip_name.zip", False,
                 lambda response: _assert_exception_message(response, "input package doesn't contain the zip file"))

    # Try to publish an old format of control file with OAPI collections not being list-of-list
    execute_test("Publish", "SPC_OAPIF_not_list-of-list.zip", False,
                 lambda response: _assert_exception_message(response, "should be a list-of-list"))

    # Try to publish with a missing feature in the geopackage
    execute_test("Publish", "SPC_OAPIF_900A_not_existing.zip", False,
                 lambda response: _assert_exception_message(response, "is not present in the geopackage"))

    # Try to publish with incompatible service type combination
    execute_test("Publish", "SPC_OWS_WMS_WFS_WCS.zip", False,
                 lambda response: _assert_exception_message(response, "Invalid OWS service type combination"))

    # Try to publish an OAPIF with invalid table name
    execute_test("Publish", "SPC_OAPIF_wrong_table.zip", False,
                 lambda response: _assert_exception_message(response, "is not present in the database"))

    # Try to publish an OAPIF with invalid table name
    execute_test("Publish", "SPC_project_projections.zip", False,
                 lambda response: _assert_exception_message(response, "layers in the project don't all use the same coordinate reference system (CRS)"))

    # Try to publish an OAPIF with invalid table name
    execute_test("Publish", "SPC_project_projections_2.zip", False,
                 lambda response: _assert_exception_message(response, "The crs '6922' of the layer 'Metal mines' is not supported"))

    # Try to publish a zip with projects with layers with wrong source name correspondance
    execute_test("Publish", "SPC_Southey2_SourcesEnVsFr.zip", False,
                 lambda response: _assert_exception_message(response, "from the 'English' project refers to a source name 'southey2' which has no equivalence in the alternate language project"))

    # Try a zip package with duplicated filenames
    execute_test("Publish", "SPC_duplicated_filenames.zip", False,
                 lambda response: _assert_exception_message(response, "has duplicated filenames which is not supported"))

    # Try a zip package with 2 gpkg with same name_table
    execute_test("Publish", "SPC_Southey3_SameDataSourceNameDifferentPackages.zip", False,
                lambda response: _assert_exception_message(response, "is used in both geopackage"))

    # Try to publish a project with no WFS layers flagged as 'publish' in the QGIS project
    execute_test("Publish", "SPC_WFS_no_wfs_checked.zip", False,
                 lambda response: _assert_exception_message(response, "but no layers of that type have their publication flag checked in the QGIS project"))

    # Try to publish a project with WFS flag to False in control file but WFS layers flagged as 'publish' in the QGIS project
    execute_test("Publish", "SPC_WFS_yes_wfs_checked.zip", False,
                 lambda response: _assert_exception_message(response, "but the following layers have their publication flag checked in the QGIS project"))

    # Try to publish a zip with an invalid dataset name vs service name in the control file
    execute_test("Publish", "SPC_WMS_bad_service_name.zip", False,
                 lambda response: _assert_exception_message(response, "must align with the dataset name"))


def execute_test_package(zip_file: str, faster: bool, send_email: bool) -> None:
    print('########################################################################')
    print(f'EXECUTING PACKAGE {os.path.basename(zip_file)}')
    print('########################################################################')

    if not faster:
        # Try to unpublish an unexisting service
        execute_test("Unpublish", zip_file, False, lambda response: _assert_exception_message(response, "is not published"))

    try:
        # Try to publish, real case
        execute_test("Publish", zip_file, send_email, _assert_true)

        if not faster:
            # Try to publish already existing service
            execute_test("Publish", zip_file, False, lambda response: _assert_exception_message(response, "already published"))

        # Try to unpublish, real case
        execute_test("Unpublish", zip_file, send_email, _assert_true)

    except:
        # Try to unpublish, when something has failed, to clean up..
        #execute_test("Unpublish", zip_file, False)
        raise
    return


def execute_test(operation: str, zip_file: str, send_email: bool, callback: Optional[Callable[[bool | Exception], None]] = None) -> None:
    print('########################################################################')
    print(f'EXECUTING {operation} WITH FILE {os.path.basename(zip_file)}')
    print('########################################################################')
    try:
        # If the file doesn't exist
        if not os.path.exists(zip_file):
            # Chance it with full path
            zip_file = os.path.join(CDTK_ZIP_ROOT, zip_file)

        with open(zip_file, 'rb') as f:
            file_storage = FileStorage(stream=f, name="ZipFile")
            res: bool = manage_publication(operation, file_storage, send_email)
            if callback:
                callback(res)

    except Exception as err:
        if callback:
            callback(err)


def test_rollback_ows(zip_file: str) -> None:
    # Instantiate the message class
    message = CDTKMessage()

    # Open the zip file
    with open(os.path.join(CDTK_ZIP_ROOT, zip_file), 'rb') as f:
        # Open the file storage
        file_storage = FileStorage(stream=f, name="ZipFile")

        # Load the zip file
        zip_res = ZipFile(file_storage, message)

        # Load the control file
        control_file_obj = ControlFile(zip_res.control_file_str, message)
        control_file_obj.validate_content()

        # Instantiate the services
        ows_service = OwsService('Publish', control_file_obj)

        # Validate, because we have to to set attributes..
        ows_service.validate_service()

        # Process the service as speciied in the control file
        ows_service.process_service()

        # Raise an error if an error was found
        ows_service.message.if_errors_raise()

        # Call the rollback
        ows_service.rollback_service()

        # Clean up
        zip_res.clean_up_directory()


def test_rollback_ows_and_download(zip_file: str) -> None:
    # Instantiate the message class
    message = CDTKMessage()

    # Open the zip file
    with open(os.path.join(CDTK_ZIP_ROOT, zip_file), 'rb') as f:
        # Open the file storage
        file_storage = FileStorage(stream=f, name="ZipFile")

        # Load the zip file
        zip_res = ZipFile(file_storage, message)

        # Load the control file
        control_file_obj = ControlFile(zip_res.control_file_str, message)
        control_file_obj.validate_content()

        # Instantiate the services
        ows_service = OwsService('Publish', control_file_obj)
        download_service = DownloadService('Publish', control_file_obj)

        # Validate, because we have to to set attributes..
        ows_service.validate_service()
        download_service.validate_service()

        # Process the service as speciied in the control file
        ows_service.process_service()
        download_service.process_service()

        # Raise an error if an error was found
        ows_service.message.if_errors_raise()
        download_service.message.if_errors_raise()

        # Call the rollback
        ows_service.rollback_service()
        download_service.rollback_service()

        # Clean up
        zip_res.clean_up_directory()

        # Check if indeed the services don't exist anymore
        assert not ows_service.check_service_name_exists(control_file_obj.get_ows_service_parameters_english_service_name())
        assert not ows_service.check_service_name_exists(control_file_obj.get_ows_service_parameters_french_service_name())
        s3_exists, _ = download_service.check_s3_path_exists()
        assert not s3_exists


def _assert_true(response) -> None:
    """Performs an assert call, expecting the provided response to be a True boolean value"""

    # Perform the assertion
    assert isinstance(response, bool) and response == True


def _assert_exception_message(response, message: str | list) -> None:
    """Performs an assert call, expecting the provided response to be a UserMessageException with message"""

    result: bool = True
    if isinstance(response, UserMessageException):
        # Show message check in console
        print("Checking response message:", f"{message} vs {response.message}")

        # Check condition
        if isinstance(message, str):
            result = message in response.message

        else:
            for msg in message:
                if result and msg not in response.message:
                    result = False

    else:
        # Nope
        print(f"Wrong response, was expecting message: {message} but instead got: {response}")
        result = False

    # Perform the assertion
    assert result


def _assert_exception_generic(response) -> None:
    """Performs an assert call, expecting the provided response to be a generic Exception"""

    # Perform the assertion
    assert isinstance(response, Exception)


#################
# START TESTING #
#################

# Test S3 bucket
#test_s3_bucket_conn()

# Read all .zip files in the official test folder
FASTER: bool = False
SEND_EMAILS: bool = False
DO_THE_DL_PACKAGES: bool = True
for item in os.listdir(CDTK_ZIP_ROOT): # loop through items in dir
    # If a zip file and starts with VEC or RAS
    if item.endswith(".zip") and (item.startswith("VEC_") or item.startswith("RAS_")):
        # If processing the DL packages, or if not, if it's not a DL package
        if DO_THE_DL_PACKAGES or item.find('_DL') < 0:
            # If extra filtering condition (for debugging mainly)
            if (True): # item.find('RAS_CDEM_OAPIC.zip') >= 0  #  RAS_CDEM_WCS.zip  VEC_EGS.zip
                # Proceed
                execute_test_package(os.path.join(CDTK_ZIP_ROOT, item), FASTER, SEND_EMAILS)

# Test the special cases
test_special_cases()

# Try to Unpublish
#execute_test("Unpublish", "VEC_900A_WMS_OAPIF.zip", True, _assert_true)

# Try to Publish
#execute_test("Publish", "VEC_900A_WMS_OAPIF.zip", True, _assert_true)

# More tests, commented
#test_messages()
#test_registry_api_conn()
#test_s3_bucket_conn()
#test_rollback_ows("OWS_WMS.zip")
#test_rollback_ows_and_download("OWS+Down.zip")

#################
# DONE TESTING  #
#################
print("")
print("TESTS COMPLETED! ALL ASSERTIONS VALID.")
