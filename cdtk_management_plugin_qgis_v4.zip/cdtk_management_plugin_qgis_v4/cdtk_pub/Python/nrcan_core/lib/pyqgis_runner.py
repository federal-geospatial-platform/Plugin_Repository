"""
Module to run PyQGIS operations in a subprocess.
Why a subprocess? (Response from chatgpt)
- QGIS's python bindings (qgis.core, qgis.gui, etc.) are tightly integrated with Qt, the C++ GUI framework.
- QgsApplication (the core entry point) is a subclass fo QCoreApplication / QApplication from Qt.
- Qt enforces that all UI-related objects and many QObject-derived classes are created and used in the main thread of the application.
- Flask, Celery and similar frameworks create their own threads or subprocesses that are not the main UI thread.
- Thus, when PyQGIS initializes or uses any QObject (even inderectly), Qt raises an error because these objects are being created or used outside the main thread.
"""
import json
import os, sys
import subprocess
import uuid
from chardet import detect

from core.lib.qgis_progress_marks import *
from core.lib.qgis_exceptions import *
from core.lib.qgis_warnings import *
from nrcan_core import config, config_env, util
from nrcan_core.lib.cdtk_message import CDTKMessage

# Get the log
from core.lib.logger import get_log
LOG = get_log(config_env.LOG_NAME)


def run_pyqgis(operation: str, run_file: dict, bucket_name: str, bucket_prefix: str, internal: bool,
               host_qgis: str, port_qgis: int, dbname_qgis: str, user_qgis: str, password_qgis: str,
               host_data: str, port_data: int, dbname_data: str, user_data: str, password_data: str,
               message: CDTKMessage | None = None):
    LOG.trace_func()

    STD_ERR_PREFIX: str = "core.lib.qgis_exceptions.QGISAggregationException: "

    def _read_exceptions_based_on_stderr(stderr: str):

        # Very experimental, but better than nothing for now!
        for l in stderr.splitlines():
            if l.startswith(STD_ERR_PREFIX):
                line: str = l[len(STD_ERR_PREFIX):]
                ex_list = json.loads(line)
                return QGISApplicationException.list_dict_as_list_ex(ex_list)

            elif l.startswith("Exception: "):
                return [Exception(l[11:])]

            elif l.startswith("TypeError: "):
                return [Exception(l[11:])]

        # Catch all
        return [Exception(stderr)]

    def _read_result_based_on_stdout(stdout: str):
        result = True
        progress_marks = []
        warnings = []

        # # If debug
        # if config_env.IS_LOCAL:
        #     print()
        #     print("Catching the results from the stdout:")
        #     print("-------------------------------------")
        #     print(stdout.strip(os.linesep))
        #     print("-------------------------------------")
        #     print()

        # For each line
        for l in stdout.splitlines():
            if l.startswith("Result: "):
                line: str = l[8:]
                output = json.loads(line)
                result = output['result']
                progress_marks = QGISProgressMark.list_dict_as_list_progress_marks(output['progress_marks'])
                warnings =  QGISWarning.list_dict_as_list_warn(output['warnings'])
        return [result, progress_marks, warnings]

    def _copy_run_file(run_file: dict) -> str:
        # If the folder doesn't exist, create it
        if not os.path.exists(config.QGIS_JOBS_PATH("")):
            os.makedirs(config.QGIS_JOBS_PATH(""))

        # Generate a randomly generated filename to hold the control file information for the nrcan_qgis process
        filepath: str = config.QGIS_JOBS_PATH(str(uuid.uuid4()) + ".json")

        # Create the file with the control file information
        with open(filepath, 'w') as outfile:
            json.dump(run_file, outfile, indent=4)

        # Return the path of the created file
        return filepath


    filepath: str | None = None
    try:
        # Copy the control file to a local file on server
        filepath = _copy_run_file(run_file)

        # Keep track
        if message is not None:
            message.add_progress(f"Executing QGIS", f"Exécution de QGIS")
            message.add_progress_detail(f"Host:Port QGIS: {host_qgis}:{port_qgis}", f"Hôte:Port QGIS: {host_qgis}:{port_qgis}")
            message.add_progress_detail(f"DB name QGIS: {dbname_qgis}", f"Nom BD QGIS: {dbname_qgis}")
            message.add_progress_detail(f"Host:Port DATA: {host_data}:{port_data}", f"Hôte:Port DATA: {host_data}:{port_data}")
            message.add_progress_detail(f"DB name DATA: {dbname_data}", f"Nom BD DATA: {dbname_data}")

        try:
            # Get the main.py file path
            main_file: str = config.QGIS_PYTHON_PATH("main.py")

            # Get the root directory and make sure it's in the PYTHONPATH so the subprocess can find it
            root_path: str = os.path.abspath(os.path.join(os.path.dirname(__file__), "../.."))
            if not root_path in sys.path:
                sys.path.append(root_path)

            res: subprocess.CompletedProcess[bytes] = \
                subprocess.run(f"python {main_file} --operation={operation} --file=\"{filepath}\" --proj_path=\"{config_env.QGIS_PROJECTS_PATH}\" --bucket_name=\"{bucket_name}\" --bucket_prefix=\"{bucket_prefix}\" --internal=\"{internal}\" --db_host_qgis=\"{host_qgis}\" --db_port_qgis={port_qgis} --db_name_qgis=\"{dbname_qgis}\" --db_user_qgis=\"{user_qgis}\" --db_pass_qgis=\"{password_qgis}\" --db_host_data=\"{host_data}\" --db_port_data={port_data} --db_name_data=\"{dbname_data}\" --db_user_data=\"{user_data}\" --db_pass_data=\"{password_data}\"",
                               shell=True, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

            # Read the result information
            [result, qgis_progress_marks, qgis_warnings] = _read_result_based_on_stdout(res.stdout.decode(detect(res.stdout)['encoding'])) # type: ignore

            # If part of a greater process, append the information
            if message is not None:
                message.progress_marks += qgis_progress_marks
                message.warnings += qgis_warnings

            return result

        except subprocess.CalledProcessError as e:
            # Unwrap the exception from the sub process
            if e.stdout:
                # Read the result information
                [result, qgis_progress_marks, qgis_warnings] = _read_result_based_on_stdout(e.stdout.decode(detect(e.stdout)['encoding']))

                # If part of a greater process, append the information
                if message is not None:
                    message.progress_marks += qgis_progress_marks
                    message.warnings += qgis_warnings

            print("THE ERROR")
            print(e.stderr.decode(detect(e.stderr)['encoding']))

            # Read the exceptions
            exs: list[Exception] = _read_exceptions_based_on_stderr(e.stderr.decode(detect(e.stderr)['encoding']))

            # If part of a greater process, append the error(s), flag progress and raise an abort exception
            if message is not None:
                message.errors.extend(exs)
                message.add_progress("ERROR when executing PyQGIS.", "ERREUR lors de l'exécution du PyQGIS.")

            # Raise a UserMessageException, as reconstructed from PyQGIS code, right away
            raise util.combine_exceptions_for_response(exs)

    finally:
        # If not running in DEV, delete the file
        if filepath and not config_env.IS_LOCAL:
            os.remove(filepath)
