"""Manage a ZipFile"""

import json
import os
import re
import zipfile
import chardet
from werkzeug.datastructures import FileStorage

from nrcan_core import config, config_env
from nrcan_core.lib.exceptions import *
from nrcan_core.lib.cdtk_message import CDTKMessage

class ZipFile(object):
    """This class manages the zip and offer different methods to access the information"""


    def __init__(self, zip_file: FileStorage, message: CDTKMessage) -> None:
        """Constructor"""

        self.message: CDTKMessage = message  # Error message object
        self.name_zip_file = None  # File address of the zip file
        self.name_files_extracted: list[str] = []  # List of the file name extracted
        self.control_file_str: str = ""
        self.infos: list[zipfile.ZipInfo] | None = None

        self._save_zip_file(zip_file)

        if not self.message.if_errors():
            self._validate_zip_file(zip_file)

        if self.message.if_errors():
            self.message.add_progress("The zip file is invalid.", "Le fichier zip est invalide.")
        else:
            self.message.add_progress("The zip file is valid.", "Le fichier zip est valide.")


    def _save_zip_file(self, zip_file: FileStorage) -> None:
        """Save the ZIP file and raise exception if there is an error"""

        # If there's a zip file attached to the request
        if zip_file and zip_file.filename:
            # Get the zip file name output path
            if not os.path.exists(config.QGIS_IN_PACKAGES_PATH("")):
                os.makedirs(config.QGIS_IN_PACKAGES_PATH(""))
            self.name_zip_file = config.QGIS_IN_PACKAGES_PATH(os.path.basename(zip_file.filename))

            # If there's no file with that name already existing for the .zip
            if not os.path.exists(self.name_zip_file):
                # Save it
                zip_file.save(self.name_zip_file)

            else:
                raise InputPackageAlreadyExistsException(zip_file.filename)

        else:
            self.message.add_error("Invalid request, no zip file", "Requête invalide, pas de fichier zip")


    def _validate_zip_file(self, zip_file) -> None:
        """Validate the content of the zip file and extract file: ControlFile.json
        The zip file must
           - contain a file named ControlFile.json
           - have all its file at the root level directory
           - any contains file with extension: .json, .zip or .qgs
        """

        # Keep track
        self.message.add_progress(f"Unzipping zip file package {zip_file}",
                                  f"Extraction du paquet fichier zip {zip_file}")

        # Work with a zip file
        with zipfile.ZipFile(zip_file, 'r') as zip_ref:
            # Get the list of files in the zip
            self.infos = zip_ref.infolist()

            # If the zip file has a control file at the root
            if "ControlFile.json" in [i.filename for i in self.infos]:
                # Loop on the files in the zip
                for info in self.infos:
                    # If it's the control file
                    if "ControlFile.json" == info.filename:
                        try:
                            # Read the control file content
                            self.control_file_str = self._read_control_file(zip_ref, info) or ""
                        except json.decoder.JSONDecodeError as e:
                            # Raise a control file unreadable exception
                            raise ControlFileUnreadableException()

            else:
                # Raise error, because can't track it anyways, as won't be able to send an email to the user
                raise ControlFileNotFoundException(zip_file)

            # If there are no duplicated file names in the zip (yes that's possible)
            if not ZipFile._has_duplicate_filenames(self.infos):
                # If the zip file doesn't have any folder
                if all(len(os.path.dirname(a.filename)) == 0 for a in self.infos):
                    # Extract the files from zip file
                    for info in self.infos:
                        # If not the control file
                        if not re.match(r'.*\.json$', info.filename):
                            self.name_files_extracted.append(info.filename)
                            zip_ref.extract(info, config.QGIS_PROJECTS_PATH(""))
                else:
                    self.message.add_error(f"Folders in the input package {zip_file} aren't supported",
                                           f"Le paquetage d'entrée {zip_file} ne doit pas contenir de dossiers")
            else:
                self.message.add_error(f"The input package {zip_file} has duplicated filenames which is not supported",
                                       f"Le paquetage d'entrée {zip_file} ne doit pas contenir de fichiers du même nom")

        return


    @staticmethod
    def _has_duplicate_filenames(dict_list: list) -> bool:
        seen = set()
        for d in dict_list:
            filename = d.filename
            if filename in seen:
                return True  # Duplicate found
            seen.add(filename)
        return False  # No duplicates


    def _read_control_file(self, zip_file: zipfile.ZipFile, zip_info: zipfile.ZipInfo) -> str | None:
        # Rear raw data
        raw_data: bytes = zip_file.read(zip_info)

        # Detect encoding
        result = chardet.detect(raw_data)
        encoding: str | None = result['encoding']

        # Keep track
        self.message.add_progress(f"Control File encoding detected: {encoding}.",
                                  f"Encodage du Fichier de Contrôle détecté: {encoding}.")

        # If encoding was determined
        if encoding:
            # Read
            return raw_data.decode(encoding)

        else:
            # Raise a control file unreadable exception
            raise ControlFileUnreadableException()


    def clean_up_directory(self) -> None:
        """
        Cleans the directory from the temporary files either received from
        the API payload or extracted from an input zip file package.
        """

        # Keep track
        self.message.add_progress("Cleaning up workspace",
                                  "Nettoyage de l'espace de travail")

        if self.name_zip_file is not None and os.path.exists(self.name_zip_file):
            # Delete the zip file
            os.remove(self.name_zip_file)

        # If there was a zip package
        if not config_env.IS_LOCAL:
            # If any working files
            for file in self.name_files_extracted:
                file_path = config.QGIS_PROJECTS_PATH(file)
                if os.path.exists(file_path):
                    # Delete the file
                    os.remove(file_path)

                # If the name of the file is a qgis file
                if file_path.endswith(".qgs"):
                    # Check if the backup file remains, and delete it too
                    if os.path.exists(file_path + '~'):
                        # Delete the backup file as well
                        os.remove(file_path + '~')

                    # Strip the extension
                    file_path_stripped = file_path.strip(".qgs")

                    # Check if the attachments zip file remains, and delete it too
                    if os.path.exists(file_path_stripped + '_attachments.zip'):
                        # Delete the backup file as well
                        os.remove(file_path_stripped + '_attachments.zip')
