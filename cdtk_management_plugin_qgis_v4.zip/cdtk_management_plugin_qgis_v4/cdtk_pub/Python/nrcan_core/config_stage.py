"""
This module stores all configurations used by this application.
"""

import logging

# Environment name
ENV_NAME: str = 'STAGE'
IS_LOCAL: bool = False
DEBUG_SUBPROCESS: bool = False  # If true, the subprocess running the PyQGIS script will show debug information on the console

FAKE_OAUTH: bool = False

# The log parameters
LOG_NAME: str = "cdtk_log"
LOG_FILE: str = "output.log"
LOG_LEVEL_CONSOLE: int = logging.DEBUG
LOG_LEVEL_FILE: int = logging.DEBUG

# Running port
PORT_API: int = 5031
PORT_WEB: int = 5030

# Secret key
SECRET_KEY: str = "cdtk-api-publication-stage"
DB_QGIS_KEY: str = "cdtk-postgis-datastore-stage"

# For the WEB interface to call the API
API_URL: str = "https://pub-api-stage.cdtk.geogc.ca/api"
# For the WEB interface to indicate url to user
WEB_REGISTRY_URL: str = "https://reg-web-stage.cdtk.geogc.ca"
# For the WEB interface to call pygeoapi
PYGEOAPI_URL: str = "https://pygeoapi-stage.cdtk.geogc.ca/"

# CDTK Registry and Publication URLs for internal communication
CDTK_REGISTRY_URL: str = "http://cdtk-registry-api-stage:5021/api"
CDTK_PUBLICATION_URL: str = "http://cdtk-publication-api-stage:5031/api"
# CDTK QGIS Server URL for internal communication to get the QGIS Server version
CDTK_QGIS_SERVER_GET_VERSION_URL: str = "http://cdtk-qgisserver-stage/ows/get/version?"

# Email configs
EMAIL_ADMIN_CONTENT: list[str] = ["alexandre.roy@nrcan-rncan.gc.ca", "martin.mimeault@nrcan-rncan.gc.ca", "geoffroy.houle@nrcan-rncan.gc.ca", "charles.fortin@nrcan-rncan.gc.ca", "genevieve.potvin@nrcan-rncan.gc.ca", "mark.lague@nrcan-rncan.gc.ca"]
EMAIL_TIMEOUT: int = 5

# QGIS configs
QGIS_JOBS_PATH: str = "..\\jobs"
QGIS_IN_PACKAGES_PATH: str = "..\\in_packs"
QGIS_PROJECTS_PATH: str = "..\\data"
QGIS_PYTHON_PATH: str = "nrcan_qgis"
