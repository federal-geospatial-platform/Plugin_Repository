from nrcan_core import config_env
from nrcan_core.lib.control_file import ControlFile
from nrcan_core.lib.exceptions import *
from nrcan_core.services.abstract_service import AbstractService

# Get the log
from core.lib.logger import get_log
LOG = get_log(config_env.LOG_NAME)


class OwsService(AbstractService):
    """OWS service include WMS, WFS and WCS service that are managed by the CDTK"""

    # Use __slots__ to disable dynamic attribute creation in order to control them at the class level
    __slots__: list[str] = ['raster_datastore_info', 'vector_datastore_info', 'server_id_info', 'qgis_project_info', 'ows_services']


    def __init__(self, operation: str, control_file: ControlFile) -> None:
        """Constructor"""

        AbstractService.__init__(self, operation, control_file)
        self.server_id_info: dict | None = None  # Dictionary containing the server information
        self.raster_datastore_info: dict | None = None  # Dictionary containing the raster dastore information
        self.vector_datastore_info: dict | None = None  # Dictionary containing the vector dastore information
        self.qgis_project_info: dict | None = None  # Dictionary containing the qgis project information
        self.ows_services: list[dict] = [] # The current OWS being unpublished (when operation is Unpublish)


    def is_service_present(self) -> bool:
        """Returns True if an OWS service is present in the control file"""
        LOG.trace_func()

        return self.control_file.has_service_type_ows()


    def on_normalize_control_file(self) -> None:
        """
        Overrides the way the normalization of the control file is done for a OWSService
        """
        LOG.trace_func()

        AbstractService.on_normalize_control_file(self)
        self.control_file.normalize_ows_section()


    def on_validate_service(self, operation: str) -> bool:
        """
        Overrides the way the validation is performed for a OWSService.
        """
        LOG.trace_func()

        # Check if there is something to validate
        if not self.is_service_present():
            # Nothing to validate and let's assume the validation is True
            return True

        # Call parent class for generic validation
        AbstractService.on_validate_service(self, operation)

        # Validate the server ID, use the department default value when not set
        ows_service_parameters: dict = self.control_file.get_ows_service_parameters()
        if self.department_info and ows_service_parameters['server_id'] == "":
            ows_service_parameters['server_id'] = self.department_info['default_ows_server_id'].upper()

        self.server_id_info = self._validate_server_id_exists(ows_service_parameters['server_id'])

        # Validate raster datastore id, use the department default value when not set
        if self.department_info and ows_service_parameters['raster_datastore_id'] == "":
            ows_service_parameters['raster_datastore_id'] = self.department_info['default_raster_datastore_id'].upper()

        self.raster_datastore_info = self._validate_datastore_id_exists(ows_service_parameters['raster_datastore_id'])

        # Validate vector datastore id, use the department default value when not set
        if self.department_info and ows_service_parameters['vector_datastore_id'] == "":
            ows_service_parameters['vector_datastore_id'] = self.department_info['default_vector_datastore_id'].upper()

        # Keep the vector datastore info
        self.vector_datastore_info = self._validate_datastore_id_exists(ows_service_parameters['vector_datastore_id'])

        # NOTE: We need the self.vector_datastore_info attribute for Publish and Unpublish (not just Publish),
        # that's why the validations happen for all operations

        # Depending on the operation
        if operation == "Publish":
            # Validate the service name is not already published
            self._validate_service_name_not_exists()

        elif operation == "Unpublish":
            # Validate that the service names and dataset are related
            self._validate_service_name_dataset_exists()

        elif operation == "Update":
            # No supplemental validation to be done
            pass

        else:
            raise ApplicationException(f"Invalid operation code '{operation}' in OwsService.on_validate_service function")

        # Add a progress mark
        if self.message.if_errors():
            self.message.add_progress("The OWS service is invalid.", "Le service OWS est invalide.")
            is_valid = False
        else:
            self.message.add_progress("The OWS service is valid.", "Le service OWS est valide.")
            is_valid = True

        return is_valid


    def on_validate_server_type(self, server_type: str) -> bool:
        """
        Overrides validation of a server type for the service.
        """
        LOG.trace_func()

        # Return if the server type is valid
        return server_type.split("_")[0] == "OWS"


    def on_process_validation(self, operation: str) -> dict:
        """
        Overrides the processing of the validation of the given operation by the service.
        """
        LOG.trace_func()

        # If not enough information
        if not (self.vector_datastore_info):
            # Invalid call
            raise ApplicationException("Missing information to process service in OWS service in on_process_validation")

        # Execute
        self.qgis_project_info = AbstractService.run_pyqgis("validate", self.control_file.inner_dict, AbstractService.is_datastore_internal(self.vector_datastore_info),
                                                            self.vector_datastore_info['connection_string'], self.message)

        # If results
        if self.qgis_project_info and 'results' in self.qgis_project_info:
            # Return the OWS validate content
            return self.qgis_project_info['results']

        # Nothing
        return {}


    def on_process_service(self, operation: str) -> None:
        """
        Overrides the processing of the given operation by the service.
        """
        LOG.trace_func()

        # If not enough information
        if not (self.vector_datastore_info):
            # Invalid call
            raise ApplicationException("Missing information to process service in OWS service in on_process_service")

        # Depending on the operation
        if operation == "Publish":
            # Flag
            self.publication_started = True

            # Execute
            self.qgis_project_info = AbstractService.run_pyqgis("export_publish", self.control_file.inner_dict, AbstractService.is_datastore_internal(self.vector_datastore_info),
                                                                self.vector_datastore_info['connection_string'], self.message)

            # Unflag
            self.publication_ended = True

            try:
                # Save in registry
                self._save_in_cdtk_registry()
            except Exception as err:
                self.message.add_error_raise("An error has occured when writing in the CDTK Registry",
                                             "Une erreur est survenue lors de l'écriture dans le CDTK Registry",
                                             err)

        elif operation == "Unpublish":
            # Validate that there are no OAPI pointing on it
            # It's possible the OAPI was deleted ealier, in the same input package process, so this check has to be here. Not in validation.
            self._validate_no_oapi_using_it()

            try:
                # Delete from registry
                self._delete_in_cdtk_registry()
            except Exception as err:
                self.message.add_error_raise("An error has occured when deleting in the CDTK Registry",
                                             "Une erreur est survenue lors de la suppresion dans le CDTK Registry",
                                             err)

            # Flag
            self.publication_started = True

            # Execute
            self.qgis_project_info = AbstractService.run_pyqgis("delete_service_and_data", self.control_file.inner_dict, AbstractService.is_datastore_internal(self.vector_datastore_info),
                                                                self.vector_datastore_info['connection_string'], self.message)

            # Unflag
            self.publication_ended = True


    def on_rollback_service(self, operation: str) -> None:
        """
        Overrides the rollback mecanism for an OWS Service.
        """
        LOG.trace_func()

        # If publish operation
        if operation == "Publish":
            # Rollbacking a Publish
            self._rollback_publish()

        else:
            # Can't rollback that operation
            self.message.add_progress(f"No rollback is possible for service '{self.get_service_name()}' and operation '{operation}'.",
                                      f"Aucun rollback de possible pour le service '{self.get_service_name()}' et l'opération '{operation}'.")


    def on_get_html_services_list(self, operation: str) -> tuple[str, str]:
        """
        Overrides the html report which summerizes the list of accessible OWS services.
        """
        LOG.trace_func()

        sp: dict = self.control_file.get_ows_service_parameters()
        ows_service_type: dict = self.control_file.get_ows_service_parameters_ows_service_type()

        # Get the service names
        service_names: list[tuple[str, str]] = [('english', sp['english']['service_name']), ('french', sp['french']['service_name'])]

        # Loop over each service name to build the server list
        services_list_en: str = ""
        services_list_fr: str = ""
        for language, service_name in service_names:
            for service_type in ["WMS", "WCS", "WFS"]:
                if ows_service_type[service_type] == "True":
                    text_html: str = ""
                    if operation in ["Publish", "Update"]:
                        # Get the OWS service
                        ows_service: dict | None = self.cdtk_request.get_ows_service(service_name, service_type)

                        # If found
                        if ows_service:
                            service_url: str = ows_service['service_url']
                            text_html = f"<li>{service_type}: <a href=\'{service_url}'>{service_url}</a></li>"

                        else:
                            # Not found
                            text_html = f"<li>{service_type}: {service_name}: <i>Error reading the service URL / Erreur lors de la lecture du service URL</i></li>"

                    else:
                        # Unpublish service
                        text_html = f"<li>{service_type}: {service_name}</li>"

                    if language == 'english':
                        services_list_en = services_list_en + text_html

                    else:
                        services_list_fr = services_list_fr + text_html

        html_content_en: str = ""
        html_content_fr: str = ""
        if operation == 'Publish':
            html_content_en = html_content_en + "Your publication request for OWS services proceeded successfully.<br/><br/>"
            html_content_fr = html_content_fr + "Votre requête de publication de services OWS a été exécutée avec succès.<br/><br/>"
            html_content_en = html_content_en + f"Here are the links of the published OWS services:<ul>{services_list_en}</ul><br/>"
            html_content_fr = html_content_fr + f"Voici les liens des services OWS publiés:<ul>{services_list_fr}</ul>"

        elif operation == 'Update':
            html_content_en = html_content_en + "Your update request for OWS services proceeded successfully.<br/><br/>"
            html_content_fr = html_content_fr + "Votre requête de mise-à-jour de services OWS a été exécutée avec succès.<br/><br/>"
            html_content_en = html_content_en + f"Voici les liens des services OWS mis-à-jour:<ul>{services_list_en}</ul>"
            html_content_fr = html_content_fr + f"Here are the links of the updated OWS services:<ul>{services_list_fr}</ul><br/>"

        else:
            html_content_en = html_content_en + "Your unpublication request for OWS services proceeded successfully.<br/><br/>"
            html_content_fr = html_content_fr + "Votre requête de dépublication de services OWS a été exécutée avec succès.<br/><br/>"
            html_content_en = html_content_en + f"Here are the unpublished services:<ul>{services_list_en}</ul><br/>"
            html_content_fr = html_content_fr + f"Voici les services dépubliés:<ul>{services_list_fr}</ul>"

        return (html_content_en, html_content_fr)


    def _save_in_cdtk_registry(self) -> None:
        """
        Saves the service in the CDTK Registry
        """
        LOG.trace_func()

        def _set_datasources() -> None:

            # If not enough information
            if not (self.qgis_project_info):
                # Invalid call
                raise ApplicationException("Missing information to set datasources in _set_datasources in _save_in_cdtk_registry")

            # Get the layers
            qgis_project_layers: list[dict] = self.qgis_project_info['results'][0]['layers']

            # For each layer
            for qgis_project_layer in qgis_project_layers:
                datasource: dict = {}
                add_it = True

                # If coverage type
                if qgis_project_layer['type'] == 'raster':
                    # If not enough information
                    if not (self.raster_datastore_info):
                        # Invalid call
                        raise ApplicationException("Missing information to set datasources for coverage type in _set_datasources in _save_in_cdtk_registry")

                    # Set data from the datacube
                    address: str = qgis_project_layer['uri']['path']  # Extract the address of the datacube address
                    parts: list[str] = address.split('/')  # Split the parts

                    path: str = '/'.join(parts[:-1])  # Reconstruct the path
                    if len(parts) > 0:
                        # If the datasource starts with http, it's an url
                        if parts[0].startswith('http'):
                            # We skip the hostname and get the remainder of the path except the very last part
                            path = '/'.join(parts[3:-1])

                    name: str =  parts[-1]  # Extract the name
                    datasource['name'] = name
                    datasource['path'] = path
                    datasource['datastore_id'] = self.raster_datastore_info['datastore_id']

                else:
                    # If not enough information
                    if not (self.vector_datastore_info):
                        # Invalid call
                        raise ApplicationException("Missing information to set datasources for vector type in _set_datasources in _save_in_cdtk_registry")

                    # Set data from the Postgres database
                    datasource['name'] = qgis_project_layer['name_table']  # At this point, the name_table is pointing to the database
                    datasource['path'] = self.control_file.get_department()
                    datasource['datastore_id'] = self.vector_datastore_info['datastore_id']

                    # If there's already a datasource for that layer source (now many layers can point to the same source), skip it
                    if datasource['name'] in list(ds['name'] for ds in datasources):
                        add_it = False

                # If adding it
                if add_it:
                    # Add the datasource
                    datasources.append(datasource)

        # Keep track
        self.message.add_progress("Saving OWS services in CDTK Registry.",
                                  "Sauvegarde des services OWS dans le Registre CDTK.")

        # If not enough information
        if not (self.server_id_info and self.dataset_id):
            # Invalid call
            raise ApplicationException("Missing information to save in CDTK Registry in _save_in_cdtk_registry")

        # Flag
        self.registry_started = True

        datasources: list[dict] = []
        ows_services: list[str] = []

        # Keep track
        self.message.add_progress_detail(f"Registry API: '{config_env.CDTK_REGISTRY_URL}'",
                                         f"API du Registre: '{config_env.CDTK_REGISTRY_URL}'")
        self.message.add_progress_detail(f"Department: '{self.control_file.get_department()}'",
                                         f"Département: '{self.control_file.get_department()}'")
        self.message.add_progress_detail(f"Dataset Name: '{self.control_file.get_dataset_name()}'",
                                         f"Nom du Dataset: '{self.control_file.get_dataset_name()}'")
        self.message.add_progress_detail(f"Metadata UUID: '{self.control_file.get_metadata_uuid()}'",
                                         f"Metadata UUID: '{self.control_file.get_metadata_uuid()}'")

        # If the dataset must be created
        if self.dataset_id == "CREATE_IT":
            # Save the dataset in the CDTK registry
            dataset_info: dict = self.cdtk_request.put_dataset(self.control_file.get_dataset_name(), self.control_file.get_department(), self.control_file.get_metadata_uuid())

            # Only 201 stustus code is returned
            self.dataset_id = dataset_info['dataset_id']

        # Keep track
        self.message.add_progress_detail(f"Server ID: '{self.server_id_info['server_id']}'",
                                         f"Serveur ID: '{self.server_id_info['server_id']}'")
        self.message.add_progress_detail(f"Dataset ID: '{self.dataset_id}'",
                                         f"Dataset ID: '{self.dataset_id}'")

        # Save each datasource in the CDTK registry
        _set_datasources()
        for datasource in datasources:
            # Save in the datasource registry
            datasource_info: dict = self.cdtk_request.put_datasource(datasource['datastore_id'], datasource['name'], datasource['path'])

            # Only status code 201 is returned
            # Get the datasource_id
            datasource_id: str = datasource_info['datasource_id']

            # Keep the datasource_id for the next operation
            datasource[datasource['name']] = datasource_id

        # Create the list of OWS services to publish
        for ows_service in ["WMS", "WFS", "WCS"]:
            if self.control_file.get_ows_service_parameters_ows_service_type()[ows_service] == "True":
                ows_services.append(ows_service)

        # Process separatly each ows service
        for ows_service in ows_services:
            # Save a data_publication in the cdtk registry
            # Note: Casting the dataset_id to str, because it'll be defined, not None by this point. Saving a warning.
            data_pub_info: dict = self.cdtk_request.put_data_publication('OWS',
                                                                         self.server_id_info['server_id'],
                                                                         str(self.dataset_id),
                                                                         self.control_file.get_email())

            # Only status code 201 is returned
            data_publication_id: str = data_pub_info['data_publication_id']

            # Keep track
            self.message.add_progress_detail(f"Data Publication ID: '{data_publication_id}'",
                                             f"Data Publication ID: '{data_publication_id}'")

            sp: dict = self.control_file.get_ows_service_parameters()
            for datasource in datasources:
                for language in ["english", "french"]:
                    # Save the OWS published data in the cdtk registry
                    self.cdtk_request.put_ows_service(sp[language]['service_name'], ows_service,
                                                      data_publication_id, datasource[datasource['name']],
                                                      sp[language]['project_filename'], language)

        # Flag
        self.registry_ended = True


    def _delete_in_cdtk_registry(self) -> None:
        """
        Deletes the service from the CDTK Registry
        """
        LOG.trace_func()

        # Keep track
        self.message.add_progress("Deleting OWS services in CDTK Registry.",
                                  "Destruction des services OWS dans le Registre CDTK.")

        try:
            # Delete the French and English services.
            # NOTE: The French service name gets deleted automatically by deleting the English one. That code is handled in cdtk_delete_ows_service stored procedure in the Registry DB.
            # The delete takes care of cleaning the following tables: datasource, ows_service, data_publication and dataset
            service_name: str = self.control_file.get_ows_service_parameters_english_service_name()

            # Delete the French and English services.
            deleted: bool = self.cdtk_request.delete_ows_service(service_name)

            # If failed to save in the registry
            if not deleted:
                self.message.add_error_raise(f"Failed to delete the OSW service '{service_name}' in the CDTK Registry.",
                                             f"Erreur lors de la destruction du service OWS '{service_name}' dans le Registre CDTK.")

            return

        except Exception as err:
            # Keep track
            self.message.add_progress("Failed deleting in CDTK Registry, no reverting.",
                                      "Échec lors de la destruction dans le Registre CDTK, pas de retour arrière.")

            # Keep raising err
            raise err


    def _rollback_publish(self) -> None:
        """
        Rollbacks a publish operation
        """
        LOG.trace_func()

        # If flagged
        if self.publication_started:
            cdtk_type = "CDTK Publication"
            if self.publication_ended:
                # If not enough information
                if not (self.vector_datastore_info):
                    # Invalid call
                    raise ApplicationException("Missing information to rollback in OWS service in _rollback_publish")

                # Can safely start the rollback
                try:
                    self.message.add_progress(f"Rollback started for '{cdtk_type}'.", f"Retour en arrière démarré pour le '{cdtk_type}'.")
                    self.qgis_project_info = AbstractService.run_pyqgis("delete_service_and_data", self.control_file.inner_dict,
                                                                        AbstractService.is_datastore_internal(self.vector_datastore_info),
                                                                        self.vector_datastore_info['connection_string'], self.message)
                    self.message.add_progress(f"Rollback terminated for '{cdtk_type}'.", f"Retour en arrière terminé pour le '{cdtk_type}'.")
                except Exception:
                    self.message.add_progress(f"Rollback error for '{cdtk_type}'. Manual operation will have to take place",
                                              f"Retour en arrière en erreur pour le '{cdtk_type}'. Des mesures manuelles devront être prises")

            else:
                # Cannot start safely the rollback process
                self.message.add_progress(f"The publication in the '{cdtk_type}' failed in the middle of the process.",
                                          f"La publication dans le '{cdtk_type}' a arrêtée avant la fin.")
                self.message.add_progress(f"It is impossible to rollback. Manual operation will have to take place in the '{cdtk_type}'",
                                          f"Il est imposssible de faire un retour en arrière. Des mesures manuelles devront être prises dans le '{cdtk_type}'.")

        if self.registry_started:
            cdtk_type = "CDTK Registry"
            if self.registry_ended:
                # Can safely start the rollback of the CDTK Registry
                try:
                    self.message.add_progress(f"Rollback started for '{cdtk_type}'.", f"Retour en arrière démarré pour le '{cdtk_type}'.")
                    self._delete_in_cdtk_registry()
                    self.message.add_progress(f"Rollback terminated for '{cdtk_type}'.", f"Retour en arrière terminé pour le '{cdtk_type}'.")

                except Exception:
                    self.message.add_progress(f"Rollback error for '{cdtk_type}'. Manual operation will have to take place",
                                              f"Retour en arrière en erreur pour le '{cdtk_type}'. Des mesures manuelles devront être prises")
            else:
                # Cannot start safely the rollback process
                self.message.add_progress(f"The publication in the '{cdtk_type}' failed in the middle of the process.",
                                          f"La publication dans le '{cdtk_type}' a arrêtée avant la fin.")
                self.message.add_progress(f"It is impossible to rollback. Manual operation will have to take place in the '{cdtk_type}'",
                                          f"Il est imposssible de faire un retour en arrière. Des mesures manuelles devront être prises dans le '{cdtk_type}'.")


    def _validate_service_name_dataset_exists(self) -> None:
        """
        Validates the following information and raise errors if not
            - Both service name exists
            - Both service name have the same publication id
            - The publication id is link to the dataset id in the control file
        """
        LOG.trace_func()

        service_name_en: str = self.control_file.get_ows_service_parameters_english_service_name()
        service_name_fr: str = self.control_file.get_ows_service_parameters_french_service_name()
        publication_ids: list[str] = []

        # For both service names (en/fr)
        for service_name in [service_name_en, service_name_fr]:
            # Get the OWS services
            ows_services: list[dict] = self.cdtk_request.get_ows_services(service_name)

            # If found
            if len(ows_services) > 0:
                self.ows_services.extend(ows_services)
                publication_ids.append(ows_services[0]['data_publication_id'])

            else:
                self.message.add_error(f"The service name '{service_name}' is not published in the CDTK Registry",
                                       f"Le service nommé '{service_name}' n'est pas publié dans le registre du CDTK")

        # Validate that each data publication have an entry in data_publication table
        for publication_id in publication_ids:
            # Get the data publication info
            data_publication_info: dict | None = self.cdtk_request.get_data_publication(publication_id)

            # If found
            if data_publication_info:
                target_dataset_id: str = data_publication_info['dataset_id']

                # Validate that the dataset ID is the same as the one in the control file
                if target_dataset_id != self.dataset_id:
                    self.message.add_error(f"The service name to delete '{service_name_en}' is not linked to the metadata uuid in the control file.",
                                           f"Le service nommé à détruire '{service_name_en}' n'est pas lié à la métadonnée_uuid dans le fichier de contrôle.")

            else:
                # Not found
                self.message.add_error(f"Unable to find Data Publication ID '{publication_ids[0]}'",
                                       f"Data Publication ID '{publication_ids[0]}' introuvable")

        return


    def _validate_no_oapi_using_it(self) -> None:
        """Validates that there are no OAPI services using the OWS data"""
        LOG.trace_func()

        # Get the unique list of OWS being processed (ows can have duplicates in the table..)
        ows_services = list({ows['service_name'].lower(): ows for ows in self.ows_services}.values())

        # Get the OAPIM services that we have
        oapim_services: list[dict] = self.cdtk_request.get_oapi_services('OAPIM')

        # For each OWS url (filtered by service_name) being unpublished
        for ows_service in ows_services:
            # For each OAPIM service that we have
            for oapim in oapim_services:
                # If map_wmsfacade
                if 'provider_map_wmsfacade' in oapim and 'data' in oapim['provider_map_wmsfacade']:
                    # Get the OWS url
                    ows_url: str = ows_service['service_url'].lower().split('?')[0]

                    # Get the OAPIM url
                    oapim_url: str = oapim['provider_map_wmsfacade']['data'].lower().split('?')[0]

                    # If the service url is the same
                    if ows_url == oapim_url:
                        # OWS service is using the OAPI, can't remove
                        self.message.add_error(f"The OWS service '{ows_service['service_name']}' is used by the OAPIM '{oapim['collection_id']}' for the url '{ows_url}'",
                                               f"Le service OWS '{ows_service['service_name']}' est utilisé par l'OAPIM '{oapim['collection_id']}' pour l'adresse '{ows_url}'")


        # Get the OAPIF services that we have
        oapif_services: list[dict] = self.cdtk_request.get_oapi_services('OAPIF')

        # For each OWS (unfiletered by service_name) being unpublished
        for ows_service in self.ows_services:
            # For each OAPIF service that we have
            for oapif in oapif_services:
                # Get the datasource id
                datasource_id = oapif['datasource_id']

                # If the datasource_id of the OWS we want to unpublish is the same, that means we must keep the data when unpublish the OWS layer
                if ows_service['datasource_id'] == datasource_id:
                    # Keep track of the data table to keep
                    self.control_file.add_oapif_data_table_to_keep(oapif['provider_feature_postgres']['data_table'])

        # If any error, raise
        self.message.if_errors_raise()
        return


    def _validate_service_name_not_exists(self) -> None:
        """Validates that the service names are not published as OWS services"""
        LOG.trace_func()

        service_name_en: str = self.control_file.get_ows_service_parameters_english_service_name()
        service_name_fr: str = self.control_file.get_ows_service_parameters_french_service_name()

        # Loop on both service names
        for service_name in [service_name_en, service_name_fr]:
            self._validate_service_name_not_exists_check(service_name)


    def _validate_service_name_not_exists_check(self, service_name: str) -> None:
        """Validates that the service name are not published as OWS services"""
        LOG.trace_func()

        # If the service name exists
        if self.check_service_name_exists(service_name):
            # Service name already published
            self.message.add_error(f"The service name '{service_name}' is already published in the CDTK Registry.",
                                   f"Le service nommé '{service_name}' est déjà publié dans le registre du CDTK.")


    def check_service_name_exists(self, service_name: str) -> bool:
        """Queries the CDTK Registry to check if the service name exists"""
        LOG.trace_func()

        # Get the OWS services
        ows_services: list[dict] = self.cdtk_request.get_ows_services(service_name)

        # True if service name exists
        return len(ows_services) > 0
