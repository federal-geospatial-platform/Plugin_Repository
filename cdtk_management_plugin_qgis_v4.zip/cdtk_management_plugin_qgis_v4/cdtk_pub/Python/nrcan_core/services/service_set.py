from nrcan_core.lib.control_file import ControlFile
from nrcan_core.services.abstract_service import AbstractService
from nrcan_core.services.ows_service import OwsService
from nrcan_core.services.download_service import DownloadService
from nrcan_core.services.oapi_service import OapiService


class ServicesSet():
    # Use __slots__ to disable dynamic attribute creation in order to control them at the class level
    __slots__: list[str] = ['control_file', 'ows_service', 'download_service', 'oapi_service', 'services']

    def __init__(self) -> None :
        self.control_file: ControlFile | None = None
        self.ows_service: OwsService | None = None
        self.download_service: DownloadService | None = None
        self.oapi_service: OapiService | None = None
        self.services: list[AbstractService] = []
