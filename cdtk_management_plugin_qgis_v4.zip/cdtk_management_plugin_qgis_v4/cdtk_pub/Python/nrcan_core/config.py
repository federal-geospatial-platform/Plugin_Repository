"""
This module stores all configurations used by this application.
"""

import os
import getpass
# CDTK NOTE IN PLUGIN THIS HAS TO BE RELATIVE ..nrcan_core #
from nrcan_core import config_env

# Security token variables
TOKEN_COOKIE_NAME = "api_pub_token"
TOKEN_EXP_MINUTES: int = 480
TOKEN_REFRESH_EXP_MINUTES: int = 1440

SYS_DOWNLOAD_ROOTS: list[str] = ['.filelisting.html']
SYS_TABLES: list[str] = ['qgis_projects']

# Process to import data
DATA_IMPORT_PROCESS = 'gdal' # Can be 'ogr2ogr' or 'gdal'

# The primary key used for the imported data
DB_PRIMARY_KEY_FIELD: str = "pk_lyr_id"
DB_GEOM_FIELD: str = "geom"

# Microsoft OAuth
TENANT_ID: str = "05c95b33-90ca-49d5-b644-288b930b912b"
AUTHORITY: str = f"https://login.microsoftonline.com/{TENANT_ID}"
SCOPES: list[str] = ['openid', 'profile', 'email']

# Maximum number of parallel workers to work with QGIS
MAX_WORKERS: int = 5

# Roles
ROLE_LEVEL_ADMIN: int = 100
ROLE_LEVEL_PUBLISHER: int = 2
ROLE_LEVEL_USER: int = 1
ROLES: dict[str, int] = {
    'ADMIN': ROLE_LEVEL_ADMIN,
    'PUBLISHER': ROLE_LEVEL_PUBLISHER,
    'USER': ROLE_LEVEL_USER
}

DB_TABLE_USERS: dict[str, str] = {
    'TABLE_NAME': "users",
    'FIELD_ID': "id",
    'FIELD_EMAIL': "email",
    'FIELD_ROLE': "role"
}

DB_TABLE_TOKEN_BLACKLIST: dict[str, str] = {
    'TABLE_NAME': "users_token_blacklist",
    'FIELD_ID': "id",
    'FIELD_JTI_UID': "jti_uid",
    'FIELD_EXP_DATE': "exp_date"
}

def QGIS_JOBS_PATH(filename: str) -> str:
    if filename and len(filename) > 0:
        return os.path.join(config_env.QGIS_JOBS_PATH, filename)
    return config_env.QGIS_JOBS_PATH


def QGIS_PROJECTS_PATH(filename: str) -> str:
    if filename and len(filename) > 0:
        return os.path.join(config_env.QGIS_PROJECTS_PATH, filename)
    return config_env.QGIS_PROJECTS_PATH


def QGIS_IN_PACKAGES_PATH(filename: str) -> str:
    if filename and len(filename) > 0:
        return os.path.join(config_env.QGIS_IN_PACKAGES_PATH, filename)
    return config_env.QGIS_IN_PACKAGES_PATH


def QGIS_PYTHON_PATH(filename: str) -> str:
    return os.path.join(config_env.QGIS_PYTHON_PATH, filename)


def EMAIL_USER(email: str) -> str:
    if config_env.IS_LOCAL:
        # Build the email address with the local user name
        user_name = getpass.getuser()
        return f"{user_name}@nrcan-rncan.gc.ca"
    return email
