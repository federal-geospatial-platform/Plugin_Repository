# Python imports
import traceback
from werkzeug.datastructures import FileStorage
import re, requests

# Application modules import
from nrcan_core import config_env, secret, util
from core.lib.qgis_progress_marks import *
from core.lib.qgis_exceptions import *
from core.lib.qgis_warnings import *
from nrcan_core.lib import cdtk_email
from nrcan_core.lib.cdtk_message import CDTKMessage
from nrcan_core.lib.control_file import ControlFile
from nrcan_core.lib.zip_file import ZipFile
from nrcan_core.lib.exceptions import *
from nrcan_core.requests.cdtk_request_registry_api import CDTKRequestRegistryAPI
from nrcan_core.services.service_set import ServicesSet
from nrcan_core.services.abstract_service import AbstractService
from nrcan_core.services.download_service import DownloadService
from nrcan_core.services.oapi_service import OapiService
from nrcan_core.services.ows_service import OwsService

# Get the log
from core.lib.logger import get_log
LOG = get_log(config_env.LOG_NAME)


def get_version() -> dict:
    """
    Fetches the QGIS Version used by the Publication API
    """
    LOG.trace_func()

    # Run PyQGIS to read and compare the project file
    pyqgis_version = AbstractService.run_pyqgis("version", {}, True, config_env.DB_QGIS_KEY, None)

    # Get the versions
    return pyqgis_version

def get_qgis_server_version() -> str:
    """
    Fetches the QGIS Server Version
    """
    LOG.trace_func()

    try:
        get_version_url = config_env.CDTK_QGIS_SERVER_GET_VERSION_URL
        # Perform a HEAD request to only fetch headers
        response = requests.head(get_version_url)
        server_header = response.headers.get('Server', '')

        # Regex pattern to extract the QGIS Server version string
        match = re.search(r'QGIS version ([\d\.]+-[\w\d]+)', server_header)
        if match:
            return match.group(1)
        else:
            return "Unknown"
    except requests.RequestException as e:
        print(f"HTTP request failed: {e}")
        return "Unknown"

def info_schema(schema: str) -> dict:
    """
    Gets the service names published under the given schema
    """
    LOG.trace_func()

    # Start the messager
    message = CDTKMessage()

    # Run PyQGIS to read and validate the project file
    res = AbstractService.run_pyqgis("info_schema", {'schema': schema.lower()}, True, config_env.DB_QGIS_KEY, message)

    # If only 1 exception and it's a SchemaNotFound
    if len(message.errors) == 1 and isinstance(message.errors[0], SchemaNotFound):
        raise NotFoundException()

    # If any errors, raise
    message.if_errors_raise()

    # Return the result
    return res


def info_service(schema: str, service_name: str) -> dict:
    """
    Gets the information on a particular service
    """
    LOG.trace_func()

    # Start the messager
    message = CDTKMessage()

    # Run PyQGIS to read and validate the project file
    res = AbstractService.run_pyqgis("info_service", {'schema': schema.lower(), 'service_name': service_name}, True, config_env.DB_QGIS_KEY, message)

    # If only 1 exception and it's a ProjectNotFound
    if len(message.errors) == 1 and isinstance(message.errors[0], ProjectNotFoundFromDatabase):
        raise NotFoundException()

    # If any errors, raise
    message.if_errors_raise()

    # Return the result
    return res


def delete_service(schema: str, service_name: str) -> dict:
    """
    Deletes a particular service
    """
    LOG.trace_func()

    # Start the messager
    message = CDTKMessage()

    # Run PyQGIS to read and validate the project file
    res = AbstractService.run_pyqgis("delete_service", {'schema': schema.lower(), 'service_name': service_name}, True, config_env.DB_QGIS_KEY, message)

    # If only 1 exception and it's a ProjectNotFound
    if len(message.errors) == 1 and isinstance(message.errors[0], ProjectNotFoundFromDatabase):
        raise NotFoundException()

    # If any errors, raise
    message.if_errors_raise()

    # Return the result
    return res


def validate_publication(operation: str, zip_file_io: FileStorage) -> dict:
    """
    Manages a validation operation
    """
    LOG.trace_func()

    # START of the validation management
    # Instantiate the message class
    message = CDTKMessage()
    zip_res: ZipFile | None = None

    # The services set
    services_set: ServicesSet = ServicesSet()

    # The validation information
    val_info: dict[str, dict | None] = {}

    try:
        try:
            # Log
            LOG.info(f"Publication validation called: '{operation}'")

            # Keep track
            message.add_progress("Service started for 'validate_project'",
                                 "Service démarré pour 'validate_project'")

            # Load the zip file
            zip_res = ZipFile(zip_file_io, message)

            # Validate the zip file and prepare the services
            _validate_zip_file_prepare_services(operation, zip_res, services_set, message)

            # Validate each service
            for service in services_set.services:
                service.validate_service()

            # Raise an error if the validation of one of the services failed
            message.if_errors_raise()

            # Log
            LOG.info("Publication services validated")

            # If all services are valid process the requested operation for each service
            for service in services_set.services:
                # Process the service as speciied in the control file
                res: dict | None = service.process_validation()

                # Compile
                val_info[service.get_service_name()] = res

                # Raise an error if an error was found
                service.message.if_errors_raise()

            # Log
            LOG.info("Publication completed")

            # Keep track
            message.add_progress(f"Done {operation}!", f"Terminé {operation}!")

            # Done
            return val_info

        except Exception as err:
            # Log
            LOG.error(f"Validation crashed {err}\n{traceback.format_exc()}")

            # Extract the detail of the error
            message.set_stack(traceback.format_exc())

            # If a UserMessageException
            if isinstance(err, UserMessageException):
                # If has an internal error
                if err.internal_error is not None:
                    message.set_big_error(err.internal_error)
            else:
                # Internal error. Not a UserMessage one.
                message.set_big_error(err)

            # There was a major error call the rollback of each service
            for service in services_set.services:
                service.rollback_service()

            # Keep raising
            raise

    finally:
        # Print out the progress and errors if any
        _print_out(message)

        if zip_res:
            # Clean up
            zip_res.clean_up_directory()


def manage_publication(operation: str, zip_file_io: FileStorage, send_email: bool = True) -> bool:
    """
    Manages a publication operation
    """
    LOG.trace_func()


    def _set_datasource_id() -> None:
        """
        Assigns the source dataset_id to all target_services
        """
        LOG.trace_func()

        if services_set.ows_service and services_set.ows_service.is_service_present():
            # The source service is present assign the dataset id
            for service in [services_set.download_service, services_set.oapi_service]:
                if service:
                    service.dataset_id = services_set.ows_service.dataset_id

        elif services_set.download_service and services_set.download_service.is_service_present():
            if services_set.oapi_service:
                services_set.oapi_service.dataset_id = services_set.download_service.dataset_id


    # In local we don't send email anymore, because of network issues
    if config_env.IS_LOCAL:
        send_email = False

    # START of the publication management
    # Instantiate the message class
    message = CDTKMessage()
    zip_res: ZipFile | None = None

    # The services set
    services_set: ServicesSet = ServicesSet()

    # Init variables
    html_services: dict[str, str] = {}
    html_services['english'] = ""  # List of services in English
    html_services['french'] = ""  # List of services in French

    try:
        try:
            # Log
            LOG.info(f"Publication operation '{operation}' started.")

            # Keep track
            message.add_progress("Service started for 'manage_publication'",
                                 "Service démarré pour 'manage_publication'")

            # Load the zip file
            zip_res = ZipFile(zip_file_io, message)

            # Validate the zip file and prepare the services
            _validate_zip_file_prepare_services(operation, zip_res, services_set, message)

            # Validate each service
            for service in services_set.services:
                service.validate_service()

            # Raise an error if the validation of one of the services failed
            message.if_errors_raise()

            # Log
            LOG.info("Publication services validated.")

            # If all services are valid process the requested operation for each service
            for service in services_set.services:
                # Process the service as speciied in the control file
                service.process_service()

                # Raise an error if an error was found
                service.message.if_errors_raise()

                # Build the html answer
                [html_service_en, html_service_fr] = service.get_html_services_list()
                html_services['english'] += html_service_en
                html_services['french'] += html_service_fr

                # Reset datasource_id if needed
                _set_datasource_id()

            # Log
            LOG.info(f"Publication operation '{operation}' completed.")

            # Keep track
            message.add_progress(f"Done {operation}!", f"Terminé {operation}!")

            # Done
            return True

        except Exception as err:
            # Log
            LOG.error(f"Publication operation '{operation}' crashed {err}\n{traceback.format_exc()}.")

            # Extract the detail of the error
            message.set_stack(traceback.format_exc())

            # If a UserMessageException
            if isinstance(err, UserMessageException):
                # If has an internal error
                if err.internal_error is not None:
                    message.set_big_error(err.internal_error)
            else:
                # Internal error. Not a UserMessage one.
                message.set_big_error(err)

            # There was a major error call the rollback of each service
            for service in services_set.services:
                service.rollback_service()

            # Keep raising
            raise

    finally:
        # Print out the progress and errors if any
        _print_out(message)

        if zip_res:
            # Clean up
            zip_res.clean_up_directory()

        # If sending email (default mode)
        if send_email and services_set.control_file:
            # Send emails
            cdtk_email.send_emails(operation, secret.get_secret_email_config(),
                                   services_set.control_file.get_email(), _get_publisher_name(services_set, message), message, html_services)


def _get_publisher_name(services_set: ServicesSet, message: CDTKMessage) -> str:
    """
    Gets the publisher name by finding the first not None publisher name.
    If all the publisher name are None return None
    """
    LOG.trace_func()

    p_name: str = "Unknown"
    if services_set.ows_service:
        p_name = services_set.ows_service.get_publisher_name_or_email()
    elif services_set.oapi_service:
        p_name = services_set.oapi_service.get_publisher_name_or_email()
    elif services_set.download_service:
        p_name = services_set.download_service.get_publisher_name_or_email()
    elif services_set.control_file:
        cdtk_request = CDTKRequestRegistryAPI(secret.get_secret_api_registry_api_key(), message)
        publisher: dict | None = cdtk_request.get_publisher(services_set.control_file.get_email())
        if publisher:
            p_name = publisher['name']
    return p_name


def _validate_zip_file_prepare_services(operation: str, zip_res: ZipFile, services_set: ServicesSet, message: CDTKMessage) -> None:
    # The services to be returned
    services: list[AbstractService] = []

    # Load the control file
    services_set.control_file = ControlFile(zip_res.control_file_str, message)

    try:
        # Initialize the control file by reading the content as JSON
        services_set.control_file.init()
    except Exception:
        # Raise invalid format exception
        raise ControlFileInvalidFormatException()

    # Raise an error if an error was set during control file validation
    message.if_errors_raise()

    # Validate the control file content
    valid: bool = services_set.control_file.validate_content()

    # Instantiate the services and add to the list
    services_set.ows_service = OwsService(operation, services_set.control_file)
    services_set.download_service = DownloadService(operation, services_set.control_file)
    services_set.oapi_service = OapiService(operation, services_set.control_file)

    # If unpublishing, we want to add the service in reverse order
    if operation == "Unpublish":
        # Reverse order, OAPI, DOWNLOAD, OWS
        services.extend([services_set.oapi_service, services_set.download_service, services_set.ows_service])

    else:
        # Regular order, OWS, DOWNLOAD, OAPI
        services.extend([services_set.ows_service, services_set.download_service, services_set.oapi_service])
    services_set.services = services

    # Raise an error if an error was set during control file validation
    message.if_errors_raise()


def _print_out(message: CDTKMessage) -> None:
    """
    Prints out what has happened.
    """
    LOG.trace_func()

    # Read the progress marks
    [english, french] = util.combine_progress_marks_for_response(message.progress_marks)

    # Get the user error message if any
    user_error: UserMessageException | None = message.get_user_message()

    print()
    print()
    print("---------------------- PRINT OUT ----------------------")
    print()
    if message.big_error and not user_error:
        print("Here's the big error:")
        print(str(message.big_error))
        print()
        print("----------------------")
        print()

    if user_error:
        print("Here's the error message sent to the user:")
        print(user_error.message)
        print()

    print("Here's what's happened:")
    print(english)
    print()
    print("----------------------")
    print()
    if user_error:
        print("Voici le message d'erreur envoyé à l'utilisateur:")
        print(user_error.message_fr)
        print()

    print("Voici ce qui est arrivé:")
    print(french)
    print()
