.. CDTK Publish API documentation master file, created by
   sphinx-quickstart on Mon Jan 31 11:12:34 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to CDTK Publish WEB's documentation!
=============================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   main
   routes
   nrcan_core
   modules



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
