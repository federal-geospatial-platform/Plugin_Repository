routes package
==============

Submodules
----------

routes.rt\_web module
---------------------

.. automodule:: routes.rt_web
   :members:
   :undoc-members:
   :show-inheritance:

routes.rt\_web\_admin module
----------------------------

.. automodule:: routes.rt_web_admin
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: routes
   :members:
   :undoc-members:
   :show-inheritance:
