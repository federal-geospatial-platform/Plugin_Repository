nrcan_core package
============

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   nrcan_core.db
   nrcan_core.lib
   nrcan_core.routes
   nrcan_core.ldap

Submodules
----------

nrcan_core.auth module
----------------

.. automodule:: nrcan_core.auth
   :members:
   :undoc-members:
   :show-inheritance:

nrcan_core.config module
------------------

.. automodule:: nrcan_core.config
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: nrcan_core
   :members:
   :undoc-members:
   :show-inheritance:
