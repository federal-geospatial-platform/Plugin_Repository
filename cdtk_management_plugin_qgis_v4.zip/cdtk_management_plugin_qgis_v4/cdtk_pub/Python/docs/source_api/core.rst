core package
============

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   core.db
   core.lib
   core.routes
   core.ldap

Submodules
----------

core.auth module
----------------

.. automodule:: core.auth
   :members:
   :undoc-members:
   :show-inheritance:

core.config module
------------------

.. automodule:: core.config
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: core
   :members:
   :undoc-members:
   :show-inheritance:
