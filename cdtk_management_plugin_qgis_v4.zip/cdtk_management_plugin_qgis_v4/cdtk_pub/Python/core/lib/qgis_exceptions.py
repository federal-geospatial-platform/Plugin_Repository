"""
This module offers application exceptions.
"""

from __future__ import annotations
import json, importlib
from typing import Any


class QGISAggregationException(Exception):
    """Exception raised when multiple exceptions happened in a process."""
    def __init__(self, ex_list: list) -> None:
        super(Exception, self)
        self.exceptions: list = ex_list

    def __str__(self) -> str:
        return json.dumps(QGISApplicationException.list_ex_as_list_dict(self.exceptions))


class QGISApplicationException(Exception):
    """Base class for Exceptions for the QGIS Framework"""

    def as_dict(self) -> dict[str, Any]:
        raise QGISApplicationException(f"as_dict() is not implemented for this exception {type(self)}")

    @staticmethod
    def list_ex_as_list_dict(ex_list: list) -> list[dict[str, Any]]:
        if ex_list and len(ex_list):
            return [QGISApplicationException.serialize(e) for e in ex_list]
        return []

    @staticmethod
    def list_dict_as_list_ex(ex_list: list) -> list[Any]:
        if ex_list and len(ex_list):
            return [QGISApplicationException.deserialize(e) for e in ex_list]
        return []

    @staticmethod
    def serialize(ex) -> dict[str, Any]:
        return {'type': type(ex).__name__, 'exception': ex.as_dict()}

    @staticmethod
    def deserialize(ex: dict) -> Any:
        the_exception_class = getattr(importlib.import_module("core.lib.qgis_exceptions"), ex['type'])
        return the_exception_class.from_dict(ex['exception'])


class ApplicationGenericException(QGISApplicationException):
    """Generic application exception."""
    def __init__(self, message: str) -> None:
        super(QGISApplicationException, self)
        self.message: str = message

    def as_dict(self) -> dict[str, str]:
        return {'message': self.message}

    @staticmethod
    def from_dict(ex_dict: dict) -> ApplicationGenericException:
        return ApplicationGenericException(ex_dict['message'])

    def __str__(self) -> str:
        return f"{self.message}'"


class DatabaseNotInitialized(QGISApplicationException):
    """Exception raised when project hasn't been initialized."""
    def __init__(self, function_name: str) -> None:
        super(QGISApplicationException, self)
        self.function_name: str = function_name

    def as_dict(self) -> dict[str, str]:
        return {'function_name': self.function_name}

    @staticmethod
    def from_dict(ex_dict: dict) -> DatabaseNotInitialized:
        return DatabaseNotInitialized(ex_dict['function_name'])

    def __str__(self) -> str:
        return f"The Database hasn't been initialized prior to calling '{self.function_name}'"


class ProjectNotInitialized(QGISApplicationException):
    """Exception raised when project hasn't been initialized."""
    def __init__(self, function_name: str) -> None:
        super(QGISApplicationException, self)
        self.function_name: str = function_name

    def as_dict(self) -> dict[str, str]:
        return {'function_name': self.function_name}

    @staticmethod
    def from_dict(ex_dict: dict) -> ProjectNotInitialized:
        return ProjectNotInitialized(ex_dict['function_name'])

    def __str__(self) -> str:
        return f"The Project hasn't been initialized prior to calling '{self.function_name}'"


class ProjectUsingSameLayerNameDifferentGeopackages(QGISApplicationException):
    """Exception raised when project hasn't been initialized."""
    def __init__(self, source_name: str, geopackage1: str, geopackage2: str) -> None:
        super(QGISApplicationException, self)
        self.source_name: str = source_name
        self.geopackage1: str = geopackage1
        self.geopackage2: str = geopackage2

    def as_dict(self) -> dict[str, str]:
        return {'source_name': self.source_name, 'geopackage1': self.geopackage1, 'geopackage2': self.geopackage2}

    @staticmethod
    def from_dict(ex_dict: dict) -> ProjectUsingSameLayerNameDifferentGeopackages:
        return ProjectUsingSameLayerNameDifferentGeopackages(ex_dict['source_name'], ex_dict['geopackage1'], ex_dict['geopackage2'])

    def __str__(self) -> str:
        return f"The feature class name '{self.source_name}' is used in both geopackage '{self.geopackage1}' and geopackage '{self.geopackage2}'"


class SchemaNotFound(QGISApplicationException):
    """Exception raised when schema doesn't exist in the QGIS datastore."""
    def __init__(self, schema: str) -> None:
        super(QGISApplicationException, self)
        self.schema: str = schema

    def as_dict(self) -> dict[str, str]:
        return {"schema": self.schema}

    @staticmethod
    def from_dict(ex_dict: dict) -> SchemaNotFound:
        return SchemaNotFound(ex_dict['schema'])

    def __str__(self) -> str:
        return f"Schema '{self.schema}' doesn't exist in the database."


class ProjectNotFoundFromFile(QGISApplicationException):
    """Exception raised when project doesn't exist on the file system."""
    def __init__(self, file_path: str) -> None:
        super(QGISApplicationException, self)
        self.file_path: str = file_path

    def as_dict(self) -> dict[str, str]:
        return {"file_path": self.file_path}

    @staticmethod
    def from_dict(ex_dict: dict) -> ProjectNotFoundFromFile:
        return ProjectNotFoundFromFile(ex_dict['file_path'])

    def __str__(self) -> str:
        return f"The project at location '{self.file_path}' couldn't be found."


class ProjectNotFoundFromDatabase(QGISApplicationException):
    """Exception raised when project doesn't exist in the QGIS datastore."""
    def __init__(self, project_name: str, schema: str) -> None:
        super(QGISApplicationException, self)
        self.project_name: str = project_name
        self.schema: str = schema

    def as_dict(self) -> dict[str, str]:
        return {'project_name': self.project_name, 'schema': self.schema}

    @staticmethod
    def from_dict(ex_dict: dict) -> ProjectNotFoundFromDatabase:
        return ProjectNotFoundFromDatabase(ex_dict['project_name'], ex_dict['schema'])

    def __str__(self) -> str:
        return f"The project '{self.project_name}' couldn't be found in the QGIS data store under schema '{self.schema}'."


class ProjectNoValidLayers(QGISApplicationException):
    """Exception raised when project doesn't exist in the QGIS datastore."""
    def __init__(self, project_name: str) -> None:
        super(QGISApplicationException, self)
        self.project_name: str = project_name

    def as_dict(self) -> dict[str, str]:
        return {'project_name': self.project_name}

    @staticmethod
    def from_dict(ex_dict: dict) -> ProjectNoValidLayers:
        return ProjectNoValidLayers(ex_dict['project_name'])

    def __str__(self) -> str:
        return f"The project '{self.project_name}' has no valid layers."


class StorageNotFound(QGISApplicationException):
    """Exception raised when project doesn't exist in the QGIS datastore."""
    def __init__(self, storage_name: str, uri: str) -> None:
        super(QGISApplicationException, self)
        self.storage_name: str = storage_name
        self.uri: str = uri

    def as_dict(self) -> dict[str, str]:
        return {'storage_name': self.storage_name, 'uri': self.uri}

    @staticmethod
    def from_dict(ex_dict: dict) -> StorageNotFound:
        return StorageNotFound(ex_dict['storage_name'], ex_dict['uri'])

    def __str__(self) -> str:
        return f"The storage '{self.storage_name}' couldn't be found in the QGIS data store under uri '{self.uri}'."


class ProjectVersionGreaterThanAPI(QGISApplicationException):
    """Exception raised when project already exists in the QGIS datastore."""
    def __init__(self, project_name: str, version_project: str, version_pyqgis: str) -> None:
        super(QGISApplicationException, self)
        self.project_name: str = project_name
        self.version_project: str = version_project
        self.version_pyqgis: str = version_pyqgis

    def as_dict(self) -> dict[str, str]:
        return {'project_name': self.project_name, 'version_project': self.version_project, 'version_pyqgis': self.version_pyqgis}

    @staticmethod
    def from_dict(ex_dict: dict) -> ProjectVersionGreaterThanAPI:
        return ProjectVersionGreaterThanAPI(ex_dict['project_name'], ex_dict['version_project'], ex_dict['version_pyqgis'])

    def __str__(self) -> str:
        return f"The project '{self.project_name}' version is '{self.version_project}' which is greater than the QGIS version used by the API '{self.version_pyqgis}'"


class ProjectVersionGreaterThanServer(QGISApplicationException):
    """Exception raised when project already exists in the QGIS datastore."""
    def __init__(self, project_name: str, version_project: str, version_server: str) -> None:
        super(QGISApplicationException, self)
        self.project_name: str = project_name
        self.version_project: str = version_project
        self.version_server: str = version_server

    def as_dict(self) -> dict[str, str]:
        return {'project_name': self.project_name, 'version_project': self.version_project, 'version_server': self.version_server}

    @staticmethod
    def from_dict(ex_dict: dict) -> ProjectVersionGreaterThanServer:
        return ProjectVersionGreaterThanServer(ex_dict['project_name'], ex_dict['version_project'], ex_dict['version_server'])

    def __str__(self) -> str:
        return f"The project '{self.project_name}' version is '{self.version_project}' which is greater than our QGIS Server running on '{self.version_server}'"


class ProjectHasNoTitle(QGISApplicationException):
    """Exception raised when project already exists in the QGIS datastore."""
    def __init__(self, project_name: str) -> None:
        super(QGISApplicationException, self)
        self.project_name: str = project_name

    def as_dict(self) -> dict[str, str]:
        return {'project_name': self.project_name}

    @staticmethod
    def from_dict(ex_dict: dict) -> ProjectHasNoTitle:
        return ProjectHasNoTitle(ex_dict['project_name'])

    def __str__(self) -> str:
        return f"The project '{self.project_name}' has no title."


class ProjectAlreadyExists(QGISApplicationException):
    """Exception raised when project already exists in the QGIS datastore."""
    def __init__(self, project_name: str) -> None:
        super(QGISApplicationException, self)
        self.project_name: str = project_name

    def as_dict(self) -> dict[str, str]:
        return {'project_name': self.project_name}

    @staticmethod
    def from_dict(ex_dict: dict) -> ProjectAlreadyExists:
        return ProjectAlreadyExists(ex_dict['project_name'])

    def __str__(self) -> str:
        return f"The project '{self.project_name}' already exists in the QGIS data store."


class ProjectsDifferentLayersCount(QGISApplicationException):
    """Exception raised when projects don't have the same number of layers."""
    def __init__(self, project_1_count: int, project_2_count: int) -> None:
        super(QGISApplicationException, self)
        self.project_1_count: int = project_1_count
        self.project_2_count: int = project_2_count

    def as_dict(self) -> dict[str, int]:
        return {'project_1_count': self.project_1_count, 'project_2_count': self.project_2_count}

    @staticmethod
    def from_dict(ex_dict: dict) -> ProjectsDifferentLayersCount:
        return ProjectsDifferentLayersCount(ex_dict['project_1_count'], ex_dict['project_2_count'])

    def __str__(self) -> str:
        return f"The projects have different number of layers; {self.project_1_count} vs {self.project_2_count}"


class ProjectsSourceNameNotFound(QGISApplicationException):
    """Exception raised when 2 projects don't have the same layer source names."""
    def __init__(self, language: str, layer_name: str, layer_source_name: str) -> None:
        super(QGISApplicationException, self)
        self.language: str = language
        self.layer_name: str = layer_name
        self.layer_source_name: str = layer_source_name

    def as_dict(self) -> dict[str, str]:
        return {'language': self.language, 'layer_name': self.layer_name, 'layer_source_name': self.layer_source_name}

    @staticmethod
    def from_dict(ex_dict: dict) -> ProjectsSourceNameNotFound:
        return ProjectsSourceNameNotFound(ex_dict['language'], ex_dict['layer_name'], ex_dict['layer_source_name'])

    def __str__(self) -> str:
        return f"The layer '{self.layer_name}' from the '{'French' if self.language == 'fr' else 'English'}' project refers to a source name '{self.layer_source_name}' which has no equivalence in the alternate language project."


# class ProjectsShortNameDuplicated(QGISApplicationException):
#     """Exception raised when project has duplicated short names."""
#     def __init__(self, project_id: str, layer_short_name: str) -> None:
#         super(QGISApplicationException, self)
#         self.project_id: str = project_id
#         self.layer_short_name: str = layer_short_name

#     def as_dict(self) -> dict[str, str]:
#         return {'project_id': self.project_id, 'layer_short_name': self.layer_short_name}

#     @staticmethod
#     def from_dict(ex_dict: dict) -> ProjectsShortNameDuplicated:
#         return ProjectsShortNameDuplicated(ex_dict['project_id'], ex_dict['layer_short_name'])

#     def __str__(self) -> str:
#         return f"The short name '{self.layer_short_name}' appears more than once in the project '{self.project_id}'."


class LayerInvalid(QGISApplicationException):
    """Warning when a layer is invalid in a project."""
    def __init__(self, project_id: str, layer_name: str) -> None:
        super(QGISApplicationException, self)
        self.project_id: str = project_id
        self.layer_name: str = layer_name

    def as_dict(self) -> dict[str, str]:
        return {'project_id': self.project_id, 'layer_name': self.layer_name}

    @staticmethod
    def from_dict(ex_dict: dict) -> LayerInvalid:
        return LayerInvalid(ex_dict['project_id'], ex_dict['layer_name'])

    def __str__(self) -> str:
        return f"The Layer '{self.layer_name}' in project '{self.project_id}' was invalid."


class LayerUnsupportedCRS(QGISApplicationException):
    """Exception raised when a layer doesn't have a supported CRS."""
    def __init__(self, layer_name: str, crs: str) -> None:
        super(QGISApplicationException, self)
        self.layer_name: str = layer_name
        self.crs: str = crs

    def as_dict(self) -> dict[str, str]:
        return {'layer_name': self.layer_name, 'crs': self.crs}

    @staticmethod
    def from_dict(ex_dict: dict) -> LayerUnsupportedCRS:
        return LayerUnsupportedCRS(ex_dict['layer_name'], ex_dict['crs'])

    def __str__(self) -> str:
        return f"The crs '{self.crs}' of the layer '{self.layer_name}' is not supported."


class LayerWithoutCRS(QGISApplicationException):
    """Exception raised when a layer doesn't have a CRS."""
    def __init__(self, layer_name: str) -> None:
        super(QGISApplicationException, self)
        self.layer_name: str = layer_name

    def as_dict(self) -> dict[str, str]:
        return {'layer_name': self.layer_name}

    @staticmethod
    def from_dict(ex_dict: dict) -> LayerWithoutCRS:
        return LayerWithoutCRS(ex_dict['layer_name'])

    def __str__(self) -> str:
        return f"The '{self.layer_name}' layer's coordinate reference system (CRS) is undefined at the data source level. Please define the appropriate CRS directly in your data storage system."

class LayerDifferentCRS(QGISApplicationException):
    """Exception raised when a project have layers with different CRS."""
    def __init__(self) -> None:
        super(QGISApplicationException, self)

    def as_dict(self) -> dict[str, str]:
        return {}

    @staticmethod
    def from_dict(ex_dict: dict) -> LayerDifferentCRS:
        return LayerDifferentCRS()

    def __str__(self) -> str:
        return f"The layers in the project don't all use the same coordinate reference system (CRS)."


class LayerWithDifferentCRS(QGISApplicationException):
    """Exception raised when a project have layers with different CRS."""
    def __init__(self, layer_name: str, crs: str, project_crs: str) -> None:
        super(QGISApplicationException, self)
        self.layer_name: str = layer_name
        self.crs: str = crs
        self.project_crs: str = project_crs

    def as_dict(self) -> dict[str, str]:
        return {'layer_name': self.layer_name, 'crs': self.crs, 'project_crs': self.project_crs}

    @staticmethod
    def from_dict(ex_dict: dict) -> LayerWithDifferentCRS:
        return LayerWithDifferentCRS(ex_dict['layer_name'], ex_dict['crs'], ex_dict['project_crs'])

    def __str__(self) -> str:
        return f"The CRS '{self.crs}' of the layer '{self.layer_name}' is different than the QGIS project's CRS '{self.project_crs}'."


class LayerNotMarkedForPublication(QGISApplicationException):
    """Exception raised when a project doesn't have layer type checked in the QGIS project."""
    def __init__(self, layer_type: str) -> None:
        super(QGISApplicationException, self)
        self.layer_type: str = layer_type

    def as_dict(self) -> dict[str, str]:
        return {'layer_type': self.layer_type}

    @staticmethod
    def from_dict(ex_dict: dict) -> LayerNotMarkedForPublication:
        return LayerNotMarkedForPublication(ex_dict['layer_type'])

    def __str__(self) -> str:
        return f"You want to publish {self.layer_type} layers, but no layers of that type have their publication flag checked in the QGIS project."


class LayerMarkedForPublication(QGISApplicationException):
    """Exception raised when a project has unexpected layer type checked in the QGIS project."""
    def __init__(self, layer_type: str, layer_ids: list) -> None:
        super(QGISApplicationException, self)
        self.layer_type: str = layer_type
        self.layer_ids: list = layer_ids

    def as_dict(self) -> dict:
        return {'layer_type': self.layer_type, 'layer_ids': self.layer_ids}

    @staticmethod
    def from_dict(ex_dict: dict) -> LayerMarkedForPublication:
        return LayerMarkedForPublication(ex_dict['layer_type'], ex_dict['layer_ids'])

    def __str__(self) -> str:
        return f"The control file indicates that you do not want to publish {self.layer_type} layers, but the following layers have their publication flag checked in the QGIS project: {self.layer_ids}"


# class LayerShortNameInvalid(QGISApplicationException):
#     """Exception raised when a layer has invalid short name."""
#     def __init__(self, layer_name: str, layer_short_name: str) -> None:
#         super(QGISApplicationException, self)
#         self.layer_name: str = layer_name
#         self.layer_short_name: str = layer_short_name

#     def as_dict(self) -> dict[str, str]:
#         return {
#             'layer_name': self.layer_name,
#             'layer_short_name': self.layer_short_name
#         }

#     @staticmethod
#     def from_dict(ex_dict: dict) -> LayerShortNameInvalid:
#         return LayerShortNameInvalid(ex_dict['layer_name'], ex_dict['layer_short_name'])

#     def __str__(self) -> str:
#         return f"The layer short name '{self.layer_short_name}' for the layer '{self.layer_name}' is invalid."


class LayerFieldIDInvalid(QGISApplicationException):
    """Exception raised when a layer has invalid short name."""
    def __init__(self, layer_name: str) -> None:
        super(QGISApplicationException, self)
        self.layer_name: str = layer_name

    def as_dict(self) -> dict[str, str]:
        return {'layer_name': self.layer_name}

    @staticmethod
    def from_dict(ex_dict: dict) -> LayerFieldIDInvalid:
        return LayerFieldIDInvalid(ex_dict['layer_name'])

    def __str__(self) -> str:
        return f"The layer '{self.layer_name}' has invalid primary key attributes. Should be 1 primary key."


class LayerFailedToGetExtent(QGISApplicationException):
    """Exception raised when system couldn't get the layer extent."""
    def __init__(self, layer_name: str, crs: str) -> None:
        super(QGISApplicationException, self)
        self.layer_name: str = layer_name
        self.crs: str = crs

    def as_dict(self) -> dict[str, str]:
        return {'layer_name': self.layer_name, 'crs': self.crs}

    @staticmethod
    def from_dict(ex_dict: dict) -> LayerFailedToGetExtent:
        return LayerFailedToGetExtent(ex_dict['layer_name'], ex_dict['crs'])

    def __str__(self) -> str:
        return f"The system couldn't get the layer extent for layer '{self.layer_name}' in crs '{self.crs}'."


class LayerExistsInBothProjects(QGISApplicationException):
    """Exception raised when the layer exists in both projects."""
    def __init__(self, layer_name: str) -> None:
        super(QGISApplicationException, self)
        self.layer_name: str = layer_name

    def as_dict(self) -> dict[str, str]:
        return {'layer_name': self.layer_name}

    @staticmethod
    def from_dict(ex_dict: dict) -> LayerExistsInBothProjects:
        return LayerExistsInBothProjects(ex_dict['layer_name'])

    def __str__(self) -> str:
        return f"The layer '{self.layer_name}' exists in both QGIS projects."


class DataSourceInvalid(QGISApplicationException):
    """Exception raised when the data source name is invalid."""
    def __init__(self, layer_name: str) -> None:
        super(QGISApplicationException, self)
        self.layer_name: str = layer_name

    def as_dict(self) -> dict[str, str]:
        return {'layer_name': self.layer_name}

    @staticmethod
    def from_dict(ex_dict: dict) -> DataSourceInvalid:
        return DataSourceInvalid(ex_dict['layer_name'])

    def __str__(self) -> str:
        return f"The layer '{self.layer_name}' has an invalid source name (name too long?)."


class DataAlreadyExists(QGISApplicationException):
    """Exception raised when the data already exists in the database."""
    def __init__(self, layer_name: str) -> None:
        super(QGISApplicationException, self)
        self.layer_name: str = layer_name

    def as_dict(self) -> dict[str, str]:
        return {'layer_name': self.layer_name}

    @staticmethod
    def from_dict(ex_dict: dict) -> DataAlreadyExists:
        return DataAlreadyExists(ex_dict['layer_name'])

    def __str__(self) -> str:
        return f"The layer '{self.layer_name}' already exists in the QGIS data store."


class StyleAlreadyExists(QGISApplicationException):
    """Exception raised when the data already exists in the database."""
    def __init__(self, layer_name: str) -> None:
        super(QGISApplicationException, self)
        self.layer_name: str = layer_name        #self.style_name = style_name

    def as_dict(self) -> dict[str, str]:
        return {'layer_name': self.layer_name}

    @staticmethod
    def from_dict(ex_dict: dict) -> StyleAlreadyExists:
        return StyleAlreadyExists(ex_dict['layer_name'])

    def __str__(self) -> str:
        return f"The style for the layer '{self.layer_name}' already exists in the QGIS data store."


class ExportFailTableExists(QGISApplicationException):
    """Exception raised when an export of a layer has failed, because the table already existed at the destination."""
    def __init__(self, layer_name: str, table_name: str) -> None:
        super(QGISApplicationException, self)
        self.layer_name: str = layer_name
        self.table_name: str = table_name

    def as_dict(self) -> dict[str, str]:
        return {'layer_name': self.layer_name, 'table_name': self.table_name}

    @staticmethod
    def from_dict(ex_dict: dict) -> ExportFailTableExists:
        return ExportFailTableExists(ex_dict['layer_name'], ex_dict['table_name'])

    def __str__(self) -> str:
        return f"The export of layer '{self.layer_name}' to table '{self.table_name}' has failed"


class TableMissingInGpkg(QGISApplicationException):
    """Exception raised when a table is missing in the GeopackageFile."""
    def __init__(self, table_name: str, gpkg_file: str) -> None:
        super(QGISApplicationException, self)
        self.table_name: str = table_name
        self.gpkg_file: str = gpkg_file

    def as_dict(self) -> dict[str, str]:
        return {
            'table_name': self.table_name,
            'gpkg_file': self.gpkg_file
        }

    @staticmethod
    def from_dict(ex_dict: dict) -> TableMissingInGpkg:
        return TableMissingInGpkg(ex_dict['table_name'], ex_dict['gpkg_file'])

    def __str__(self) -> str:
        return f"The table '{self.table_name}' is not present in the geopackage file '{self.gpkg_file}'"


class PrimaryKeyMissingInGpkg(QGISApplicationException):
    """Exception raised when a table in the GeopackageFile is missing a primary key."""
    def __init__(self, table_name: str, gpkg_file: str) -> None:
        super(QGISApplicationException, self)
        self.table_name: str = table_name
        self.gpkg_file: str = gpkg_file

    def as_dict(self) -> dict[str, str]:
        return {
            'table_name': self.table_name,
            'gpkg_file': self.gpkg_file
        }

    @staticmethod
    def from_dict(ex_dict: dict) -> PrimaryKeyMissingInGpkg:
        return PrimaryKeyMissingInGpkg(ex_dict['table_name'], ex_dict['gpkg_file'])

    def __str__(self) -> str:
        return f"The table '{self.table_name}' has no primary key in the geopackage file '{self.gpkg_file}'"

class TableMissingInDatabase(QGISApplicationException):
    """Exception raised when a table is missing in the Database."""
    def __init__(self, schema_name: str, table_name: str) -> None:
        super(QGISApplicationException, self)
        self.schema_name: str = schema_name
        self.table_name: str = table_name

    def as_dict(self) -> dict[str, str]:
        return {
            'schema_name': self.schema_name,
            'table_name': self.table_name
        }

    @staticmethod
    def from_dict(ex_dict: dict) -> TableMissingInDatabase:
        return TableMissingInDatabase(ex_dict['schema_name'], ex_dict['table_name'])

    def __str__(self) -> str:
        return f"The table '{self.schema_name}.{self.table_name}' is not present in the database"


class TableAlreadyExists(QGISApplicationException):
    """Exception raised when a table already exists in the database."""
    def __init__(self, schema_name: str, table_name: str) -> None:
        super(QGISApplicationException, self)
        self.schema_name: str = schema_name
        self.table_name: str = table_name

    def as_dict(self) -> dict[str, str]:
        return {'schema_name': self.schema_name, 'table_name': self.table_name}

    @staticmethod
    def from_dict(ex_dict: dict) -> TableAlreadyExists:
        return TableAlreadyExists(ex_dict['schema_name'], ex_dict['table_name'])

    def __str__(self) -> str:
        return f"The table: '{self.schema_name}.{self.table_name}' already exists in the database."


class UnableCopyGpkgTable(QGISApplicationException):
    """Exception raised when unable to copy geopackage table to the database."""
    def __init__(self, input_file: str, schema_name: str, db_table_name: str) -> None:
        super(QGISApplicationException, self)
        self.input_file: str = input_file
        self.schema_name: str = schema_name
        self.db_table_name: str = db_table_name

    def as_dict(self) -> dict[str, str]:
        return {
            'input_file': self.input_file,
            'schema_name': self.schema_name,
            'db_table_name': self.db_table_name
        }

    @staticmethod
    def from_dict(ex_dict: dict) -> UnableCopyGpkgTable:
        return UnableCopyGpkgTable(ex_dict['input_file'], ex_dict['schema_name'], ex_dict['db_table_name'])

    def __str__(self) -> str:
        return f"Unable to copy the table from: '{self.input_file}' into '{self.schema_name}.{self.db_table_name}'."


class UnableAccessGpkg(QGISApplicationException):
    """Exception to open or access geopackage file."""
    def __init__(self, gpkg_file:str) -> None:
        super(QGISApplicationException, self)
        self.gpkg_file: str = gpkg_file

    def as_dict(self) -> dict[str, str]:
        return {'gpkg_file': self.gpkg_file}

    @staticmethod
    def from_dict(ex_dict: dict) -> UnableAccessGpkg:
        return UnableAccessGpkg(ex_dict['gpkg_file'])

    def __str__(self) -> str:
        return f"Unable to open/access GeoPackage file '{self.gpkg_file}'."


class FailedExportLayer(QGISApplicationException):
    """Exception when exporting a layer failed."""
    def __init__(self, layer_name: str, table_name: str, message: str) -> None:
        super(QGISApplicationException, self)
        self.layer_name: str = layer_name
        self.table_name: str = table_name
        self.message: str = message

    def as_dict(self) -> dict[str, str]:
        return {
            'layer_name': self.layer_name,
            'table_name': self.table_name,
            'message': self.message
        }

    @staticmethod
    def from_dict(ex_dict: dict) -> FailedExportLayer:
        return FailedExportLayer(ex_dict['layer_name'], ex_dict['table_name'], ex_dict['message'])

    def __str__(self) -> str:
        return f"Failed to export the layer '{self.layer_name}' with table '{self.table_name}' : {self.message}."


class FailedSaveQgisProject(QGISApplicationException):
    """Exception when export of QGIS project failed."""
    def __init__(self, project_id:str) -> None:
        super(QGISApplicationException, self)
        self.project_id: str = project_id

    def as_dict(self) -> dict[str, str]:
        return {'project_id': self.project_id}

    @staticmethod
    def from_dict(ex_dict: dict) -> FailedSaveQgisProject:
        return FailedSaveQgisProject(ex_dict['project_id'])

    def __str__(self) -> str:
        return f"Failed to save the QGIS Project '{self.project_id}' in the db."


class FailedDeleteQgisProject(QGISApplicationException):
    """Exception when delete of QGIS project failed."""
    def __init__(self, project_id:str) -> None:
        super(QGISApplicationException, self)
        self.project_id: str = project_id

    def as_dict(self) -> dict[str, str]:
        return {'project_id': self.project_id}

    @staticmethod
    def from_dict(ex_dict: dict) -> FailedDeleteQgisProject:
        return FailedDeleteQgisProject(ex_dict['project_id'])

    def __str__(self) -> str:
        return f"Failed to delete the QGIS Project '{self.project_id}' in the db."
    
class ProjectsVirtualLayerDifferences(QGISApplicationException):
    """Exception raised when 2 projects don't have the same virtual layers or query."""
    def __init__(self, diff_type:str, en_content: list, fr_content: list) -> None:
        super(QGISApplicationException, self)
        self.diff_type: str = diff_type
        self.en_content: list = en_content
        self.fr_content: list = fr_content

    def as_dict(self) -> dict[str, Any]:
        return {'diff_type': self.diff_type, 'en_content': self.en_content, 'fr_content': self.fr_content}

    @staticmethod
    def from_dict(ex_dict: dict) -> ProjectsVirtualLayerDifferences:
        return ProjectsVirtualLayerDifferences(ex_dict['diff_type'], ex_dict['en_content'], ex_dict['fr_content'])

    def __str__(self) -> str:
        return f"Virutal layers differences of type '{self.diff_type}' were detected between EN and FR projects."