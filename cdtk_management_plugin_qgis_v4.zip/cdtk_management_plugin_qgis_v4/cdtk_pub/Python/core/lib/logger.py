import logging
from typing import Any, cast

###
# To use the log library, call init_log once in your application and then use
# the exposed functions such as log_info, log_error, log_trace_func to log.
###

# Constant
TRACE_LEVEL: int = 5  # Custom log level for TRACE

# NRCan logger
class NRCanLogger(logging.Logger):
    """
    Custom logger class that includes a TRACE level and trace-related methods.
    """

    def __init__(self, name: str) -> None:
        # Call parent
        logging.Logger.__init__(self, name)

    def trace_func(self, *args: Any, **kwargs: Any) -> None:
        """
        Log a trace-level message with the caller's function name.

        This function is specifically designed for logging the function call.
        It uses stacklevel=2 to capture the name of the caller's function.
        """
        # NOTE: Don't redirect code, because stacklevel will change
        if self.isEnabledFor(TRACE_LEVEL):
            # Use stacklevel=2 to capture the correct caller's function name
            self._log(TRACE_LEVEL, "called", args, stacklevel=2, **kwargs)

    def trace(self, message: str, *args: Any, **kwargs: Any) -> None:
        """
        Log a custom trace-level message.

        This method is used to log any trace-level messages in the code.
        It includes the caller's function name using stacklevel=2.
        """
        # NOTE: Don't redirect code, because stacklevel will change
        if self.isEnabledFor(TRACE_LEVEL):
            # Use stacklevel=2 to capture the correct caller's function name
            self._log(TRACE_LEVEL, message, args, stacklevel=2, **kwargs)


def get_log(log_name: str) -> NRCanLogger:
    return cast(NRCanLogger, logging.getLogger(log_name))


def init_log(log_name: str, log_file: str, log_level_file: int, log_level_console: int) -> None:
    """
    Initializes the logger. This function should be called once at the start of the application.

    :param log_name: Name of the logger.
    :param log_file: Path to the log file where logs will be written.
    :param log_level_file: The logging level for the log file (e.g., logging.DEBUG).
    :param log_level_console: The logging level for the console output (e.g., logging.INFO).
    """

    # Create a custom level 'TRACE' with a weight of 5
    logging.addLevelName(TRACE_LEVEL, "TRACE")

    # Set the NRCanLogger as the default logger class
    logging.setLoggerClass(NRCanLogger)

    # Get the logger with the specified log name
    log = get_log(log_name)

    # Set the base logging level to TRACE
    log.setLevel(TRACE_LEVEL)

    # Create a log formatter to structure the log entries
    # The formatter includes the timestamp, process ID, log level, module name, function name, and the log message.
    formatter = logging.Formatter('%(asctime)s|%(process)d|%(levelname)s|%(module)s|%(funcName)s|%(message)s')

    # Setup the file handler to write logs to the specified file
    file_handler = logging.FileHandler(log_file)
    file_handler.setLevel(log_level_file)  # Set the level for file logging
    file_handler.setFormatter(formatter)   # Attach the formatter to the file handler
    log.addHandler(file_handler)           # Add the file handler to the logger

    # Setup the console handler to print logs to the console
    console_handler = logging.StreamHandler()
    console_handler.setLevel(log_level_console)  # Set the level for console logging
    console_handler.setFormatter(formatter)     # Attach the formatter to the console handler
    log.addHandler(console_handler)             # Add the console handler to the logger
