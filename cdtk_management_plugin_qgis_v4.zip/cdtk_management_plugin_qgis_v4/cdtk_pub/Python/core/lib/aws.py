"""
This module offers functions to communicate with AWS services
"""

# 3rd party imports
import os, glob, boto3
from typing import Any
from botocore.exceptions import ClientError
from pathlib import Path
from nrcan_core import config_env


def get_ecs_client(region_name: str, iam_role: str):
    """
    Creates an Amazon ECS client using temporary security credentials from an IAM role.

    :param region_name: AWS region where the ECS service is hosted.
    :param iam_role: The IAM role ARN to assume.
    :return: ECS client configured with temporary credentials.
    """

    # Create an STS client object that represents a live connection to the STS service
    sts_client = boto3.client('sts')

    # Call the assume_role method of the STSConnection object and pass the role ARN and a role session name
    assumed_role_object = sts_client.assume_role(
        RoleArn=iam_role,
        RoleSessionName="AssumeRoleECS"
    )

    # From the response that contains the assumed role, get the temporary credentials
    credentials = assumed_role_object['Credentials']

    # Use the temporary credentials to create an ECS client
    ecs_client = boto3.client(
        'ecs',
        aws_access_key_id=credentials['AccessKeyId'],
        aws_secret_access_key=credentials['SecretAccessKey'],
        aws_session_token=credentials['SessionToken'],
        region_name=region_name
    )

    # Return the ECS client object
    return ecs_client


def get_s3_resource():
    """
    Creates an Amazon S3 resource using temporary security credentials from an IAM role.

    :param iam_role: The IAM role ARN to assume.
    :return: S3 resource configured with temporary credentials.
    """

    # Create the S3 resource using the temporary credentials
    s3_resource = boto3.resource('s3')

    # Return the S3 resource object
    return s3_resource


# def get_secret(region: str, service_name: str, secret_key: str) -> dict:
#     """
#     Retrieve a secret from AWS Secrets Manager.

#     :param region: The AWS region to access the service.
#     :param service_name: The service name (e.g., "secretsmanager").
#     :param secret_key: The name or ARN of the secret to retrieve.
#     :return: A dictionary containing the decrypted secret.
#     """

#     # Create a Secrets Manager client
#     session = Session()
#     client = session.client(
#         service_name=service_name,
#         region_name=region
#     )

#     try:
#         # Retrieve the secret value from Secrets Manager
#         get_secret_value_response = client.get_secret_value(
#             SecretId=secret_key
#         )

#     except ClientError as e:
#         # Handle client error exceptions
#         # For a list of exceptions thrown, see
#         # https://docs.aws.amazon.com/secretsmanager/latest/apireference/API_GetSecretValue.html
#         raise e

#     # Decrypt the secret using KMS (if applicable)
#     return json.loads(get_secret_value_response['SecretString'])


def list_bucket(bucket_name: str, filter_prefix: str | None = None) -> Any:
    """
    Lists objects in an S3 bucket, optionally filtering by prefix.

    :param bucket_name: The S3 bucket name.
    :param iam_role: The IAM role to assume for accessing S3.
    :param filter_prefix: Optional prefix to filter the list of objects.
    :return: List of objects in the bucket, filtered if a prefix is provided.
    """

    try:
        # Get S3 resource using IAM role
        s3_resource = get_s3_resource()

        # If a filter prefix is provided, filter the objects
        if filter_prefix:
            return s3_resource.Bucket(bucket_name).objects.filter(Prefix=filter_prefix) # type: ignore
        else:
            return s3_resource.Bucket(bucket_name).objects.all() # type: ignore

    except ClientError as e:
        print("ERROR LISTING FILE ON S3")
        print(str(e))
        raise


def upload_bucket_file(source_file: str, bucket_name: str, prefix: str, file: str) -> None:
    """
    Uploads the given file to an S3 bucket using a specified IAM role and bucket name.

    :param bucket_name: The name of the destination S3 bucket.
    :param source_file: Path to the local file to upload.
    :param prefix: The folder path within the bucket where the file will be uploaded.
    :param file: The file name to use in the destination S3 bucket.
    """

    try:
        s3_resource = None

        if config_env.IS_LOCAL:
            # If in Local environment, create a boto3 session with temporary credentials retrieved from environment variables
            session = boto3.Session(
                aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
                aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY"),
                aws_session_token=os.getenv("AWS_SESSION_TOKEN"),
                region_name=os.getenv("AWS_REGION")
            )

            # Create S3 resource from session
            s3_resource = session.resource('s3')

        else:
            # Get S3 resource using IAM role
            s3_resource = get_s3_resource()


        # Ensure the prefix ends with "/"
        if not prefix.endswith("/"):
            prefix = prefix + "/"

        # Upload the file to the specified S3 bucket
        s3_resource.Bucket(bucket_name).upload_file(source_file, prefix + os.path.basename(file))  # type: ignore

    except ClientError as e:
        # Log error
        print("ERROR UPLOADING FILE TO S3")
        print(str(e))
        raise


def upload_bucket_folder(bucket_name: str, source_folder: str, prefix: str) -> None:
    """
    Uploads all files in a folder to an S3 bucket, using a specified IAM role and bucket name.

    :param bucket_name: The name of the destination S3 bucket.
    :param source_folder: Path to the local folder to upload.
    :param prefix: The folder path within the bucket where the files will be uploaded.
    """

    try:
        # Get S3 resource using IAM role
        s3_resource = get_s3_resource()

        # Ensure the prefix ends with "/"
        if not prefix.endswith("/"):
            prefix = prefix + "/"

        # Walk through the source folder and upload files
        p = Path(source_folder)
        mydirs = list(p.glob('**'))
        for mydir in mydirs:
            file_names = glob.glob(os.path.join(mydir, "*.*"))
            file_names = [f for f in file_names if not Path(f).is_dir()]
            for i, file_name in enumerate(file_names):
                # Transform the path to Bucket path
                file_path = file_name.replace(source_folder, "").replace("\\", "/").replace("//", "/").strip("/")

                # Create the AWS path
                aws_path = os.path.join(prefix, file_path)

                # Upload the file to the S3 bucket
                s3_resource.Bucket(bucket_name).upload_file(file_name, aws_path)  # type: ignore

    except ClientError as e:
        # Log error
        print("ERROR UPLOADING FOLDER TO S3")
        print(str(e))
        raise


def copy_bucket_folder(bucket_name_from: str, prefix_from: str, bucket_name_to: str, prefix_to: str, delete_og: bool) -> None:
    """
    Copies a folder from one S3 bucket to another, with optional deletion of the original files.

    :param bucket_name_from: Source S3 bucket name.
    :param prefix_from: Source folder prefix within the bucket.
    :param bucket_name_to: Destination S3 bucket name.
    :param prefix_to: Destination folder prefix within the bucket.
    :param iam_role: The IAM role to assume for accessing S3.
    :param delete_og: If True, deletes the original files from the source bucket.
    """

    try:
        # Get S3 resource using IAM role
        s3_resource = get_s3_resource()

        # Get source and destination buckets
        bucket_from = s3_resource.Bucket(bucket_name_from)  # type: ignore
        bucket_to = s3_resource.Bucket(bucket_name_to)  # type: ignore

        # Get all objects in the source folder
        objects_from = bucket_from.objects.filter(Prefix=prefix_from)

        # Copy each object to the destination bucket
        for key in objects_from:
            dest = prefix_to + "/" + os.path.basename(key.key)

            # Copy parameters
            params = {
                'Bucket': bucket_name_from,
                'Key': key.key
            }

            # Perform the copy operation
            s3_resource.meta.client.copy(params, bucket_name_to, dest)  # type: ignore

            # If deletion of the original is requested, delete the object
            if delete_og:
                key.delete()

    except ClientError as e:
        print("ERROR COPYING FOLDER IN S3")
        print(str(e))
        raise


def delete_bucket_folder(bucket_name: str, full_folder_path: str) -> None:
    """
    Deletes a folder from an S3 bucket using a specified IAM role and bucket name.

    :param bucket_name: The name of the S3 bucket.
    :param prefix: The folder path within the bucket to delete.
    :param source_folder: Path to the local folder to delete.
    """

    try:
        # Get S3 resource using IAM role
        s3_resource = get_s3_resource()

        # Ensure the prefix ends with "/"
        if not full_folder_path.endswith("/"):
            full_folder_path = full_folder_path + "/"

        # Delete all objects within the folder
        for key in s3_resource.Bucket(bucket_name).objects.filter(Prefix=(full_folder_path)):  # type: ignore
            # Delete the object
            key.delete()
        return

    except ClientError as e:
        print("ERROR DELETING FOLDER FROM S3")
        print(str(e))
        raise


def delete_bucket_file(bucket_name: str, file_path: str) -> None:
    """
    Deletes a file from an S3 bucket using a specified IAM role and bucket name.

    :param iam_role: The IAM role to assume for accessing S3.
    :param bucket_name: The name of the S3 bucket.
    :param file_path: The file path to delete within the bucket.
    """

    try:
        s3_resource = None

        if config_env.IS_LOCAL:
            # If in Local environment, create a boto3 session with temporary credentials retrieved from environment variables
            session = boto3.Session(
                aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
                aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY"),
                aws_session_token=os.getenv("AWS_SESSION_TOKEN"),
                region_name=os.getenv("AWS_REGION")
            )

            # Create S3 resource from session
            s3_resource = session.resource('s3')

        else:
            # Get S3 resource using IAM role
            s3_resource = get_s3_resource()


        # Delete the file within the folder
        s3_resource.Object(bucket_name, file_path).delete() # type: ignore

    except ClientError as e:
        print("ERROR DELETING FILE FROM S3")
        print(str(e))
        raise


def download_bucket_file(bucket_name: str, input_package_path: str, destination_path: str) -> str:
    """
    Downloads a file from an S3 bucket to a local path.

    :param bucket_name: The name of the S3 bucket.
    :param input_package_path: The key (path) to the file in the S3 bucket.
    :param destination_path: The local path to download the file to.
    :return: The local destination path where the file was saved.
    """

    # Connect to S3
    s3 = boto3.resource('s3')

    # Download the file from the S3 bucket to the local destination
    s3.Bucket(bucket_name).download_file(input_package_path, destination_path)  # type: ignore

    # Return the local destination path
    return destination_path
