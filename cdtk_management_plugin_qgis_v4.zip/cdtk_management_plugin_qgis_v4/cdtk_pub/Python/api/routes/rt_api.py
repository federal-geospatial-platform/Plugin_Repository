"""
This module, implementing OpenAPI concepts, manages the various routes for the API.
"""

# 3rd party imports
import sys
from typing import Any
from werkzeug.datastructures import FileStorage
from flask import request

# Application imports
from nrcan_core import cdtk_core, cdtk_publisher, config, config_env
from nrcan_core.db.entity.user import DBUser
from nrcan_core.lib import auth, user
from nrcan_core.lib.exceptions import *
from nrcan_core.routes import rt_core
from . import routes

# Get the log
from core.lib.logger import get_log
LOG = get_log(config_env.LOG_NAME)

# Cached OpenAPI Config and Version information for performance, as this never changes
OAPI_CONFIG_CACHED: dict | None = None
QGIS_VERSION_CACHED: str | None = None


@routes.route('/api/token', methods=['POST'])
def token() -> Any:
    """
    Handles a POST request on "/api/token" end point to return an access token.
    """
    LOG.trace_func()

    try:
        # Validate the parameters
        body: dict = request.json # type: ignore
        if 'microsoft_token' in body and 'client_id' in body:
            # Read the params
            microsoft_token = body['microsoft_token']
            client_id = body['client_id']

            try:
                # Validate the ms token
                res = auth.read_claims_in_token(client_id, microsoft_token)

                # Extract username and fullname from ID token claims
                user_name = res['preferred_username']
                user_fullname = res['name']

                # Generate token for the user
                return auth.query_user_and_generate_token(user_name, user_fullname)

            except UserNotFound as err:
                # User couldn't be found in the database
                not_found_ex = UserMessageException(401, f'Email {err.username} not found', f'Email {err.username} non trouvé')
                not_found_ex.title = err.username
                raise not_found_ex

            except Exception as err:
                # Failed to generate token from code
                print(err)
                LOG.error(err)
                raise ParametersInvalidException()

        else:
            # Parameters invalid
            raise ParametersInvalidException()

    except UserMessageException as err:
        # Handle the error
        rt_core.abort_user_message(err)

    except Exception as err:
        # Raise a generic error
        rt_core.abort_error(err)


@routes.route('/api/refresh', methods=['POST'])
def refresh() -> Any:
    """
    Handles a POST request on "/api/refresh" endpoint to return a new Publisher token.
    """
    LOG.trace_func()

    try:
        # Validate the parameters
        body = request.json
        if body and "refresh_token" in body:
            # Redirect
            return auth.refresh_token(body['refresh_token'])

        else:
            # Parameters invalid
            raise ParametersInvalidException()

    except UserMessageException as err:
        # Handle the error
        rt_core.abort_user_message(err)

    except Exception as err:
        # Raise a generic error
        rt_core.abort_error(err)


@routes.route('/api/logout', methods=['DELETE'])
@rt_core.validate_user_level(config.ROLE_LEVEL_USER)
def logout() -> Any:
    """
    Handles a DELETE request on "/api/logout" endpoint to logout a Publisher.
    """
    LOG.trace_func()

    try:
        # Redirect
        if auth.logout():
            return rt_core.response_204()

        else:
            raise UserMessageException(500,
                                       "Failed to logout from the API completely",
                                       "La tentative de déconnexion de l'API ne s'est pas bien terminée")

    except UserMessageException as err:
        # Handle the error
        rt_core.abort_user_message(err)

    except Exception as err:
        # Raise a generic error
        rt_core.abort_error(err)


@routes.route('/api/services', methods=['GET'])
@rt_core.validate_user_level(config.ROLE_LEVEL_ADMIN)
def get_info_all() -> Any:
    """
    Handles a GET request on endpoint "/api/services" to retrieve information
    on a given service.
    """
    LOG.trace_func()

    try:
        # Get information of all services
        services: dict = cdtk_core.get_info_services_via_api()

        # Return 200, done
        return rt_core.response_200(services)

    except UserMessageException as err:
        # Handle the error
        rt_core.abort_user_message(err)

    except Exception as err:
        # Raise a generic error
        rt_core.abort_error(err)


@routes.route('/api/services/<schema>', methods=['GET'])
@rt_core.validate_user_level(config.ROLE_LEVEL_ADMIN)
def get_info_schema(schema: str) -> Any:
    """
    Handles a GET request on endpoint "/api/services/<schema>" to retrieve information
    on a given service.
    """
    LOG.trace_func()

    try:
        # Load the project
        res: dict = cdtk_publisher.info_schema(schema)

        # Return 200, done
        return rt_core.response_200(res)

    except UserMessageException as err:
        # Handle the error
        rt_core.abort_user_message(err)

    except Exception as err:
        # Raise a generic error
        rt_core.abort_error(err)


@routes.route('/api/services/<schema>/<service_name>', methods=['GET'])
@rt_core.validate_user_level(config.ROLE_LEVEL_ADMIN)
def get_info_service(schema: str, service_name: str) -> Any:
    """
    Handles a GET request on endpoint "/api/services/<schema>/<service_name>" to retrieve information
    on a given service.
    """
    LOG.trace_func()

    try:
        # Load the project
        res: dict = cdtk_publisher.info_service(schema, service_name)

        # Return 200, done
        return rt_core.response_200(res)

    except UserMessageException as err:
        # Handle the error
        rt_core.abort_user_message(err)

    except Exception as err:
        # Raise a generic error
        rt_core.abort_error(err)


@routes.route('/api/services/<schema>/<service_name>', methods=['DELETE'])
@rt_core.validate_user_level(config.ROLE_LEVEL_ADMIN)
def delete_info_service(schema: str, service_name: str) -> Any:
    """
    Handles a DELETE request on endpoint "/api/services/<schema>/<service_name>" to delete
    a given service.
    """
    LOG.trace_func()

    try:
        # Load the project
        res: dict = cdtk_publisher.delete_service(schema, service_name)

        # Return 200, done
        return rt_core.response_200(res)

    except UserMessageException as err:
        # Handle the error
        rt_core.abort_user_message(err)

    except Exception as err:
        # Raise a generic error
        rt_core.abort_error(err)


@routes.route('/api/data', methods=['GET'])
@rt_core.validate_user_level(config.ROLE_LEVEL_ADMIN)
def get_data_all() -> Any:
    """
    Handles a GET request on endpoint "/api/data/<schema>" to read tables.
    """
    LOG.trace_func()

    try:
        # Get the tables on the schema
        tables: dict = cdtk_core.get_info_data()

        # Return 200, done
        return rt_core.response_200(tables)

    except UserMessageException as err:
        # Handle the error
        rt_core.abort_user_message(err)

    except Exception as err:
        # Raise a generic error
        rt_core.abort_error(err)


@routes.route('/api/data/<schema>', methods=['GET'])
@rt_core.validate_user_level(config.ROLE_LEVEL_ADMIN)
def get_data(schema: str) -> Any:
    """
    Handles a GET request on endpoint "/api/data/<schema>" to read tables.
    """
    LOG.trace_func()

    try:
        # Get the tables on the schema
        tables: list = cdtk_core.info_data(schema)

        # Return 200, done
        return rt_core.response_200({'tables': tables})

    except UserMessageException as err:
        # Handle the error
        rt_core.abort_user_message(err)

    except Exception as err:
        # Raise a generic error
        rt_core.abort_error(err)


@routes.route('/api/data/<schema>/<table_name>', methods=['DELETE'])
@rt_core.validate_user_level(config.ROLE_LEVEL_ADMIN)
def delete_table(schema: str, table_name: str) -> Any:
    """
    Handles a DELETE request on endpoint "/api/data/<schema>/<table_name>" to delete a table.
    """
    LOG.trace_func()

    try:
        # Delete/drop a table from the database
        res: bool = cdtk_core.delete_table(schema, table_name)

        # Return 200, done
        return rt_core.response_201({'deleted': res})

    except UserMessageException as err:
        # Handle the error
        rt_core.abort_user_message(err)

    except Exception as err:
        # Raise a generic error
        rt_core.abort_error(err)


@routes.route('/api/folders', methods=['GET'])
@rt_core.validate_user_level(config.ROLE_LEVEL_ADMIN)
def get_folders() -> Any:
    """
    Handles a GET request on endpoint "/api/folders" to get the folders/files information from the repository.
    """
    LOG.trace_func()

    try:
        # Get the tables on the schema
        files: dict = cdtk_core.get_info_files()

        # Return 200, done
        return rt_core.response_200(files)

    except UserMessageException as err:
        # Handle the error
        rt_core.abort_user_message(err)

    except Exception as err:
        # Raise a generic error
        rt_core.abort_error(err)


@routes.route('/api/folders', methods=['DELETE'])
@rt_core.validate_user_level(config.ROLE_LEVEL_ADMIN)
def delete_folder() -> Any:
    """
    Handles a DELETE request on endpoint "/api/folders" to delete a folder from the repository.
    """
    LOG.trace_func()

    try:
        # Get the info
        body: dict = request.json # type: ignore

        # Delete/drop a table from the database
        res: bool = cdtk_core.delete_folder(body['datastore_id'], body['schema'], body['core_subject_term'], body['folder_name'])

        # Return 200, done
        return rt_core.response_201({'deleted': res})

    except UserMessageException as err:
        # Handle the error
        rt_core.abort_user_message(err)

    except Exception as err:
        # Raise a generic error
        rt_core.abort_error(err)


@routes.route('/api/versions', methods=['GET'])
def get_versions() -> Any:
    """
    Handles a GET request on endpoint "/api/versions" to retrieve the CDTK Publication API, QGIS and QGIS Server versions.
    """
    global OAPI_CONFIG_CACHED
    global QGIS_VERSION_CACHED
    LOG.trace_func()

    try:
        # The returned dict
        res: dict = {}

        # Get the version
        res['python'] = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"

        # If not cached yet
        res['cdtk_publication'] = "Unknown"
        if not OAPI_CONFIG_CACHED:
            # Read the open api config
            OAPI_CONFIG_CACHED = rt_core.read_open_api_config()

        # If openapi file was found
        if OAPI_CONFIG_CACHED:
            res['cdtk_publication'] = OAPI_CONFIG_CACHED['info']['version']

        # If not cached yet
        res['qgis_api'] = "Unknown"
        if not QGIS_VERSION_CACHED:
            # Gets the version and cache the result
            QGIS_VERSION_CACHED = cdtk_publisher.get_version()['qgis_api']

        # Set the QGIS Version from the cache
        res['qgis_api'] = QGIS_VERSION_CACHED

        # Set the QGIS Server Version
        res['qgis_server'] = cdtk_publisher.get_qgis_server_version()

        # Return the information
        return res

    except UserMessageException as err:
        # Handle the error
        rt_core.abort_user_message(err)

    except Exception as err:
        # Raise a generic error
        rt_core.abort_error(err)


@routes.route('/api/cdtk_registry_departments', methods=['GET'])
@rt_core.validate_user_level(config.ROLE_LEVEL_PUBLISHER)
def get_cdtk_departments() -> Any:
    """
    Handles a GET request on endpoint "/api/cdtk_registry_departments" to retrieve the CDTK Departments.
    """
    LOG.trace_func()

    try:
        # Gets the CDTK Departments
        res: list = cdtk_core.get_cdtk_my_departments()

        # Return the list
        return res

    except UserMessageException as err:
        # Handle the error
        rt_core.abort_user_message(err)

    except Exception as err:
        # Raise a generic error
        rt_core.abort_error(err)


@routes.route('/api/cdtk_registry_servers', methods=['GET'])
@rt_core.validate_user_level(config.ROLE_LEVEL_PUBLISHER)
def get_cdtk_servers() -> Any:
    """
    Handles a GET request on endpoint "/api/cdtk_registry_servers" to retrieve the CDTK Servers.
    """
    LOG.trace_func()

    try:
        # Gets the CDTK Servers
        res: list = cdtk_core.get_cdtk_my_servers()

        # Return the list
        return res

    except UserMessageException as err:
        # Handle the error
        rt_core.abort_user_message(err)

    except Exception as err:
        # Raise a generic error
        rt_core.abort_error(err)


@routes.route('/api/cdtk_registry_downloads', methods=['GET'])
@rt_core.validate_user_level(config.ROLE_LEVEL_PUBLISHER)
def get_cdtk_downloads() -> Any:
    """
    Handles a GET request on endpoint "/api/cdtk_registry_downloads" to retrieve the CDTK Downloads.
    """
    LOG.trace_func()

    try:
        # Gets the CDTK Downloads
        res: list = cdtk_core.get_cdtk_my_downloads()

        # Return the list
        return res

    except UserMessageException as err:
        # Handle the error
        rt_core.abort_user_message(err)

    except Exception as err:
        # Raise a generic error
        rt_core.abort_error(err)


@routes.route('/api/cdtk_registry_datasets/<metadata_id>', methods=['GET'])
@rt_core.validate_user_level(config.ROLE_LEVEL_PUBLISHER)
def get_cdtk_datasets(metadata_id: str) -> Any:
    """
    Handles a GET request on endpoint "/api/cdtk_registry_datasets" to retrieve the CDTK Datasets.
    """
    LOG.trace_func()

    try:
        # Gets the CDTK Datasets
        res: dict = cdtk_core.get_cdtk_dataset(metadata_id)

        # Return the list
        return res

    except UserMessageException as err:
        # Handle the error
        rt_core.abort_user_message(err)

    except Exception as err:
        # Raise a generic error
        rt_core.abort_error(err)


@routes.route('/api/cdtk_registry_my_publisher_email', methods=['GET'])
@rt_core.validate_user_level(config.ROLE_LEVEL_PUBLISHER)
def get_cdtk_my_email() -> Any:
    """
    Handles a GET request on endpoint "/api/cdtk_registry_my_publisher_email" to retrieve the Email of the logged in user.
    """
    LOG.trace_func()

    try:
        # Gets the email
        res: str | None = cdtk_core.get_cdtk_my_email()

        # Return the email
        return {"email": res}

    except UserMessageException as err:
        # Handle the error
        rt_core.abort_user_message(err)

    except Exception as err:
        # Raise a generic error
        rt_core.abort_error(err)


@routes.route('/api/validate', methods=['POST'])
@rt_core.validate_user_level(config.ROLE_LEVEL_PUBLISHER)
def post_validate() -> Any:
    """
    Handles a GET request on endpoint "/api/validate" to retrieve information from the project file.
    """

    try:
        # Read the input
        file: FileStorage | None = None
        if request.files and "zip_file" in request.files:
            file = request.files['zip_file']

        # If file was there
        if file:
            # Get operation
            operation: str | None = request.form.get("operation")

            # If operation was defined
            if operation:
                # Validate the project
                res = cdtk_publisher.validate_publication(operation, file)

                # Return 200, done
                return rt_core.response_200(res)

            raise UserMessageException(500,
                                       "No operation provided",
                                       "Aucune operation fourni")

        raise UserMessageException(500,
                                   "No zip file provided",
                                   "Aucun fichier zip fourni")

    except UserMessageException as err:
        # Handle the error
        rt_core.abort_user_message(err)

    except Exception as err:
        # Raise a generic error
        rt_core.abort_error(err)


@routes.route('/api/publish', methods=['PUT'])
@rt_core.validate_user_level(config.ROLE_LEVEL_PUBLISHER)
def put_services() -> Any:
    """
    Handles a PUT request on endpoint "/api/publish" to publish a service.
    """
    LOG.trace_func()

    try:
        # Read the input
        file: FileStorage | None = None
        if request.files and "zip_file" in request.files:
            file = request.files['zip_file']

        # If file was there
        if file:
            # Load the project
            cdtk_publisher.manage_publication('Publish', file)

            # Return 204, done
            return rt_core.response_204()

        raise UserMessageException(500,
                                   "No zip file provided",
                                   "Aucun fichier zip fourni")

    except UserMessageException as err:
        # Handle the error
        rt_core.abort_user_message(err)

    except Exception as err:
        # Raise a generic error
        rt_core.abort_error(err)


# @routes.route('/api/processes', methods=['PATCH'])
# @rt_core.validate_user_level(config.ROLE_LEVEL_PUBLISHER)
# def patch_services():
#     """
#     Handles a PATCH request on endpoint "/api/processes" to update a service.
#     """

#     try:
#         # Read the input
#         file: FileStorage | None = None
#         if request.files and "zip_file" in request.files:
#             file = request.files['zip_file']

#         # If file was there
#         if file:
#             # Load the project
#             cdtk_publisher.update_project(file)

#             # Return 204, done
#             return rt_core.response_204()

#         raise UserMessageException(500,
#                                    "No zip file provided",
#                                    "Aucun fichier zip fourni")

#     except UserMessageException as err:
#         # Handle the error
#         rt_core.abort_user_message(err)

#     except Exception as err:
#         # Raise a generic error
#         rt_core.abort_error(err)


@routes.route('/api/unpublish', methods=['DELETE'])
@rt_core.validate_user_level(config.ROLE_LEVEL_PUBLISHER)
def delete_services() -> Any:
    """
    Handles a DELETE request on endpoint "/api/unpublish" to delete a service.
    """
    LOG.trace_func()

    try:
        # Read the input
        file: FileStorage | None = None
        if request.files and "zip_file" in request.files:
            file = request.files['zip_file']

        # If file was there
        if file:
            # Load the project
            cdtk_publisher.manage_publication('Unpublish', file)

            # Return 204, done
            return rt_core.response_204()

        raise UserMessageException(500,
                                   "No zip file provided",
                                   "Aucun fichier zip fourni")

    except UserMessageException as err:
        # Handle the error
        rt_core.abort_user_message(err)

    except Exception as err:
        # Raise a generic error
        rt_core.abort_error(err)


@routes.route('/api/users', methods=['GET'])
@rt_core.validate_user_level(config.ROLE_LEVEL_ADMIN)
def get_users() -> Any:
    """
    Handles a GET request on endpoint "/api/users" to get all Users of the system.
    """
    LOG.trace_func()

    try:
        # Get the users
        users: list[DBUser] = user.get_users()

        # Parse and return
        return [x.to_dict() for x in users]

    except UserMessageException as err:
        # Handle the error for the User
        rt_core.abort_user_message(err)

    except Exception as err:
        # Raise a generic error
        rt_core.abort_error(err)


@routes.route('/api/users', methods=['PUT'])
@rt_core.validate_user_level(config.ROLE_LEVEL_ADMIN)
def put_user() -> Any:
    """
    Handles a PUT request on endpoint "/api/user" to create a User.
    """
    LOG.trace_func()

    try:
        # Validate the parameters
        body = request.json
        if body and "email" in body:
            # Create the User
            user.create_user(body['email'], body['role'])
            return rt_core.response_204()

        else:
            # Parameters invalid
            raise ParametersInvalidException()

    except UserMessageException as err:
        # Handle the error for the User
        rt_core.abort_user_message(err)

    except Exception as err:
        # Raise a generic error
        rt_core.abort_error(err)


@routes.route('/api/users/<email>', methods=['PATCH'])
@rt_core.validate_user_level(config.ROLE_LEVEL_ADMIN)
def patch_user(email: str) -> Any:
    """
    Handles a PATCH request on end point "/api/users" to update a User of the system.
    """
    LOG.trace_func()

    try:
        # Get the info
        body: list = request.json # type: ignore

        # Update
        user.update_user(email, body)

        # Return 204
        return rt_core.response_204()

    except UserMessageException as err:
        # Handle the error
        rt_core.abort_user_message(err)

    except Exception as err:
        # Raise a generic error
        rt_core.abort_error(err)


@routes.route('/api/users/<email>', methods=['DELETE'])
@rt_core.validate_user_level(config.ROLE_LEVEL_ADMIN)
def delete_user(email) -> Any:
    """
    Handles a DELETE request on endpoint "/api/user" to delete a User.
    """
    LOG.trace_func()

    try:
        # Delete the User
        user.delete_user(email)
        return rt_core.response_204()

    except UserMessageException as err:
        # Handle the error for the User
        rt_core.abort_user_message(err)

    except Exception as err:
        # Raise a generic error
        rt_core.abort_error(err)
