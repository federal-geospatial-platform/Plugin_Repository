"""
This is the CDTK Registry web application which offers a user interface to work with the CDTK Registry API.
- main.py: The starting point.
- routes\\\\rt_web.py: Routes module handling all HTML end points
- static\\\\: Website JavaScript and CSS code
- templates\\\\: Website HTML pages templates
- requirements.txt: Details the Python packages necessary to run this application.
"""

# Core modules
import sys, os, datetime

# Flask imports
from flask import Flask, session
from flask_jwt_extended import JWTManager
from flask_wtf.csrf import CSRFProtect
from flask_babel import Babel

# Add the parent folder to the path so that the "core" module can be loaded
sys.path.append(os.path.dirname(sys.path[0]))
from nrcan_core import config, config_env, secret
from core.lib.logger import init_log, get_log

# Init the log
init_log(config_env.LOG_NAME, config_env.LOG_FILE, config_env.LOG_LEVEL_FILE, config_env.LOG_LEVEL_CONSOLE)

# Get the log
LOG = get_log(config_env.LOG_NAME)

# Application imports
from routes import *

# Log
LOG.info('WEB Started')

# Create the Flask application
app = Flask(__name__)

# Flask Configurations
app.config['JWT_TOKEN_LOCATION'] = ["cookies"]
app.config['JWT_ACCESS_COOKIE_NAME'] = config.TOKEN_COOKIE_NAME
app.config['JWT_COOKIE_CSRF_PROTECT'] = True
app.config["JWT_ACCESS_TOKEN_EXPIRES"] = datetime.timedelta(minutes=config.TOKEN_EXP_MINUTES)
app.config["JWT_REFRESH_TOKEN_EXPIRES"] = datetime.timedelta(minutes=config.TOKEN_REFRESH_EXP_MINUTES)
app.config['SECRET_KEY'] = secret.get_secret_web_token_api()  # For Web auth and CSRF
app.config['APPLICATION_ROOT'] = '/'
app.config['PREFERRED_URL_SCHEME'] = 'https'

# Trick to support accented characters!
# After further tests, it seems the accented characters are only lost when the response is returned inside a browser.
# Requests via Postman already work with accents even when True. Anyways, doesn't hurt to leave it False for all.
app.config['JSON_AS_ASCII'] = False

# Create a Flask JWT Manager
jwtMan = JWTManager(app)

# Babel
babel = Babel(app)
app.config['BABEL_TRANSLATION_DIRECTORIES'] = './translations'
app.config["BABEL_DEFAULT_LOCALE"] = "en"

# Register the WEB routes blueprint in Flask
app.register_blueprint(routes)

# Register the CSRF protection
csrf = CSRFProtect(app)

# Read the parameters
app.jinja_env.globals["api_url"] = config_env.API_URL
app.jinja_env.globals["api_url_pygeoapi"] = config_env.PYGEOAPI_URL
app.jinja_env.globals["api_cookie_key"] = config.TOKEN_COOKIE_NAME


def get_locale():
    return session.get('language', 'en')
babel.init_app(app, locale_selector=get_locale)


@jwtMan.unauthorized_loader
def _handle_token_missing(_reason):
    """
    Handles the returned response when the token is missing.
    """

    print("app_web._handle_token_missing")
    print(_reason)
    return rt_core.redirect_login()


@jwtMan.invalid_token_loader
def _handle_token_invalid_check(_reason):
    """
    Handles the returned response when the token is invalid.
    """

    print("app_web._handle_token_invalid_check")
    print(_reason)
    return rt_core.redirect_expired()


@jwtMan.expired_token_loader
def _handle_token_expired(_jwt_header, _jwt_data):
    """
    Handles the returned response when the token has expired.
    """

    print("app_web._handle_token_expired")
    return rt_core.redirect_expired()


@app.errorhandler(404)
def _handle_not_found(_reason):
    """
    Handles the returned response when the URL or information wasn't found.
    """

    print("app_web._handle_not_found")
    print(_reason)
    return rt_core.redirect_not_found()


@app.errorhandler(429)
def _handle_rate_limit(rate_limit_exception):
    """
    Handles the returned response when the API is rate limiting a User.
    """

    print("app_web._handle_rate_limit")
    return rt_core.response_user(RateLimitedException(rate_limit_exception.description))


@app.errorhandler(Exception)
def _handle_all_errors(err):
    """
    Handles any exception.
    """

    print("app._handle_all_errors")
    return rt_core.response_generic(err)


# If we're running in stand alone mode, run the application
if __name__ == '__main__':
    """
    Run!
    """

    # Run
    app.run(host='0.0.0.0', port=config_env.PORT_WEB, debug=config_env.IS_LOCAL)
