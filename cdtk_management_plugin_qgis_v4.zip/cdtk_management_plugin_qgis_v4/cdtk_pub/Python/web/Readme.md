# CDTK Registry web interface
- `main.py` is the entry point of the CDTK Registry web interface. It launches the web server Flask and initializes the endpoints.
- `routes` folder contains the 1-to-1 Python code for handling each web endpoint requests.
- `static` folder contains the JavaScript/CSS shared code and assets.
- `templates` folder contains the web page models which are loaded by the route endpoints.
- `babel.cfg` is the Babel configuration for handling language translations and `UPDATE_BABEL.bat` is an executable file to generate/update the necessary English/French translation files which are then stored in the `translations` folder.
- `gunicorn_conf.py` contains the configuration for Gunicorn which is the WSGI HTTP Server launched when the web interface is running inside a Docker instance.

#### The source-code at this level is for the web high-level management. Most of the code redirects to logic implemented in the [`core`](https://github.com/federal-geospatial-platform/ddr_registry/tree/main/Python/core)
