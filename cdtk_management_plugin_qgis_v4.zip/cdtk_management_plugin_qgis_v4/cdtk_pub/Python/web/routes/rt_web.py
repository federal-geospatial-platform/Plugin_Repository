"""
This module, implementing OpenAPI concepts, manages the various routes for the web interface.

End points:
 - / or /en/home or /fr/home : endpoing to home page in correct language
 - /en/login or /fr/login : endpoint to a page to login with the API
 - /en/logout or /fr/logout : endpoint to a page to logout with the API
 - /en/query or /fr/query : endpoint to a page to query a quality metadata uuid
 - /en/profile or /fr/profile : endpoint to the user profile page
 - /en/expired or /fr/expired : endpoint to a page indicating the User has expired/invalid credentials
 - /en/denied or /fr/denied : endpoint to a page indicating the User has insufficient permissions
 - /en/not_found or /fr/not_found : endpoint to a page indicating the page originally queried couldn't be found
"""

# 3rd party imports
from typing import Any
from flask import request, session
import requests

# Application imports
from core.lib.msauth import MSAuth
from nrcan_core import cdtk_core, config, config_env, secret
from nrcan_core.lib import auth
from nrcan_core.lib.exceptions import *
import nrcan_core.routes.rt_core as rt_core
from . import routes


@routes.route('/', methods=['GET'])
@routes.route('/<any(en,fr):lang>/home', methods=['GET'])
@rt_core.validate_user_html_level(config.ROLE_LEVEL_USER)
def html_index(lang = "en"):
    """
    Handles a GET request on "/" or "/<lang>/home" end point to load an HTML page for the Home page.
    """

    try:
        # Render the page
        return rt_core.render_home()

    except Exception as err:
        # Weird, just proceed
        print(err)
        return rt_core.render_home()


@routes.route('/<any(en,fr):lang>/validate', methods=['GET'])
@rt_core.validate_user_html_level(config.ROLE_LEVEL_PUBLISHER)
def html_validate(lang = "en"):
    """
    Handles a GET request on "/" or "/<lang>/validate" end point to load an HTML page for the Home page.
    """

    try:
        # Render the page
        return rt_core.render_page('validate.html', url_prefix='validate')

    except Exception as err:
        # Weird, just proceed
        print(err)
        return rt_core.render_home()


@routes.route('/<any(en,fr):lang>/publish', methods=['GET'])
@rt_core.validate_user_html_level(config.ROLE_LEVEL_PUBLISHER)
def html_publish(lang = "en"):
    """
    Handles a GET request on "/" or "/<lang>/publish" end point to load an HTML page for the Home page.
    """

    try:
        # Render the page
        return rt_core.render_page('publish.html', url_prefix='publish')

    except Exception as err:
        # Weird, just proceed
        print(err)
        return rt_core.render_home()


@routes.route('/<any(en,fr):lang>/unpublish', methods=['GET'])
@rt_core.validate_user_html_level(config.ROLE_LEVEL_PUBLISHER)
def html_unpublish(lang = "en"):
    """
    Handles a GET request on "/" or "/<lang>/publish" end point to load an HTML page for the Home page.
    """

    try:
        # Render the page
        return rt_core.render_page('unpublish.html', url_prefix='unpublish')

    except Exception as err:
        # Weird, just proceed
        print(err)
        return rt_core.render_home()


@routes.route('/<any(en,fr):lang>/data', methods=['GET'])
@rt_core.validate_user_html_level(config.ROLE_LEVEL_ADMIN)
def html_data(lang = "en"):
    """
    Handles a GET request on "/" or "/<lang>/data" end point to load an HTML page for the Home page.
    """

    try:
        # Get all data
        data: dict = cdtk_core.get_info_data()

        # Render the page
        return rt_core.render_page('data.html', url_prefix='data', records=data)

    except Exception as err:
        # Weird, just proceed
        print(err)
        return rt_core.render_home()


@routes.route('/<any(en,fr):lang>/folders', methods=['GET'])
@rt_core.validate_user_html_level(config.ROLE_LEVEL_ADMIN)
def html_folders(lang = "en"):
    """
    Handles a GET request on "/" or "/<lang>/folders" end point to load an HTML page for the Home page.
    """

    try:
        # Get all folders/files
        files: dict = cdtk_core.get_info_files_via_api()

        # Render the page
        return rt_core.render_page('folders.html', url_prefix='folders', records=files)

    except Exception as err:
        # Weird, just proceed
        print(err)
        return rt_core.render_home()


@routes.route('/<any(en,fr):lang>/services', methods=['GET'])
@rt_core.validate_user_html_level(config.ROLE_LEVEL_ADMIN)
def html_services(lang = "en"):
    """
    Handles a GET request on "/" or "/<lang>/services" end point to load an HTML page for the Home page.
    """

    try:
        # Get all folders/files
        services: dict = cdtk_core.get_info_services_via_api()

        # Render the page
        return rt_core.render_page('services.html', url_prefix='services', records=services)

    except Exception as err:
        # Weird, just proceed
        print(err)
        return rt_core.render_home()


@routes.route('/<any(en,fr):lang>/services/<schema>/<service_name>', methods=['GET'])
@rt_core.validate_user_html_level(config.ROLE_LEVEL_PUBLISHER)
def html_service_info(schema: str, service_name: str, lang: str = "en"):
    """
    Handles a GET request on "/" or "/<lang>/services/<schema>/<service_name>" end point to load an HTML page for the Home page.
    """

    try:
        # Redirect
        service_info: dict | None = cdtk_core.get_info_schema_service_via_api(schema, service_name)

        # Render the page
        return rt_core.render_page('service_info.html', url_prefix=f"services/{schema}/{service_name}", record=service_info)

    except Exception as err:
        # Weird, just proceed
        print(err)
        return rt_core.render_home()


@routes.route('/<any(en,fr):lang>/login', methods=['GET'])
def html_login(lang):
    """
    Handles a GET request on "/<lang>/login" end point to load an HTML page with login capabilities for a User.
    """

    try:
        # If not already logged in
        if not auth.current_user():
            # Generate PKCE parameters
            code_verifier: str = MSAuth.generate_code_verifier()
            code_challenge: str = MSAuth.generate_code_challenge(code_verifier)

            # Store the verifier in the user session
            session['code_verifier'] = code_verifier

            # If running local
            if config_env.FAKE_OAUTH:
                # Render the page
                return rt_core.render_page('login.html', auth_url=f"{secret.get_secret_oauth_redirect_uri()}?client_id={secret.get_secret_oauth_id()}&scope={'+'.join(config.SCOPES)}&code_challenge={code_challenge}&code_challenge_method=S256")

            else:
                # Generate the OAuth url
                auth_url: str = auth.generate_url_for_msauth(secret.get_secret_oauth_id(),
                                                             secret.get_secret_oauth_redirect_uri(),
                                                             config.SCOPES, code_challenge)
                # Render the page
                return rt_core.render_page('login.html', auth_url=auth_url)

        else:
            # Already logged in
            return rt_core.redirect_home()

    except Exception as err:
        # Weird, just proceed
        print(err)
        return rt_core.render_page('login.html')


@routes.route('/verify-auth-azure', methods=['GET'])
def html_token():
    """
    Handles a GET request on "/verify-auth-azure" end point used as the redirect_uri for the OAuth2 security.
    """

    try:
        # Read the code
        code: str | None = request.args.get('code')

        # Retrieve the code verifier from the session
        code_verifier: str | None = session.pop('code_verifier', None)

        # If running local
        if config_env.FAKE_OAUTH:
            # Generate a fake token
            fake_token = auth.query_user_and_generate_token(config_env.USER_LOCAL, 'Alex')
            # Redirecting..
            return rt_core.render_page('redirect.html', token=fake_token)

        elif code and code_verifier:
            # Log
            print("Exchanging code for token...")

            # Exchange the code for an access token
            ms_res = auth.exchange_code_for_token(secret.get_secret_oauth_id(),
                                                  secret.get_secret_oauth_secret(),
                                                  secret.get_secret_oauth_redirect_uri(),
                                                  config.SCOPES, code, code_verifier)

            # If the response contains a token
            if 'id_token' in ms_res:
                # Build a payload
                payload = {
                    'microsoft_token': ms_res['id_token'],
                    'client_id': secret.get_secret_oauth_id()
                }

                # Log
                print("Calling our own token service...")
                print(payload)

                # Redirect to the token endpoint
                res = requests.post(f"{config_env.CDTK_PUBLICATION_URL}/token", json=payload)
                print(res)

                # Here, requests has returned something
                if res is not None:
                    # If a 200
                    if res.status_code == 200:
                        # Redirecting..
                        return rt_core.render_page('redirect.html', token=res.json())

                    elif res.status_code == 401:
                        # User not found
                        return rt_core.render_page('basics/denied.html', username=res.json()['title'])

                    elif res.status_code == 400:
                        # Error, no code
                        return rt_core.render_page('basics/denied.html', no_code=True)

            else:
                # Print the error
                print("Error obtaining the 'id_token' from MicrosoftOnline", ms_res)

        # Make the user start over their login process
        return rt_core.redirect_login_straight()

    except Exception as err:
        # Weird, just go back to login page
        print(err)
        return rt_core.redirect_login_straight()


@routes.route('/<any(en,fr):lang>/logout', methods=['GET'])
@rt_core.validate_user_html_level(config.ROLE_LEVEL_USER)
def html_logout(lang):
    """
    Handles a GET request on "/<lang>/logout" end point to load an HTML page indicating the User is being logged out.
    """

    try:
        # Render logout page
        return rt_core.render_page('basics/logout.html')

    except Exception as err:
        # Weird, just proceed
        print(err)
        return rt_core.redirect_home()


@routes.route('/<any(en,fr):lang>/expired', methods=['GET'])
def html_expired(lang):
    """
    Handles a GET request on "/<lang>/expired" end point to load an HTML page indicating the User token has expired or
     is invalid.
    """

    try:
        # Render the page
        return rt_core.render_page('basics/expired.html')

    except Exception as err:
        # Weird, just proceed
        print(err)
        return rt_core.redirect_home()


@routes.route('/<any(en,fr):lang>/denied', methods=['GET'])
def html_denied(lang):
    """
    Handles a GET request on "/<lang>/denied" end point to load an HTML page indicating the User token has
     insufficient permissions.
    """

    try:
        # Render the page
        return rt_core.render_page('basics/denied.html')

    except Exception as err:
        # Weird, just proceed
        print(err)
        return rt_core.redirect_home()


@routes.route('/<any(en,fr):lang>/not_found', methods=['GET'])
def html_not_found(lang) -> Any:
    """
    Handles a GET request on "/<lang>/not_found" end point to load an HTML page indicating the Page couldn't be found.
    """

    try:
        # Render the page
        return rt_core.render_page('basics/not_found.html')

    except Exception as err:
        # Weird, just proceed
        print(err)
        return rt_core.redirect_home()


@routes.route('/<any(en,fr):lang>/profile', methods=['GET'])
@rt_core.validate_user_html_level(config.ROLE_LEVEL_USER)
def html_my_profile(lang):
    """
    Handles a GET request on "/profile" end point to load an HTML page with information on the user profile.
    """

    try:
        # Render the page
        return rt_core.render_page('my_profile.html')

    except Exception as err:
        # Weird, just proceed
        print(err)
        return rt_core.redirect_home()

