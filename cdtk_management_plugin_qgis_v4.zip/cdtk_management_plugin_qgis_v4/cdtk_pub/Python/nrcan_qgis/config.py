"""
This module stores all configurations used by this application.
"""

import os

SUPPORTED_EPSG_CRS: list[int] = [3857, 3978, 3979, 4269, 4326, 4617, 3995, 5937, 32661]
WMS_CRS_LIST: list[str] = ["EPSG:3857", "EPSG:3978", "EPSG:3979", "EPSG:4269", "EPSG:4326", "EPSG:4617", "EPSG:3995", "EPSG:5937", "EPSG:32661"]
WMS_ORGANIZATION_NAME_EN: str = "Government of Canada"
WMS_ORGANIZATION_NAME_FR: str = "Gouvernement du Canada"
WMS_ONLINE_RESOURCE: str = "https://www.geo.ca/"
WMS_CONTACT_EMAIL: str = "geo@nrcan-rncan.gc.ca"
WMS_FEES: str = "No Conditions Apply"
WMS_ACCESS_CONSTRAINTS: str = "License"
MINIMUM_SCALE: int = 50000000
MAXIMUM_SCALE: int = 10
GDAL_S3_VSI_PREFIX: str = "/vsis3/"

def QGIS_PROJECTS_PATH(proj_path: str, filename: str):
    if filename and len(filename) > 0:
        return os.path.join(proj_path, filename)
    return proj_path
