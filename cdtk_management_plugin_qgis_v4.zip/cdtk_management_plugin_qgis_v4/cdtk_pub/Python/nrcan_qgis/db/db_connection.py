"""
This module offers functions to query and manage a Postgresql database.
"""

# 3rd party imports
import urllib.parse
import psycopg2
import psycopg2.extras
from psycopg2.extensions import connection
from psycopg2 import sql

from core.lib.qgis_exceptions import *


def _gen_uri_base(host: str, port: int, db_name: str, user: str, password: str, ssl_mode: str) -> str:
    """
    Helper function to generate a base uri for a database connection for PyQGIS
    """
    return f"host='{host}' port={str(port)} dbname='{db_name}' user='{user}' password='{password}' sslmode={ssl_mode} "


class PyDB(object):
    """
    Class representing a Database connection.
    """

    def __init__(self, host: str, port: int, dbname: str, user: str, password: str) -> None:
        """Constructor"""

        self.host: str = host
        self.port: int = port
        self.dbname: str = dbname
        self.user: str = user
        self.password: str = password


    def open_conn(self) -> connection:
        """
        Connects to the database.

        :returns: A :class:`~psycopg2` connection
        """

        # Connects and returns the connection
        return psycopg2.connect(host=self.host, port=self.port, dbname=self.dbname, user=self.user, password=self.password, sslmode="prefer", connect_timeout=5)


    # def init_schema(self, schema: str) -> bool:
    #     """
    #     Initializes the database schema for the functions in this class
    #     that require a database schema.

    #     :param schema: The database schema
    #     """

    #     # Init the schema
    #     #self.schema = None

    #     # Validate the schema exists in the database
    #     with self.open_conn() as conn:
    #         # Open a cursor
    #         with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
    #             str_query = "SELECT * FROM {table} WHERE UPPER(schema_name) LIKE UPPER(%s);"

    #             # Query in the database
    #             query: sql.Composed = sql.SQL(str_query).format(table=sql.Identifier("information_schema","schemata"))

    #             # Execute cursor and fetch
    #             cur.execute(query, (schema,))
    #             res: psycopg2.extras.RealDictRow | None = cur.fetchone()
    #             if res:
    #                 # Read the schema as-is from the database, because this is case sensitive!
    #                 #self.schema = res['schema_name']
    #                 return True

    #             else:
    #                 #self.schema = None
    #                 raise SchemaNotFound(schema)


    def gen_uri_base(self) -> str:
        return _gen_uri_base(self.host, self.port, self.dbname, self.user, self.password, "allow")


    def gen_uri_export(self, schema: str, table: str, key: str, geometry_column: str, type: str) -> str:
        """
        Helper function to generate a base uri for a table in a database connection in PyQGIS
        """

        # Redirect
        uri: str = self.gen_uri_base()
        return uri + f" table=\"{schema}\".\"{table}\" ({geometry_column}) key='{key}' type={type} "


    def gen_uri_data_source(self, schema: str, table: str, key: str, geometry_column: str, type: str) -> str:
        """
        Helper function to generate a base uri for a table with a srid in a database connection in PyQGIS
        """

        # Redirect
        uri: str = self.gen_uri_export(schema, table, key, geometry_column, type)
        return uri + f" checkPrimaryKeyUnicity='{1}' estimatedmetadata=true "


    def gen_uri_data_source_srid(self, schema: str, table: str, key: str, geometry_column: str, type: str, srid: str) -> str:
        """
        Helper function to generate a base uri for a table with a srid in a database connection in PyQGIS
        """

        # Redirect
        uri: str = self.gen_uri_data_source(schema, table, key, geometry_column, type)
        return uri + f" srid={srid} "


    def gen_uri_storage_schema(self, schema: str) -> str:
        """
        Helper function to generate a base uri for the storage in PyQGIS
        """

        return f"postgresql://{urllib.parse.quote(self.user)}:{urllib.parse.quote(self.password)}@{self.host}:{self.port}?dbname={self.dbname}&schema={schema}"


    def gen_uri_project(self, schema: str, qgis_project_id: str) -> str:
        """
        Helper function to generate a base uri for a PyQGIS project stored within the storage in PyQGIS
        """

        return f"{self.gen_uri_storage_schema(schema)}&project={qgis_project_id}"



    def table_exists(self, schema_name: str, table_name: str) -> bool:
        """
        Utility function to check if a table exists in the database.
        """

        # Connect to the database
        with self.open_conn() as conn:
            # Open a cursor
            with conn.cursor() as cur:
                # Query in the database
                query: sql.Composed = sql.SQL("SELECT * FROM {table};").format(
                    table=sql.Identifier(schema_name, table_name))

                exists = False
                try:
                    # Execute cursor
                    cur.execute(query)
                    exists = True

                except Exception as err:
                    pass

                return exists
        return False


    def save_layer_style_finalize(self, style_name: str, type_str: str) -> None:
        """
        Utility function to quickly open an SQL connection and drop the table with the given name.
        """

        # Connect to the database
        with self.open_conn() as conn:
            # Open a cursor
            with conn.cursor() as cur:
                # The update query
                str_query = """UPDATE {layer_styles_table}
                               SET type = %s
                               WHERE stylename = %s;
                            """

                # Query in the database
                query: sql.Composed = sql.SQL(str_query).format(
                    layer_styles_table=sql.Identifier("public", "layer_styles"))

                # Execute cursor
                res = cur.execute(query, (type_str, style_name,))

            # Commit
            conn.commit()



    def rename_table_go(self, cur, schema: str, table_name_og: str, table_name_new: str) -> None:
        """
        Drops a table from the database by running the "ALTER TABLE RENAME TO ..." SQL command.
        """

        # The drop query
        str_query = "ALTER TABLE {table_og} RENAME TO {table_new};"

        # Query in the database
        query: sql.Composed = sql.SQL(str_query).format(
            table_og=sql.Identifier(schema, table_name_og),
            table_new=sql.Identifier(table_name_new))

        # Execute cursor
        #print(f"RENAMING TABLE FROM {table_og} TO {table_new}")
        cur.execute(query)


    def drop_table_go(self, cur, schema: str, table_name: str) -> None:
        """
        Drops a table from the database by running the "DROP TABLE IF EXISTS ..." SQL command.
        """

        # The drop query
        str_query = "DROP TABLE IF EXISTS {table};"

        # Query in the database
        query: sql.Composed = sql.SQL(str_query).format(
            table=sql.Identifier(schema, table_name))

        # Execute cursor
        #print(f"DROPPING TABLE {table_name}")
        cur.execute(query)


    def create_spatial_index_go(self, cur, schema: str, table_name: str, index_name: str) -> None:
        """
        Creates a spatial index on the given table by running the "CREATE INDEX ... USING GIST(geom)" SQL command.
        """

        # The drop query
        str_query = "CREATE INDEX {index_name} ON {table_name} USING GIST(geom);"

        # Query in the database
        query: sql.Composed = sql.SQL(str_query).format(
            index_name=sql.Identifier(index_name),
            table_name=sql.Identifier(schema, table_name))

        # Execute cursor
        cur.execute(query)


    def drop_index_go(self, cur, schema: str, index_name: str) -> None:
        """
        Drops an index from the database by running the "DROP INDEX IF EXISTS ..." SQL command.
        """

        # Drop the index so the new table can use it
        str_query = "DROP INDEX IF EXISTS {index_name};"

        # Query in the database
        query: sql.Composed = sql.SQL(str_query).format(
            index_name=sql.Identifier(schema, index_name))

        # Execute cursor
        cur.execute(query)


    def rename_layer_style_go(self, cur, schema: str, table_name_og: str, table_name_new: str) -> None:
        # The update query
        str_query = """UPDATE {layer_styles_table}
                       SET f_table_name = %s
                       WHERE f_table_schema = %s AND f_table_name = %s;
                    """

        # Query in the database
        query: sql.Composed = sql.SQL(str_query).format(
            layer_styles_table=sql.Identifier("public", "layer_styles"))

        # Execute cursor
        res = cur.execute(query, (table_name_new, schema, table_name_og,))


    def delete_layer_style_go(self, cur, schema: str, table_name: str) -> None:
        """
        Utility function to delete a layer style for a given table name.
        """

        # The update query
        str_query = """DELETE FROM {layer_styles_table}
                       WHERE f_table_schema = %s AND f_table_name = %s;
                    """

        # Query in the database
        query: sql.Composed = sql.SQL(str_query).format(
            layer_styles_table=sql.Identifier("public", "layer_styles"))

        # Execute cursor
        res = cur.execute(query, (schema, table_name,))

