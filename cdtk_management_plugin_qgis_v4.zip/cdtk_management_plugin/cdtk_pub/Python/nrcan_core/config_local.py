"""
This module stores all configurations used by this application.
"""

import logging

# If the environment is local
ENV_NAME: str = 'LOCAL'
IS_LOCAL: bool = True
FAKE_OAUTH: bool = False
TRICK_ENV_VARIABLE_FOR_RANCHER = False
USER_LOCAL: str = 'alexandre.roy@nrcan-rncan.gc.ca'  # This config is only used when debugging. It does not exist for other environments.
DEBUG_SUBPROCESS: bool = False  # If true, the subprocess running the PyQGIS script will show debug information on the console

# The log parameters
LOG_NAME: str = "cdtk_log"
LOG_FILE: str = "output.log"
LOG_LEVEL_CONSOLE: int = logging.DEBUG
LOG_LEVEL_FILE: int = logging.DEBUG  # 5  # Trace level

# Determine if setting allow-origin for CORS
USE_CORS: bool = True

# Running port
PORT_API: int = 5031
PORT_WEB: int = 5030

# Secret key
SECRET_KEY: str = "cdtk-api-publication-local"
DB_QGIS_KEY: str = "cdtk-postgis-datastore-dev"

# TODO: TEMPORARY CONFIGS, TO DISCUSS HOW TO GET IT FOR THE WEB INTERFACE
IAM_ROLE: str = 'arn:aws:iam::042025765691:role/fgp-ddr-dev-s3-ftp-rw-role'
BUCKET_NAME: str = 'dev-ftp-maps-canada-ca'

# For the WEB interface to call the API
API_URL: str = "http://localhost:5031/api"
# For the WEB interface to indicate url to user
WEB_REGISTRY_URL: str = "http://localhost:5020"

# For the WEB interface to call pygeoapi
PYGEOAPI_URL: str = "http://localhost:5000"

# CDTK Registry and Publication URLs for internal communication
CDTK_REGISTRY_URL: str = "http://registry_api:5021/api"
CDTK_PUBLICATION_URL: str = "http://publication_api:5031/api"
# CDTK QGIS Server URL for internal communication to get the QGIS Server version
CDTK_QGIS_SERVER_GET_VERSION_URL: str = "http://qgis-server:80/ows/get/version?"

# Email configs
EMAIL_ADMIN_CONTENT: list[str] = [] # Ignored when running local (in config_env)
EMAIL_TIMEOUT: int = 5

# QGIS configs
QGIS_JOBS_PATH: str = "..\\jobs"
QGIS_IN_PACKAGES_PATH: str = "..\\in_packs"
QGIS_PROJECTS_PATH: str = "..\\data"
QGIS_PYTHON_PATH: str = "nrcan_qgis"
