from abc import ABC, abstractmethod
from typing import Any

from nrcan_core import secret, config_env
from nrcan_core.requests.cdtk_request_registry_api import CDTKRequestRegistryAPI
from nrcan_core.lib.pyqgis_runner import run_pyqgis
from nrcan_core.lib.cdtk_message import CDTKMessage
from nrcan_core.lib.control_file import ControlFile
from nrcan_core.lib.exceptions import *

# Get the log
from core.lib.logger import get_log
LOG = get_log(config_env.LOG_NAME)

class AbstractService(ABC):
    """Abstract class from which all the published services of derived"""

    # Use __slots__ to disable dynamic attribute creation in order to control them at the class level
    __slots__: list[str] = ['operation', 'control_file', 'message', 'cdtk_request',
                            'department_info', 'publisher_info', 'dataset_id',
                            'publication_started', 'publication_ended', 'registry_started', 'registry_ended']


    def __init__(self, operation: str, control_file: ControlFile) -> None:
        """Constructor"""

        self.operation = operation
        self.control_file: ControlFile = control_file  # The control file
        self.message: CDTKMessage = control_file.message  # Message object that contains: progress marks, warnings and errors
        self.cdtk_request = CDTKRequestRegistryAPI(secret.get_secret_api_registry_api_key(), self.message)
        self.department_info: dict | None = None  # Dictionary containg the department information, only populated once validated
        self.publisher_info: dict | None = None  # Dictionary containg the publisher information, only populated once validated
        self.dataset_id: str | None = None  # Dataset id
        self.publication_started: bool = False  # Flag indicating if the process started in the CDTK Publication
        self.publication_ended: bool = False  # Flag indicating if the process ended in the CDTK Publication
        self.registry_started: bool = False  # Flag indicating if the process started in the CDTK Registry
        self.registry_ended: bool = False  # Flag indicating if the process ended in the CDTK Registry


    def get_service_name(self) -> str:
        """
        Gets the service name for this class
        """

        # Return the service name
        return self.__class__.__name__


    def validate_service(self) -> bool:
        """
        Validates a service. All the control file must be validated to allow to push the service.
        (publish, unpublish or update) to go without errors.
        """
        LOG.trace_func()

        # print(f"Validating service {self.get_service_name()}...")

        # Redirect to overridable method
        return self.on_validate_service(self.operation)


    def process_validation(self) -> dict | None:
        """
        Processes the validation check on the service.
        """
        LOG.trace_func()

        # print(f"Processing service {self.get_service_name()}...")

        # If service is present
        if self.is_service_present():
            # Mark progress
            self.message.add_progress(f"SERVICE {self.get_service_name()} STARTED", f"SERVICE {self.get_service_name()} DÉMARRÉ")

            # Redirect to overridable method
            return self.on_process_validation(self.operation)

        # Nothing, empty dictionnary
        return None


    def process_service(self) -> None:
        """
        Processes the validated service in the registry and publication databases.
        """
        LOG.trace_func()

        # print(f"Processing service {self.get_service_name()}...")

        # If service is present
        if self.is_service_present():
            # Mark progress
            self.message.add_progress(f"SERVICE {self.get_service_name()} STARTED", f"SERVICE {self.get_service_name()} DÉMARRÉ")

            # Redirect to overridable method
            return self.on_process_service(self.operation)

        # Nothing to process
        return None


    def get_publisher(self) -> dict | None:
        """
        Gets the publisher information based on the given email
        """
        LOG.trace_func()

        return self.cdtk_request.get_publisher(self.control_file.get_email())


    def get_publisher_name_or_email(self) -> str:
        """
        Gets the publisher name or at least their email as written in the control file
        """
        LOG.trace_func()

        publisher: dict | None = self.get_publisher()
        if publisher:
            return publisher['name']
        return self.control_file.get_email() or "Unknown"


    def get_html_services_list(self) -> tuple[str, str]:
        """
        Extracts a an html report which summerizes the work done.
        """
        LOG.trace_func()

        # If service is present
        if self.is_service_present():
            # Redirect to overridable method
            return self.on_get_html_services_list(self.operation)

        # Default
        return ("", "")


    def rollback_service(self) -> None:
        """
        Rollbacks the service process.
        """
        LOG.trace_func()

        # Start rollback process
        if self.is_service_present():
            # Track progress
            self.message.add_progress(f"Rollback process activated for '{self.get_service_name()}'",
                                      f"Processus de retour en arrière activé pour '{self.get_service_name()}'")

            # Redirect to overridable method
            self.on_rollback_service(self.operation)

            # Track progress
            self.message.add_progress(f"Rollback process terminated for '{self.get_service_name()}'",
                                      f"Processus de retour en arrière terminé pour '{self.get_service_name()}'")


    @abstractmethod
    def on_validate_service(self, operation: str) -> bool:
        """
        Overridable method to perform service validation.
        This function performs generic validations.
        """
        LOG.trace_func()

        # Start by normalizing the control file for the service
        self.on_normalize_control_file()

        # Get access token to CDTK registry
        self.message.add_progress("Testing communication with CDTK Registry.",
                                  "Test du canal de communication avec le Registre CDTK.")

        # Validate the department exists
        dept_info: dict | None = self._validate_department_exists(self.control_file.get_department())
        if dept_info:
            self.department_info = dept_info

        # Validate the publisher exists and linked to the department
        self._validate_publisher_exists_and_department(self.control_file.get_email(), self.control_file.get_department())

        # Validate the dataset exists for this department
        dataset_info = self._validate_dataset_department(self.control_file.get_metadata_uuid(), self.control_file.get_department())

        self._validate_dataset_name(self.control_file.get_dataset_name(), dataset_info)

        return True


    @abstractmethod
    def on_validate_server_type(self, server_type: str) -> bool:
        """
        Overridable method to return True or False depending if the server information is valid for the service.
        """
        LOG.trace_func()

        # Default not implemented (has to be implemented by child class)
        raise NotImplementedError()


    @abstractmethod
    def on_normalize_control_file(self) -> None:
        """
        Overridable method to normalize a section in the control file. This function performs generic normalizations.
        """
        LOG.trace_func()

        # Check children classes implementations for more
        return


    @abstractmethod
    def is_service_present(self) -> bool:
        """
        Overridable method to return True or False depending if the service is present in the control file.
        """
        LOG.trace_func()

        # Default false
        return False


    @abstractmethod
    def on_process_validation(self, operation: str) -> dict:
        """
        Must-override method to process a service validation.
        """
        LOG.trace_func()

        # Default not implemented (has to be implemented by child class)
        raise NotImplementedError()


    @abstractmethod
    def on_process_service(self, operation: str) -> None:
        """
        Must-override method to process a service.
        """
        LOG.trace_func()

        # Default not implemented (has to be implemented by child class)
        raise NotImplementedError()


    @abstractmethod
    def on_get_html_services_list(self, operation: str) -> tuple[str, str]:
        """
        Overridable method to build an html report which summerizes the work done.
        """
        LOG.trace_func()

        # Default
        return ("", "")


    @abstractmethod
    def on_rollback_service(self, operation: str) -> None:
        """
        Must-override method called when the service needs to rollback cleanly all the transactions
        done in the registry and publication databases.
        """
        LOG.trace_func()

        # Default not implemented (has to be implemented by child class)
        raise NotImplementedError()


    def _validate_department_exists(self, dept_acrn_en: str) -> dict | None:
        """
        Validates if the department exists.
        """
        LOG.trace_func()

        # Get the department info
        dept_info: dict | None = self.cdtk_request.get_department(dept_acrn_en)

        # If found
        if dept_info:
            return dept_info

        else:
            # Not found
            self.message.add_error(f"The department with the English TBS acronym '{dept_acrn_en}' does not exists in the CDTK Registry",
                                   f"Le département dont l'acronyme anglais du TBS est '{dept_acrn_en}' n'existe pas dans le registre du CDTK")

        return None


    def _validate_publisher_exists_and_department(self, email: str, dept_acrn_en: str) -> str | None:
        """
        Validates if the publisher has permissions to perform an operation on that department.
        """
        LOG.trace_func()

        # Get the publisher information
        pub_info: dict | None = self.cdtk_request.get_publisher(email)

        # If the publisher exists
        if pub_info:
            # Keep it
            self.publisher_info = pub_info

            # Check if the publisher is linked to the department
            depts_for_publisher: list[dict] = self.cdtk_request.get_departments_by_publisher(email)

            # If exists
            if dept_acrn_en.lower() in [x['tbs_dept_acrn_en'].lower() for x in depts_for_publisher]:
                # Return the publisher full name
                return self.publisher_info['name']

            else:
                self.message.add_error(f"Publisher with email '{email}' is not allowed to publish for department '{dept_acrn_en}'",
                                       f"L'éditeur avec le email '{email}' n'est pas autorisé à publier pour le ministère '{dept_acrn_en}'")

        else:
            # Not found
            self.message.add_error(f"The publisher '{email}' couldn't be validated",
                                   f"L'éditeur '{email}' n'a pu être validé")

        return None


    def _validate_dataset_department(self, metadata_uuid: str, dept_acrn_en: str) -> dict | None:
        """
        Validates that the dataset department correspond to the department in the control file.
        """
        LOG.trace_func()

        # Get the dataset information
        dataset_info: dict | None = self.cdtk_request.get_dataset(metadata_uuid)

        # If found the dataset
        if dataset_info:
            # Get the department id for the dataset
            dept_id: str = dataset_info['department_id']

            # Get the dataset id which will be returned if all goes well
            dataset_id: str = dataset_info['dataset_id']

            # Get the department by department id
            departments: list[dict] = self.cdtk_request.get_departments_by_dept_id(dept_id)

            # If found
            if len(departments) == 1:
                # If the department of the existing metadata uuid is the same as the department in the control file
                if departments[0]['tbs_dept_acrn_en'].lower() == dept_acrn_en.lower():
                    self.dataset_id = dataset_id

                else:
                    self.message.add_error(f"Dataset with metadata uuid '{metadata_uuid}' already exist in the CDTK registry and is associated to another department than requested",
                                           f"Le jeu de données associé à la métadonnée '{metadata_uuid}' existe déjà dans le registre du CDTK et est associé à un autre ministère que celui demandé")

            else:
                self.message.add_error(f"Dataset with metadata '{metadata_uuid}' couldn't be validated with the department information '{dept_acrn_en}'",
                                       f"Le jeu de données avec metadonnée '{metadata_uuid}' n'a pu être validé avec les informations du ministère '{dept_acrn_en}'")

        else:
            # Dataset with metadata doesn't exist, it'll be created, fine
            # Keep track
            self.dataset_id = "CREATE_IT"
            self.message.add_progress(f"A new record will be created in the dataset table with '{metadata_uuid}' as value for the metadata_id field",
                                      f"Un nouvel enregistrement sera créé dans la table dataset avec '{metadata_uuid}' comme valeur pour le champ metadata_id")

        return dataset_info

    def _validate_dataset_name(self, dataset_name: str, dataset_info: dict | None) -> None:
        """
        Validates that the dataset_name correspond to the dataset_name in the control file.
        """
        LOG.trace_func()

        # If found the dataset
        if dataset_info:
            # Get the department id for the dataset
            if dataset_name != dataset_info['dataset_name']:
                self.message.add_error(f"Dataset with metadata uuid '{dataset_info['metadata_id']}' already exist in the CDTK Registry with the Name '{dataset_info['dataset_name']}', which is different than the one requested ('{dataset_name}')",
                                           f"Le jeu de données associé à la métadonnée '{dataset_info['metadata_id']}' existe déjà dans le registre du CDTK avec le nom '{dataset_info['dataset_name']}', qui est différent que celui demandé ('{dataset_name}')")


    def _validate_server_id_exists(self, server_id: str) -> dict | None:
        """
        Validates if the server id exist and if the server type is well associaqted with the service name.
        """
        LOG.trace_func()

        # Get the server id content
        server_info: dict | None = self.cdtk_request.get_server(server_id)

        # If found
        if server_info:
            # Get the server type
            server_type: str = server_info['server_type']

            # Validate the server type is valid for the name of the service
            if not self.on_validate_server_type(server_type):
                # Not valid
                self.message.add_error(f"Combination of service name '{self.get_service_name()}' and server type '{server_type}' is invalid.",
                                       f"La combinaison de service name '{self.get_service_name()}' et server type '{server_type}' est invalide.")

        else:
            # Server info not found
            self.message.add_error(f"Server ID '{server_id}' does not exist in the CDTK Registry.",
                                   f"Le serveur avec l'identifiant '{server_id}' n'existe pas dans le registre du CDTK.")

        return server_info


    def _validate_datastore_id_exists(self, datastore_id: str) -> dict | None:
        """
        Extracts the requested datastore ID. Once extracted the field 'hosting' is added to determine if
        the datastore is 'INTERNAL' or 'EXTERNAL'.
        """
        LOG.trace_func()

        # Get the datastore info
        datastore_info: dict | None = self.cdtk_request.get_datastore(datastore_id)

        # If found
        if datastore_info:
            # Check if special hosting attribute is there
            if not 'hosting' in datastore_info:
                self.message.add_error(f"The 'datastore_type' key is invalid '{datastore_info['datastore_type']}' (ID: '{datastore_id}')",
                                       f"La clé 'datastore_type' est invalide: '{datastore_info['datastore_type']}' (ID: '{datastore_id}')",)

        else:
            # Not found
            self.message.add_error(f"The datastore with ID '{datastore_id}' does not exist in the CDTK Registry",
                                   f"Le site de téléchargement avec l'identifiant '{datastore_id}' n'existe pas dans le registre du CDTK")

        return datastore_info


    @staticmethod
    def is_datastore_internal(datastore) -> bool:
        """
        Indicates if the provided datastore is for internal data (or external)
        """
        LOG.trace_func()

        if 'hosting' in datastore:
            return datastore['hosting'] == 'INTERNAL'

        else:
            raise Exception('Invalid datastore to check if internal')

    @staticmethod
    def run_pyqgis(operation: str, run_file: dict, internal: bool, db_secret_key_data: str, message: CDTKMessage | None = None) -> Any:
        # Extract the credentiels for the postgres vector datastore
        db_secret_value: dict = secret.get_secrets_db_qgis()
        host_qgis: str = db_secret_value['host']
        port_qgis: str = db_secret_value['port']
        dbname_qgis: str = db_secret_value['dbname']
        user_qgis: str = db_secret_value['user']
        password_qgis: str = db_secret_value['password']

        db_secret_value = secret.get_secrets_by_key(db_secret_key_data)
        host_data: str = db_secret_value['host']
        port_data: str = db_secret_value['port']
        dbname_data: str = db_secret_value['dbname']
        user_data: str = db_secret_value['user']
        password_data: str = db_secret_value['password']

        # Run PyQGIS to read and validate the project file
        return run_pyqgis(operation, run_file, secret.get_secret_bucket_name(), secret.get_secret_bucket_prefix(), internal,
                          host_qgis, int(port_qgis), dbname_qgis, user_qgis, password_qgis,
                          host_data, int(port_data), dbname_data, user_data, password_data,
                          message)
