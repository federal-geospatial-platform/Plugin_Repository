# Python import
import json
import os
from typing import Any
import zipfile

# Application import
from botocore.exceptions import ClientError
from core.lib import aws
from nrcan_core import config, secret
from nrcan_core.lib.cdtk_message import CDTKMessage


class CDTKS3Bucket(object):
    """Class containing the methods needed to manipulate download data in the S3 Bucket"""

    # Use __slots__ to disable dynamic attribute creation in order to control them at the class level
    __slots__: list[str] = ['region_name', 'tbs_dept_acrn_en', 'tbs_dept_acrn_fr', 'core_subject_term', 'folder_name', 'secret_name', 'message',
                            'download_root_subpath', 'subfolder_name']

    def __init__(self, region_name: str, tbs_dept_acrn_en: str, tbs_dept_acrn_fr: str, core_subject_term: str, folder_name: str, secret_name: str, message: CDTKMessage) -> None:
        """Constructor"""

        # Save parameters
        self.region_name: str = region_name
        self.tbs_dept_acrn_en: str = tbs_dept_acrn_en.lower()  # English department acronym
        self.tbs_dept_acrn_fr: str = tbs_dept_acrn_fr.lower()  # French department acronym
        self.folder_name: str = folder_name  # Name of the folder
        self.secret_name: str = secret_name  # The secret name
        self.core_subject_term: str = core_subject_term  # Name of the core subject term
        self.message: CDTKMessage = message  # Message object: for progress, error, warning
        self.download_root_subpath: str | None = None  # Name of the download root path (to be set)
        self.subfolder_name: str | None = None  # Name of the sub folfer (to be set)

        # Extract the secret for the S3 bucket
        self._extract_secret_sftp(secret_name)


    def _extract_secret_sftp(self, secret_name: str) -> None:
        """Extract the key/value from the secret for the SFTP connection"""

        try:
            # Query Secrets
            secret_json: dict = secret.get_secrets_by_key(secret_name)

            # Read Secret
            self.download_root_subpath = secret_json['bucket_name']
            self.subfolder_name = secret_json['subfolder_name']

        except ClientError as err:
            self.message.add_error(f"Unable to read AWS secret name: {secret_name}",
                                   f"Impossible d'extraire le nom secret AWS: {secret_name}",
                                   err)


    def list_bucket(self, filter_prefix: str | None = None) -> Any:
        """List the content of a S3 bucket"""

        # If initialized
        if self.download_root_subpath:
            # Redirect
            return aws.list_bucket(self.download_root_subpath, filter_prefix)

        raise RuntimeError("Trying to list_bucket without being initialized")


    # def try_update_download_package(self, control_file: dict, message: CDTKMessage):

    #     try:
    #         # Backup the download package
    #         backup_download_package(control_file, message)

    #         # Save the download package
    #         save_download_package(control_file, message)

    #         # Clean the download package backup
    #         clean_download_package(control_file, message)

    #     except Exception as err:
    #         # Restore the backup
    #         restore_download_package(control_file, message)
    #         raise


    def save_download_package(self, control_file: dict) -> None:

        # If initialized
        if self.download_root_subpath:
            # Get S3 path
            s3_path_prefix: str = self.get_download_path(False, None)

            try:
                # Keep track
                self.message.add_progress("Extracting and saving download package to FTP",
                                          "Extraction et sauvegarde du paquet de téléchargement dans le FTP")

                # Set the destination folder and zip file path
                dest_path: str = config.QGIS_PROJECTS_PATH(self.folder_name)

                # If the folder doesn't exist, create it
                if not os.path.exists(dest_path):
                    os.makedirs(dest_path)

                # Extract the zip content in the folder
                zip_path: str = dest_path + ".zip"
                with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                    for info in zip_ref.infolist():
                        # Extract the file
                        zip_ref.extract(info, dest_path)

                # Upload the folder to S3
                aws.upload_bucket_folder(self.download_root_subpath, dest_path, s3_path_prefix)

                # Keep track
                self.message.add_progress(f"Download package saved to {s3_path_prefix}/{self.folder_name}",
                                          f"Paquet de téléchargement sauvegardé dans {s3_path_prefix}/{self.folder_name}")

            except Exception as err:
                # Failed saving download package, unregister from CDTK and unpublish everything
                self.message.add_progress("ERROR when saving download package, reverting. " + str(err),
                                          "ERREUR lors de la sauvegarde du paquet de téléchargement, retour arrière. " + str(err))

                # ROLLBACK, cascade
                pass

                # TODO: Check if this is still working? It seems that this change, which happened during the classes refactoring, wasn't tested correctly with
                # the new services classes, hence why it was probably set to 'pass' just above, normal?

                # Delete the folder
                aws.delete_bucket_folder(control_file['process_parameters']['download_info']['download_root_path'],
                                         f"{s3_path_prefix}/{control_file['generic_parameters']['download_package_name']}")

                # Keep raising err
                raise err

        else:
            raise RuntimeError("Trying to save_download_package without being initialized")


    # def backup_download_package(self, control_file: dict, message: CDTKMessage):

    #     # Keep track
    #     message.add_progress("Backuping download package in FTP",
    #                         "Copie de sauvegarde du paquet de téléchargement du FTP")

    #     # Get S3 path
    #     s3_path_prefix = util.get_download_path(control_file, True, None)
    #     s3_path_prefix_backup = util.get_download_path(control_file, True, "_bck_")

    #     # Copy download package
    #     aws.copy_bucket_folder(control_file['process_parameters']['download_info']['download_root_path'],
    #                         s3_path_prefix,
    #                         control_file['process_parameters']['download_info']['download_root_path'],
    #                         s3_path_prefix_backup,
    #                         control_file['process_parameters']['download_info']['owner_username'],
    #                         True)


    # def restore_download_package(self, control_file: dict, message: CDTKMessage):

    #     # Keep track
    #     message.add_progress("Restoring the download package backup in FTP",
    #                         "Récupération de la copie de sauvegarde du paquet de téléchargement du FTP")

    #     # Get S3 path
    #     s3_path_prefix_restore = util.get_download_path(control_file, True, "_bck_")
    #     s3_path_prefix = util.get_download_path(control_file, True, None)

    #     # Copy download package
    #     aws.copy_bucket_folder(control_file['process_parameters']['download_info']['download_root_path'],
    #                         s3_path_prefix_restore,
    #                         control_file['process_parameters']['download_info']['download_root_path'],
    #                         s3_path_prefix,
    #                         control_file['process_parameters']['download_info']['owner_username'],
    #                         True)


    # def clean_download_package(self, control_file: dict, message: CDTKMessage) -> None:
    #     """
    #     Cleans the download package in the FTP S3 bucket
    #     """

    #     # Keep track
    #     message.add_progress("Cleaning the download package backup from FTP",
    #                          "Nettoyage de la copie de sauvegarde du paquet de téléchargement du FTP")

    #     # Get S3 path
    #     s3_path_prefix = util.get_download_path(control_file, False, None)

    #     # Copy download package
    #     aws.delete_bucket_folder(control_file['process_parameters']['download_info']['download_root_path'],
    #                              s3_path_prefix,
    #                              "_bck_" + control_file['generic_parameters']['download_package_name'])


    def delete_download_package(self) -> None:
        """
        Deletes a download package in the FTP S3 bucket
        """

        # If initialized
        if self.download_root_subpath:
            # Keep track
            self.message.add_progress("Deleting download package from FTP",
                                      "Suppression du paquet de téléchargement du FTP")

            # Get S3 path
            s3_path_prefix = self.get_download_path(False, None)

            # Delete the folder from S3
            aws.delete_bucket_folder(self.download_root_subpath, f"{s3_path_prefix}/{self.folder_name}")

        else:
            raise RuntimeError("Trying to delete_download_package without being initialized")


    def get_download_path(self, with_package_name: bool, with_prefix: str | None) -> str:
        """
        Adjusts the download path
        """

        path = f"{self.subfolder_name}/{self.tbs_dept_acrn_en}_{self.tbs_dept_acrn_fr}/{self.core_subject_term}"

        if with_package_name:
            if with_prefix and len(with_prefix) > 0:
                path = f"{path}/{with_prefix}{self.folder_name}"
            else:
                path = f"{path}/{self.folder_name}"

        return path.replace("//", "/")
