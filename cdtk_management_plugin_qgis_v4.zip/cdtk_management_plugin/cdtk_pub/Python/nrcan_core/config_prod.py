"""
This module stores all configurations used by this application.
"""

import logging

# Environment name
ENV_NAME: str = 'PROD'
IS_LOCAL: bool = False
DEBUG_SUBPROCESS: bool = False  # If true, the subprocess running the PyQGIS script will show debug information on the console

FAKE_OAUTH: bool = False

# The log parameters
LOG_NAME: str = "cdtk_log"
LOG_FILE: str = "output.log"
LOG_LEVEL_CONSOLE: int = logging.INFO
LOG_LEVEL_FILE: int = logging.INFO

# Running port
PORT_API: int = 5031
PORT_WEB: int = 5030

# Secret key
SECRET_KEY: str = "cdtk-api-publication-prod"
DB_QGIS_KEY: str = "cdtk-postgis-datastore-prod"

# For the WEB interface to call the API
API_URL: str = "http://10.68.130.138:5031/api"
# For the WEB interface to indicate url to user
WEB_REGISTRY_URL: str = "https://reg-web.cdtk.geogc.ca"
# For the WEB interface to call pygeoapi
PYGEOAPI_URL: str = "https://pygeoapi.cdtk.geogc.ca/"

# CDTK Registry and Publication URLs for internal communication
CDTK_REGISTRY_URL: str = "http://cdtk-registry-api:5021/api"
CDTK_PUBLICATION_URL: str = "http://cdtk-publication-api:5031/api"

# Email configs
EMAIL_ADMIN_CONTENT: list[str] = ["geodiscoverydatadissemination-diffusiondesdonneesgeodecouverte@nrcan-rncan.gc.ca"]
EMAIL_TIMEOUT = 5

# QGIS configs
QGIS_JOBS_PATH: str = "..\\jobs"
QGIS_IN_PACKAGES_PATH: str = "..\\in_packs"
QGIS_PROJECTS_PATH: str = "..\\data"
QGIS_PYTHON_PATH: str = "nrcan_qgis"
