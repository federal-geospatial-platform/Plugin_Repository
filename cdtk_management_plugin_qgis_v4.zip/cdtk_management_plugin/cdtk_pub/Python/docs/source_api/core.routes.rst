core.routes package
===================

Submodules
----------

core.routes.rt\_core module
---------------------------

.. automodule:: core.routes.rt_core
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: core.routes
   :members:
   :undoc-members:
   :show-inheritance:
