//
// CDTK Publication JavaScript
//

// function loginUser(username, password, lang, redirect_uri, failedCallback) {
//     // Call the web login
//     callWEB("post", "/login", {
//         username: username,
//         password: password
//     },
//     function(res) {
//         // Store the cookie
//         Cookies.set(document.___API_COOKIE_KEY, res.access_token);

//         // Redirects
//         if (redirect_uri) {
//             // Redirect there
//             window.location.replace(redirect_uri);
//         }

//         else {
//             // Return home
//             redirectHome(lang);
//         }
//     }, failedCallback);
// }

function logoutUser(lang) {
    // Call the API logout
    callAPI("delete", "/logout", null,
    function() {
        // Clear the API token
        Cookies.set(document.___API_COOKIE_KEY, "", -1);

        // Return home
        redirectHome(lang);
    });
}

function createUser(paramsJson, successCallback, failedCallback) {
    // Call the API
    callAPI("put", "/users", paramsJson,
            successCallback, failedCallback);
}

function updateUser(username, paramsJson, successCallback, failedCallback) {
    // Call the API
    callAPI("patch", "/users/" + username, paramsJson,
            successCallback, failedCallback);
}

function deleteUser(username, successCallback, failedCallback) {
    // Call the API
    callAPI("delete", "/users/" + username, null,
            successCallback, failedCallback);
}

function showPubUnpubProgress() {
    $(".progress_indicator").removeClass("hidden");
    $(".progress_indicator")[0].scrollIntoView();
}

function hidePubUnpubProgress() {
    $(".progress_indicator").addClass("hidden");
}

function deleteData(schema, table_name, successMessage) {
    // Redirect to the core
    deleteCore("/data/" + schema + "/" + table_name, schema + "-" + table_name, null, successMessage);
}

function deleteService(schema, service_name, successMessage) {
    // Redirect to the core
    deleteCore("/services/" + schema + "/" + service_name, schema + "-" + service_name, null, successMessage);
}

function deleteFolder(datastore_id, schema, core_sub, folder, successMessage) {
    // Redirect to the core
    deleteCore("/folders",
        datastore_id + "-" + schema + "-" + core_sub + "-" + folder,
        {
            datastore_id: datastore_id,
            schema: schema,
            core_subject_term: core_sub,
            folder_name: folder
        },
        successMessage);
}

function deleteCore(url, key, payload, successMessage) {
    // Redirect
    hideAlerts();

    // Hide the delete and show a progress instead
    $("#row-" + key).addClass("hidden");
    $("#row-prog-" + key).removeClass("hidden");

    // Call the API
    callAPI("delete", url, payload,
        () => {
            // Hide the progress
            $("#row-prog-" + key).addClass("hidden");

            // Delete the row
            // $("#row-" + key).parents('.data-row').remove();

            // Show the success
            showSuccess(successMessage);
        }, (err) => {
            // Hide the progress
            $("#row-prog-" + key).addClass("hidden");

            // Re-show the delete button
            $("#row-" + key).removeClass("hidden");

            // Show the error
            showError(err);
        });
}

function showSuccess(message) {
    $(".alert").addClass("hidden");
    $("#alert-success").removeClass("hidden");
    $("#alert-success p").html(message || "Success!");
}

function showError(message) {
    $(".alert").addClass("hidden");
    $("#alert-danger").removeClass("hidden");

    // If the message is actually an array of messages
    $("#alert-danger p").html(message || "Error!");
    if (Array.isArray(message)) {
        $("#alert-danger p").html(message.join('<br/>') || "Error!");
    }

    $("#alert-danger")[0].scrollIntoView();
}

function hideAlerts() {
    $(".alert").addClass("hidden");
}

function showErrorFromAPIResponse(body, lang) {
    if ('detail' in body && 'detail_fr' in body) {
        // Depending on the language
        if (lang == 'fr') {
            // French
            const message = body['detail_fr']
            const messages = message.split(/\r?\n/);
            showError(messages);
        } else {
            // Default
            const message = body['detail']
            const messages = message.split(/\r?\n/);
            showError(messages);
        }
    }

    else {
        showError(body['title']);
    }
}

function redirectHome(lang) {
    if (lang == "fr")
        window.location.replace("/fr/home");
    else
        window.location.replace("/en/home");
}

function _defaultSuccessCallback(res) {
    alert("Success!");
}

function _readErrorMessage(err, lang) {
    // If handling it
    if (err.responseJSON) {
        var msg = err.responseJSON.detail;

        // If French language
        if (lang == "fr" && err.responseJSON.detail_fr)
            msg = err.responseJSON.detail_fr;
        return msg;
    }

    else {
        return "Failed...";
    }
}

function _defaultFailedCallback(err) {
    // If handling it
    if (err.responseJSON) {
        var detailFr = "";
        if (err.responseJSON.detail_fr)
            detailFr = "\n" + err.responseJSON.detail_fr;
        console.error(err.responseJSON);
        alert(err.responseJSON.detail + detailFr);
    }

    else {
        console.error(err);
        alert("Failed...");
    }
}


function callWEB(verb, url, paramsJson, success, failed) {
    // If the parameters are set
    var d = null;
    if (paramsJson)
        d = JSON.stringify(paramsJson);

    // Set the authentication headers automatically (if the user is authenticated)
    const headers = {};
    if (document.___CSRF_TOKEN) {
        headers["X-CSRFToken"] = document.___CSRF_TOKEN;
    }

    // Call
    $.ajax({
        type: verb,
        url: url,
        headers: headers,
        data: d,
        contentType: "application/json; charset=utf-8",
        success: success || _defaultSuccessCallback,
        error: failed || _defaultFailedCallback
    });
}

function callAPI(verb, url, paramsJson, success, failed) {
    // If the parameters are set
    var d = null;
    if (paramsJson)
        d = JSON.stringify(paramsJson);

    // Set the authentication headers automatically (if the user is authenticated)
    const headers = {};
    const api_token = Cookies.get(document.___API_COOKIE_KEY);
    if (api_token) {
        headers["Authorization"] = "Bearer " + api_token;
    }

    // Call
    $.ajax({
        type: verb,
        url: document.___API_URL + url,
        headers: headers,
        data: d,
        contentType: "application/json; charset=utf-8",
        success: success || _defaultSuccessCallback,
        error: failed || _defaultFailedCallback
    });
}

async function callAPIFile(verb, url, data, success, failed) {
    // Set the authentication headers automatically (if the user is authenticated)
    const headers = {};
    const api_token = Cookies.get(document.___API_COOKIE_KEY);
    if (api_token) {
        headers["Authorization"] = "Bearer " + api_token;
    }

    const successCallback = success || _defaultSuccessCallback;
    const failedCallback = failed || _defaultFailedCallback;
    try {
        // Call API
        const response = await fetch(document.___API_URL + url, {
            method: verb,
            headers: headers,
            body: data
        });

        // If success
        if (response.ok) {
            successCallback(response)
        }

        else {
            failedCallback(response);
        }
    }

    catch (error) {
        failedCallback('Error uploading file:', error);
    }
}

async function callAPIPublishUnpublish(verb, url, lang, successCallback) {
    // Hide the alerts
    hideAlerts();
    showPubUnpubProgress();

    // Get the file
    const zipFileInput = document.getElementById('in_file');
    const file = zipFileInput.files[0];
    if (file) {
        // Create a FormData object to send the file to the API
        const formData = new FormData();
        formData.append('zip_file', file);

        callAPIFile(verb, url, formData, async (response) => {
            // Callback
            hidePubUnpubProgress();
            successCallback?.();
        }, async (error) => {
            // Failed
            hidePubUnpubProgress();

            // Read the body
            const body = await error.json();

            // Show the error
            showErrorFromAPIResponse(body, lang);
        });
    }

    else {
        // Failed
        hidePubUnpubProgress();

        // Show error
        showError('Please select a .zip file.');
    }
}

async function callAPIValidate(verb, url, operation, lang, successCallback, failCallback) {
    // Hide the alerts
    hideAlerts();
    showPubUnpubProgress();

    // Get the file
    const zipFileInput = document.getElementById('in_file');
    const file = zipFileInput.files[0];
    if (file) {
        // Create a FormData object to send the file to the API
        const formData = new FormData();
        formData.append('operation', operation);
        formData.append('zip_file', file);

        callAPIFile(verb, url, formData, async (response) => {
            // Callback
            hidePubUnpubProgress();
            successCallback?.(await response.json());
        }, async (error) => {
            // Failed
            hidePubUnpubProgress();

            // Read the body
            const body = await error.json();

            // Show the error
            showErrorFromAPIResponse(body, lang);
            failCallback?.();
        });
    }

    else {
        // Failed
        hidePubUnpubProgress();

        // Show error
        showError('Please select a .zip file.');
    }
}