# System imports
import os
from datetime import datetime
from typing import Callable
from urllib.parse import unquote, parse_qs
import xml.etree.ElementTree as ET
import subprocess
import re

from psycopg2._psycopg import connection, cursor
from osgeo import ogr

# QGIS imports
from qgis.core import Qgis, QgsApplication, QgsProject, QgsProviderRegistry  # type: ignore
from qgis.core import QgsProjectStorage, QgsProjectStorageRegistry  # type: ignore
from qgis.core import QgsProcessingFeedback, QgsProcessingProvider, QgsProcessingAlgorithm, QgsProcessingContext   # type: ignore
from qgis.core import QgsLayerTree, QgsMapLayer, QgsLayerTreeGroup # type: ignore
from qgis.core import QgsVectorLayer, QgsProjectVersion, QgsWkbTypes, QgsFieldConstraints, QgsDataProvider # type: ignore
from qgis.PyQt.QtXml import QDomDocument # type: ignore
from qgis.PyQt.QtCore import QFile, QIODevice # type: ignore
import processing # type: ignore
from processing.core.Processing import Processing # type: ignore

# Application imports
from core.lib.qgis_progress_marks import *
from core.lib.qgis_exceptions import *
from nrcan_core import config_env
from nrcan_qgis.db import db_connection

# Get the log
from core.lib.logger import get_log
LOG = get_log(config_env.LOG_NAME)


def get_version() -> QgsProjectVersion:
    """
    Gets the QGIS Version
    """
    LOG.trace_func()

    return QgsProjectVersion(Qgis.QGIS_VERSION)


def compare_version(version1: QgsProjectVersion, version2: QgsProjectVersion) -> int:
    if version1.majorVersion() < version2.majorVersion():
        return -1

    elif version1.majorVersion() == version2.majorVersion():
        if version1.minorVersion() < version2.minorVersion():
            return -1

        elif version1.minorVersion() == version2.minorVersion():
            return 0 # Subversion should be fine, considering it valid.

        else:
            return 1
    else:
        return 1


def get_geometry_type_string(geometry_type: int) -> str:
    if geometry_type == 2:
        return "Polygon"
    elif geometry_type == 1:
        return "Line"
    elif geometry_type == 0:
        return "Point"
    else:
        return "Unknown geometry"


def _format_crs_epsg(crs_authid: str) -> str:
    """
    Helper function to format the crs (EPSG) to a short number
    """

    return crs_authid.replace("EPSG:","").strip()


class PyQgis(object):
    """
    A PyQGIS management class
    """

    def __init__(self, qgis_install_path: str) -> None:
        """
        Constructor

        :param qgis_install_path: The path to QGIS install
        """
        LOG.trace_func()

        self.progress_marks: list[QGISProgressMark] = []
        self.qgis_project_id: str | None
        self.qgis_project_id_short: str | None
        self.qgis_project_schema: str | None
        self.qgis_project_lang: str | None
        self.db_qgis: db_connection.PyDB | None = None
        self.db_host_qgis: str | None
        self.db_port_qgis: int | None
        self.db_name_qgis: str | None
        self.db_user_qgis: str | None
        self.db_password_qgis: str | None
        self.db_data: db_connection.PyDB | None = None
        self.db_host_data: str | None
        self.db_port_data: int | None
        self.db_name_data: str | None
        self.db_user_data: str | None
        self.db_password_data: str | None

        # Log
        LOG.debug(f"Initializing PyQgis with prefix path: '{qgis_install_path}'")
        self.qgis_app_reference = QgsApplication([], False)
        self.set_qgis_path = QgsApplication.setPrefixPath(qgis_install_path, True)
        self.init_qgis = self.qgis_app_reference.initQgis()

        # Get the version upon init for log
        qgis_version: str = get_version().text()
        LOG.debug(f"PyQGIS version: {qgis_version}")

        # Add to progress mark
        self.progress_marks = [ProgressMarkInitialized(datetime.now(), qgis_version)]


    def close(self) -> None:
        """
        Exits a QgsApplication
        """
        LOG.trace_func()

        # Exit QGIS
        self.qgis_app_reference.exitQgis()


    def init_project_from_file(self, qgis_project_file: str) -> None:
        """
        Initializes a QGIS project from the file path;
        for the functions in this class that require project connectivity.

        :param qgis_project_file: The path to the QGIS project file
        """
        LOG.trace_func()

        # Keep track
        self.progress_marks.append(ProgressMarkInitializingProjectFromFile(datetime.now(), qgis_project_file))

        # QGIS props
        self.project = QgsProject.instance()

        # If instantiated
        if self.project:
            try:
                # Log
                LOG.info(f"Opening project: {qgis_project_file}")

                # Read project file
                read_success = self.project.read(qgis_project_file)
                #read_success = self.project.read(qgis_project_file, flags=QgsProject.FlagDontResolveLayers)

            except Exception as err:
                # Failed to read the project file
                LOG.error(f"Failed to open project: {qgis_project_file}", err)
                raise err

            # If failed to read the project
            self.qgis_project_id = None
            if read_success:
                # Initialized
                self.qgis_project_id = os.path.basename(qgis_project_file).split(".")[0]
                self.qgis_project_id_short = self.qgis_project_id
                self.qgis_project_lang = "en"
                if self.qgis_project_id.endswith("_en") or self.qgis_project_id.endswith("-en"):
                    self.qgis_project_id_short = self.qgis_project_id[:-3]

                elif self.qgis_project_id.endswith("_fr") or self.qgis_project_id.endswith("-fr"):
                    self.qgis_project_id_short = self.qgis_project_id[:-3]
                    self.qgis_project_lang = "fr"

                # Keep track
                self.progress_marks.append(ProgressMarkInitializedProject(datetime.now()))

                # Log
                LOG.info(f"Project opened.")

            else:
                self.project = None
                raise ProjectNotFoundFromFile(qgis_project_file)

        else:
            self.project = None
            raise ProjectNotFoundFromFile(qgis_project_file)


    def init_project_from_db(self, schema: str, qgis_project_id: str) -> None:
        """
        Initializes a QGIS project from the database;
        for the functions in this class that require project connectivity.

        :param qgis_project_id: The project id as stored in the database
        """
        LOG.trace_func()

        # Keep track
        self.progress_marks.append(ProgressMarkInitializingProjectFromDatabase(datetime.now(), qgis_project_id))

        # If the database has been initialized
        if self.db_qgis:
            # QGIS props
            self.project: QgsProject | None = QgsProject.instance()

            # If instantiated
            if self.project:
                # Read the project
                read_success: bool = self.project.read(self.db_qgis.gen_uri_project(schema, qgis_project_id))

                # If read
                self.qgis_project_id = None
                if read_success:
                    # Initialized
                    self.qgis_project_id = qgis_project_id
                    self.qgis_project_id_short = self.qgis_project_id
                    self.qgis_project_schema = schema
                    self.qgis_project_lang = "en"
                    if self.qgis_project_id.endswith("_en") or self.qgis_project_id.endswith("-en"):
                        self.qgis_project_id_short = self.qgis_project_id[:-3]

                    elif self.qgis_project_id.endswith("_fr") or self.qgis_project_id.endswith("-fr"):
                        self.qgis_project_id_short = self.qgis_project_id[:-3]
                        self.qgis_project_lang = "fr"

                    # Keep track
                    self.progress_marks.append(ProgressMarkInitializedProject(datetime.now()))

                else:
                    self.project = None
                    raise ProjectNotFoundFromDatabase(qgis_project_id, schema)

            else:
                self.project = None
                raise ProjectNotFoundFromDatabase(qgis_project_id, schema)

        else:
            # Throws
            raise DatabaseNotInitialized("init_project_from_db")


    def init_project_schema(self, schema: str) -> None:
        self.qgis_project_schema = schema


    def init_database_qgis(self, db_host_qgis: str, db_port_qgis: int, db_name_qgis: str, db_user_qgis: str, db_password_qgis: str) -> None:
        """
        Initializes the database parameters for the functions in this class
        that require database connectivity.
        """
        LOG.trace_func()

        # Create database connection
        self.db_qgis = db_connection.PyDB(db_host_qgis, db_port_qgis, db_name_qgis, db_user_qgis, db_password_qgis)

        # Keep a copy of the credentials if an alternative connection access to the database is needed
        self.db_host_qgis = db_host_qgis
        self.db_port_qgis = db_port_qgis
        self.db_name_qgis = db_name_qgis
        self.db_user_qgis = db_user_qgis
        self.db_password_qgis = db_password_qgis

        # Mark progression
        self.progress_marks.append(ProgressMarkInitializedDatabase(datetime.now(), "qgis"))


    def init_database_data(self, db_host_data: str, db_port_data: int, db_name_data: str, db_user_data: str, db_password_data: str) -> None:
        """
        Initializes the database parameters for the functions in this class
        that require database connectivity.
        """
        LOG.trace_func()

        # Create database connection
        self.db_data = db_connection.PyDB(db_host_data, db_port_data, db_name_data, db_user_data, db_password_data)

        # Keep a copy of the credentials if an alternative connection access to the database is needed
        self.db_host_data = db_host_data
        self.db_port_data = db_port_data
        self.db_name_data = db_name_data
        self.db_user_data = db_user_data
        self.db_password_data = db_password_data

        # Mark progression
        self.progress_marks.append(ProgressMarkInitializedDatabase(datetime.now(), "data"))


    def get_projects_in_db(self, schema: str) -> list:
        """
        Gets the list of projects as stored in the QGIS repository for the active schema
        """
        LOG.trace_func()

        # If the database has been initialized
        if self.db_qgis:
            # Get the uri
            uri: str = self.db_qgis.gen_uri_storage_schema(schema)

            # Get the storage registry
            storage_reg: QgsProjectStorageRegistry | None = QgsApplication.projectStorageRegistry()

            # If found
            if storage_reg:
                # Get the storage
                storage: QgsProjectStorage | None = storage_reg.projectStorageFromUri(uri)

                # If found
                if storage:
                    # Get the list of projects
                    the_list = storage.listProjects(uri)
                    # Sort it alphabetically
                    the_list.sort()
                    # Return it
                    return the_list

            # Throws
            raise StorageNotFound(schema, uri)

        else:
            # Throws
            raise DatabaseNotInitialized("get_projects_in_db")


    def project_exists_in_db(self, schema: str, qgis_project_id: str) -> bool:
        """
        Checks if the given project exists in the QGIS repository
        """
        LOG.trace_func()

        # Get the projects
        projects: list | None = self.get_projects_in_db(schema)

        # If the projects could be searched
        if projects:
            # If the project exists
            return qgis_project_id in projects
        return False


    def get_dom_document(self) -> Any | None:
        LOG.trace_func()

        # If the valid is defined
        if self.project:
            # Open the QGS file
            f: Any = None
            try:
                f = QFile(self.project.fileInfo().absoluteFilePath())
                f.open(QIODevice.OpenModeFlag.ReadOnly)

                doc = QDomDocument()
                doc.setContent(f.readAll())
                return doc

            except Exception as err:
                print(str(err))
                pass # Skip

            finally:
                if f:
                    f.close()

        return None


    def get_dom_document_qgis_node(self) -> Any | None:
        LOG.trace_func()

        # Get the doc
        doc: Any | None = self.get_dom_document()

        # If defined
        if doc:
            # Open the QGS file
            node = doc.elementsByTagName("qgis").item(0)
            return node


    def get_crs(self) -> str:
        """
        Gets the CRS of the main dataframe
        """
        LOG.trace_func()

        # If the project has been initialized
        if self.project:
            return _format_crs_epsg(self.project.crs().authid())

        else:
            # Throws
            raise ProjectNotInitialized("get_crs")


    def get_layers_in_order(self, condition: Callable[[QgsMapLayer], bool] | None) -> list[QgsMapLayer]:
        """
        Helper function to get the layers list in order.
        """
        LOG.trace_func()

        layers: list[QgsMapLayer] = []
        if self.project:
            self._get_layers_all_rec(self.project.layerTreeRoot(), layers, condition)
        return layers


    def get_layers_vector(self) -> list[QgsMapLayer]:
        """
        Helper function to get the raster layers list in order.
        """
        LOG.trace_func()

        # Redirect
        return self.get_layers_in_order(lambda l: l.type() == QgsMapLayer.LayerType.VectorLayer)


    def get_layers_raster(self) -> list[QgsMapLayer]:
        """
        Helper function to get the raster layers list in order.
        """
        LOG.trace_func()

        # Redirect
        return self.get_layers_in_order(lambda l: l.type() == QgsMapLayer.LayerType.RasterLayer)


    def get_layers_wcs_compatible(self) -> list[QgsMapLayer]:
        """
        Helper function to get the raster layers list in order.
        """
        LOG.trace_func()

        # Redirect
        return self.get_layers_in_order(lambda l: l.type() == QgsMapLayer.LayerType.RasterLayer or \
                                                 (l.type() == QgsMapLayer.LayerType.VectorLayer and l.geometryType() in {QgsWkbTypes.GeometryType.PolygonGeometry, QgsWkbTypes.GeometryType.LineGeometry}))


    def get_layers_that_point_to_database(self, valid_only: bool) -> list[QgsMapLayer]:
        """
        Helper function to get the layers pointing to our database in order.
        """
        LOG.trace_func()

        # Redirect
        return self.get_layers_in_order(lambda l: self.get_layer_is_database(l, valid_only))


    def get_layers_that_point_to_vrt_file(self) -> list[QgsMapLayer]:
        """
        Helper function to get the layers pointing to a vrt file.
        """
        LOG.trace_func()

        # For each raster layer
        vrt_layers = []
        for rlayer in self.get_layers_raster():
            # Read the data provider when any
            data_prov = rlayer.dataProvider()

            # If found
            if data_prov:
                # Get the data source of the raster layer
                data_source = data_prov.dataSourceUri()

                # If the datasource is vrt file
                if data_source.lower().endswith('.vrt'):
                    vrt_layers.append(rlayer)

        # Return the layers pointing to vrt files
        return vrt_layers


    def get_group_layers_all(self) -> list[QgsLayerTreeGroup]:
        """
        Recursively get all group layers in the project and return a list.
        """
        LOG.trace_func()

        layers: list[QgsLayerTreeGroup] = []
        if self.project:
            # For each layer at the tree
            self._get_group_layers_all_rec(self.project.layerTreeRoot(), layers)
        return layers


    def _get_group_layers_all_rec(self, current_node, results: list[QgsLayerTreeGroup]) -> None:
        """
        Recursive function to get all the group layers in the QGIS table of contents
        """
        LOG.trace_func()

        # If the layer is a group
        if QgsLayerTree.isGroup(current_node):
            # If root node and we want root node
            if isinstance(current_node, QgsLayerTree):
                # Skip the very root group
                pass

            elif isinstance(current_node, QgsLayerTreeGroup):
                # Keep the group layer
                results.append(current_node)

            # For each child
            for c in current_node.children():
                self._get_group_layers_all_rec(c, results)


    def _get_layers_all_rec(self, current_node, results: list[QgsMapLayer], condition: Callable[[QgsMapLayer], bool] | None) -> None:
        """
        Recursive function to get all the layers in the QGIS table of contents which meets the optional condition provided
        """
        LOG.trace_func()

        # If the project is initialized
        if self.qgis_project_id:
            # If the layer is a group
            if QgsLayerTree.isGroup(current_node):
                # For each child
                for c in current_node.children():
                    self._get_layers_all_rec(c, results, condition)

            else:
                # Read the layer
                layer: QgsMapLayer = current_node.layer()

                # If layer could be read
                if layer is not None:
                    # If there's no condition or condition is satisfied
                    if condition is None or condition(layer):
                        # Add the layer
                        results.append(layer)
                else:
                    # Raise problem
                    raise LayerInvalid(self.qgis_project_id, current_node.name())


    def copy_gpkg_tables_to_postgis(self, data_import_process: str, schema_name: str, gpkg_file: str, gpkg_table_name: str,
                                    db_table_name: str, db_pk_field: str, db_geom_field: str) -> None:
        """
        Copy the Geopackage table to the database using the specified data import process
        """
        LOG.trace_func()

        # Initialize the processing tool
        Processing.initialize()

        try:
            # Mark about to copy
            self.progress_marks.append(ProgressMarkTableAdding(datetime.now(), schema_name, db_table_name))

            # Get the primary key field name of the table in the gpkg
            #primary_key: str = self.get_pk_field_from_gpkg_table(gpkg_file, gpkg_table_name)

            from datetime import timezone
            date_track = datetime.now(timezone.utc)

            # Log
            LOG.info(f"Running {data_import_process} exportation for table {gpkg_table_name} to {db_table_name}...")

            # The input file layer string
            input_file: str = f"{gpkg_file}|layername={gpkg_table_name}"

            # Depending on the import process to use
            if data_import_process == 'ogr2ogr':
                # Define the ogr2ogr command
                ogr2ogr_command = [
                    "ogr2ogr",
                    "-progress",
                    "-f", "PostgreSQL",
                    "--config", "PG_USE_COPY", "YES",
                    f"PG:host={self.db_host_data} port={self.db_port_data} dbname={self.db_name_data} user={self.db_user_data} password={self.db_password_data}",
                    gpkg_file, gpkg_table_name,
                    "-lco", "DIM=2",
                    "-lco", f"GEOMETRY_NAME={db_geom_field}",
                    "-lco", f"FID={db_pk_field}",
                    "-nln", f"{schema_name}.{db_table_name}"
                ]

                # Run subprocess
                subprocess.run(ogr2ogr_command, check=True)

            else:
                # Create the feedback object
                feedback = MyFeedBack()

                # Copy the GeoPackage table to PostGis database using gdal
                processing.run("gdal:importvectorintopostgisdatabasenewconnection", {
                    'INPUT': input_file,
                    'SHAPE_ENCODING': '',
                    'GTYPE': 0,
                    'A_SRS': None,
                    'T_SRS': None,
                    'S_SRS': None,
                    'HOST': self.db_host_data,
                    'PORT': self.db_port_data,
                    'USER': self.db_user_data,
                    'DBNAME': self.db_name_data,
                    'PASSWORD': self.db_password_data,
                    'SCHEMA': schema_name,
                    'TABLE': db_table_name,
                    'PK': db_pk_field,
                    'PRIMARY_KEY': '',
                    'GEOCOLUMN': db_geom_field,
                    'DIM': 0,
                    'SIMPLIFY': '',
                    'SEGMENTIZE': '',
                    'SPAT': None,
                    'CLIP': False,
                    'FIELDS': [],
                    'WHERE': '',
                    'GT': '', # '10000' ?
                    'OVERWRITE': False,
                    'APPEND': False,
                    'ADDFIELDS': False,
                    'LAUNDER': True,
                    'INDEX': False,
                    'SKIPFAILURES': False,
                    'PROMOTETOMULTI': False,
                    'PRECISION': True,
                    'OPTIONS': ''
                }, feedback=feedback)

            # Check the time duration
            time_span = datetime.now(timezone.utc) - date_track

            # Log
            LOG.info(f"{data_import_process} exportation processing completed. Duration: '{time_span}'")

        except Exception as exc:
            # Log error
            LOG.error(exc)
            raise UnableCopyGpkgTable(input_file, schema_name, db_table_name) from exc

        # Get the list of layers from the PostGis database
        db_table_names = self.get_layers_from_db(schema_name)
        if db_table_name in db_table_names:
            self.progress_marks.append(ProgressMarkTableAddedVerified(datetime.now(), schema_name, db_table_name))

        else:
            # Mark progress
            self.progress_marks.append(ProgressMarkTableAddedButFailed(datetime.now(), schema_name, db_table_name))
            raise UnableCopyGpkgTable(input_file, schema_name, db_table_name)


    def get_layer_is_geopackage_in_same_folder(self, layer: QgsMapLayer) -> bool:
        """
        Helper function to check if the layer points to a geopackage that's in the same folder as the project.
        """
        LOG.trace_func()

        # First of all, check if geopackage
        if self.project and get_layer_is_geopackage(layer):
            # Get the layer properties
            props = get_layer_properties(layer)

            # Return if geopackage path is same folder as project
            return self.project.readPath("./").lower() == os.path.dirname(props['path']).lower()

        # Not a geopackage
        return False


    def get_layer_id_field_names(self, layer) -> list[str]:
        # For each index
        names: list[str] = []
        for i in layer.primaryKeyAttributes():
            names.append(layer.fields()[i].name())
        return names


    def get_layers_from_db(self, schema_name) -> list[tuple[Any, ...]]:
        """Get the name of the layers (table names) in the DB for a specific schema"""
        LOG.trace_func()

        # If the database has been initialized
        if self.db_data:
            # Create a cursor
            db_conn: connection = self.db_data.open_conn()  # Open connection to the DB
            cur: cursor = db_conn.cursor()  # Get a cursor

            # Execute SQL query to fetch table names for the specified schema
            cur.execute(f"SELECT tablename FROM pg_catalog.pg_tables WHERE schemaname = '{schema_name}'")

            # Fetch all results
            table_names: list[tuple[Any, ...]] = cur.fetchall()

            # Extract a list of string from a list of tuples
            table_names = [table_name[0] for table_name in table_names]

            # Close the cursor and connection
            cur.close()

            return table_names

        else:
            # Throws
            raise DatabaseNotInitialized("get_layers_from_db")


    def get_layer_is_database(self, layer: QgsMapLayer, valid_only: bool) -> bool:
        LOG.trace_func()

        # First of all, check if the data provider and layer type is valid
        if isinstance(layer, QgsVectorLayer):
            # Get the data provider
            data_prov: QgsDataProvider | None = layer.dataProvider()

            if (not valid_only or (valid_only and data_prov and data_prov.isValid())):
                # Get the layer properties
                props: dict = get_layer_properties(layer)

                # Return if there's a path and if the path ends with a geopackage file
                return 'table' in props and 'schema' in props and props['schema']

        # Not
        return False


    def save_project_on_disk(self, path: str) -> None:
        """
        Saves the project on disk
        """

        # If initialized
        if self.project:
            # Save it
            self.project.write(path)


    def save_project_in_db(self) -> None:
        """
        Saves the project in the database
        """
        LOG.trace_func()

        # If valid name
        if self.qgis_project_id:
            # Redirect
            self.save_project_in_db_as(self.qgis_project_id)

        else:
            raise ProjectNotInitialized("save_project_in_db")


    def save_project_in_db_as(self, project_id: str) -> bool:
        """
        Saves the project in the database with the given name
        """
        LOG.trace_func()

        # If the project has been initialized
        if self.project and self.db_qgis and self.qgis_project_schema:
            # Keep track
            self.progress_marks.append(ProgressMarkSavingProject(datetime.now(), project_id))

            # Generate the uri
            uri: str = self.db_qgis.gen_uri_project(self.qgis_project_schema, project_id)

            # Save the QGIS project in database
            saved = self.project.write(uri)

            if saved:
                # Log
                LOG.info(f"The QGIS Project '{project_id}' has been saved in the database.")
                return True

            else:
                # Throws
                raise FailedSaveQgisProject(project_id)

        else:
            # Throws
            raise ProjectNotInitialized("save_project_in_db_as")


    def copy_project(self, copy_name: str) -> None:
        LOG.trace_func()

        # If the database has been initialized
        if self.db_qgis and self.qgis_project_schema:
            if self.project_exists_in_db(self.qgis_project_schema, copy_name):
                self.delete_project_from_db_as(copy_name)
            self.save_project_in_db_as(copy_name)

        else:
            raise DatabaseNotInitialized("copy_project")


    def delete_project_from_db(self) -> None:
        """
        Deletes the project from the database
        """
        LOG.trace_func()

        # If initialized
        if self.db_qgis and self.qgis_project_id:
            # Redirect
            self.delete_project_from_db_as(self.qgis_project_id)

        else:
            raise ProjectNotInitialized("delete_project_from_db")


    def delete_project_from_db_as(self, project_id: str) -> bool:
        """
        Deletes the project from the database
        """
        LOG.trace_func()

        # If the project has been initialized
        if self.project and self.db_qgis and self.qgis_project_schema:
            # Keep track
            self.progress_marks.append(ProgressMarkDeletingProject(datetime.now(), project_id))

            # Generate the uri
            uri: str = self.db_qgis.gen_uri_project(self.qgis_project_schema, project_id)

            # Get the storage registry
            storage_reg: QgsProjectStorageRegistry | None = QgsApplication.projectStorageRegistry()

            # If registry was found
            if storage_reg:
                # Get the storage
                storage: QgsProjectStorage | None = storage_reg.projectStorageFromUri(uri)

                # If found
                if storage:
                    # If the project exists
                    if project_id in storage.listProjects(uri):
                        # Delete the QGIS project from database
                        deleted = storage.removeProject(uri)

                        if deleted:
                            # Log
                            LOG.info(f"The QGIS Project '{project_id}' has been deleted.")
                            return True

                        # Throws
                        raise FailedDeleteQgisProject(project_id)

                    # Throws
                    raise ProjectNotFoundFromDatabase(project_id, self.qgis_project_schema)

            # Throws
            raise StorageNotFound(project_id, uri)

        # Throws
        raise ProjectNotInitialized("delete_project_from_db_as")


    # def get_layer_styles(self, layer):

    #     print(QgsProviderRegistry.instance().providerList())

    #     # Get the layer styles using the layer
    #     [count, style_ids, style_names, style_descs, error] = layer.listStylesInDatabase()
    #     print(f"--> 1) Styles using layer: {style_names}")

    #     # This is what we want, but we want to list the styles using the QgsProviderRegistry instead of from a layer.
    #     # So after reading the C++ code inside listStylesInDatabase we try to replicate it
    #     style_ids = []   #reset
    #     style_names = [] #reset
    #     style_descs = [] #reset
    #     error = ""       #reset
    #     QgsProviderRegistry.instance().listStyles(layer.dataProvider().name(),
    #                                               layer.dataProvider().dataSourceUri(),
    #                                               style_ids, style_names, style_descs, error)

    #     print(f"--> 2) Styles using provider registry: {style_names}")

    #     return style_names


    def layer_style_exists_in_db(self, layer, style_name: str) -> bool:
        """
        Gets if the layer style for the layer exists in the database
        """
        LOG.trace_func()

        # Export the layer named style
        #documentNamedStyle = QDomDocument()
        #layer.exportNamedStyle(documentNamedStyle)

        # Export the layer SLD style
        #documentSLDStyle = QDomDocument()
        #layer.exportSldStyle(documentSLDStyle, "")

        # Generate the uri
        #uri_specific = self.db_qgis.gen_uri_data_source(self.db_qgis.schema, table_name, geom_type)

        # success = QgsProviderRegistry.instance().saveStyle(DATA_PROVIDER_KEY, uri_specific,
        #                                                    documentNamedStyle.toString(), documentSLDStyle.toString(),
        #                                                    style_name, f"Default style for {layer.name()}", "", True, "")

        # Fetch the styles
        [count, style_ids, style_names, style_descs, error] = layer.listStylesInDatabase()

        # Return if the style exists in the database
        return style_name in style_names


    def save_layer_style_in_database(self, layer, style_name: str) -> None:
        """
        Saves the layer style to Postgres DB
        """
        LOG.trace_func()

        # If the project has been initialized
        if self.project and self.db_qgis:
            # Fetch the styles
            #[count, style_ids, style_names, style_descs, error] = layer.listStylesInDatabase()

            # Save it
            layer.saveStyleToDatabase(style_name, "", True, "")

            # Update the record in layer_styles to set the type
            # (I couldn't find a way to do it with PyQGIS SDK)
            self.db_qgis.save_layer_style_finalize(style_name, get_geometry_type_string(layer.geometryType()))

            # Log
            #LOG.debug(f"Style '{style_name}' has been saved in the database")

        else:
            # Throws
            raise ProjectNotInitialized("save_layer_style_in_database")


    def delete_layer_style_from_db(self, layer, style_name: str) -> None:
        """
        Deletes the layer style from CDTK Postgres DB
        """
        LOG.trace_func()

        # Fetch the styles
        [count, style_ids, style_names, style_descs, error] = layer.listStylesInDatabase()

        # Get the style id from the name (if exists)
        if style_name in style_names:
            # Delete the style (replacing it and we don't want the pop up window)
            layer.deleteStyleFromDatabase(style_ids[style_names.index(style_name)])
            # Log
            #LOG.debug(f"Style '{style_name}' has been deleted from the Database")

        else:
            # Log
            #LOG.debug(f"Style '{style_name}' not found in Database, skip")
            pass  # No need, style doesn't exist


def get_layer_schema_name(layer: QgsMapLayer) -> str | None:
        LOG.trace_func()

        # Check layer information
        layer_info: dict = get_layer_properties(layer)

        # If the layer points to a GeoPackage
        schema_name: str | None = None
        if 'schema' in layer_info:
            schema_name = layer_info['schema']
        return schema_name


def get_layer_source_name(layer: QgsMapLayer) -> str | None:
    LOG.trace_func()

    # Check layer information
    layer_info: dict = get_layer_properties(layer)

    # If the layer points to a GeoPackage
    table_name: str | None = None
    if 'layerName' in layer_info:
        table_name = layer_info['layerName']
    elif 'table' in layer_info:
        table_name = layer_info['table']
    return table_name


def get_layer_is_vector(layer: QgsMapLayer) -> bool:
        """
        Helper function to check if the layer is a WFS layer
        """

        # Get the data provider
        data_prov: QgsDataProvider | None = layer.dataProvider()

        # Check if the data provider and layer type is valid
        return (data_prov and data_prov.isValid() and isinstance(layer, QgsVectorLayer)) or False


def get_layer_is_geopackage(layer: QgsMapLayer) -> bool:
    """
    Helper function to check if the layer points to a geopackage.
    """
    LOG.trace_func()

    # First of all, check if the data provider and layer type is valid
    if get_layer_is_vector(layer):
        # Get the layer properties
        props: dict = get_layer_properties(layer)

        # Return if there's a path and if the path ends with a geopackage file
        return 'path' in props and props['path'].endswith("gpkg")

    # Not a geopackage
    return False


def get_layer_properties(layer: QgsMapLayer) -> dict:
    """
    Helper function to get the layer properties.
    """
    LOG.trace_func()

    # Get the provider registry
    prov_reg: QgsProviderRegistry | None = QgsProviderRegistry.instance()

    # If found
    if prov_reg:
        # Get the data provider
        data_prov: QgsDataProvider | None = layer.dataProvider()
        prov_type = layer.providerType()

        # If found
        if data_prov:
            uri = data_prov.dataSourceUri()

            # and data provider type is virtual
            if prov_type == "virtual":
                return _decode_virtual_layer_uri(uri)

            # Decode the uri
            return prov_reg.decodeUri(prov_type, uri)
        else:
            # add warning that the data provider is undefined for the layer
            LOG.warning(f"Data provider is undefined for layer '{layer.name()}'")
    return {}

def build_virtual_layer_uri(source: dict, db_user, db_password) -> str:
    """
    Format the URI for the virtual layer.
    Inserts the user and password into the URI.

    The full URI format is typically:
    "user='...' password='...' ?layer=... host='...' port='...'"

    """
    LOG.trace_func()

    try:
        layer_uri = "?"
        for layer in source.get('layers', []):
            layer_uri += "layer=postgres:"
            for key in ['dbname', 'host', 'port', 'user', 'password', 'key', 'srid', 'type']:
                if key in layer and key != 'user' and key != 'password':
                    layer_uri += f"{key}={layer[key]} "
                # add user and password from the datastore' secret
                elif key == 'user' or key == 'password':
                    if key == 'user':
                        layer_uri += f"user={db_user} "
                    else:
                        layer_uri += f"password={db_password} "
            if 'table' in layer and 'schema' in layer:
                layer_uri += f'table="{layer["schema"]}"."{layer["table"]}" '
            if 'layer_name' in layer:
                layer_uri += f'(geom):{layer["layer_name"]}:UTF-8&'

        if 'query' in source:
            layer_uri += f"query={source['query']}"

        return layer_uri

    except Exception as e:
        LOG.warning(f"Failed to build the virtual layer URI: {e}")
        return ""

def _decode_virtual_layer_uri(uri: str) -> dict:
    """
    Manually decode a virtual layer URI to extract database connection info.

    Virtual layer URIs can have two formats:
    1. Simple query format: ?query=SELECT ... FROM "dbname='mydb' ..."
    2. Layer reference format: ?layer=postgres:dbname='...'&layer=...&query=...
    """
    LOG.trace_func()

    props: dict = {}

    try:
        # Check if uri is composed of multiple parts and if so extract the virtual layer part
        if not uri.startswith('?') and ' ?layer=' in uri:
            for part in uri.split(' '):
                if part.startswith('?layer='):
                    uri = unquote(part)
                    break

        # Parse query parameters
        if uri.startswith('?'):
            # Remove leading '?' and parse
            query_string = uri[1:]
            params = parse_qs(query_string)

            # Check if we have 'layer' parameters (multi-layer format)
            if 'layer' in params:
                layers_info = []

                # Process each layer parameter
                for layer_param in params['layer']:
                    # Decode the layer parameter
                    layer_param = layer_param.strip("\'")
                    decoded_layer = unquote(layer_param)

                    # Extract connection info from postgres: connection string
                    if decoded_layer.startswith('postgres:'):
                        layer_info = _parse_postgres_connection_string(decoded_layer)
                        if layer_info:
                            layers_info.append(layer_info)
                        else:
                            LOG.warning(f"Failed to parse postgres connection string")

                # Store layers info
                if layers_info:
                    props['layers'] = layers_info

                    # Use the first layer's connection info as main props
                    first_layer = layers_info[0]
                    for key in ['dbname', 'host', 'port', 'user', 'password', 'key']:
                        if key in first_layer:
                            props[key] = first_layer[key].replace('"', '')

                    # Extract schema and table from the first layer
                    if 'table' in first_layer and 'schema' in first_layer:
                        props['schema'] = first_layer['schema']
                        props['table'] = first_layer['table']

                    elif 'table' in first_layer:
                        # Format: "schema"."table"
                        table_full = first_layer['table']
                        if '.' in table_full:
                            schema_table = table_full.split('.')
                            props['schema'] = schema_table[0].strip('"')
                            props['table'] = schema_table[1].strip('"')
                        else:
                            props['table'] = table_full

            # Extract the query if present
            if 'query' in params:
                query = params['query'][0]
                query = query.strip("\'").replace("\r\n", " ").replace("\\", " ")
                props['query'] = query

        # Fallback: try old format (simple query with embedded connection)
        elif 'query=' in uri:
            decoded_uri = unquote(uri)

            # Extract database connection parameters using regex
            patterns = {
                'dbname': r"dbname='([^']+)'",
                'host': r"host='([^']+)'",
                'port': r"port=(\d+)",
                'schema': r"schema='([^']+)'",
                'table': r"table='([^']+)'",
                'user': r"user='([^']+)'",
                'password': r"password='([^']+)'"
            }

            for key, pattern in patterns.items():
                match = re.search(pattern, decoded_uri)
                if match:
                    props[key] = match.group(1)

            # Extract the query itself
            query_match = re.search(r'\?query=(.+?)(?:&|$)', decoded_uri)
            if query_match:
                props['query'] = query_match.group(1)

        # Mark as virtual layer
        props['providerType'] = 'virtual'

    except Exception as e:
        LOG.warning(f"Failed to decode virtual layer URI: {e}")
        props['error'] = str(e)
        props['raw_uri'] = uri

    return props


def _parse_postgres_connection_string(connection_str: str) -> dict:
    """
    Parse a postgres connection string from a virtual layer.
    Format: postgres:dbname='...' host=... port=... user='...' password='...' 
            key='...' srid=... type=... table="schema"."table" (geom):layer_name:encoding
    """
    LOG.trace_func()

    info = {}

    # Remove 'postgres:' prefix
    if connection_str.startswith('postgres:'):
        connection_str = connection_str[9:]

    # Extract parameters with quotes
    quoted_patterns = {
        'dbname': r"dbname=([\S]+)",
        'key': r"key=([\S]+)"
        }

    for key, pattern in quoted_patterns.items():
        match = re.search(pattern, connection_str)
        if match:
            value = match.group(1)
            info[key] = value.strip("\'").strip("'")

    # Extract parameters without quotes
    unquoted_patterns = {
        'host': r"host=([^\s]+)",
        'port': r"port=(\d+)",
        'srid': r"srid=(\d+)",
        'type': r"type=(\w+)"
    }

    for key, pattern in unquoted_patterns.items():
        match = re.search(pattern, connection_str)
        if match:
            info[key] = match.group(1)

    # Extract table (format: table="schema"."table" (geom))
    table_match = re.search(r'table=([^\s:]+)', connection_str)
    if table_match:
        table_full = table_match.group(1).split('.')
        schema = table_full[0].strip('"')
        table = table_full[1].strip('"')
        # Remove geometry column info if present
        # table_full = re.sub(r'\s*\([^)]+\)', '', table_full)
        info['table'] = table
        info['schema'] = schema

    # Format: :layer_name:encoding
    parts = connection_str.split(':')
    if len(parts) >= 3:
        info['layer_name'] = parts[-2]
        info['encoding'] = parts[-1]

    return info


def get_layers_from_gpkg(gpkg_file) -> list[str]:
    """
    Get the list of layer names in a GeoPackage file
    """
    LOG.trace_func()

    layer_names: list[str] = []

    try:
        # Open the GeoPackage
        geopackage = ogr.Open(gpkg_file)

        if geopackage is None:
            raise UnableAccessGpkg(gpkg_file)

        else:
            # Get number of layers
            num_layers = geopackage.GetLayerCount()

            # Iterate over each layer and extract their name
            for i in range(num_layers):
                layer = geopackage.GetLayerByIndex(i)
                layer_names.append(layer.GetName())

    except Exception as exc:
        raise UnableAccessGpkg(gpkg_file) from exc

    return layer_names


def get_pk_field_from_gpkg_table(gpkg_file: str, gpkg_table_name: str) -> str:
    """
    Get the primary key field name used by the geopackage
    """
    LOG.trace_func()

    # The input file
    input_file: str = f"{gpkg_file}|layername={gpkg_table_name}"

    # load the table as a vector layer
    layer = QgsVectorLayer(input_file, gpkg_table_name, "ogr")

    # If valid
    if layer.isValid():
        # For each field
        for f in layer.fields():
            # Get the constraints, constraints object, yeah bit weird..
            constraints = f.constraints().constraints()

            # If found the primary key (not much other choice than check the constraint "ConstraintUnique")
            if constraints & QgsFieldConstraints.Constraint.ConstraintUnique:
                # Found it
                return str(f.name())

    # Couldn't find the PK for the gpkg table
    raise PrimaryKeyMissingInGpkg(gpkg_table_name, gpkg_file)


class MyFeedBack(QgsProcessingFeedback):

    def pushCommandInfo(self, info: str | None):
        # Works, but not really interesting
        pass
        #LOG.debug(info)
        #print(info)

    def pushInfo(self, info: str | None):
        # Works, but not really interesting
        pass
        #LOG.info(info)
        #print(info)

    def reportError(self, error: str | None, fatalError: bool = False):
        # Couldn't test if actually working, leaving it
        pass
        LOG.error(error, fatalError)
        print(error, fatalError)

    def pushConsoleInfo(self, info: str | None):
        # Not working?
        pass
        #LOG.info(f"Progress: {info}")
        #print(f"Progress: {info}")

    def pushDebugInfo(self, info: str | None):
        # Not working?
        pass
        #LOG.debug(info)
        #print(info)

    def pushFormattedMessage(self, html: str | None, text: str | None):
        # Not working?
        pass
        #LOG.debug(text)
        #print(text)

    def pushFormattedResults(self, algorithm: QgsProcessingAlgorithm | None, context: QgsProcessingContext, results: dict[str, Any]):
        # Not working?
        pass
        #LOG.debug(results)
        #print(results)

    def pushVersionInfo(self, provider: QgsProcessingProvider | None = None):
        # Not working?
        pass
        #LOG.info(provider)
        #print(provider)

    def pushWarning(self, warning: str | None):
        # Not working?
        pass
        #LOG.warning(warning)
        #print(warning)

    def setProgressText(self, text: str | None):
        # Not working?
        pass
        #LOG.debug(text)
        #print(text)

    def setProgress(self, progress: int):
        # Not working?
        pass
        #LOG.debug(f"{progress}%")
        #print(f"{progress}%")
