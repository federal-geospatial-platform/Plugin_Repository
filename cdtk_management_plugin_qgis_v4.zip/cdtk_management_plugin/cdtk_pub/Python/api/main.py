"""
This is the CDTK Admin OpenAPI which offers functions to manage the CDTK
This API uses Python, Flask, connexion, JWT and psycopg2 frameworks along with the openapi.yaml file.
Navigate to http://{HOST}:{PORT}/ui to visualize the OpenAPI user interface to learn/test this API.
"""

# Core modules
import sys, os, datetime

# Flask imports
from flask import Flask
from flask.blueprints import Blueprint
from flask.json.provider import DefaultJSONProvider
from flask_swagger_ui import get_swaggerui_blueprint
from flask_jwt_extended import JWTManager

# Add the parent folder to the path so that the "core" module can be loaded
sys.path.append(os.path.dirname(sys.path[0]))
from nrcan_core import config, config_env, secret
from core.lib.logger import init_log, get_log

# Init the log
init_log(config_env.LOG_NAME, config_env.LOG_FILE, config_env.LOG_LEVEL_FILE, config_env.LOG_LEVEL_CONSOLE)

# Get the log
LOG = get_log(config_env.LOG_NAME)

# Application imports
from routes import *

# Log
LOG.info('API Started')

# Create the Flask application
app: Flask = Flask(__name__)

# Flask Security Configurations
app.config['JWT_TOKEN_LOCATION'] = ["headers"]  # API working with headers only
app.config['JWT_COOKIE_CSRF_PROTECT'] = False  # No need, not using cookies, only headers
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = datetime.timedelta(minutes=config.TOKEN_EXP_MINUTES)
app.config['JWT_REFRESH_TOKEN_EXPIRES'] = datetime.timedelta(minutes=config.TOKEN_REFRESH_EXP_MINUTES)
app.config['SECRET_KEY'] = secret.get_secret_web_token_api()

# Trick to support accented characters!
# After further tests, it seems the accented characters are only lost when the response is returned inside a browser.
# Requests via Postman already work with accents even when True. Anyways, doesn't hurt to leave it False for all.
app.config['JSON_AS_ASCII'] = False

# Create a Flask JWT Manager
jwtMan = JWTManager(app)

swagger_ui_blueprint: Blueprint = get_swaggerui_blueprint('/api/ui', '/static/openapi.yaml', config={'app_name': 'CDTK Publication'})

class UpdatedJSONProvider(DefaultJSONProvider):
    def __init__(self, app) -> None:
        super().__init__(app)

    def default(self, o) -> str | Any:
        if isinstance(o, datetime.date) or isinstance(o, datetime.datetime):
            return o.isoformat()
        return super().default(o)

# We override the json provider formatter since the Flask migration, because we want all our date/datetime values to return in ISO format, always.
app.json = UpdatedJSONProvider(app)

# Register the API routes blueprint in Flask
app.register_blueprint(routes)
app.register_blueprint(swagger_ui_blueprint, url_prefix='/api/ui')

# Register for CORS
from flask_cors import CORS
CORS(app, resources={r"/api/*": {"origins": "*"}})


with app.app_context():
    """
    Init config
    """
    pass


@jwtMan.unauthorized_loader
def _handle_token_missing(_reason):
    """
    Handles the returned response when the token is missing.
    """

    print("app._handle_token_missing")
    print(_reason)
    return rt_core.response_user(TokenMissingException())


@jwtMan.invalid_token_loader
def _handle_token_invalid_check(_reason):
    """
    Handles the returned response when the token is invalid.
    """

    print("app._handle_token_invalid_check")
    print(_reason)
    return rt_core.response_user(TokenInvalidException())


@jwtMan.expired_token_loader
def _handle_token_expired(_jwt_header, _jwt_data):
    """
    Handles the returned response when the token has expired.
    """

    print("app._handle_token_expired")
    return rt_core.response_user(TokenExpiredException())


@app.errorhandler(404)
def _handle_not_found(_reason):
    """
    Handles the returned response when the URL or information wasn't found.
    """

    print("app._handle_not_found")
    print(_reason)
    return rt_core.response_user(NotFoundException())


@app.errorhandler(405)
def _handle_method_not_allowed(_reason):
    """
    Handles the returned response when the HTTP Method wasn't allowed.
    """

    print("app._handle_method_not_allowed")
    print(_reason)
    return rt_core.response_user(MethodNotAllowedException())


@app.errorhandler(429)
def _handle_rate_limit(rate_limit_exception):
    """
    Handles the returned response when the API is rate limiting a User.
    """

    print("app._handle_rate_limit")
    return rt_core.response_user(RateLimitedException(rate_limit_exception.description))


@app.errorhandler(Exception)
def _handle_all_errors(err):
    """
    Handles any exception.
    """

    print("app._handle_all_errors")
    print(err)
    return rt_core.response_generic(err)


# If we're running in stand alone mode, run the application
if __name__ == '__main__':
    """
    Run!
    """

    # If using Connexion API
    app.run(host='0.0.0.0', port=config_env.PORT_API, debug=config_env.IS_LOCAL)
    #threading.Thread(target=lambda: app.run(host='0.0.0.0', port=5031, debug=config_env.IS_LOCAL, use_reloader=False)).start()

