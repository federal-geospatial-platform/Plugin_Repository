# CDTK Publication

This solution offers an OpenAPI project to publish/update/unpublish QGIS map services.

## Python
Navigate to the [`Python`](https://github.com/federal-geospatial-platform/ddr_publication/tree/main/Python) folder to get documentation on the `CDTK Publication OpenAPI`.
