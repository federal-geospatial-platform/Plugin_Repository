--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3
-- Dumped by pg_dump version 16.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: aafc; Type: SCHEMA; Schema: -; Owner: cdtk_sys_pub_admin_dev
--

CREATE SCHEMA aafc;


ALTER SCHEMA aafc OWNER TO cdtk_sys_pub_admin_dev;

--
-- Name: cannor; Type: SCHEMA; Schema: -; Owner: cdtk_sys_pub_admin_dev
--

CREATE SCHEMA cannor;


ALTER SCHEMA cannor OWNER TO cdtk_sys_pub_admin_dev;

--
-- Name: iaac; Type: SCHEMA; Schema: -; Owner: cdtk_sys_pub_admin_dev
--

CREATE SCHEMA iaac;


ALTER SCHEMA iaac OWNER TO cdtk_sys_pub_admin_dev;

--
-- Name: nrcan; Type: SCHEMA; Schema: -; Owner: cdtk_sys_pub_admin_dev
--

CREATE SCHEMA nrcan;


ALTER SCHEMA nrcan OWNER TO cdtk_sys_pub_admin_dev;

--
-- Name: qgis_sys; Type: SCHEMA; Schema: -; Owner: cdtk_sys_pub_admin_dev
--

CREATE SCHEMA qgis_sys;


ALTER SCHEMA qgis_sys OWNER TO cdtk_sys_pub_admin_dev;

--
-- Name: statcan; Type: SCHEMA; Schema: -; Owner: cdtk_sys_pub_admin_dev
--

CREATE SCHEMA statcan;


ALTER SCHEMA statcan OWNER TO cdtk_sys_pub_admin_dev;

--
-- Name: tc; Type: SCHEMA; Schema: -; Owner: cdtk_sys_pub_admin_dev
--

CREATE SCHEMA tc;


ALTER SCHEMA tc OWNER TO cdtk_sys_pub_admin_dev;

--
-- Name: topology; Type: SCHEMA; Schema: -; Owner: pgsql
--

CREATE SCHEMA topology;


ALTER SCHEMA topology OWNER TO pgsql;

--
-- Name: SCHEMA topology; Type: COMMENT; Schema: -; Owner: pgsql
--

COMMENT ON SCHEMA topology IS 'PostGIS Topology schema';


--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry, geography, and raster spatial types and functions';


--
-- Name: postgis_topology; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis_topology WITH SCHEMA topology;


--
-- Name: EXTENSION postgis_topology; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis_topology IS 'PostGIS topology spatial types and functions';


--
-- Name: get_user_count(); Type: FUNCTION; Schema: public; Owner: cdtk_sys_pub_admin_dev
--

CREATE FUNCTION public.get_user_count() RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
v_count integer;
begin
	SELECT count(*) into v_count FROM pg_catalog.pg_user;
RETURN v_count;
END
$$;


ALTER FUNCTION public.get_user_count() OWNER TO cdtk_sys_pub_admin_dev;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: qgis_projects; Type: TABLE; Schema: cannor; Owner: cdtk_sys_pub_admin_dev
--

CREATE TABLE cannor.qgis_projects (
    name text NOT NULL,
    metadata jsonb,
    content bytea
);


ALTER TABLE cannor.qgis_projects OWNER TO cdtk_sys_pub_admin_dev;

--
-- Name: qgis_projects; Type: TABLE; Schema: iaac; Owner: cdtk_sys_pub_admin_dev
--

CREATE TABLE iaac.qgis_projects (
    name text NOT NULL,
    metadata jsonb,
    content bytea
);


ALTER TABLE iaac.qgis_projects OWNER TO cdtk_sys_pub_admin_dev;

--
-- Name: assessment_inve__iaac_assessments_pt; Type: TABLE; Schema: nrcan; Owner: cdtk_sys_pub_admin_dev
--

CREATE TABLE nrcan.assessment_inve__iaac_assessments_pt (
    pk_lyr_id integer NOT NULL,
    "OBJECTID" integer,
    project_id character varying(16),
    project_cat_en character varying(24),
    project_cat_fr character varying(32),
    project_name_en character varying(200),
    project_name_fr character varying(200),
    proponent_en character varying(120),
    proponent_fr character varying(120),
    province_codes character varying(208),
    location_en character varying(136),
    location_fr character varying(136),
    responsible_authority_en character varying(200),
    responsible_authority_fr character varying(200),
    project_url_en character varying(96),
    project_url_fr character varying(96),
    start_date character varying(24),
    project_state_en character varying(16),
    project_state_fr character varying(16),
    location_type_en character varying(24),
    location_type_fr character varying(24),
    coordinates character varying(240),
    latitude double precision,
    longitude double precision,
    updated_at character varying(24),
    description_en character varying(10000),
    description_fr character varying(10000),
    geom public.geometry(Point,3978)
);


ALTER TABLE nrcan.assessment_inve__iaac_assessments_pt OWNER TO cdtk_sys_pub_admin_dev;

--
-- Name: assessment_inve__iaac_assessments_pt_pk_lyr_id_seq; Type: SEQUENCE; Schema: nrcan; Owner: cdtk_sys_pub_admin_dev
--

CREATE SEQUENCE nrcan.assessment_inve__iaac_assessments_pt_pk_lyr_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE nrcan.assessment_inve__iaac_assessments_pt_pk_lyr_id_seq OWNER TO cdtk_sys_pub_admin_dev;

--
-- Name: assessment_inve__iaac_assessments_pt_pk_lyr_id_seq; Type: SEQUENCE OWNED BY; Schema: nrcan; Owner: cdtk_sys_pub_admin_dev
--

ALTER SEQUENCE nrcan.assessment_inve__iaac_assessments_pt_pk_lyr_id_seq OWNED BY nrcan.assessment_inve__iaac_assessments_pt.pk_lyr_id;


--
-- Name: qgis_projects; Type: TABLE; Schema: nrcan; Owner: cdtk_sys_pub_admin_dev
--

CREATE TABLE nrcan.qgis_projects (
    name text NOT NULL,
    metadata jsonb,
    content bytea
);


ALTER TABLE nrcan.qgis_projects OWNER TO cdtk_sys_pub_admin_dev;

--
-- Name: seismic_reflect__imagery_imagerie; Type: TABLE; Schema: nrcan; Owner: cdtk_sys_pub_admin_dev
--

CREATE TABLE nrcan.seismic_reflect__imagery_imagerie (
    pk_lyr_id integer NOT NULL,
    "EXPEDITION" character varying(24),
    "YEAR" character varying(4),
    "DATE_START" character varying(16),
    "DATE_END" character varying(24),
    "LENGHT" character varying(16),
    "COMMENTS" character varying(200),
    "HR_SCAN" character varying(200),
    "THUMBNAIL" character varying(200),
    "NAVIGATION" character varying(200),
    "DATA_TYPE_EN" character varying(24),
    "DATA_TYPE_FR" character varying(32),
    "INSTRUMENT_EN" character varying(16),
    "INSTRUMENT_FR" character varying(24),
    "REGION_EN" character varying(80),
    "REGION_FR" character varying(80),
    geom public.geometry(LineString,3978)
);


ALTER TABLE nrcan.seismic_reflect__imagery_imagerie OWNER TO cdtk_sys_pub_admin_dev;

--
-- Name: seismic_reflect__imagery_imagerie_pk_lyr_id_seq; Type: SEQUENCE; Schema: nrcan; Owner: cdtk_sys_pub_admin_dev
--

CREATE SEQUENCE nrcan.seismic_reflect__imagery_imagerie_pk_lyr_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE nrcan.seismic_reflect__imagery_imagerie_pk_lyr_id_seq OWNER TO cdtk_sys_pub_admin_dev;

--
-- Name: seismic_reflect__imagery_imagerie_pk_lyr_id_seq; Type: SEQUENCE OWNED BY; Schema: nrcan; Owner: cdtk_sys_pub_admin_dev
--

ALTER SEQUENCE nrcan.seismic_reflect__imagery_imagerie_pk_lyr_id_seq OWNED BY nrcan.seismic_reflect__imagery_imagerie.pk_lyr_id;


--
-- Name: seismic_reflect__regions; Type: TABLE; Schema: nrcan; Owner: cdtk_sys_pub_admin_dev
--

CREATE TABLE nrcan.seismic_reflect__regions (
    pk_lyr_id integer NOT NULL,
    "REGION_EN" character varying(80),
    "REGION_FR" character varying(80),
    "BATHYMETRY_CT" integer,
    "LOW_KHZ_BATHYMETRY_CT" integer,
    "SEISMIC_CT" integer,
    "SIDESCAN_CT" integer,
    "ANALYSES_CT" integer,
    geom public.geometry(Point,3978)
);


ALTER TABLE nrcan.seismic_reflect__regions OWNER TO cdtk_sys_pub_admin_dev;

--
-- Name: seismic_reflect__regions_pk_lyr_id_seq; Type: SEQUENCE; Schema: nrcan; Owner: cdtk_sys_pub_admin_dev
--

CREATE SEQUENCE nrcan.seismic_reflect__regions_pk_lyr_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE nrcan.seismic_reflect__regions_pk_lyr_id_seq OWNER TO cdtk_sys_pub_admin_dev;

--
-- Name: seismic_reflect__regions_pk_lyr_id_seq; Type: SEQUENCE OWNED BY; Schema: nrcan; Owner: cdtk_sys_pub_admin_dev
--

ALTER SEQUENCE nrcan.seismic_reflect__regions_pk_lyr_id_seq OWNED BY nrcan.seismic_reflect__regions.pk_lyr_id;


--
-- Name: layer_styles; Type: TABLE; Schema: public; Owner: cdtk_sys_pub_admin_dev
--

CREATE TABLE public.layer_styles (
    id integer NOT NULL,
    f_table_catalog character varying,
    f_table_schema character varying,
    f_table_name character varying,
    f_geometry_column character varying,
    stylename text,
    styleqml xml,
    stylesld xml,
    useasdefault boolean,
    description text,
    owner character varying(63) DEFAULT CURRENT_USER,
    ui xml,
    update_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    type character varying
);


ALTER TABLE public.layer_styles OWNER TO cdtk_sys_pub_admin_dev;

--
-- Name: layer_styles_id_seq; Type: SEQUENCE; Schema: public; Owner: cdtk_sys_pub_admin_dev
--

CREATE SEQUENCE public.layer_styles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.layer_styles_id_seq OWNER TO cdtk_sys_pub_admin_dev;

--
-- Name: layer_styles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cdtk_sys_pub_admin_dev
--

ALTER SEQUENCE public.layer_styles_id_seq OWNED BY public.layer_styles.id;


--
-- Name: users; Type: TABLE; Schema: qgis_sys; Owner: cdtk_sys_pub_admin_dev
--

CREATE TABLE qgis_sys.users (
    id integer NOT NULL,
    role integer DEFAULT 1 NOT NULL,
    email character varying(250) DEFAULT ''::character varying NOT NULL,
    usage character varying(250) DEFAULT 'User'::character varying NOT NULL
);


ALTER TABLE qgis_sys.users OWNER TO cdtk_sys_pub_admin_dev;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: qgis_sys; Owner: cdtk_sys_pub_admin_dev
--

CREATE SEQUENCE qgis_sys.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE qgis_sys.users_id_seq OWNER TO cdtk_sys_pub_admin_dev;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: qgis_sys; Owner: cdtk_sys_pub_admin_dev
--

ALTER SEQUENCE qgis_sys.users_id_seq OWNED BY qgis_sys.users.id;


--
-- Name: users_token_blacklist; Type: TABLE; Schema: qgis_sys; Owner: cdtk_sys_pub_admin_dev
--

CREATE TABLE qgis_sys.users_token_blacklist (
    id integer NOT NULL,
    jti_uid text NOT NULL,
    exp_date timestamp without time zone NOT NULL
);


ALTER TABLE qgis_sys.users_token_blacklist OWNER TO cdtk_sys_pub_admin_dev;

--
-- Name: users_token_blacklist_id_seq; Type: SEQUENCE; Schema: qgis_sys; Owner: cdtk_sys_pub_admin_dev
--

CREATE SEQUENCE qgis_sys.users_token_blacklist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE qgis_sys.users_token_blacklist_id_seq OWNER TO cdtk_sys_pub_admin_dev;

--
-- Name: users_token_blacklist_id_seq; Type: SEQUENCE OWNED BY; Schema: qgis_sys; Owner: cdtk_sys_pub_admin_dev
--

ALTER SEQUENCE qgis_sys.users_token_blacklist_id_seq OWNED BY qgis_sys.users_token_blacklist.id;


--
-- Name: v_count; Type: TABLE; Schema: qgis_sys; Owner: cdtk_sys_pub_admin_dev
--

CREATE TABLE qgis_sys.v_count (
    count bigint
);


ALTER TABLE qgis_sys.v_count OWNER TO cdtk_sys_pub_admin_dev;

--
-- Name: proximity_measu__proximity_measures_database; Type: TABLE; Schema: statcan; Owner: cdtk_sys_pub_admin_dev
--

CREATE TABLE statcan.proximity_measu__proximity_measures_database (
    pk_lyr_id integer NOT NULL,
    id bigint,
    prov_name_en character varying(100),
    prov_name_fr character varying(100),
    cd_name character varying(100),
    ccs_name character varying(100),
    cs_name character varying(100),
    er_name character varying(100),
    fed_name character varying(200),
    cma_name character varying(100),
    db_uid character varying(12),
    db_pop integer,
    employment_exists_en character varying(3),
    employment_exists_fr character varying(3),
    employment_prox double precision,
    pharma_exists_en character varying(3),
    pharma_exists_fr character varying(3),
    pharma_prox double precision,
    childcare_exists_en character varying(3),
    childcare_exists_fr character varying(3),
    childcare_prox double precision,
    health_exists_en character varying(3),
    health_exists_fr character varying(3),
    health_prox double precision,
    grocery_exists_en character varying(3),
    grocery_exists_fr character varying(3),
    grocery_prox double precision,
    educpri_exists_en character varying(3),
    educpri_exists_fr character varying(3),
    educpri_prox double precision,
    educsec_exists_en character varying(3),
    educsec_exists_fr character varying(3),
    educsec_prox double precision,
    library_exists_en character varying(3),
    library_exists_fr character varying(3),
    library_prox double precision,
    park_exists_en character varying(3),
    park_exists_fr character varying(3),
    park_prox double precision,
    transit_exists_en character varying(3),
    transit_exists_fr character varying(3),
    transit_prox double precision,
    geom public.geometry(MultiPolygon,3978)
);


ALTER TABLE statcan.proximity_measu__proximity_measures_database OWNER TO cdtk_sys_pub_admin_dev;

--
-- Name: proximity_measu__proximity_measures_database_centroids; Type: TABLE; Schema: statcan; Owner: cdtk_sys_pub_admin_dev
--

CREATE TABLE statcan.proximity_measu__proximity_measures_database_centroids (
    pk_lyr_id integer NOT NULL,
    db_uid character varying(12),
    employment_exists_en character varying(3),
    employment_exists_fr character varying(3),
    pharma_exists_en character varying(3),
    pharma_exists_fr character varying(3),
    childcare_exists_en character varying(3),
    childcare_exists_fr character varying(3),
    health_exists_en character varying(3),
    health_exists_fr character varying(3),
    grocery_exists_en character varying(3),
    grocery_exists_fr character varying(3),
    educpri_exists_en character varying(3),
    educpri_exists_fr character varying(3),
    educsec_exists_en character varying(3),
    educsec_exists_fr character varying(3),
    library_exists_en character varying(3),
    library_exists_fr character varying(3),
    park_exists_en character varying(3),
    park_exists_fr character varying(3),
    transit_exists_en character varying(3),
    transit_exists_fr character varying(3),
    geom public.geometry(Point,3978)
);


ALTER TABLE statcan.proximity_measu__proximity_measures_database_centroids OWNER TO cdtk_sys_pub_admin_dev;

--
-- Name: proximity_measu__proximity_measures_database_cent_pk_lyr_id_seq; Type: SEQUENCE; Schema: statcan; Owner: cdtk_sys_pub_admin_dev
--

CREATE SEQUENCE statcan.proximity_measu__proximity_measures_database_cent_pk_lyr_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE statcan.proximity_measu__proximity_measures_database_cent_pk_lyr_id_seq OWNER TO cdtk_sys_pub_admin_dev;

--
-- Name: proximity_measu__proximity_measures_database_cent_pk_lyr_id_seq; Type: SEQUENCE OWNED BY; Schema: statcan; Owner: cdtk_sys_pub_admin_dev
--

ALTER SEQUENCE statcan.proximity_measu__proximity_measures_database_cent_pk_lyr_id_seq OWNED BY statcan.proximity_measu__proximity_measures_database_centroids.pk_lyr_id;


--
-- Name: proximity_measu__proximity_measures_database_line; Type: TABLE; Schema: statcan; Owner: cdtk_sys_pub_admin_dev
--

CREATE TABLE statcan.proximity_measu__proximity_measures_database_line (
    pk_lyr_id integer NOT NULL,
    geom public.geometry(LineString,3978)
);


ALTER TABLE statcan.proximity_measu__proximity_measures_database_line OWNER TO cdtk_sys_pub_admin_dev;

--
-- Name: proximity_measu__proximity_measures_database_line_pk_lyr_id_seq; Type: SEQUENCE; Schema: statcan; Owner: cdtk_sys_pub_admin_dev
--

CREATE SEQUENCE statcan.proximity_measu__proximity_measures_database_line_pk_lyr_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE statcan.proximity_measu__proximity_measures_database_line_pk_lyr_id_seq OWNER TO cdtk_sys_pub_admin_dev;

--
-- Name: proximity_measu__proximity_measures_database_line_pk_lyr_id_seq; Type: SEQUENCE OWNED BY; Schema: statcan; Owner: cdtk_sys_pub_admin_dev
--

ALTER SEQUENCE statcan.proximity_measu__proximity_measures_database_line_pk_lyr_id_seq OWNED BY statcan.proximity_measu__proximity_measures_database_line.pk_lyr_id;


--
-- Name: proximity_measu__proximity_measures_database_pk_lyr_id_seq; Type: SEQUENCE; Schema: statcan; Owner: cdtk_sys_pub_admin_dev
--

CREATE SEQUENCE statcan.proximity_measu__proximity_measures_database_pk_lyr_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE statcan.proximity_measu__proximity_measures_database_pk_lyr_id_seq OWNER TO cdtk_sys_pub_admin_dev;

--
-- Name: proximity_measu__proximity_measures_database_pk_lyr_id_seq; Type: SEQUENCE OWNED BY; Schema: statcan; Owner: cdtk_sys_pub_admin_dev
--

ALTER SEQUENCE statcan.proximity_measu__proximity_measures_database_pk_lyr_id_seq OWNED BY statcan.proximity_measu__proximity_measures_database.pk_lyr_id;


--
-- Name: qgis_projects; Type: TABLE; Schema: statcan; Owner: cdtk_sys_pub_admin_dev
--

CREATE TABLE statcan.qgis_projects (
    name text NOT NULL,
    metadata jsonb,
    content bytea
);


ALTER TABLE statcan.qgis_projects OWNER TO cdtk_sys_pub_admin_dev;

--
-- Name: assessment_inve__iaac_assessments_pt pk_lyr_id; Type: DEFAULT; Schema: nrcan; Owner: cdtk_sys_pub_admin_dev
--

ALTER TABLE ONLY nrcan.assessment_inve__iaac_assessments_pt ALTER COLUMN pk_lyr_id SET DEFAULT nextval('nrcan.assessment_inve__iaac_assessments_pt_pk_lyr_id_seq'::regclass);


--
-- Name: seismic_reflect__imagery_imagerie pk_lyr_id; Type: DEFAULT; Schema: nrcan; Owner: cdtk_sys_pub_admin_dev
--

ALTER TABLE ONLY nrcan.seismic_reflect__imagery_imagerie ALTER COLUMN pk_lyr_id SET DEFAULT nextval('nrcan.seismic_reflect__imagery_imagerie_pk_lyr_id_seq'::regclass);


--
-- Name: seismic_reflect__regions pk_lyr_id; Type: DEFAULT; Schema: nrcan; Owner: cdtk_sys_pub_admin_dev
--

ALTER TABLE ONLY nrcan.seismic_reflect__regions ALTER COLUMN pk_lyr_id SET DEFAULT nextval('nrcan.seismic_reflect__regions_pk_lyr_id_seq'::regclass);


--
-- Name: layer_styles id; Type: DEFAULT; Schema: public; Owner: cdtk_sys_pub_admin_dev
--

ALTER TABLE ONLY public.layer_styles ALTER COLUMN id SET DEFAULT nextval('public.layer_styles_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: qgis_sys; Owner: cdtk_sys_pub_admin_dev
--

ALTER TABLE ONLY qgis_sys.users ALTER COLUMN id SET DEFAULT nextval('qgis_sys.users_id_seq'::regclass);


--
-- Name: users_token_blacklist id; Type: DEFAULT; Schema: qgis_sys; Owner: cdtk_sys_pub_admin_dev
--

ALTER TABLE ONLY qgis_sys.users_token_blacklist ALTER COLUMN id SET DEFAULT nextval('qgis_sys.users_token_blacklist_id_seq'::regclass);


--
-- Name: proximity_measu__proximity_measures_database pk_lyr_id; Type: DEFAULT; Schema: statcan; Owner: cdtk_sys_pub_admin_dev
--

ALTER TABLE ONLY statcan.proximity_measu__proximity_measures_database ALTER COLUMN pk_lyr_id SET DEFAULT nextval('statcan.proximity_measu__proximity_measures_database_pk_lyr_id_seq'::regclass);


--
-- Name: proximity_measu__proximity_measures_database_centroids pk_lyr_id; Type: DEFAULT; Schema: statcan; Owner: cdtk_sys_pub_admin_dev
--

ALTER TABLE ONLY statcan.proximity_measu__proximity_measures_database_centroids ALTER COLUMN pk_lyr_id SET DEFAULT nextval('statcan.proximity_measu__proximity_measures_database_cent_pk_lyr_id_seq'::regclass);


--
-- Name: proximity_measu__proximity_measures_database_line pk_lyr_id; Type: DEFAULT; Schema: statcan; Owner: cdtk_sys_pub_admin_dev
--

ALTER TABLE ONLY statcan.proximity_measu__proximity_measures_database_line ALTER COLUMN pk_lyr_id SET DEFAULT nextval('statcan.proximity_measu__proximity_measures_database_line_pk_lyr_id_seq'::regclass);


--
-- Name: qgis_projects qgis_projects_pkey; Type: CONSTRAINT; Schema: cannor; Owner: cdtk_sys_pub_admin_dev
--

ALTER TABLE ONLY cannor.qgis_projects
    ADD CONSTRAINT qgis_projects_pkey PRIMARY KEY (name);


--
-- Name: qgis_projects qgis_projects_pkey; Type: CONSTRAINT; Schema: iaac; Owner: cdtk_sys_pub_admin_dev
--

ALTER TABLE ONLY iaac.qgis_projects
    ADD CONSTRAINT qgis_projects_pkey PRIMARY KEY (name);


--
-- Name: assessment_inve__iaac_assessments_pt assessment_inve__iaac_assessments_pt_pkey; Type: CONSTRAINT; Schema: nrcan; Owner: cdtk_sys_pub_admin_dev
--

ALTER TABLE ONLY nrcan.assessment_inve__iaac_assessments_pt
    ADD CONSTRAINT assessment_inve__iaac_assessments_pt_pkey PRIMARY KEY (pk_lyr_id);


--
-- Name: qgis_projects qgis_projects_pkey; Type: CONSTRAINT; Schema: nrcan; Owner: cdtk_sys_pub_admin_dev
--

ALTER TABLE ONLY nrcan.qgis_projects
    ADD CONSTRAINT qgis_projects_pkey PRIMARY KEY (name);


--
-- Name: seismic_reflect__imagery_imagerie seismic_reflect__imagery_imagerie_pkey; Type: CONSTRAINT; Schema: nrcan; Owner: cdtk_sys_pub_admin_dev
--

ALTER TABLE ONLY nrcan.seismic_reflect__imagery_imagerie
    ADD CONSTRAINT seismic_reflect__imagery_imagerie_pkey PRIMARY KEY (pk_lyr_id);


--
-- Name: seismic_reflect__regions seismic_reflect__regions_pkey; Type: CONSTRAINT; Schema: nrcan; Owner: cdtk_sys_pub_admin_dev
--

ALTER TABLE ONLY nrcan.seismic_reflect__regions
    ADD CONSTRAINT seismic_reflect__regions_pkey PRIMARY KEY (pk_lyr_id);


--
-- Name: layer_styles layer_styles_pkey; Type: CONSTRAINT; Schema: public; Owner: cdtk_sys_pub_admin_dev
--

ALTER TABLE ONLY public.layer_styles
    ADD CONSTRAINT layer_styles_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: qgis_sys; Owner: cdtk_sys_pub_admin_dev
--

ALTER TABLE ONLY qgis_sys.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users_token_blacklist users_token_blacklist_pkey; Type: CONSTRAINT; Schema: qgis_sys; Owner: cdtk_sys_pub_admin_dev
--

ALTER TABLE ONLY qgis_sys.users_token_blacklist
    ADD CONSTRAINT users_token_blacklist_pkey PRIMARY KEY (id);


--
-- Name: proximity_measu__proximity_measures_database_centroids proximity_measu__proximity_measures_database_centroids_pkey; Type: CONSTRAINT; Schema: statcan; Owner: cdtk_sys_pub_admin_dev
--

ALTER TABLE ONLY statcan.proximity_measu__proximity_measures_database_centroids
    ADD CONSTRAINT proximity_measu__proximity_measures_database_centroids_pkey PRIMARY KEY (pk_lyr_id);


--
-- Name: proximity_measu__proximity_measures_database_line proximity_measu__proximity_measures_database_line_pkey; Type: CONSTRAINT; Schema: statcan; Owner: cdtk_sys_pub_admin_dev
--

ALTER TABLE ONLY statcan.proximity_measu__proximity_measures_database_line
    ADD CONSTRAINT proximity_measu__proximity_measures_database_line_pkey PRIMARY KEY (pk_lyr_id);


--
-- Name: proximity_measu__proximity_measures_database proximity_measu__proximity_measures_database_pkey; Type: CONSTRAINT; Schema: statcan; Owner: cdtk_sys_pub_admin_dev
--

ALTER TABLE ONLY statcan.proximity_measu__proximity_measures_database
    ADD CONSTRAINT proximity_measu__proximity_measures_database_pkey PRIMARY KEY (pk_lyr_id);


--
-- Name: qgis_projects qgis_projects_pkey; Type: CONSTRAINT; Schema: statcan; Owner: cdtk_sys_pub_admin_dev
--

ALTER TABLE ONLY statcan.qgis_projects
    ADD CONSTRAINT qgis_projects_pkey PRIMARY KEY (name);


--
-- Name: assessment_inve__iaac_assessments_pt_geom_geom_idx; Type: INDEX; Schema: nrcan; Owner: cdtk_sys_pub_admin_dev
--

CREATE INDEX assessment_inve__iaac_assessments_pt_geom_geom_idx ON nrcan.assessment_inve__iaac_assessments_pt USING gist (geom);


--
-- Name: seismic_reflect__imagery_imagerie_geom_geom_idx; Type: INDEX; Schema: nrcan; Owner: cdtk_sys_pub_admin_dev
--

CREATE INDEX seismic_reflect__imagery_imagerie_geom_geom_idx ON nrcan.seismic_reflect__imagery_imagerie USING gist (geom);


--
-- Name: seismic_reflect__regions_geom_geom_idx; Type: INDEX; Schema: nrcan; Owner: cdtk_sys_pub_admin_dev
--

CREATE INDEX seismic_reflect__regions_geom_geom_idx ON nrcan.seismic_reflect__regions USING gist (geom);


--
-- Name: proximity_measu__proximity_measures_database_centroids_geom_geo; Type: INDEX; Schema: statcan; Owner: cdtk_sys_pub_admin_dev
--

CREATE INDEX proximity_measu__proximity_measures_database_centroids_geom_geo ON statcan.proximity_measu__proximity_measures_database_centroids USING gist (geom);


--
-- Name: proximity_measu__proximity_measures_database_geom_geom_idx; Type: INDEX; Schema: statcan; Owner: cdtk_sys_pub_admin_dev
--

CREATE INDEX proximity_measu__proximity_measures_database_geom_geom_idx ON statcan.proximity_measu__proximity_measures_database USING gist (geom);


--
-- Name: proximity_measu__proximity_measures_database_line_geom_geom_idx; Type: INDEX; Schema: statcan; Owner: cdtk_sys_pub_admin_dev
--

CREATE INDEX proximity_measu__proximity_measures_database_line_geom_geom_idx ON statcan.proximity_measu__proximity_measures_database_line USING gist (geom);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- Name: SCHEMA topology; Type: ACL; Schema: -; Owner: pgsql
--

GRANT ALL ON SCHEMA topology TO cdtk_sys_pub_admin_dev;
GRANT USAGE ON SCHEMA topology TO editors;
GRANT USAGE ON SCHEMA topology TO viewers;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: topology; Owner: pgsql
--

ALTER DEFAULT PRIVILEGES FOR ROLE pgsql IN SCHEMA topology GRANT ALL ON TABLES TO editors;
ALTER DEFAULT PRIVILEGES FOR ROLE pgsql IN SCHEMA topology GRANT ALL ON TABLES TO viewers;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: -; Owner: pgsql
--

ALTER DEFAULT PRIVILEGES FOR ROLE pgsql GRANT ALL ON TABLES TO cdtk_sys_pub_admin_dev;
ALTER DEFAULT PRIVILEGES FOR ROLE pgsql GRANT SELECT ON TABLES TO cdtk_sys_pub_view_dev;


--
-- PostgreSQL database dump complete
--

